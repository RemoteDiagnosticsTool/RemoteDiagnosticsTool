﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class RemoteRegistry
    Inherits MetroFramework.Forms.MetroForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(RemoteRegistry))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.DatagridviewRegistryValuesClick = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.NewValueToAdd = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddStringValue1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddBinaryValue1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddDwordValue1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddQwordValue1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddMultiStringValue1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddExpandableStringValue1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.DeleteMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.DeleteValue = New System.Windows.Forms.ToolStripMenuItem()
        Me.ImageList2 = New System.Windows.Forms.ImageList(Me.components)
        Me.TreeviewKeysRightClick = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.Add_Key = New System.Windows.Forms.ToolStripMenuItem()
        Me.Rename_Key = New System.Windows.Forms.ToolStripMenuItem()
        Me.Delete_Key = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.Export_Key = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.CopyKeyName = New System.Windows.Forms.ToolStripMenuItem()
        Me.Copy_Key_FullPath = New System.Windows.Forms.ToolStripMenuItem()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.StatusStrip2 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.TreeViewKeys = New System.Windows.Forms.TreeView()
        Me.DataGridViewValues = New System.Windows.Forms.DataGridView()
        Me.ValuesName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ValuesType = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ValuesData = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.RegistryBox1 = New System.Windows.Forms.ComboBox()
        Me.CurrentUserlabel = New System.Windows.Forms.Label()
        Me.MetroLabel1 = New MetroFramework.Controls.MetroLabel()
        Me.Refreshed = New MetroFramework.Controls.MetroTile()
        Me.ClearRegistryLists = New MetroFramework.Controls.MetroTile()
        Me.DatagridviewRegistryValuesClick.SuspendLayout()
        Me.TreeviewKeysRightClick.SuspendLayout()
        Me.StatusStrip2.SuspendLayout()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        CType(Me.DataGridViewValues, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DatagridviewRegistryValuesClick
        '
        Me.DatagridviewRegistryValuesClick.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewValueToAdd, Me.ToolStripSeparator3, Me.DeleteMenu})
        Me.DatagridviewRegistryValuesClick.Name = "DatagridviewRegistryValuesClick"
        Me.DatagridviewRegistryValuesClick.Size = New System.Drawing.Size(108, 54)
        '
        'NewValueToAdd
        '
        Me.NewValueToAdd.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AddStringValue1, Me.AddBinaryValue1, Me.AddDwordValue1, Me.AddQwordValue1, Me.AddMultiStringValue1, Me.AddExpandableStringValue1})
        Me.NewValueToAdd.Image = CType(resources.GetObject("NewValueToAdd.Image"), System.Drawing.Image)
        Me.NewValueToAdd.Name = "NewValueToAdd"
        Me.NewValueToAdd.Size = New System.Drawing.Size(107, 22)
        Me.NewValueToAdd.Text = "New"
        '
        'AddStringValue1
        '
        Me.AddStringValue1.ForeColor = System.Drawing.Color.DarkRed
        Me.AddStringValue1.Name = "AddStringValue1"
        Me.AddStringValue1.Size = New System.Drawing.Size(199, 22)
        Me.AddStringValue1.Text = "String Value"
        '
        'AddBinaryValue1
        '
        Me.AddBinaryValue1.Name = "AddBinaryValue1"
        Me.AddBinaryValue1.Size = New System.Drawing.Size(199, 22)
        Me.AddBinaryValue1.Text = "Binary Value"
        '
        'AddDwordValue1
        '
        Me.AddDwordValue1.ForeColor = System.Drawing.Color.DarkBlue
        Me.AddDwordValue1.Name = "AddDwordValue1"
        Me.AddDwordValue1.Size = New System.Drawing.Size(199, 22)
        Me.AddDwordValue1.Text = "Dword (32 bit) Value"
        '
        'AddQwordValue1
        '
        Me.AddQwordValue1.ForeColor = System.Drawing.Color.DarkSlateBlue
        Me.AddQwordValue1.Name = "AddQwordValue1"
        Me.AddQwordValue1.Size = New System.Drawing.Size(199, 22)
        Me.AddQwordValue1.Text = "Qword (64 bit) Value"
        '
        'AddMultiStringValue1
        '
        Me.AddMultiStringValue1.ForeColor = System.Drawing.Color.DarkViolet
        Me.AddMultiStringValue1.Name = "AddMultiStringValue1"
        Me.AddMultiStringValue1.Size = New System.Drawing.Size(199, 22)
        Me.AddMultiStringValue1.Text = "Multi-String Value"
        '
        'AddExpandableStringValue1
        '
        Me.AddExpandableStringValue1.ForeColor = System.Drawing.Color.DarkOliveGreen
        Me.AddExpandableStringValue1.Name = "AddExpandableStringValue1"
        Me.AddExpandableStringValue1.Size = New System.Drawing.Size(199, 22)
        Me.AddExpandableStringValue1.Text = "Expandable String Value"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(104, 6)
        '
        'DeleteMenu
        '
        Me.DeleteMenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DeleteValue})
        Me.DeleteMenu.Image = CType(resources.GetObject("DeleteMenu.Image"), System.Drawing.Image)
        Me.DeleteMenu.Name = "DeleteMenu"
        Me.DeleteMenu.Size = New System.Drawing.Size(107, 22)
        Me.DeleteMenu.Text = "Delete"
        '
        'DeleteValue
        '
        Me.DeleteValue.ForeColor = System.Drawing.Color.DarkRed
        Me.DeleteValue.Name = "DeleteValue"
        Me.DeleteValue.Size = New System.Drawing.Size(139, 22)
        Me.DeleteValue.Text = "Whole Value"
        '
        'ImageList2
        '
        Me.ImageList2.ImageStream = CType(resources.GetObject("ImageList2.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList2.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList2.Images.SetKeyName(0, "regedit_205.ico")
        Me.ImageList2.Images.SetKeyName(1, "regedit_206.ico")
        '
        'TreeviewKeysRightClick
        '
        Me.TreeviewKeysRightClick.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Add_Key, Me.Rename_Key, Me.Delete_Key, Me.ToolStripSeparator1, Me.Export_Key, Me.ToolStripSeparator2, Me.CopyKeyName, Me.Copy_Key_FullPath})
        Me.TreeviewKeysRightClick.Name = "TreeviewKeysRightClick"
        Me.TreeviewKeysRightClick.Size = New System.Drawing.Size(174, 148)
        '
        'Add_Key
        '
        Me.Add_Key.Image = CType(resources.GetObject("Add_Key.Image"), System.Drawing.Image)
        Me.Add_Key.Name = "Add_Key"
        Me.Add_Key.Size = New System.Drawing.Size(173, 22)
        Me.Add_Key.Text = "Add Key"
        '
        'Rename_Key
        '
        Me.Rename_Key.Image = CType(resources.GetObject("Rename_Key.Image"), System.Drawing.Image)
        Me.Rename_Key.Name = "Rename_Key"
        Me.Rename_Key.Size = New System.Drawing.Size(173, 22)
        Me.Rename_Key.Text = "Rename Key"
        '
        'Delete_Key
        '
        Me.Delete_Key.Image = CType(resources.GetObject("Delete_Key.Image"), System.Drawing.Image)
        Me.Delete_Key.Name = "Delete_Key"
        Me.Delete_Key.Size = New System.Drawing.Size(173, 22)
        Me.Delete_Key.Text = "Delete Key"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(170, 6)
        '
        'Export_Key
        '
        Me.Export_Key.Image = CType(resources.GetObject("Export_Key.Image"), System.Drawing.Image)
        Me.Export_Key.Name = "Export_Key"
        Me.Export_Key.Size = New System.Drawing.Size(173, 22)
        Me.Export_Key.Text = "Export Key"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(170, 6)
        '
        'CopyKeyName
        '
        Me.CopyKeyName.Image = CType(resources.GetObject("CopyKeyName.Image"), System.Drawing.Image)
        Me.CopyKeyName.Name = "CopyKeyName"
        Me.CopyKeyName.Size = New System.Drawing.Size(173, 22)
        Me.CopyKeyName.Text = "Copy Key Name"
        '
        'Copy_Key_FullPath
        '
        Me.Copy_Key_FullPath.Image = CType(resources.GetObject("Copy_Key_FullPath.Image"), System.Drawing.Image)
        Me.Copy_Key_FullPath.Name = "Copy_Key_FullPath"
        Me.Copy_Key_FullPath.Size = New System.Drawing.Size(173, 22)
        Me.Copy_Key_FullPath.Text = "Copy Key Full Path"
        '
        'ImageList1
        '
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList1.Images.SetKeyName(0, "Franksouza183-Fs-Places-folder-yellow.ico")
        Me.ImageList1.Images.SetKeyName(1, "Franksouza183-Fs-Places-folder-add.ico")
        '
        'StatusStrip2
        '
        Me.StatusStrip2.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StatusStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel2})
        Me.StatusStrip2.Location = New System.Drawing.Point(20, 558)
        Me.StatusStrip2.Name = "StatusStrip2"
        Me.StatusStrip2.Size = New System.Drawing.Size(984, 22)
        Me.StatusStrip2.TabIndex = 137
        Me.StatusStrip2.Text = "StatusStrip2"
        '
        'ToolStripStatusLabel2
        '
        Me.ToolStripStatusLabel2.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripStatusLabel2.Name = "ToolStripStatusLabel2"
        Me.ToolStripStatusLabel2.Size = New System.Drawing.Size(126, 17)
        Me.ToolStripStatusLabel2.Text = "ToolStripStatusLabel2"
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.Location = New System.Drawing.Point(20, 60)
        Me.SplitContainer1.Name = "SplitContainer1"
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.TreeViewKeys)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.DataGridViewValues)
        Me.SplitContainer1.Size = New System.Drawing.Size(984, 498)
        Me.SplitContainer1.SplitterDistance = 377
        Me.SplitContainer1.TabIndex = 138
        '
        'TreeViewKeys
        '
        Me.TreeViewKeys.ContextMenuStrip = Me.TreeviewKeysRightClick
        Me.TreeViewKeys.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TreeViewKeys.FullRowSelect = True
        Me.TreeViewKeys.ImageIndex = 0
        Me.TreeViewKeys.ImageList = Me.ImageList1
        Me.TreeViewKeys.Location = New System.Drawing.Point(0, 0)
        Me.TreeViewKeys.Name = "TreeViewKeys"
        Me.TreeViewKeys.SelectedImageIndex = 0
        Me.TreeViewKeys.Size = New System.Drawing.Size(377, 498)
        Me.TreeViewKeys.TabIndex = 130
        '
        'DataGridViewValues
        '
        Me.DataGridViewValues.AllowUserToAddRows = False
        Me.DataGridViewValues.AllowUserToDeleteRows = False
        Me.DataGridViewValues.AllowUserToResizeRows = False
        Me.DataGridViewValues.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells
        Me.DataGridViewValues.BackgroundColor = System.Drawing.Color.White
        Me.DataGridViewValues.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.DataGridViewValues.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.ValuesName, Me.ValuesType, Me.ValuesData})
        Me.DataGridViewValues.ContextMenuStrip = Me.DatagridviewRegistryValuesClick
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Tahoma", 8.25!)
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.LightSkyBlue
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridViewValues.DefaultCellStyle = DataGridViewCellStyle1
        Me.DataGridViewValues.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DataGridViewValues.Location = New System.Drawing.Point(0, 0)
        Me.DataGridViewValues.MultiSelect = False
        Me.DataGridViewValues.Name = "DataGridViewValues"
        Me.DataGridViewValues.RowHeadersVisible = False
        Me.DataGridViewValues.RowHeadersWidth = 25
        Me.DataGridViewValues.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridViewValues.ShowCellErrors = False
        Me.DataGridViewValues.ShowCellToolTips = False
        Me.DataGridViewValues.ShowEditingIcon = False
        Me.DataGridViewValues.ShowRowErrors = False
        Me.DataGridViewValues.Size = New System.Drawing.Size(603, 498)
        Me.DataGridViewValues.TabIndex = 0
        '
        'ValuesName
        '
        Me.ValuesName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells
        Me.ValuesName.FillWeight = 138.1565!
        Me.ValuesName.HeaderText = "Name"
        Me.ValuesName.MinimumWidth = 150
        Me.ValuesName.Name = "ValuesName"
        Me.ValuesName.Width = 150
        '
        'ValuesType
        '
        Me.ValuesType.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells
        Me.ValuesType.FillWeight = 101.5228!
        Me.ValuesType.HeaderText = "Type"
        Me.ValuesType.MinimumWidth = 100
        Me.ValuesType.Name = "ValuesType"
        Me.ValuesType.ReadOnly = True
        '
        'ValuesData
        '
        Me.ValuesData.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells
        Me.ValuesData.FillWeight = 138.1565!
        Me.ValuesData.HeaderText = "Data"
        Me.ValuesData.MinimumWidth = 1920
        Me.ValuesData.Name = "ValuesData"
        Me.ValuesData.Width = 1920
        '
        'RegistryBox1
        '
        Me.RegistryBox1.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.RegistryBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.RegistryBox1.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RegistryBox1.FormattingEnabled = True
        Me.RegistryBox1.Items.AddRange(New Object() {"LocalMachine", "CurrentUser"})
        Me.RegistryBox1.Location = New System.Drawing.Point(403, 26)
        Me.RegistryBox1.Name = "RegistryBox1"
        Me.RegistryBox1.Size = New System.Drawing.Size(135, 27)
        Me.RegistryBox1.TabIndex = 139
        '
        'CurrentUserlabel
        '
        Me.CurrentUserlabel.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.CurrentUserlabel.AutoSize = True
        Me.CurrentUserlabel.BackColor = System.Drawing.Color.Transparent
        Me.CurrentUserlabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CurrentUserlabel.ForeColor = System.Drawing.Color.Black
        Me.CurrentUserlabel.Location = New System.Drawing.Point(544, 26)
        Me.CurrentUserlabel.Name = "CurrentUserlabel"
        Me.CurrentUserlabel.Size = New System.Drawing.Size(0, 20)
        Me.CurrentUserlabel.TabIndex = 141
        '
        'MetroLabel1
        '
        Me.MetroLabel1.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.MetroLabel1.AutoSize = True
        Me.MetroLabel1.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.MetroLabel1.Location = New System.Drawing.Point(341, 27)
        Me.MetroLabel1.Name = "MetroLabel1"
        Me.MetroLabel1.Size = New System.Drawing.Size(56, 19)
        Me.MetroLabel1.TabIndex = 144
        Me.MetroLabel1.Text = "Select >"
        Me.MetroLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.MetroLabel1.UseCustomForeColor = True
        '
        'Refreshed
        '
        Me.Refreshed.ActiveControl = Nothing
        Me.Refreshed.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Refreshed.BackColor = System.Drawing.Color.AliceBlue
        Me.Refreshed.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.Refreshed.Location = New System.Drawing.Point(826, 28)
        Me.Refreshed.Name = "Refreshed"
        Me.Refreshed.Size = New System.Drawing.Size(89, 26)
        Me.Refreshed.TabIndex = 145
        Me.Refreshed.Text = "Refresh (F5)"
        Me.Refreshed.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Refreshed.TileTextFontSize = MetroFramework.MetroTileTextSize.Small
        Me.Refreshed.UseCustomBackColor = True
        Me.Refreshed.UseCustomForeColor = True
        Me.Refreshed.UseSelectable = True
        '
        'ClearRegistryLists
        '
        Me.ClearRegistryLists.ActiveControl = Nothing
        Me.ClearRegistryLists.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ClearRegistryLists.BackColor = System.Drawing.Color.AliceBlue
        Me.ClearRegistryLists.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.ClearRegistryLists.Location = New System.Drawing.Point(921, 28)
        Me.ClearRegistryLists.Name = "ClearRegistryLists"
        Me.ClearRegistryLists.Size = New System.Drawing.Size(83, 26)
        Me.ClearRegistryLists.TabIndex = 146
        Me.ClearRegistryLists.Text = "Clear All"
        Me.ClearRegistryLists.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ClearRegistryLists.TileTextFontSize = MetroFramework.MetroTileTextSize.Small
        Me.ClearRegistryLists.UseCustomBackColor = True
        Me.ClearRegistryLists.UseCustomForeColor = True
        Me.ClearRegistryLists.UseSelectable = True
        '
        'RemoteRegistry
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BorderStyle = MetroFramework.Forms.MetroFormBorderStyle.FixedSingle
        Me.ClientSize = New System.Drawing.Size(1024, 600)
        Me.Controls.Add(Me.ClearRegistryLists)
        Me.Controls.Add(Me.Refreshed)
        Me.Controls.Add(Me.MetroLabel1)
        Me.Controls.Add(Me.RegistryBox1)
        Me.Controls.Add(Me.CurrentUserlabel)
        Me.Controls.Add(Me.SplitContainer1)
        Me.Controls.Add(Me.StatusStrip2)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "RemoteRegistry"
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
        Me.DatagridviewRegistryValuesClick.ResumeLayout(False)
        Me.TreeviewKeysRightClick.ResumeLayout(False)
        Me.StatusStrip2.ResumeLayout(False)
        Me.StatusStrip2.PerformLayout()
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.ResumeLayout(False)
        CType(Me.DataGridViewValues, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents DatagridviewRegistryValuesClick As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents NewValueToAdd As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AddStringValue1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AddBinaryValue1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AddDwordValue1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AddQwordValue1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AddMultiStringValue1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AddExpandableStringValue1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents DeleteMenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DeleteValue As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ImageList2 As System.Windows.Forms.ImageList
    Friend WithEvents TreeviewKeysRightClick As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents Add_Key As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Rename_Key As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Delete_Key As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Export_Key As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents CopyKeyName As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Copy_Key_FullPath As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ImageList1 As System.Windows.Forms.ImageList
    Friend WithEvents StatusStrip2 As System.Windows.Forms.StatusStrip
    Friend WithEvents ToolStripStatusLabel2 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents TreeViewKeys As System.Windows.Forms.TreeView
    Friend WithEvents DataGridViewValues As System.Windows.Forms.DataGridView
    Friend WithEvents ValuesName As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ValuesType As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ValuesData As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents RegistryBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents CurrentUserlabel As System.Windows.Forms.Label
    Friend WithEvents MetroLabel1 As MetroFramework.Controls.MetroLabel
    Friend WithEvents Refreshed As MetroFramework.Controls.MetroTile
    Friend WithEvents ClearRegistryLists As MetroFramework.Controls.MetroTile
End Class
