Public Class cliConnector

    Private IsConnectionSuccessful As Boolean = False
    Private socketexception As Exception
    Private TimeoutObject As New Threading.ManualResetEvent(False)

    Public Function Connect(ByVal remoteEndPoint As Net.IPEndPoint, ByVal timeoutMSec As Integer) As Net.Sockets.TcpClient
        TimeoutObject.Reset()
        socketexception = Nothing

        Dim serverip As String = remoteEndPoint.Address.ToString
        Dim serverPort As Integer = remoteEndPoint.Port
        Dim tcpCli As New Net.Sockets.TcpClient

        tcpCli.BeginConnect(serverip, serverPort, New AsyncCallback(AddressOf CallBackMethod), tcpCli)

        If TimeoutObject.WaitOne(timeoutMSec, False) Then
            If IsConnectionSuccessful Then
                Return tcpCli
            Else
                Throw socketexception
            End If
        Else
            tcpCli.Close()
            Throw New TimeoutException("Connection attempt Timed Out")
        End If

    End Function

    Private Sub CallBackMethod(ByVal asyncResult As IAsyncResult)
        Try
            IsConnectionSuccessful = False
            Dim tcpCli As Net.Sockets.TcpClient = CType(asyncResult.AsyncState, Net.Sockets.TcpClient)
            If Not tcpCli Is Nothing Then
                tcpCli.EndConnect(asyncResult)
                IsConnectionSuccessful = True
            End If
        Catch ex As Exception
            IsConnectionSuccessful = False
            socketexception = ex
        Finally
            TimeoutObject.Set()
        End Try
    End Sub
End Class
