Imports System.ComponentModel

Public Class Form1
    Inherits MetroFramework.Forms.MetroForm

    Dim txtusername As String
    Dim txtpassword As String
    Dim txtdomain As String

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Useloggedonuser.Checked = False
        username.Focus()
        Activate()
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Dim response As MsgBoxResult
        response = MsgBox("Do you want to close this application down?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "Confirm")
        If response = MsgBoxResult.Yes Then
            Try
                'Dim sResult As String
                Dim objShell = CreateObject("Wscript.Shell")
                Try
                    'sResult = objShell.run("cmd /c net use * /d /y", 0, True)
                Catch ex As Exception
                End Try
            Catch
            End Try
            Dim pProcess() As Process = System.Diagnostics.Process.GetProcessesByName("RDT.exe")
            For Each p As Process In pProcess
                p.Kill()
            Next
            Me.Dispose()
        ElseIf response = MsgBoxResult.No Then
            e.Cancel = True
            Exit Sub
        End If
    End Sub

    Private Sub username_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles username.TextChanged
    End Sub

    Private Sub password_MaskInputRejected(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MaskInputRejectedEventArgs) Handles password.MaskInputRejected
    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click, MyBase.Enter, Button1.Enter
        If Useloggedonuser.Checked = False Then
            If username.Text = "" Then
                MsgBox("Your ""Username"" must be set properly and cannot be blank. Please input your account details correctly!")
                Exit Sub
            End If
            If password.Text = "" Then
                MsgBox("Your ""Password"" must be set properly and cannot be blank. Please input your account details correctly!")
                Exit Sub
            End If
            If Domain.Text = "" Then
                MsgBox("Your ""Domain"" must be set properly and cannot be blank. Please input your account details correctly!")
                Exit Sub
            End If
            txtusername = username.Text.ToLower
            txtpassword = password.Text
            txtdomain = Domain.Text.ToLower
        Else
            txtusername = Environment.GetEnvironmentVariable("USERNAME").ToLower
            txtdomain = Environment.GetEnvironmentVariable("USERDOMAIN").ToLower

            Passwordbox.ShowDialog()
            txtpassword = GlobalVariables.password

        End If

        Dim form5 As New Form5()
        form5.PassParam(txtusername, txtpassword, txtdomain)
        Me.Cursor = Cursors.Default
        Try
            form5.Show() 'or form.ShowDialog() for Modal forms
        Catch ex As InvalidOperationException
            form5.Show()
        End Try
        Me.Hide() 'or form.ShowDialog() for Modal forms

    End Sub

End Class
