<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form2))
        Me.Label1 = New System.Windows.Forms.Label
        Me.PCname = New System.Windows.Forms.TextBox
        Me.Button1 = New System.Windows.Forms.Button
        Me.Button2 = New System.Windows.Forms.Button
        Me.GetBasicText = New System.Windows.Forms.Label
        Me.GetBasicOut = New System.Windows.Forms.Label
        Me.GetKeysCSC_Button = New System.Windows.Forms.Button
        Me.GetSoftwareList = New System.Windows.Forms.Button
        Me.DataGridView1 = New System.Windows.Forms.DataGridView
        Me.SoftwareName = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.SoftwareVersion = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.InstallDate = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.KeyName = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewCSCPackages = New System.Windows.Forms.DataGridView
        Me.PackageName = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Installed = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.BrowseAppslogs = New System.Windows.Forms.Button
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.MSIUNINSTALL = New System.Windows.Forms.Button
        Me.GreenlnkSD = New System.Windows.Forms.ListBox
        Me.greenlnklistpackages = New System.Windows.Forms.Button
        Me.GreenlnkSDBOX = New System.Windows.Forms.TextBox
        Me.InstallSoftware = New System.Windows.Forms.Button
        Me.RemoveSoftware = New System.Windows.Forms.Button
        Me.Alive = New System.Windows.Forms.TextBox
        Me.COmmand1 = New System.Windows.Forms.Button
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar
        Me.Button3 = New System.Windows.Forms.Button
        Me.Host = New System.Windows.Forms.Label
        Me.Reboot = New System.Windows.Forms.Label
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridViewCSCPackages, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(13, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(87, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Enter PC name >"
        '
        'PCname
        '
        Me.PCname.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PCname.ForeColor = System.Drawing.SystemColors.WindowText
        Me.PCname.Location = New System.Drawing.Point(97, 13)
        Me.PCname.Name = "PCname"
        Me.PCname.Size = New System.Drawing.Size(185, 20)
        Me.PCname.TabIndex = 1
        '
        'Button1
        '
        Me.Button1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button1.AutoSize = True
        Me.Button1.Location = New System.Drawing.Point(882, 11)
        Me.Button1.Name = "Button1"
        Me.Button1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Button1.Size = New System.Drawing.Size(114, 23)
        Me.Button1.TabIndex = 3
        Me.Button1.Text = "Enter Username"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.AutoSize = True
        Me.Button2.Location = New System.Drawing.Point(633, 11)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(101, 23)
        Me.Button2.TabIndex = 2
        Me.Button2.Text = "Get basic details"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'GetBasicText
        '
        Me.GetBasicText.AutoSize = True
        Me.GetBasicText.Location = New System.Drawing.Point(503, 40)
        Me.GetBasicText.Name = "GetBasicText"
        Me.GetBasicText.Size = New System.Drawing.Size(0, 13)
        Me.GetBasicText.TabIndex = 4
        '
        'GetBasicOut
        '
        Me.GetBasicOut.AutoSize = True
        Me.GetBasicOut.Location = New System.Drawing.Point(645, 40)
        Me.GetBasicOut.Name = "GetBasicOut"
        Me.GetBasicOut.Size = New System.Drawing.Size(0, 13)
        Me.GetBasicOut.TabIndex = 5
        '
        'GetKeysCSC_Button
        '
        Me.GetKeysCSC_Button.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.GetKeysCSC_Button.AutoSize = True
        Me.GetKeysCSC_Button.Location = New System.Drawing.Point(520, 416)
        Me.GetKeysCSC_Button.Name = "GetKeysCSC_Button"
        Me.GetKeysCSC_Button.Size = New System.Drawing.Size(128, 23)
        Me.GetKeysCSC_Button.TabIndex = 6
        Me.GetKeysCSC_Button.Text = "Get CSC Package List"
        Me.GetKeysCSC_Button.UseVisualStyleBackColor = True
        '
        'GetSoftwareList
        '
        Me.GetSoftwareList.AccessibleRole = System.Windows.Forms.AccessibleRole.None
        Me.GetSoftwareList.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GetSoftwareList.AutoSize = True
        Me.GetSoftwareList.Location = New System.Drawing.Point(11, 200)
        Me.GetSoftwareList.Name = "GetSoftwareList"
        Me.GetSoftwareList.Size = New System.Drawing.Size(167, 23)
        Me.GetSoftwareList.TabIndex = 7
        Me.GetSoftwareList.Text = "Get Add / Remove Programs"
        Me.GetSoftwareList.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToOrderColumns = True
        Me.DataGridView1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView1.BackgroundColor = System.Drawing.SystemColors.Window
        Me.DataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.SoftwareName, Me.SoftwareVersion, Me.InstallDate, Me.KeyName})
        Me.DataGridView1.Location = New System.Drawing.Point(11, 217)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(985, 193)
        Me.DataGridView1.TabIndex = 10
        '
        'SoftwareName
        '
        Me.SoftwareName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.SoftwareName.HeaderText = "SoftwareName"
        Me.SoftwareName.Name = "SoftwareName"
        Me.SoftwareName.ReadOnly = True
        '
        'SoftwareVersion
        '
        Me.SoftwareVersion.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.SoftwareVersion.FillWeight = 40.0!
        Me.SoftwareVersion.HeaderText = "SoftwareVersion"
        Me.SoftwareVersion.Name = "SoftwareVersion"
        Me.SoftwareVersion.ReadOnly = True
        '
        'InstallDate
        '
        Me.InstallDate.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.InstallDate.FillWeight = 33.0!
        Me.InstallDate.HeaderText = "InstallDate"
        Me.InstallDate.MinimumWidth = 10
        Me.InstallDate.Name = "InstallDate"
        Me.InstallDate.ReadOnly = True
        '
        'KeyName
        '
        Me.KeyName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.KeyName.HeaderText = "KeyName"
        Me.KeyName.Name = "KeyName"
        Me.KeyName.ReadOnly = True
        '
        'DataGridViewCSCPackages
        '
        Me.DataGridViewCSCPackages.AllowUserToOrderColumns = True
        Me.DataGridViewCSCPackages.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.DataGridViewCSCPackages.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridViewCSCPackages.BackgroundColor = System.Drawing.SystemColors.Window
        Me.DataGridViewCSCPackages.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.DataGridViewCSCPackages.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewCSCPackages.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.PackageName, Me.Installed})
        Me.DataGridViewCSCPackages.Location = New System.Drawing.Point(520, 435)
        Me.DataGridViewCSCPackages.Name = "DataGridViewCSCPackages"
        Me.DataGridViewCSCPackages.Size = New System.Drawing.Size(476, 225)
        Me.DataGridViewCSCPackages.TabIndex = 11
        '
        'PackageName
        '
        Me.PackageName.HeaderText = "PackageName"
        Me.PackageName.MinimumWidth = 10
        Me.PackageName.Name = "PackageName"
        '
        'Installed
        '
        Me.Installed.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.Installed.FillWeight = 20.0!
        Me.Installed.HeaderText = "Installed"
        Me.Installed.MinimumWidth = 2
        Me.Installed.Name = "Installed"
        '
        'BrowseAppslogs
        '
        Me.BrowseAppslogs.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.BrowseAppslogs.AutoSize = True
        Me.BrowseAppslogs.Location = New System.Drawing.Point(898, 695)
        Me.BrowseAppslogs.Name = "BrowseAppslogs"
        Me.BrowseAppslogs.Size = New System.Drawing.Size(98, 23)
        Me.BrowseAppslogs.TabIndex = 12
        Me.BrowseAppslogs.Text = "Open Appslogs"
        Me.BrowseAppslogs.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.TextBox1.Location = New System.Drawing.Point(483, 191)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(348, 20)
        Me.TextBox1.TabIndex = 20
        '
        'MSIUNINSTALL
        '
        Me.MSIUNINSTALL.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.MSIUNINSTALL.Location = New System.Drawing.Point(827, 186)
        Me.MSIUNINSTALL.Name = "MSIUNINSTALL"
        Me.MSIUNINSTALL.Size = New System.Drawing.Size(169, 25)
        Me.MSIUNINSTALL.TabIndex = 21
        Me.MSIUNINSTALL.Text = "Uninstall MSI by GUID selected"
        Me.MSIUNINSTALL.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.MSIUNINSTALL.UseVisualStyleBackColor = True
        '
        'GreenlnkSD
        '
        Me.GreenlnkSD.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.GreenlnkSD.FormattingEnabled = True
        Me.GreenlnkSD.Location = New System.Drawing.Point(12, 435)
        Me.GreenlnkSD.Name = "GreenlnkSD"
        Me.GreenlnkSD.Size = New System.Drawing.Size(438, 225)
        Me.GreenlnkSD.TabIndex = 22
        '
        'greenlnklistpackages
        '
        Me.greenlnklistpackages.AutoSize = True
        Me.greenlnklistpackages.Location = New System.Drawing.Point(11, 416)
        Me.greenlnklistpackages.Name = "greenlnklistpackages"
        Me.greenlnklistpackages.Size = New System.Drawing.Size(103, 23)
        Me.greenlnklistpackages.TabIndex = 23
        Me.greenlnklistpackages.Text = "List \\greenlnk\sd"
        Me.greenlnklistpackages.UseVisualStyleBackColor = True
        '
        'GreenlnkSDBOX
        '
        Me.GreenlnkSDBOX.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.GreenlnkSDBOX.Location = New System.Drawing.Point(12, 666)
        Me.GreenlnkSDBOX.Name = "GreenlnkSDBOX"
        Me.GreenlnkSDBOX.Size = New System.Drawing.Size(438, 20)
        Me.GreenlnkSDBOX.TabIndex = 24
        '
        'InstallSoftware
        '
        Me.InstallSoftware.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.InstallSoftware.AutoSize = True
        Me.InstallSoftware.Location = New System.Drawing.Point(11, 692)
        Me.InstallSoftware.Name = "InstallSoftware"
        Me.InstallSoftware.Size = New System.Drawing.Size(90, 23)
        Me.InstallSoftware.TabIndex = 25
        Me.InstallSoftware.Text = "Install Package"
        Me.InstallSoftware.UseVisualStyleBackColor = True
        '
        'RemoveSoftware
        '
        Me.RemoveSoftware.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.RemoveSoftware.AutoSize = True
        Me.RemoveSoftware.Location = New System.Drawing.Point(347, 695)
        Me.RemoveSoftware.Name = "RemoveSoftware"
        Me.RemoveSoftware.Size = New System.Drawing.Size(103, 23)
        Me.RemoveSoftware.TabIndex = 26
        Me.RemoveSoftware.Text = "Remove Package"
        Me.RemoveSoftware.UseVisualStyleBackColor = True
        '
        'Alive
        '
        Me.Alive.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Alive.Location = New System.Drawing.Point(288, 13)
        Me.Alive.Name = "Alive"
        Me.Alive.Size = New System.Drawing.Size(90, 20)
        Me.Alive.TabIndex = 27
        '
        'COmmand1
        '
        Me.COmmand1.AutoSize = True
        Me.COmmand1.Location = New System.Drawing.Point(402, 10)
        Me.COmmand1.Name = "COmmand1"
        Me.COmmand1.Size = New System.Drawing.Size(101, 23)
        Me.COmmand1.TabIndex = 28
        Me.COmmand1.Text = "Check PC Online"
        Me.COmmand1.UseVisualStyleBackColor = True
        '
        'ProgressBar1
        '
        Me.ProgressBar1.BackColor = System.Drawing.SystemColors.Control
        Me.ProgressBar1.Location = New System.Drawing.Point(384, 17)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(12, 12)
        Me.ProgressBar1.TabIndex = 29
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(11, 100)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(101, 23)
        Me.Button3.TabIndex = 30
        Me.Button3.Text = "Open APPV Tools"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Host
        '
        Me.Host.Location = New System.Drawing.Point(97, 40)
        Me.Host.Name = "Host"
        Me.Host.Size = New System.Drawing.Size(185, 20)
        Me.Host.TabIndex = 31
        '
        'Reboot
        '
        Me.Reboot.Font = New System.Drawing.Font("Papyrus", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Reboot.Location = New System.Drawing.Point(509, 15)
        Me.Reboot.Name = "Reboot"
        Me.Reboot.Size = New System.Drawing.Size(94, 18)
        Me.Reboot.TabIndex = 32
        '
        'Form2
        '
        Me.AcceptButton = Me.COmmand1
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.ClientSize = New System.Drawing.Size(1008, 730)
        Me.Controls.Add(Me.Reboot)
        Me.Controls.Add(Me.Host)
        Me.Controls.Add(Me.MSIUNINSTALL)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.ProgressBar1)
        Me.Controls.Add(Me.COmmand1)
        Me.Controls.Add(Me.Alive)
        Me.Controls.Add(Me.RemoveSoftware)
        Me.Controls.Add(Me.InstallSoftware)
        Me.Controls.Add(Me.GreenlnkSDBOX)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.BrowseAppslogs)
        Me.Controls.Add(Me.DataGridViewCSCPackages)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.GetSoftwareList)
        Me.Controls.Add(Me.GetKeysCSC_Button)
        Me.Controls.Add(Me.GetBasicOut)
        Me.Controls.Add(Me.GetBasicText)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.PCname)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.GreenlnkSD)
        Me.Controls.Add(Me.greenlnklistpackages)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "Form2"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "CSC Desktop Tool"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridViewCSCPackages, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents PCname As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents GetBasicText As System.Windows.Forms.Label
    Friend WithEvents GetBasicOut As System.Windows.Forms.Label
    Friend WithEvents GetKeysCSC_Button As System.Windows.Forms.Button
    Friend WithEvents GetSoftwareList As System.Windows.Forms.Button
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewCSCPackages As System.Windows.Forms.DataGridView
    Friend WithEvents PackageName As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Installed As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents SoftwareName As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents SoftwareVersion As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents InstallDate As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents KeyName As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents BrowseAppslogs As System.Windows.Forms.Button
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents MSIUNINSTALL As System.Windows.Forms.Button
    Friend WithEvents GreenlnkSD As System.Windows.Forms.ListBox
    Friend WithEvents greenlnklistpackages As System.Windows.Forms.Button
    Friend WithEvents GreenlnkSDBOX As System.Windows.Forms.TextBox
    Friend WithEvents InstallSoftware As System.Windows.Forms.Button
    Friend WithEvents RemoveSoftware As System.Windows.Forms.Button
    Friend WithEvents Alive As System.Windows.Forms.TextBox
    Friend WithEvents COmmand1 As System.Windows.Forms.Button
    Friend WithEvents ProgressBar1 As System.Windows.Forms.ProgressBar
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Host As System.Windows.Forms.Label
    Friend WithEvents Reboot As System.Windows.Forms.Label
End Class
