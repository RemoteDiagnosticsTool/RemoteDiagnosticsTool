Imports System.DirectoryServices


Public Class Serial
    Inherits MetroFramework.Forms.MetroForm

    Private Sub Serial_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        MaskedTextBox1.Text = ""
        MaskedTextBox2.Text = ""
        MaskedTextBox3.Text = ""
        MaskedTextBox4.Text = ""
        MaskedTextBox5.Text = ""

        Dim SerialRead As String = ""

        Try
            Dim regKey As Microsoft.Win32.RegistryKey
            regKey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey("Software", True)
            regKey.CreateSubKey("RDT")
            regKey.Close()
        Catch ex As Exception
        End Try

        Try
            Dim regKey As Microsoft.Win32.RegistryKey
            regKey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey("Software\RDT", True)
            SerialRead = regKey.GetValue("Serial")
            SerialRead = Crypt(SerialRead)
        Catch ex As Exception
            Exit Sub
        End Try

        If SerialRead = "11111-47090-34325-08642-25839-11111" Then
            'Me.WindowState = FormWindowState.Minimized
            Dim form1 As New Form1()
            form1.Show()
            Hide()
            Exit Sub
        End If

        If SerialRead = "" Then

        ElseIf SerialRead <> "11111-47090-34325-08642-25839-11111" Then
            MsgBox("Invalid serial number. Please enter a valid serial number! Please see help (?) for further details.")
        End If

    End Sub

    Private Sub SerialButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SerialButton.Click
        Dim SerialRead As String = MaskedTextBox1.Text & "-" & MaskedTextBox2.Text & "-" & MaskedTextBox3.Text & "-" & MaskedTextBox4.Text & "-" & MaskedTextBox5.Text & "-" & MaskedTextBox6.Text
        SerialRead = Crypt(SerialRead)

        Try
            Dim regKey As Microsoft.Win32.RegistryKey
            regKey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey("Software", True)
            regKey.CreateSubKey("RDT")
            regKey.Close()
        Catch ex As Exception
            MsgBox("Unable to create RDT registry key needed for the serial number! Please check permissions in the registry.")
            Me.Close()
        End Try

        Try
            Dim regKey As Microsoft.Win32.RegistryKey
            regKey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey("Software\RDT", True)
            regKey.SetValue("Serial", SerialRead)
            regKey.Close()
        Catch ex As Exception
            MsgBox("Unable to create RDT registry key needed for the serial number! Please check permissions in the registry.")
        End Try

        SerialCheck2()

    End Sub

    Private Sub SerialCheck2()
        Dim SerialRead As String = ""

        Try
            Dim regKey As Microsoft.Win32.RegistryKey
            regKey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey("Software\RDT", True)
            SerialRead = regKey.GetValue("Serial")
            SerialRead = Crypt(SerialRead)
            regKey.Close()
        Catch ex As Exception
        End Try

        If SerialRead = "11111-47090-34325-08642-25839-11111" Then
            'Me.WindowState = FormWindowState.Minimized
            Dim form1 As New Form1()
            form1.Show()
            Hide()
            Exit Sub
        End If

        If SerialRead = "" Then

        ElseIf SerialRead <> "11111-47090-34325-08642-25839-11111" Then
            MsgBox("Invalid serial number. Please enter a valid serial number! Please see help (?) for further details.")
        End If

    End Sub

    Private Sub Evaluate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Evaluate.Click
        EvaluateFlag = "True"

        'Me.WindowState = FormWindowState.Minimized
        Dim form1 As New Form1()
        form1.Show()
        Hide()
    End Sub

    Public Function Crypt(ByVal Text As String) As String
        ' Encrypts/decrypts the passed string using 
        ' a simple ASCII value-swapping algorithm
        Dim strTempChar As String = ""
        Dim i As Integer
        For i = 1 To Len(Text)
            If Asc(Mid$(Text, i, 1)) < 128 Then
                strTempChar = CType(Asc(Mid$(Text, i, 1)) + 128, String)
            ElseIf Asc(Mid$(Text, i, 1)) > 128 Then
                strTempChar = CType(Asc(Mid$(Text, i, 1)) - 128, String)
            End If
            Mid$(Text, i, 1) = Chr(CType(strTempChar, Integer))
        Next i
        Return Text
    End Function


    Private Sub HelpButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HelpButton1.Click

        Dim sResult As String
        Dim objShell = CreateObject("Wscript.Shell")
        Dim path2 As String = System.IO.Directory.GetCurrentDirectory()
        Try
            sResult = objShell.run("help.pdf", 1, False)
        Catch ex As Exception
        End Try
    End Sub
End Class
