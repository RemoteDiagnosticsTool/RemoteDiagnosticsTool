Public Class Passwordbox
    Inherits MetroFramework.Forms.MetroForm

    Private Sub Paswordbox_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        passwordboxtext.Text = ""
        password = ""
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MetroTile1.Click, MyBase.Enter, MetroTile1.Enter
        If passwordboxtext.Text = "" Then
            MsgBox("Your ""Password"" must be set properly and cannot be blank.")
            Exit Sub
        Else
            password = passwordboxtext.Text
            Me.Hide()
        End If
    End Sub
End Class