﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AppV
    Inherits MetroFramework.Forms.MetroForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MetroTabControl1 = New MetroFramework.Controls.MetroTabControl()
        Me.MetroTabPage1 = New MetroFramework.Controls.MetroTabPage()
        Me.TableLayoutPanel36 = New System.Windows.Forms.TableLayoutPanel()
        Me.ProgressBar_APPVCACHE = New System.Windows.Forms.ProgressBar()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label178 = New System.Windows.Forms.Label()
        Me.APPVCACHEfree = New System.Windows.Forms.Label()
        Me.APPVCACHEsize = New System.Windows.Forms.Label()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.PUAPPVCache = New System.Windows.Forms.Label()
        Me.Label176 = New System.Windows.Forms.Label()
        Me.Label193 = New System.Windows.Forms.Label()
        Me.APPV4mindiskspace = New System.Windows.Forms.Label()
        Me.APPVCACHElocation = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.MetroTabPage2 = New MetroFramework.Controls.MetroTabPage()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.NameOfIt = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Version = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FileLocation = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.UserDataDirectory = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DriveLetter = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SizeOfit = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SftPath = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MetroTabPage3 = New MetroFramework.Controls.MetroTabPage()
        Me.DataGridView2 = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LastLaunchOnSystem = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PkgGuid = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Loading = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.OriginalOsdPath = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MetroTabPage4 = New MetroFramework.Controls.MetroTabPage()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.PaExec = New MetroFramework.Controls.MetroTile()
        Me.MetroTabControl1.SuspendLayout()
        Me.MetroTabPage1.SuspendLayout()
        Me.TableLayoutPanel36.SuspendLayout()
        Me.MetroTabPage2.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MetroTabPage3.SuspendLayout()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MetroTabPage4.SuspendLayout()
        Me.SuspendLayout()
        '
        'MetroTabControl1
        '
        Me.MetroTabControl1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.MetroTabControl1.Controls.Add(Me.MetroTabPage1)
        Me.MetroTabControl1.Controls.Add(Me.MetroTabPage2)
        Me.MetroTabControl1.Controls.Add(Me.MetroTabPage3)
        Me.MetroTabControl1.Controls.Add(Me.MetroTabPage4)
        Me.MetroTabControl1.Location = New System.Drawing.Point(20, 60)
        Me.MetroTabControl1.Name = "MetroTabControl1"
        Me.MetroTabControl1.SelectedIndex = 0
        Me.MetroTabControl1.Size = New System.Drawing.Size(961, 520)
        Me.MetroTabControl1.TabIndex = 0
        Me.MetroTabControl1.UseSelectable = True
        '
        'MetroTabPage1
        '
        Me.MetroTabPage1.Controls.Add(Me.TableLayoutPanel36)
        Me.MetroTabPage1.HorizontalScrollbarBarColor = False
        Me.MetroTabPage1.HorizontalScrollbarHighlightOnWheel = False
        Me.MetroTabPage1.HorizontalScrollbarSize = 0
        Me.MetroTabPage1.Location = New System.Drawing.Point(4, 38)
        Me.MetroTabPage1.Name = "MetroTabPage1"
        Me.MetroTabPage1.Size = New System.Drawing.Size(953, 478)
        Me.MetroTabPage1.TabIndex = 0
        Me.MetroTabPage1.Text = "Cache Details"
        Me.MetroTabPage1.VerticalScrollbarBarColor = False
        Me.MetroTabPage1.VerticalScrollbarHighlightOnWheel = False
        Me.MetroTabPage1.VerticalScrollbarSize = 0
        '
        'TableLayoutPanel36
        '
        Me.TableLayoutPanel36.ColumnCount = 2
        Me.TableLayoutPanel36.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 22.44444!))
        Me.TableLayoutPanel36.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 77.55556!))
        Me.TableLayoutPanel36.Controls.Add(Me.ProgressBar_APPVCACHE, 1, 3)
        Me.TableLayoutPanel36.Controls.Add(Me.Label1, 0, 5)
        Me.TableLayoutPanel36.Controls.Add(Me.Label178, 0, 2)
        Me.TableLayoutPanel36.Controls.Add(Me.APPVCACHEfree, 1, 1)
        Me.TableLayoutPanel36.Controls.Add(Me.APPVCACHEsize, 1, 0)
        Me.TableLayoutPanel36.Controls.Add(Me.Label49, 0, 1)
        Me.TableLayoutPanel36.Controls.Add(Me.PUAPPVCache, 1, 2)
        Me.TableLayoutPanel36.Controls.Add(Me.Label176, 0, 3)
        Me.TableLayoutPanel36.Controls.Add(Me.Label193, 0, 4)
        Me.TableLayoutPanel36.Controls.Add(Me.APPV4mindiskspace, 1, 5)
        Me.TableLayoutPanel36.Controls.Add(Me.APPVCACHElocation, 1, 4)
        Me.TableLayoutPanel36.Controls.Add(Me.Label31, 0, 0)
        Me.TableLayoutPanel36.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel36.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel36.Name = "TableLayoutPanel36"
        Me.TableLayoutPanel36.RowCount = 6
        Me.TableLayoutPanel36.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 42.97189!))
        Me.TableLayoutPanel36.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 57.02811!))
        Me.TableLayoutPanel36.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 102.0!))
        Me.TableLayoutPanel36.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 68.0!))
        Me.TableLayoutPanel36.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 80.0!))
        Me.TableLayoutPanel36.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 57.0!))
        Me.TableLayoutPanel36.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel36.Size = New System.Drawing.Size(953, 478)
        Me.TableLayoutPanel36.TabIndex = 2
        '
        'ProgressBar_APPVCACHE
        '
        Me.ProgressBar_APPVCACHE.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ProgressBar_APPVCACHE.Location = New System.Drawing.Point(216, 275)
        Me.ProgressBar_APPVCACHE.Name = "ProgressBar_APPVCACHE"
        Me.ProgressBar_APPVCACHE.Size = New System.Drawing.Size(734, 62)
        Me.ProgressBar_APPVCACHE.TabIndex = 7
        '
        'Label1
        '
        Me.Label1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(3, 420)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(207, 58)
        Me.Label1.TabIndex = 12
        Me.Label1.Text = "APPV Min Free Disk Space >"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label178
        '
        Me.Label178.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label178.AutoSize = True
        Me.Label178.Location = New System.Drawing.Point(3, 170)
        Me.Label178.Name = "Label178"
        Me.Label178.Size = New System.Drawing.Size(207, 102)
        Me.Label178.TabIndex = 6
        Me.Label178.Text = "Percentage free of APPV Cache ="
        Me.Label178.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'APPVCACHEfree
        '
        Me.APPVCACHEfree.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.APPVCACHEfree.AutoSize = True
        Me.APPVCACHEfree.Location = New System.Drawing.Point(216, 73)
        Me.APPVCACHEfree.Name = "APPVCACHEfree"
        Me.APPVCACHEfree.Size = New System.Drawing.Size(734, 97)
        Me.APPVCACHEfree.TabIndex = 1
        Me.APPVCACHEfree.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'APPVCACHEsize
        '
        Me.APPVCACHEsize.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.APPVCACHEsize.AutoSize = True
        Me.APPVCACHEsize.Location = New System.Drawing.Point(216, 0)
        Me.APPVCACHEsize.Name = "APPVCACHEsize"
        Me.APPVCACHEsize.Size = New System.Drawing.Size(734, 73)
        Me.APPVCACHEsize.TabIndex = 2
        Me.APPVCACHEsize.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label49
        '
        Me.Label49.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label49.AutoSize = True
        Me.Label49.Location = New System.Drawing.Point(3, 73)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(207, 97)
        Me.Label49.TabIndex = 5
        Me.Label49.Text = "File Size of APPV Cache ="
        Me.Label49.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'PUAPPVCache
        '
        Me.PUAPPVCache.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PUAPPVCache.AutoSize = True
        Me.PUAPPVCache.Location = New System.Drawing.Point(216, 170)
        Me.PUAPPVCache.Name = "PUAPPVCache"
        Me.PUAPPVCache.Size = New System.Drawing.Size(734, 102)
        Me.PUAPPVCache.TabIndex = 9
        Me.PUAPPVCache.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label176
        '
        Me.Label176.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label176.AutoSize = True
        Me.Label176.Location = New System.Drawing.Point(3, 272)
        Me.Label176.Name = "Label176"
        Me.Label176.Size = New System.Drawing.Size(207, 68)
        Me.Label176.TabIndex = 8
        Me.Label176.Text = "Amount of APPV Cache used ="
        Me.Label176.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label193
        '
        Me.Label193.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label193.AutoSize = True
        Me.Label193.Location = New System.Drawing.Point(3, 340)
        Me.Label193.Name = "Label193"
        Me.Label193.Size = New System.Drawing.Size(207, 80)
        Me.Label193.TabIndex = 10
        Me.Label193.Text = "APPV Cache Location > "
        Me.Label193.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'APPV4mindiskspace
        '
        Me.APPV4mindiskspace.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.APPV4mindiskspace.AutoSize = True
        Me.APPV4mindiskspace.Location = New System.Drawing.Point(216, 420)
        Me.APPV4mindiskspace.Name = "APPV4mindiskspace"
        Me.APPV4mindiskspace.Size = New System.Drawing.Size(734, 58)
        Me.APPV4mindiskspace.TabIndex = 13
        Me.APPV4mindiskspace.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'APPVCACHElocation
        '
        Me.APPVCACHElocation.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.APPVCACHElocation.AutoSize = True
        Me.APPVCACHElocation.Location = New System.Drawing.Point(216, 340)
        Me.APPVCACHElocation.Name = "APPVCACHElocation"
        Me.APPVCACHElocation.Size = New System.Drawing.Size(734, 80)
        Me.APPVCACHElocation.TabIndex = 14
        Me.APPVCACHElocation.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label31
        '
        Me.Label31.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(3, 0)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(207, 73)
        Me.Label31.TabIndex = 4
        Me.Label31.Text = "Total Size of APPV Cache ="
        Me.Label31.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'MetroTabPage2
        '
        Me.MetroTabPage2.Controls.Add(Me.DataGridView1)
        Me.MetroTabPage2.HorizontalScrollbarBarColor = False
        Me.MetroTabPage2.HorizontalScrollbarHighlightOnWheel = False
        Me.MetroTabPage2.HorizontalScrollbarSize = 0
        Me.MetroTabPage2.Location = New System.Drawing.Point(4, 38)
        Me.MetroTabPage2.Name = "MetroTabPage2"
        Me.MetroTabPage2.Size = New System.Drawing.Size(953, 478)
        Me.MetroTabPage2.TabIndex = 1
        Me.MetroTabPage2.Text = "Packages"
        Me.MetroTabPage2.VerticalScrollbarBarColor = False
        Me.MetroTabPage2.VerticalScrollbarHighlightOnWheel = False
        Me.MetroTabPage2.VerticalScrollbarSize = 0
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.AllowUserToOrderColumns = True
        Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.NameOfIt, Me.Version, Me.FileLocation, Me.UserDataDirectory, Me.DriveLetter, Me.SizeOfit, Me.SftPath})
        Me.DataGridView1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DataGridView1.Location = New System.Drawing.Point(0, 0)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowHeadersVisible = False
        Me.DataGridView1.RowTemplate.Height = 24
        Me.DataGridView1.Size = New System.Drawing.Size(953, 478)
        Me.DataGridView1.TabIndex = 49
        '
        'NameOfIt
        '
        Me.NameOfIt.FillWeight = 15.0!
        Me.NameOfIt.HeaderText = "Name"
        Me.NameOfIt.Name = "NameOfIt"
        '
        'Version
        '
        Me.Version.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.Version.FillWeight = 5.03672!
        Me.Version.HeaderText = "Version"
        Me.Version.Name = "Version"
        Me.Version.ReadOnly = True
        '
        'FileLocation
        '
        Me.FileLocation.FillWeight = 12.46262!
        Me.FileLocation.HeaderText = "Package GUID"
        Me.FileLocation.Name = "FileLocation"
        Me.FileLocation.ReadOnly = True
        '
        'UserDataDirectory
        '
        Me.UserDataDirectory.FillWeight = 4.0!
        Me.UserDataDirectory.HeaderText = "InUse"
        Me.UserDataDirectory.MinimumWidth = 4
        Me.UserDataDirectory.Name = "UserDataDirectory"
        Me.UserDataDirectory.ReadOnly = True
        '
        'DriveLetter
        '
        Me.DriveLetter.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DriveLetter.FillWeight = 4.0!
        Me.DriveLetter.HeaderText = "Locked"
        Me.DriveLetter.MinimumWidth = 4
        Me.DriveLetter.Name = "DriveLetter"
        Me.DriveLetter.ReadOnly = True
        '
        'SizeOfit
        '
        Me.SizeOfit.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.SizeOfit.FillWeight = 7.0!
        Me.SizeOfit.HeaderText = "Size"
        Me.SizeOfit.Name = "SizeOfit"
        Me.SizeOfit.ReadOnly = True
        '
        'SftPath
        '
        Me.SftPath.FillWeight = 30.0!
        Me.SftPath.HeaderText = "SftPath"
        Me.SftPath.Name = "SftPath"
        '
        'MetroTabPage3
        '
        Me.MetroTabPage3.Controls.Add(Me.DataGridView2)
        Me.MetroTabPage3.HorizontalScrollbarBarColor = False
        Me.MetroTabPage3.HorizontalScrollbarHighlightOnWheel = False
        Me.MetroTabPage3.HorizontalScrollbarSize = 0
        Me.MetroTabPage3.Location = New System.Drawing.Point(4, 38)
        Me.MetroTabPage3.Name = "MetroTabPage3"
        Me.MetroTabPage3.Size = New System.Drawing.Size(953, 478)
        Me.MetroTabPage3.TabIndex = 2
        Me.MetroTabPage3.Text = "Shortcuts"
        Me.MetroTabPage3.VerticalScrollbarBarColor = False
        Me.MetroTabPage3.VerticalScrollbarHighlightOnWheel = False
        Me.MetroTabPage3.VerticalScrollbarSize = 0
        '
        'DataGridView2
        '
        Me.DataGridView2.AllowUserToAddRows = False
        Me.DataGridView2.AllowUserToDeleteRows = False
        Me.DataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.DataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView2.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4, Me.LastLaunchOnSystem, Me.PkgGuid, Me.Loading, Me.OriginalOsdPath})
        Me.DataGridView2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DataGridView2.Location = New System.Drawing.Point(0, 0)
        Me.DataGridView2.Name = "DataGridView2"
        Me.DataGridView2.RowHeadersVisible = False
        Me.DataGridView2.RowTemplate.Height = 24
        Me.DataGridView2.Size = New System.Drawing.Size(953, 478)
        Me.DataGridView2.TabIndex = 53
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn3.FillWeight = 20.0!
        Me.DataGridViewTextBoxColumn3.HeaderText = "Shortcut"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.ReadOnly = True
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn4.FillWeight = 8.0!
        Me.DataGridViewTextBoxColumn4.HeaderText = "Version"
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.ReadOnly = True
        '
        'LastLaunchOnSystem
        '
        Me.LastLaunchOnSystem.FillWeight = 11.0!
        Me.LastLaunchOnSystem.HeaderText = "LastLaunchOnSystem"
        Me.LastLaunchOnSystem.Name = "LastLaunchOnSystem"
        '
        'PkgGuid
        '
        Me.PkgGuid.FillWeight = 8.0!
        Me.PkgGuid.HeaderText = "PackageGUID"
        Me.PkgGuid.Name = "PkgGuid"
        '
        'Loading
        '
        Me.Loading.FillWeight = 5.0!
        Me.Loading.HeaderText = "Loading"
        Me.Loading.Name = "Loading"
        '
        'OriginalOsdPath
        '
        Me.OriginalOsdPath.FillWeight = 30.0!
        Me.OriginalOsdPath.HeaderText = "OriginalOsdPath"
        Me.OriginalOsdPath.Name = "OriginalOsdPath"
        '
        'MetroTabPage4
        '
        Me.MetroTabPage4.Controls.Add(Me.ListBox1)
        Me.MetroTabPage4.HorizontalScrollbarBarColor = False
        Me.MetroTabPage4.HorizontalScrollbarHighlightOnWheel = False
        Me.MetroTabPage4.HorizontalScrollbarSize = 0
        Me.MetroTabPage4.Location = New System.Drawing.Point(4, 38)
        Me.MetroTabPage4.Name = "MetroTabPage4"
        Me.MetroTabPage4.Size = New System.Drawing.Size(953, 478)
        Me.MetroTabPage4.TabIndex = 3
        Me.MetroTabPage4.Text = "Appv 4.6 Commands"
        Me.MetroTabPage4.VerticalScrollbarBarColor = False
        Me.MetroTabPage4.VerticalScrollbarHighlightOnWheel = False
        Me.MetroTabPage4.VerticalScrollbarSize = 0
        '
        'ListBox1
        '
        Me.ListBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Items.AddRange(New Object() {"SFTMIME command examples:", "", "Add Publishing Server " & Global.Microsoft.VisualBasic.ChrW(9) & "= SFTMIME ADD SERVER:""Production Environemt App-V"" /HOST *" &
                "**HOSTNAMEHERE*** /TYPE RTSP /PORT 554 /REFRESH ON", "Delete Publishing Server " & Global.Microsoft.VisualBasic.ChrW(9) & "= SFTMIME DELETE SERVER:""Production Environemt App-V""", "Start Refresh of Server" & Global.Microsoft.VisualBasic.ChrW(9) & "= SFTMIME REFRESH SERVER:""Production Environemt App-V""", "", "Load Package" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "= SFTMIME LOAD PACKAGE:{4DE133E9-B54D-468F-9E7D-0B51A26CB538}", "Delete Package" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "= SFTMIME DELETE PACKAGE:{4DE133E9-B54D-468F-9E7D-0B51A26CB538}", "", "Remove Complete App" & Global.Microsoft.VisualBasic.ChrW(9) & "= SFTMIME REMOVE APP:""Open Options User Application 7.2.0.0"" " &
                "/COMPLETE", "", "Add FileType" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "= SFTMIME ADD TYPE:DOCX /APP ""Microsoft Word 14.3.2.0"" /ICON icon-p" &
                "athname  /CONTENT-TYPE content-type /GLOBAL /PERCEIVED-TYPE perceived-type", "" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "   /PROGID progid /CONFIRMOPEN NO /SHOWEXT YES /NEWMENU YES  ", "Delete FileType" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "= SFTMIME DELETE TYPE:DOCX /GLOBAL", "", "", "Standard command examples:", "", "Remove Directory" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "= RD /S /Q ""C:\Program Files\RDT\Folder""", "Remove File" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "= Del /F /Q ""C:\Program Files\RDT\RDT\RDT.EXE"""})
        Me.ListBox1.Location = New System.Drawing.Point(0, 0)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(953, 478)
        Me.ListBox1.TabIndex = 2
        '
        'PaExec
        '
        Me.PaExec.ActiveControl = Nothing
        Me.PaExec.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PaExec.Location = New System.Drawing.Point(816, 30)
        Me.PaExec.Name = "PaExec"
        Me.PaExec.Size = New System.Drawing.Size(160, 24)
        Me.PaExec.TabIndex = 94
        Me.PaExec.Text = "Remote Shell (As you)"
        Me.PaExec.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.PaExec.UseSelectable = True
        '
        'AppV
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BorderStyle = MetroFramework.Forms.MetroFormBorderStyle.FixedSingle
        Me.ClientSize = New System.Drawing.Size(1000, 600)
        Me.Controls.Add(Me.MetroTabControl1)
        Me.Controls.Add(Me.PaExec)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "AppV"
        Me.Resizable = False
        Me.ShadowType = MetroFramework.Forms.MetroFormShadowType.None
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
        Me.Text = "APPV 4.6"
        Me.MetroTabControl1.ResumeLayout(False)
        Me.MetroTabPage1.ResumeLayout(False)
        Me.TableLayoutPanel36.ResumeLayout(False)
        Me.TableLayoutPanel36.PerformLayout()
        Me.MetroTabPage2.ResumeLayout(False)
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MetroTabPage3.ResumeLayout(False)
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MetroTabPage4.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents MetroTabControl1 As MetroFramework.Controls.MetroTabControl
    Friend WithEvents MetroTabPage1 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents MetroTabPage2 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents MetroTabPage3 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents MetroTabPage4 As MetroFramework.Controls.MetroTabPage
    Public WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents DataGridView2 As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents LastLaunchOnSystem As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PkgGuid As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Loading As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents OriginalOsdPath As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents NameOfIt As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Version As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents FileLocation As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents UserDataDirectory As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DriveLetter As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents SizeOfit As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents SftPath As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TableLayoutPanel36 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents ProgressBar_APPVCACHE As System.Windows.Forms.ProgressBar
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label178 As System.Windows.Forms.Label
    Friend WithEvents APPVCACHEfree As System.Windows.Forms.Label
    Friend WithEvents APPVCACHEsize As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents PUAPPVCache As System.Windows.Forms.Label
    Friend WithEvents Label176 As System.Windows.Forms.Label
    Friend WithEvents Label193 As System.Windows.Forms.Label
    Friend WithEvents APPV4mindiskspace As System.Windows.Forms.Label
    Friend WithEvents APPVCACHElocation As System.Windows.Forms.Label
    Friend WithEvents PaExec As MetroFramework.Controls.MetroTile
End Class
