Public Class CopyingFilesPopup
    Inherits MetroFramework.Forms.MetroForm

    Private Sub CopyingFilesPopup_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        MetroLabel2.Text = "Copying to " & MachineName & "\C$\program Files\RDT\RDT\" & Form5.SDBOXFolder.Text & " , Please check."
    End Sub
End Class