﻿Public Class OLD_Secure_product_Form5_Load_Code
    'If EvaluateFlag = "True" Then

    '    Dim sResult As String
    '    Dim objShell = CreateObject("Wscript.Shell")
    '    Dim path2 As String = Directory.GetCurrentDirectory()
    '    Try
    '        sResult = objShell.run("help.pdf", 1, False)
    '    Catch ex As Exception
    '    End Try

    '    Try
    '        Dim regKey As Microsoft.Win32.RegistryKey
    '        regKey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey("Software\RDT", True)
    '        Serial1Read = Crypt(regKey.GetValue("Serial1"))
    '        regKey.Close()
    '    Catch ex As Exception
    '    End Try
    '    Try
    '        Dim regKey As Microsoft.Win32.RegistryKey
    '        regKey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey("Software\RDT", True)
    '        Serial2Read = Crypt(regKey.GetValue("Serial2"))
    '        regKey.Close()
    '    Catch ex As Exception
    '    End Try
    '    Try
    '        Dim regKey As Microsoft.Win32.RegistryKey
    '        regKey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey("SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer", True)
    '        REnableTRead = Crypt(regKey.GetValue("REnableT"))
    '        regKey.Close()
    '    Catch ex As Exception
    '    End Try

    '    BackgroundWorkerEval.RunWorkerAsync()

    '    If Serial2Read = "" Then
    '    Else
    '        Dim Serial2Date As DateTime = DateTime.Parse(Serial2Read)
    '        If Serial2Date > Now Then
    '            SecurityResult = "Security Breach , Clock Changed Since Last Run!"
    '            TabControl1.Visible = False
    '            PCNAME.Text = txtpcname
    '            Form1.Hide()
    '            Serial.Hide()
    '            TabControl1.Size = New Size(MyBase.Width, MyBase.Height)
    '            PopulateComboboxList()
    '            Inst_RemDriveLetter.Text = "A"
    '            TabControl1.SelectTab(0)
    '            If SecurityResult <> "" Then
    '                EvalText.Text = SecurityResult
    '            End If
    '            Exit Sub
    '        End If
    '    End If
    '    Try
    '        Dim regKey As Microsoft.Win32.RegistryKey
    '        regKey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey("Software", True)
    '        regKey.CreateSubKey("RDT")
    '        regKey.Close()
    '    Catch ex As Exception
    '    End Try
    '    Try
    '        Dim regKey As Microsoft.Win32.RegistryKey
    '        regKey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey("Software\RDT", True)
    '        Dim Serial2Write As String = Crypt(Now)
    '        regKey.SetValue("Serial2", Serial2Write)
    '        regKey.Close()
    '    Catch ex As Exception
    '    End Try

    '    If Serial1Read = "" And REnableTRead = "" Then
    '        Try
    '            Dim regKey As Microsoft.Win32.RegistryKey
    '            regKey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey("Software\RDT", True)
    '            Dim Serial1Write As String = Crypt(Now)
    '            regKey.SetValue("Serial1", Serial1Write)
    '            regKey.Close()
    '        Catch ex As Exception
    '        End Try
    '        Try
    '            Dim regKey As Microsoft.Win32.RegistryKey
    '            regKey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey("SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer", True)
    '            Dim REnableTWrite As String = Crypt("939470635061287049")
    '            regKey.SetValue("REnableT", REnableTWrite)
    '            regKey.Close()
    '        Catch ex As Exception
    '        End Try
    '        SecurityResult = "Trial Period : " & (29 - xdays) & " Days Left"
    '    End If

    '    If Serial1Read <> "" And REnableTRead = "939470635061287049" Then
    '        Dim Serial1Date As DateTime = DateTime.Parse(Serial1Read)
    '        If Serial1Date > Now Then
    '            SecurityResult = "Security Breach , Clock Changed Since First Run!"
    '            TabControl1.Visible = False
    '        Else
    '            Dim trialspan As TimeSpan = (Now - Serial1Date)
    '            xdays = CInt(trialspan.TotalDays)
    '            If (29 - xdays) > 1 Then
    '                SecurityResult = "Trial Period : " & (29 - xdays) & " Days Left"
    '            End If
    '            If (29 - xdays) = 1 Then
    '                SecurityResult = "Trial Period : 1 Day Left"
    '            End If
    '            If (29 - xdays) < 1 Then
    '                SecurityResult = "Trial Period : Ended!"
    '                TabControl1.Visible = False
    '            End If
    '        End If
    '    End If

    '    If Serial1Read = "" And REnableTRead = "939470635061287049" Then
    '        SecurityResult = "Security Breach , Registry Deleted!"
    '        TabControl1.Visible = False
    '    End If

    'Else
    'MetroLabelSelect.Visible = False
    'End If

    ' If SecurityResult <> "" Then
    ' EvalText.Text = SecurityResult
    ' End If

End Class
