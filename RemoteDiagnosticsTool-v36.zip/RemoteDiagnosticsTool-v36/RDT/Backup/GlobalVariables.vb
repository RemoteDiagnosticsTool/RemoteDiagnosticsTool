Module GlobalVariables
    Public username As String
    Public password As String
    Public domain As String
    Public txtpcname As String
End Module
