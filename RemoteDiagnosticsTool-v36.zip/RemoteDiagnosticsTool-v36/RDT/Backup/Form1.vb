Public Class Form1

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    End Sub
    Private Sub username_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles username.TextChanged
    End Sub

    Private Sub password_MaskInputRejected(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MaskInputRejectedEventArgs) Handles password.MaskInputRejected
    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim txtusername As String = Nothing
        Dim txtpassword As String = Nothing
        Dim txtdomain As String = Nothing
        txtusername = username.Text
        txtpassword = password.Text
        txtdomain = domain.Text
        Dim form2 As New Form2()
        form2.PassParam(txtusername, txtpassword, txtdomain)
        form2.Show() 'or form.ShowDialog() for Modal forms
        Me.Hide() 'or form.ShowDialog() for Modal forms
    End Sub

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click

    End Sub

    Private Sub Label2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label2.Click

    End Sub
End Class
