﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class StartupItems
    Inherits MetroFramework.Forms.MetroForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MetroTabControl1 = New MetroFramework.Controls.MetroTabControl()
        Me.MetroTabPage1 = New MetroFramework.Controls.MetroTabPage()
        Me.DataGridViewRunUser = New System.Windows.Forms.DataGridView()
        Me.RunUserName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.RunUserData = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewRun64 = New System.Windows.Forms.DataGridView()
        Me.Run64Name = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Run64Data = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewRun32 = New System.Windows.Forms.DataGridView()
        Me.Run32Name = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Run32Data = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MetroTabPage2 = New MetroFramework.Controls.MetroTabPage()
        Me.DataGridViewShellEX3 = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewShellEX4 = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewShellEX2 = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewShellEX1 = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MetroTabPage3 = New MetroFramework.Controls.MetroTabPage()
        Me.DataGridViewIE4 = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn10 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewIE3 = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn11 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn12 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewIE2 = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn13 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn14 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewIE1 = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn15 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn16 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MetroTabPage4 = New MetroFramework.Controls.MetroTabPage()
        Me.DataGridViewNW4 = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn17 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn18 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewNW3 = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn19 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn20 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewNW2 = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn21 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn22 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewNW1 = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn23 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn24 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MetroTabPage5 = New MetroFramework.Controls.MetroTabPage()
        Me.DataGridViewPM = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn25 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn26 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MetroTabControl1.SuspendLayout()
        Me.MetroTabPage1.SuspendLayout()
        CType(Me.DataGridViewRunUser, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridViewRun64, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridViewRun32, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MetroTabPage2.SuspendLayout()
        CType(Me.DataGridViewShellEX3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridViewShellEX4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridViewShellEX2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridViewShellEX1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MetroTabPage3.SuspendLayout()
        CType(Me.DataGridViewIE4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridViewIE3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridViewIE2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridViewIE1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MetroTabPage4.SuspendLayout()
        CType(Me.DataGridViewNW4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridViewNW3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridViewNW2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridViewNW1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MetroTabPage5.SuspendLayout()
        CType(Me.DataGridViewPM, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MetroTabControl1
        '
        Me.MetroTabControl1.Controls.Add(Me.MetroTabPage1)
        Me.MetroTabControl1.Controls.Add(Me.MetroTabPage2)
        Me.MetroTabControl1.Controls.Add(Me.MetroTabPage3)
        Me.MetroTabControl1.Controls.Add(Me.MetroTabPage4)
        Me.MetroTabControl1.Controls.Add(Me.MetroTabPage5)
        Me.MetroTabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.MetroTabControl1.Location = New System.Drawing.Point(20, 60)
        Me.MetroTabControl1.Name = "MetroTabControl1"
        Me.MetroTabControl1.SelectedIndex = 1
        Me.MetroTabControl1.Size = New System.Drawing.Size(978, 518)
        Me.MetroTabControl1.TabIndex = 0
        Me.MetroTabControl1.UseSelectable = True
        '
        'MetroTabPage1
        '
        Me.MetroTabPage1.Controls.Add(Me.DataGridViewRunUser)
        Me.MetroTabPage1.Controls.Add(Me.DataGridViewRun64)
        Me.MetroTabPage1.Controls.Add(Me.DataGridViewRun32)
        Me.MetroTabPage1.HorizontalScrollbarBarColor = False
        Me.MetroTabPage1.HorizontalScrollbarHighlightOnWheel = False
        Me.MetroTabPage1.HorizontalScrollbarSize = 0
        Me.MetroTabPage1.Location = New System.Drawing.Point(4, 38)
        Me.MetroTabPage1.Name = "MetroTabPage1"
        Me.MetroTabPage1.Size = New System.Drawing.Size(970, 476)
        Me.MetroTabPage1.TabIndex = 0
        Me.MetroTabPage1.Text = "Login Items Run"
        Me.MetroTabPage1.VerticalScrollbarBarColor = False
        Me.MetroTabPage1.VerticalScrollbarHighlightOnWheel = False
        Me.MetroTabPage1.VerticalScrollbarSize = 0
        '
        'DataGridViewRunUser
        '
        Me.DataGridViewRunUser.AllowUserToAddRows = False
        Me.DataGridViewRunUser.AllowUserToDeleteRows = False
        Me.DataGridViewRunUser.AllowUserToResizeRows = False
        Me.DataGridViewRunUser.BackgroundColor = System.Drawing.SystemColors.Window
        Me.DataGridViewRunUser.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewRunUser.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.RunUserName, Me.RunUserData})
        Me.DataGridViewRunUser.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.DataGridViewRunUser.Location = New System.Drawing.Point(0, 330)
        Me.DataGridViewRunUser.Name = "DataGridViewRunUser"
        Me.DataGridViewRunUser.ReadOnly = True
        Me.DataGridViewRunUser.RowHeadersVisible = False
        Me.DataGridViewRunUser.Size = New System.Drawing.Size(970, 146)
        Me.DataGridViewRunUser.TabIndex = 5
        '
        'RunUserName
        '
        Me.RunUserName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.RunUserName.FillWeight = 65.0!
        Me.RunUserName.HeaderText = "USER > SOFTWARE\Microsoft\Windows\CurrentVersion\Run"
        Me.RunUserName.Name = "RunUserName"
        Me.RunUserName.ReadOnly = True
        '
        'RunUserData
        '
        Me.RunUserData.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.RunUserData.HeaderText = "Command Run at Login"
        Me.RunUserData.Name = "RunUserData"
        Me.RunUserData.ReadOnly = True
        '
        'DataGridViewRun64
        '
        Me.DataGridViewRun64.AllowUserToAddRows = False
        Me.DataGridViewRun64.AllowUserToDeleteRows = False
        Me.DataGridViewRun64.AllowUserToResizeRows = False
        Me.DataGridViewRun64.BackgroundColor = System.Drawing.SystemColors.Window
        Me.DataGridViewRun64.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewRun64.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Run64Name, Me.Run64Data})
        Me.DataGridViewRun64.Dock = System.Windows.Forms.DockStyle.Top
        Me.DataGridViewRun64.Location = New System.Drawing.Point(0, 162)
        Me.DataGridViewRun64.Name = "DataGridViewRun64"
        Me.DataGridViewRun64.ReadOnly = True
        Me.DataGridViewRun64.RowHeadersVisible = False
        Me.DataGridViewRun64.Size = New System.Drawing.Size(970, 167)
        Me.DataGridViewRun64.TabIndex = 4
        '
        'Run64Name
        '
        Me.Run64Name.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.Run64Name.FillWeight = 65.0!
        Me.Run64Name.HeaderText = "SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Run"
        Me.Run64Name.Name = "Run64Name"
        Me.Run64Name.ReadOnly = True
        '
        'Run64Data
        '
        Me.Run64Data.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.Run64Data.HeaderText = "Command Run at Login"
        Me.Run64Data.Name = "Run64Data"
        Me.Run64Data.ReadOnly = True
        '
        'DataGridViewRun32
        '
        Me.DataGridViewRun32.AllowUserToAddRows = False
        Me.DataGridViewRun32.AllowUserToDeleteRows = False
        Me.DataGridViewRun32.AllowUserToResizeRows = False
        Me.DataGridViewRun32.BackgroundColor = System.Drawing.SystemColors.Window
        Me.DataGridViewRun32.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewRun32.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Run32Name, Me.Run32Data})
        Me.DataGridViewRun32.Dock = System.Windows.Forms.DockStyle.Top
        Me.DataGridViewRun32.Location = New System.Drawing.Point(0, 0)
        Me.DataGridViewRun32.Name = "DataGridViewRun32"
        Me.DataGridViewRun32.ReadOnly = True
        Me.DataGridViewRun32.RowHeadersVisible = False
        Me.DataGridViewRun32.ShowCellToolTips = False
        Me.DataGridViewRun32.ShowEditingIcon = False
        Me.DataGridViewRun32.Size = New System.Drawing.Size(970, 162)
        Me.DataGridViewRun32.TabIndex = 3
        '
        'Run32Name
        '
        Me.Run32Name.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.Run32Name.FillWeight = 65.0!
        Me.Run32Name.HeaderText = "SOFTWARE\Microsoft\Windows\CurrentVersion\Run"
        Me.Run32Name.Name = "Run32Name"
        Me.Run32Name.ReadOnly = True
        '
        'Run32Data
        '
        Me.Run32Data.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.Run32Data.HeaderText = "Command Run at Login"
        Me.Run32Data.Name = "Run32Data"
        Me.Run32Data.ReadOnly = True
        '
        'MetroTabPage2
        '
        Me.MetroTabPage2.Controls.Add(Me.DataGridViewShellEX3)
        Me.MetroTabPage2.Controls.Add(Me.DataGridViewShellEX4)
        Me.MetroTabPage2.Controls.Add(Me.DataGridViewShellEX2)
        Me.MetroTabPage2.Controls.Add(Me.DataGridViewShellEX1)
        Me.MetroTabPage2.HorizontalScrollbarBarColor = False
        Me.MetroTabPage2.HorizontalScrollbarHighlightOnWheel = False
        Me.MetroTabPage2.HorizontalScrollbarSize = 0
        Me.MetroTabPage2.Location = New System.Drawing.Point(4, 38)
        Me.MetroTabPage2.Name = "MetroTabPage2"
        Me.MetroTabPage2.Size = New System.Drawing.Size(970, 476)
        Me.MetroTabPage2.TabIndex = 1
        Me.MetroTabPage2.Text = "Shell Plug-ins"
        Me.MetroTabPage2.VerticalScrollbarBarColor = False
        Me.MetroTabPage2.VerticalScrollbarHighlightOnWheel = False
        Me.MetroTabPage2.VerticalScrollbarSize = 0
        '
        'DataGridViewShellEX3
        '
        Me.DataGridViewShellEX3.AllowUserToAddRows = False
        Me.DataGridViewShellEX3.AllowUserToDeleteRows = False
        Me.DataGridViewShellEX3.AllowUserToResizeRows = False
        Me.DataGridViewShellEX3.BackgroundColor = System.Drawing.SystemColors.Window
        Me.DataGridViewShellEX3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewShellEX3.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn7, Me.DataGridViewTextBoxColumn8})
        Me.DataGridViewShellEX3.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.DataGridViewShellEX3.Location = New System.Drawing.Point(0, 361)
        Me.DataGridViewShellEX3.Name = "DataGridViewShellEX3"
        Me.DataGridViewShellEX3.ReadOnly = True
        Me.DataGridViewShellEX3.RowHeadersVisible = False
        Me.DataGridViewShellEX3.Size = New System.Drawing.Size(970, 115)
        Me.DataGridViewShellEX3.TabIndex = 8
        '
        'DataGridViewTextBoxColumn7
        '
        Me.DataGridViewTextBoxColumn7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn7.FillWeight = 65.0!
        Me.DataGridViewTextBoxColumn7.HeaderText = "COPYHOOK"
        Me.DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7"
        Me.DataGridViewTextBoxColumn7.ReadOnly = True
        '
        'DataGridViewTextBoxColumn8
        '
        Me.DataGridViewTextBoxColumn8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn8.HeaderText = "Shell Plug-in"
        Me.DataGridViewTextBoxColumn8.Name = "DataGridViewTextBoxColumn8"
        Me.DataGridViewTextBoxColumn8.ReadOnly = True
        '
        'DataGridViewShellEX4
        '
        Me.DataGridViewShellEX4.AllowUserToAddRows = False
        Me.DataGridViewShellEX4.AllowUserToDeleteRows = False
        Me.DataGridViewShellEX4.AllowUserToResizeRows = False
        Me.DataGridViewShellEX4.BackgroundColor = System.Drawing.SystemColors.Window
        Me.DataGridViewShellEX4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewShellEX4.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn5, Me.DataGridViewTextBoxColumn6})
        Me.DataGridViewShellEX4.Dock = System.Windows.Forms.DockStyle.Top
        Me.DataGridViewShellEX4.Location = New System.Drawing.Point(0, 240)
        Me.DataGridViewShellEX4.Name = "DataGridViewShellEX4"
        Me.DataGridViewShellEX4.ReadOnly = True
        Me.DataGridViewShellEX4.RowHeadersVisible = False
        Me.DataGridViewShellEX4.Size = New System.Drawing.Size(970, 124)
        Me.DataGridViewShellEX4.TabIndex = 7
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn5.FillWeight = 65.0!
        Me.DataGridViewTextBoxColumn5.HeaderText = "FOLDER"
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        Me.DataGridViewTextBoxColumn5.ReadOnly = True
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn6.HeaderText = "Shell Plug-in"
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        Me.DataGridViewTextBoxColumn6.ReadOnly = True
        '
        'DataGridViewShellEX2
        '
        Me.DataGridViewShellEX2.AllowUserToAddRows = False
        Me.DataGridViewShellEX2.AllowUserToDeleteRows = False
        Me.DataGridViewShellEX2.AllowUserToResizeRows = False
        Me.DataGridViewShellEX2.BackgroundColor = System.Drawing.SystemColors.Window
        Me.DataGridViewShellEX2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewShellEX2.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4})
        Me.DataGridViewShellEX2.Dock = System.Windows.Forms.DockStyle.Top
        Me.DataGridViewShellEX2.Location = New System.Drawing.Point(0, 116)
        Me.DataGridViewShellEX2.Name = "DataGridViewShellEX2"
        Me.DataGridViewShellEX2.ReadOnly = True
        Me.DataGridViewShellEX2.RowHeadersVisible = False
        Me.DataGridViewShellEX2.Size = New System.Drawing.Size(970, 124)
        Me.DataGridViewShellEX2.TabIndex = 6
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn3.FillWeight = 65.0!
        Me.DataGridViewTextBoxColumn3.HeaderText = "DIRECTORY"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.ReadOnly = True
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn4.HeaderText = "Shell Plug-in"
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.ReadOnly = True
        '
        'DataGridViewShellEX1
        '
        Me.DataGridViewShellEX1.AllowUserToAddRows = False
        Me.DataGridViewShellEX1.AllowUserToDeleteRows = False
        Me.DataGridViewShellEX1.AllowUserToResizeRows = False
        Me.DataGridViewShellEX1.BackgroundColor = System.Drawing.SystemColors.Window
        Me.DataGridViewShellEX1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewShellEX1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2})
        Me.DataGridViewShellEX1.Dock = System.Windows.Forms.DockStyle.Top
        Me.DataGridViewShellEX1.Location = New System.Drawing.Point(0, 0)
        Me.DataGridViewShellEX1.Name = "DataGridViewShellEX1"
        Me.DataGridViewShellEX1.ReadOnly = True
        Me.DataGridViewShellEX1.RowHeadersVisible = False
        Me.DataGridViewShellEX1.Size = New System.Drawing.Size(970, 116)
        Me.DataGridViewShellEX1.TabIndex = 5
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn1.FillWeight = 65.0!
        Me.DataGridViewTextBoxColumn1.HeaderText = "DRIVE"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.ReadOnly = True
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn2.HeaderText = "Shell Plug-in"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.ReadOnly = True
        '
        'MetroTabPage3
        '
        Me.MetroTabPage3.Controls.Add(Me.DataGridViewIE4)
        Me.MetroTabPage3.Controls.Add(Me.DataGridViewIE3)
        Me.MetroTabPage3.Controls.Add(Me.DataGridViewIE2)
        Me.MetroTabPage3.Controls.Add(Me.DataGridViewIE1)
        Me.MetroTabPage3.HorizontalScrollbarBarColor = False
        Me.MetroTabPage3.HorizontalScrollbarHighlightOnWheel = False
        Me.MetroTabPage3.HorizontalScrollbarSize = 0
        Me.MetroTabPage3.Location = New System.Drawing.Point(4, 38)
        Me.MetroTabPage3.Name = "MetroTabPage3"
        Me.MetroTabPage3.Size = New System.Drawing.Size(970, 476)
        Me.MetroTabPage3.TabIndex = 2
        Me.MetroTabPage3.Text = "Internet Plug-ins"
        Me.MetroTabPage3.VerticalScrollbarBarColor = False
        Me.MetroTabPage3.VerticalScrollbarHighlightOnWheel = False
        Me.MetroTabPage3.VerticalScrollbarSize = 0
        '
        'DataGridViewIE4
        '
        Me.DataGridViewIE4.AllowUserToAddRows = False
        Me.DataGridViewIE4.AllowUserToDeleteRows = False
        Me.DataGridViewIE4.AllowUserToResizeRows = False
        Me.DataGridViewIE4.BackgroundColor = System.Drawing.SystemColors.Window
        Me.DataGridViewIE4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewIE4.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn9, Me.DataGridViewTextBoxColumn10})
        Me.DataGridViewIE4.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.DataGridViewIE4.Location = New System.Drawing.Point(0, 353)
        Me.DataGridViewIE4.Name = "DataGridViewIE4"
        Me.DataGridViewIE4.ReadOnly = True
        Me.DataGridViewIE4.RowHeadersVisible = False
        Me.DataGridViewIE4.Size = New System.Drawing.Size(970, 123)
        Me.DataGridViewIE4.TabIndex = 12
        '
        'DataGridViewTextBoxColumn9
        '
        Me.DataGridViewTextBoxColumn9.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn9.HeaderText = "Software\Wow6432Node\Microsoft\Internet Explorer\Extensions"
        Me.DataGridViewTextBoxColumn9.Name = "DataGridViewTextBoxColumn9"
        Me.DataGridViewTextBoxColumn9.ReadOnly = True
        '
        'DataGridViewTextBoxColumn10
        '
        Me.DataGridViewTextBoxColumn10.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn10.HeaderText = "Plug-in"
        Me.DataGridViewTextBoxColumn10.Name = "DataGridViewTextBoxColumn10"
        Me.DataGridViewTextBoxColumn10.ReadOnly = True
        '
        'DataGridViewIE3
        '
        Me.DataGridViewIE3.AllowUserToAddRows = False
        Me.DataGridViewIE3.AllowUserToDeleteRows = False
        Me.DataGridViewIE3.AllowUserToResizeRows = False
        Me.DataGridViewIE3.BackgroundColor = System.Drawing.SystemColors.Window
        Me.DataGridViewIE3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewIE3.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn11, Me.DataGridViewTextBoxColumn12})
        Me.DataGridViewIE3.Dock = System.Windows.Forms.DockStyle.Top
        Me.DataGridViewIE3.Location = New System.Drawing.Point(0, 235)
        Me.DataGridViewIE3.Name = "DataGridViewIE3"
        Me.DataGridViewIE3.ReadOnly = True
        Me.DataGridViewIE3.RowHeadersVisible = False
        Me.DataGridViewIE3.Size = New System.Drawing.Size(970, 117)
        Me.DataGridViewIE3.TabIndex = 11
        '
        'DataGridViewTextBoxColumn11
        '
        Me.DataGridViewTextBoxColumn11.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn11.HeaderText = "Software\Microsoft\Internet Explorer\Extensions"
        Me.DataGridViewTextBoxColumn11.Name = "DataGridViewTextBoxColumn11"
        Me.DataGridViewTextBoxColumn11.ReadOnly = True
        '
        'DataGridViewTextBoxColumn12
        '
        Me.DataGridViewTextBoxColumn12.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn12.HeaderText = "Plug-in"
        Me.DataGridViewTextBoxColumn12.Name = "DataGridViewTextBoxColumn12"
        Me.DataGridViewTextBoxColumn12.ReadOnly = True
        '
        'DataGridViewIE2
        '
        Me.DataGridViewIE2.AllowUserToAddRows = False
        Me.DataGridViewIE2.AllowUserToDeleteRows = False
        Me.DataGridViewIE2.AllowUserToResizeRows = False
        Me.DataGridViewIE2.BackgroundColor = System.Drawing.SystemColors.Window
        Me.DataGridViewIE2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewIE2.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn13, Me.DataGridViewTextBoxColumn14})
        Me.DataGridViewIE2.Dock = System.Windows.Forms.DockStyle.Top
        Me.DataGridViewIE2.Location = New System.Drawing.Point(0, 106)
        Me.DataGridViewIE2.Name = "DataGridViewIE2"
        Me.DataGridViewIE2.ReadOnly = True
        Me.DataGridViewIE2.RowHeadersVisible = False
        Me.DataGridViewIE2.Size = New System.Drawing.Size(970, 129)
        Me.DataGridViewIE2.TabIndex = 10
        '
        'DataGridViewTextBoxColumn13
        '
        Me.DataGridViewTextBoxColumn13.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn13.HeaderText = "Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\Browser Helper Obj" &
    "ects"
        Me.DataGridViewTextBoxColumn13.Name = "DataGridViewTextBoxColumn13"
        Me.DataGridViewTextBoxColumn13.ReadOnly = True
        '
        'DataGridViewTextBoxColumn14
        '
        Me.DataGridViewTextBoxColumn14.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn14.HeaderText = "Plug-in"
        Me.DataGridViewTextBoxColumn14.Name = "DataGridViewTextBoxColumn14"
        Me.DataGridViewTextBoxColumn14.ReadOnly = True
        '
        'DataGridViewIE1
        '
        Me.DataGridViewIE1.AllowUserToAddRows = False
        Me.DataGridViewIE1.AllowUserToDeleteRows = False
        Me.DataGridViewIE1.AllowUserToResizeRows = False
        Me.DataGridViewIE1.BackgroundColor = System.Drawing.SystemColors.Window
        Me.DataGridViewIE1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewIE1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn15, Me.DataGridViewTextBoxColumn16})
        Me.DataGridViewIE1.Dock = System.Windows.Forms.DockStyle.Top
        Me.DataGridViewIE1.Location = New System.Drawing.Point(0, 0)
        Me.DataGridViewIE1.Name = "DataGridViewIE1"
        Me.DataGridViewIE1.ReadOnly = True
        Me.DataGridViewIE1.RowHeadersVisible = False
        Me.DataGridViewIE1.Size = New System.Drawing.Size(970, 106)
        Me.DataGridViewIE1.TabIndex = 9
        '
        'DataGridViewTextBoxColumn15
        '
        Me.DataGridViewTextBoxColumn15.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn15.HeaderText = "Software\Microsoft\Windows\CurrentVersion\Explorer\Browser Helper Objects"
        Me.DataGridViewTextBoxColumn15.Name = "DataGridViewTextBoxColumn15"
        Me.DataGridViewTextBoxColumn15.ReadOnly = True
        '
        'DataGridViewTextBoxColumn16
        '
        Me.DataGridViewTextBoxColumn16.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn16.HeaderText = "Plug-in"
        Me.DataGridViewTextBoxColumn16.Name = "DataGridViewTextBoxColumn16"
        Me.DataGridViewTextBoxColumn16.ReadOnly = True
        '
        'MetroTabPage4
        '
        Me.MetroTabPage4.Controls.Add(Me.DataGridViewNW4)
        Me.MetroTabPage4.Controls.Add(Me.DataGridViewNW3)
        Me.MetroTabPage4.Controls.Add(Me.DataGridViewNW2)
        Me.MetroTabPage4.Controls.Add(Me.DataGridViewNW1)
        Me.MetroTabPage4.HorizontalScrollbarBarColor = False
        Me.MetroTabPage4.HorizontalScrollbarHighlightOnWheel = False
        Me.MetroTabPage4.HorizontalScrollbarSize = 0
        Me.MetroTabPage4.Location = New System.Drawing.Point(4, 38)
        Me.MetroTabPage4.Name = "MetroTabPage4"
        Me.MetroTabPage4.Size = New System.Drawing.Size(970, 476)
        Me.MetroTabPage4.TabIndex = 3
        Me.MetroTabPage4.Text = "Network Plug-ins"
        Me.MetroTabPage4.VerticalScrollbarBarColor = False
        Me.MetroTabPage4.VerticalScrollbarHighlightOnWheel = False
        Me.MetroTabPage4.VerticalScrollbarSize = 0
        '
        'DataGridViewNW4
        '
        Me.DataGridViewNW4.AllowUserToAddRows = False
        Me.DataGridViewNW4.AllowUserToDeleteRows = False
        Me.DataGridViewNW4.AllowUserToResizeRows = False
        Me.DataGridViewNW4.BackgroundColor = System.Drawing.SystemColors.Window
        Me.DataGridViewNW4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewNW4.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn17, Me.DataGridViewTextBoxColumn18})
        Me.DataGridViewNW4.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.DataGridViewNW4.Location = New System.Drawing.Point(0, 358)
        Me.DataGridViewNW4.Name = "DataGridViewNW4"
        Me.DataGridViewNW4.ReadOnly = True
        Me.DataGridViewNW4.RowHeadersVisible = False
        Me.DataGridViewNW4.Size = New System.Drawing.Size(970, 118)
        Me.DataGridViewNW4.TabIndex = 16
        '
        'DataGridViewTextBoxColumn17
        '
        Me.DataGridViewTextBoxColumn17.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn17.FillWeight = 125.0!
        Me.DataGridViewTextBoxColumn17.HeaderText = "System\CurrentControlSet\Services\WinSock2\Parameters\NameSpace_Catalog5\Catalog_" &
    "Entries64"
        Me.DataGridViewTextBoxColumn17.Name = "DataGridViewTextBoxColumn17"
        Me.DataGridViewTextBoxColumn17.ReadOnly = True
        '
        'DataGridViewTextBoxColumn18
        '
        Me.DataGridViewTextBoxColumn18.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn18.HeaderText = "Plug-in"
        Me.DataGridViewTextBoxColumn18.Name = "DataGridViewTextBoxColumn18"
        Me.DataGridViewTextBoxColumn18.ReadOnly = True
        '
        'DataGridViewNW3
        '
        Me.DataGridViewNW3.AllowUserToAddRows = False
        Me.DataGridViewNW3.AllowUserToDeleteRows = False
        Me.DataGridViewNW3.AllowUserToResizeRows = False
        Me.DataGridViewNW3.BackgroundColor = System.Drawing.SystemColors.Window
        Me.DataGridViewNW3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewNW3.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn19, Me.DataGridViewTextBoxColumn20})
        Me.DataGridViewNW3.Dock = System.Windows.Forms.DockStyle.Top
        Me.DataGridViewNW3.Location = New System.Drawing.Point(0, 236)
        Me.DataGridViewNW3.Name = "DataGridViewNW3"
        Me.DataGridViewNW3.ReadOnly = True
        Me.DataGridViewNW3.RowHeadersVisible = False
        Me.DataGridViewNW3.Size = New System.Drawing.Size(970, 121)
        Me.DataGridViewNW3.TabIndex = 15
        '
        'DataGridViewTextBoxColumn19
        '
        Me.DataGridViewTextBoxColumn19.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn19.FillWeight = 125.0!
        Me.DataGridViewTextBoxColumn19.HeaderText = "System\CurrentControlSet\Services\WinSock2\Parameters\NameSpace_Catalog5\Catalog_" &
    "Entries"
        Me.DataGridViewTextBoxColumn19.Name = "DataGridViewTextBoxColumn19"
        Me.DataGridViewTextBoxColumn19.ReadOnly = True
        '
        'DataGridViewTextBoxColumn20
        '
        Me.DataGridViewTextBoxColumn20.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn20.HeaderText = "Plug-in"
        Me.DataGridViewTextBoxColumn20.Name = "DataGridViewTextBoxColumn20"
        Me.DataGridViewTextBoxColumn20.ReadOnly = True
        '
        'DataGridViewNW2
        '
        Me.DataGridViewNW2.AllowUserToAddRows = False
        Me.DataGridViewNW2.AllowUserToDeleteRows = False
        Me.DataGridViewNW2.AllowUserToResizeRows = False
        Me.DataGridViewNW2.BackgroundColor = System.Drawing.SystemColors.Window
        Me.DataGridViewNW2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewNW2.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn21, Me.DataGridViewTextBoxColumn22})
        Me.DataGridViewNW2.Dock = System.Windows.Forms.DockStyle.Top
        Me.DataGridViewNW2.Location = New System.Drawing.Point(0, 111)
        Me.DataGridViewNW2.Name = "DataGridViewNW2"
        Me.DataGridViewNW2.ReadOnly = True
        Me.DataGridViewNW2.RowHeadersVisible = False
        Me.DataGridViewNW2.Size = New System.Drawing.Size(970, 125)
        Me.DataGridViewNW2.TabIndex = 14
        '
        'DataGridViewTextBoxColumn21
        '
        Me.DataGridViewTextBoxColumn21.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn21.FillWeight = 125.0!
        Me.DataGridViewTextBoxColumn21.HeaderText = "System\CurrentControlSet\Services\WinSock2\Parameters\Protocol_Catalog9\Catalog_E" &
    "ntries64"
        Me.DataGridViewTextBoxColumn21.Name = "DataGridViewTextBoxColumn21"
        Me.DataGridViewTextBoxColumn21.ReadOnly = True
        '
        'DataGridViewTextBoxColumn22
        '
        Me.DataGridViewTextBoxColumn22.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn22.HeaderText = "Plug-in"
        Me.DataGridViewTextBoxColumn22.Name = "DataGridViewTextBoxColumn22"
        Me.DataGridViewTextBoxColumn22.ReadOnly = True
        '
        'DataGridViewNW1
        '
        Me.DataGridViewNW1.AllowUserToAddRows = False
        Me.DataGridViewNW1.AllowUserToDeleteRows = False
        Me.DataGridViewNW1.AllowUserToResizeRows = False
        Me.DataGridViewNW1.BackgroundColor = System.Drawing.SystemColors.Window
        Me.DataGridViewNW1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewNW1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn23, Me.DataGridViewTextBoxColumn24})
        Me.DataGridViewNW1.Dock = System.Windows.Forms.DockStyle.Top
        Me.DataGridViewNW1.Location = New System.Drawing.Point(0, 0)
        Me.DataGridViewNW1.Name = "DataGridViewNW1"
        Me.DataGridViewNW1.ReadOnly = True
        Me.DataGridViewNW1.RowHeadersVisible = False
        Me.DataGridViewNW1.Size = New System.Drawing.Size(970, 111)
        Me.DataGridViewNW1.TabIndex = 13
        '
        'DataGridViewTextBoxColumn23
        '
        Me.DataGridViewTextBoxColumn23.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn23.FillWeight = 125.0!
        Me.DataGridViewTextBoxColumn23.HeaderText = "System\CurrentControlSet\Services\WinSock2\Parameters\Protocol_Catalog9\Catalog_E" &
    "ntries"
        Me.DataGridViewTextBoxColumn23.Name = "DataGridViewTextBoxColumn23"
        Me.DataGridViewTextBoxColumn23.ReadOnly = True
        '
        'DataGridViewTextBoxColumn24
        '
        Me.DataGridViewTextBoxColumn24.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn24.HeaderText = "Plug-in"
        Me.DataGridViewTextBoxColumn24.Name = "DataGridViewTextBoxColumn24"
        Me.DataGridViewTextBoxColumn24.ReadOnly = True
        '
        'MetroTabPage5
        '
        Me.MetroTabPage5.Controls.Add(Me.DataGridViewPM)
        Me.MetroTabPage5.HorizontalScrollbarBarColor = False
        Me.MetroTabPage5.HorizontalScrollbarHighlightOnWheel = False
        Me.MetroTabPage5.HorizontalScrollbarSize = 0
        Me.MetroTabPage5.Location = New System.Drawing.Point(4, 38)
        Me.MetroTabPage5.Name = "MetroTabPage5"
        Me.MetroTabPage5.Size = New System.Drawing.Size(970, 476)
        Me.MetroTabPage5.TabIndex = 4
        Me.MetroTabPage5.Text = "Local Print Server"
        Me.MetroTabPage5.VerticalScrollbarBarColor = False
        Me.MetroTabPage5.VerticalScrollbarHighlightOnWheel = False
        Me.MetroTabPage5.VerticalScrollbarSize = 0
        '
        'DataGridViewPM
        '
        Me.DataGridViewPM.AllowUserToAddRows = False
        Me.DataGridViewPM.AllowUserToDeleteRows = False
        Me.DataGridViewPM.AllowUserToResizeRows = False
        Me.DataGridViewPM.BackgroundColor = System.Drawing.SystemColors.Window
        Me.DataGridViewPM.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewPM.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn25, Me.DataGridViewTextBoxColumn26})
        Me.DataGridViewPM.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DataGridViewPM.Location = New System.Drawing.Point(0, 0)
        Me.DataGridViewPM.Name = "DataGridViewPM"
        Me.DataGridViewPM.ReadOnly = True
        Me.DataGridViewPM.RowHeadersVisible = False
        Me.DataGridViewPM.Size = New System.Drawing.Size(970, 476)
        Me.DataGridViewPM.TabIndex = 11
        '
        'DataGridViewTextBoxColumn25
        '
        Me.DataGridViewTextBoxColumn25.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn25.HeaderText = "SYSTEM\CurrentControlSet\Control\Print\Monitors"
        Me.DataGridViewTextBoxColumn25.Name = "DataGridViewTextBoxColumn25"
        Me.DataGridViewTextBoxColumn25.ReadOnly = True
        '
        'DataGridViewTextBoxColumn26
        '
        Me.DataGridViewTextBoxColumn26.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn26.HeaderText = "Driver"
        Me.DataGridViewTextBoxColumn26.Name = "DataGridViewTextBoxColumn26"
        Me.DataGridViewTextBoxColumn26.ReadOnly = True
        '
        'StartupItems
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BorderStyle = MetroFramework.Forms.MetroFormBorderStyle.FixedSingle
        Me.ClientSize = New System.Drawing.Size(1018, 598)
        Me.Controls.Add(Me.MetroTabControl1)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "StartupItems"
        Me.Resizable = False
        Me.ShadowType = MetroFramework.Forms.MetroFormShadowType.None
        Me.ShowIcon = False
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
        Me.MetroTabControl1.ResumeLayout(False)
        Me.MetroTabPage1.ResumeLayout(False)
        CType(Me.DataGridViewRunUser, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridViewRun64, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridViewRun32, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MetroTabPage2.ResumeLayout(False)
        CType(Me.DataGridViewShellEX3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridViewShellEX4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridViewShellEX2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridViewShellEX1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MetroTabPage3.ResumeLayout(False)
        CType(Me.DataGridViewIE4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridViewIE3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridViewIE2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridViewIE1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MetroTabPage4.ResumeLayout(False)
        CType(Me.DataGridViewNW4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridViewNW3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridViewNW2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridViewNW1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MetroTabPage5.ResumeLayout(False)
        CType(Me.DataGridViewPM, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents MetroTabControl1 As MetroFramework.Controls.MetroTabControl
    Friend WithEvents MetroTabPage1 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents MetroTabPage2 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents MetroTabPage3 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents MetroTabPage4 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents MetroTabPage5 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents DataGridViewRunUser As System.Windows.Forms.DataGridView
    Friend WithEvents RunUserName As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents RunUserData As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewRun64 As System.Windows.Forms.DataGridView
    Friend WithEvents Run64Name As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Run64Data As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewRun32 As System.Windows.Forms.DataGridView
    Friend WithEvents Run32Name As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Run32Data As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewShellEX3 As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn7 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn8 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewShellEX4 As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewShellEX2 As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewShellEX1 As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewIE4 As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn9 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn10 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewIE3 As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn11 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn12 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewIE2 As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn13 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn14 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewIE1 As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn15 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn16 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewNW4 As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn17 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn18 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewNW3 As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn19 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn20 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewNW2 As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn21 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn22 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewNW1 As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn23 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn24 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewPM As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn25 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn26 As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
