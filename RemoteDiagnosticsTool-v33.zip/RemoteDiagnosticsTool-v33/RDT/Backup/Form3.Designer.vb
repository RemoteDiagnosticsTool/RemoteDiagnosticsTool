<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.DataGridView5 = New System.Windows.Forms.DataGridView
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridView4 = New System.Windows.Forms.DataGridView
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridView3 = New System.Windows.Forms.DataGridView
        Me.CONNECTIONNAME = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.SERVER = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridView2 = New System.Windows.Forms.DataGridView
        Me.Version = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.GlobalDataDirectory = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.UserDataDirectory = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DriveLetter = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DetectAPPV = New System.Windows.Forms.Button
        Me.RemoteCommand = New System.Windows.Forms.TextBox
        Me.ExecuteRemoteCommand = New System.Windows.Forms.Button
        CType(Me.DataGridView5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DataGridView5
        '
        Me.DataGridView5.AllowUserToOrderColumns = True
        Me.DataGridView5.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.DataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView5.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4})
        Me.DataGridView5.Location = New System.Drawing.Point(170, 172)
        Me.DataGridView5.Name = "DataGridView5"
        Me.DataGridView5.Size = New System.Drawing.Size(826, 48)
        Me.DataGridView5.TabIndex = 21
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn3.FillWeight = 250.0!
        Me.DataGridViewTextBoxColumn3.HeaderText = "Application"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.ReadOnly = True
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn4.HeaderText = "Version"
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.ReadOnly = True
        '
        'DataGridView4
        '
        Me.DataGridView4.AllowUserToOrderColumns = True
        Me.DataGridView4.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.DataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView4.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2})
        Me.DataGridView4.Location = New System.Drawing.Point(170, 118)
        Me.DataGridView4.Name = "DataGridView4"
        Me.DataGridView4.Size = New System.Drawing.Size(826, 48)
        Me.DataGridView4.TabIndex = 20
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn1.FillWeight = 60.0!
        Me.DataGridViewTextBoxColumn1.HeaderText = "Package"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.ReadOnly = True
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn2.HeaderText = "URL"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.ReadOnly = True
        '
        'DataGridView3
        '
        Me.DataGridView3.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.DataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView3.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.CONNECTIONNAME, Me.SERVER})
        Me.DataGridView3.Location = New System.Drawing.Point(170, 65)
        Me.DataGridView3.Name = "DataGridView3"
        Me.DataGridView3.Size = New System.Drawing.Size(826, 47)
        Me.DataGridView3.TabIndex = 19
        '
        'CONNECTIONNAME
        '
        Me.CONNECTIONNAME.FillWeight = 200.0!
        Me.CONNECTIONNAME.HeaderText = "CONNECTIONNAME"
        Me.CONNECTIONNAME.Name = "CONNECTIONNAME"
        Me.CONNECTIONNAME.ReadOnly = True
        '
        'SERVER
        '
        Me.SERVER.HeaderText = "SERVER"
        Me.SERVER.Name = "SERVER"
        Me.SERVER.ReadOnly = True
        '
        'DataGridView2
        '
        Me.DataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.DataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView2.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Version, Me.GlobalDataDirectory, Me.UserDataDirectory, Me.DriveLetter})
        Me.DataGridView2.Location = New System.Drawing.Point(170, 12)
        Me.DataGridView2.Name = "DataGridView2"
        Me.DataGridView2.Size = New System.Drawing.Size(826, 47)
        Me.DataGridView2.TabIndex = 18
        '
        'Version
        '
        Me.Version.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.Version.FillWeight = 15.35755!
        Me.Version.HeaderText = "Version"
        Me.Version.Name = "Version"
        Me.Version.ReadOnly = True
        '
        'GlobalDataDirectory
        '
        Me.GlobalDataDirectory.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.GlobalDataDirectory.FillWeight = 71.24635!
        Me.GlobalDataDirectory.HeaderText = "GlobalDataDirectory"
        Me.GlobalDataDirectory.Name = "GlobalDataDirectory"
        Me.GlobalDataDirectory.ReadOnly = True
        '
        'UserDataDirectory
        '
        Me.UserDataDirectory.FillWeight = 38.39387!
        Me.UserDataDirectory.HeaderText = "UserDataDirectory"
        Me.UserDataDirectory.Name = "UserDataDirectory"
        Me.UserDataDirectory.ReadOnly = True
        '
        'DriveLetter
        '
        Me.DriveLetter.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DriveLetter.FillWeight = 15.35755!
        Me.DriveLetter.HeaderText = "DriveLetter"
        Me.DriveLetter.Name = "DriveLetter"
        Me.DriveLetter.ReadOnly = True
        '
        'DetectAPPV
        '
        Me.DetectAPPV.AutoSize = True
        Me.DetectAPPV.Location = New System.Drawing.Point(12, 12)
        Me.DetectAPPV.Name = "DetectAPPV"
        Me.DetectAPPV.Size = New System.Drawing.Size(109, 23)
        Me.DetectAPPV.TabIndex = 22
        Me.DetectAPPV.TabStop = False
        Me.DetectAPPV.Text = "Detect APPV Client"
        Me.DetectAPPV.UseVisualStyleBackColor = True
        '
        'RemoteCommand
        '
        Me.RemoteCommand.Location = New System.Drawing.Point(268, 695)
        Me.RemoteCommand.Name = "RemoteCommand"
        Me.RemoteCommand.Size = New System.Drawing.Size(632, 20)
        Me.RemoteCommand.TabIndex = 24
        '
        'ExecuteRemoteCommand
        '
        Me.ExecuteRemoteCommand.Location = New System.Drawing.Point(170, 695)
        Me.ExecuteRemoteCommand.Name = "ExecuteRemoteCommand"
        Me.ExecuteRemoteCommand.Size = New System.Drawing.Size(90, 23)
        Me.ExecuteRemoteCommand.TabIndex = 23
        Me.ExecuteRemoteCommand.Text = "Send Command"
        Me.ExecuteRemoteCommand.UseVisualStyleBackColor = True
        '
        'Form3
        '
        Me.AcceptButton = Me.DetectAPPV
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1008, 730)
        Me.Controls.Add(Me.RemoteCommand)
        Me.Controls.Add(Me.ExecuteRemoteCommand)
        Me.Controls.Add(Me.DetectAPPV)
        Me.Controls.Add(Me.DataGridView5)
        Me.Controls.Add(Me.DataGridView4)
        Me.Controls.Add(Me.DataGridView3)
        Me.Controls.Add(Me.DataGridView2)
        Me.MaximizeBox = False
        Me.Name = "Form3"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "APPV"
        CType(Me.DataGridView5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents DataGridView5 As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridView4 As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridView3 As System.Windows.Forms.DataGridView
    Friend WithEvents CONNECTIONNAME As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents SERVER As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridView2 As System.Windows.Forms.DataGridView
    Friend WithEvents Version As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents GlobalDataDirectory As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents UserDataDirectory As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DriveLetter As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DetectAPPV As System.Windows.Forms.Button
    Friend WithEvents RemoteCommand As System.Windows.Forms.TextBox
    Friend WithEvents ExecuteRemoteCommand As System.Windows.Forms.Button
End Class
