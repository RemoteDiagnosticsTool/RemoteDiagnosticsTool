﻿Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Management
Imports System.Runtime.InteropServices
Imports System.Diagnostics.Process
Imports System.IO
Imports System.Net
Imports System.Text.RegularExpressions
Imports System.DirectoryServices
Imports System.Threading
Imports System.Text
Imports System.Security.AccessControl
Imports System.Security.Principal

Public Class Appv5
    Inherits MetroFramework.Forms.MetroForm

    Public Declare Function WNetAddConnection2 Lib "mpr.dll" Alias "WNetAddConnection2A" (ByRef lpNetResource As NETRESOURCE, ByVal lpPassword As String, ByVal lpUserName As String, ByVal dwFlags As Integer) As Integer
    Public Declare Function WNetCancelConnection2 Lib "mpr" Alias "WNetCancelConnection2A" (ByVal lpName As String, ByVal dwFlags As Integer, ByVal fForce As Integer) As Integer

    <Runtime.InteropServices.StructLayout(LayoutKind.Sequential)> Public Structure NETRESOURCE
        Public dwScope As Integer
        Public dwType As Integer
        Public dwDisplayType As Integer
        Public dwUsage As Integer
        Public lpLocalName As String
        Public lpRemoteName As String
        Public lpComment As String
        Public lpProvider As String
    End Structure

    Public Const RESOURCETYPE_DISK As Long = &H1

    Private Sub Powershell_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Powershell.Click
        If MachineName = "" Then
            Exit Sub
        End If

        Dim powersetup As Boolean = False
        powersetup = SETUPPowerShellonRemote()
        If powersetup = False Then
            MsgBox("Unable to configure Powershell for connection on computer : " & txtpcname)
            Exit Sub
        End If

        Me.Cursor = Cursors.WaitCursor

        Try

            Dim securepass As New Security.SecureString
            Dim c As Char
            For Each c In password
                securepass.AppendChar(c)
            Next
            Process.Start(New ProcessStartInfo() With {.UseShellExecute = False, .FileName = "powershell.exe", .UserName = username, .Password = securepass, .Domain = domain, .Arguments = "-Noexit enter-pssession " & MachineName, .WorkingDirectory = "C:\Windows\Temp"})

        Catch ex As Exception
        End Try

        Me.Cursor = Cursors.Default

    End Sub

    Private Function IsPortOpen(ByVal Host As String, ByVal PortNumber As Integer) As Boolean
        Dim Client As Sockets.TcpClient = Nothing
        Try
            Client = New Sockets.TcpClient(Host, PortNumber)
            Return True
        Catch ex As Sockets.SocketException
            Return False
        Finally
            If Not Client Is Nothing Then
                Client.Close()
            End If
        End Try
    End Function

    Private Function SETUPPowerShellonRemote() As Boolean

        Dim Port As Integer = 5985
        Dim Hostname As String = IP4Address
        Dim PortOpen As Boolean = IsPortOpen(Hostname, Port)
        If PortOpen = True Then
            Return True
            Exit Function
        End If
        If PortOpen = False Then

            Try
                Dim wmi_out As Management.ManagementBaseObject
                Dim objManagementScope As Management.ManagementScope
                Dim objManagementClass As Management.ManagementClass = Nothing
                Dim objManagementBaseObject As Management.ManagementBaseObject = Nothing
                Dim retValue As Integer
                Dim Command As String = "CMD /C winrm quickconfig -quiet"

                Try
                    Dim options As Management.ConnectionOptions
                    options = New Management.ConnectionOptions()
                    Dim computerconnect As String = "\\" & txtpcname & "\root\cimv2:Win32_Process"

                    options.Username = username
                    options.Password = password
                    options.Timeout = TimeSpan.FromSeconds(30)
                    options.Authority = "NTLMDOMAIN:" & domain
                    options.Authentication = Management.AuthenticationLevel.PacketPrivacy
                    objManagementScope = New Management.ManagementScope(computerconnect, options)

                    If objManagementScope.IsConnected = True Then
                    Else
                        Try
                            objManagementScope.Connect()
                        Catch ex As Exception
                            'MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                            Return False
                            Exit Function
                        End Try
                    End If

                    objManagementClass = New Management.ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
                    objManagementClass.Scope = objManagementScope

                    objManagementBaseObject = objManagementClass.GetMethodParameters("Create")
                    objManagementBaseObject.SetPropertyValue("CommandLine", Command)
                    wmi_out = objManagementClass.InvokeMethod("Create", objManagementBaseObject, Nothing)

                    retValue = Convert.ToInt32(wmi_out("returnValue"))
                    Select Case retValue
                        Case 0
                        ' success!
                        Case 2
                            Throw New ApplicationException("Access denied")
                        Case 3
                            Throw New ApplicationException("Insufficient privilege")
                        Case 8
                            Throw New ApplicationException("Unknown failure")
                        Case 9
                            Throw New ApplicationException("Path not found")
                        Case 21
                            Throw New ApplicationException("Invalid parameter")
                        Case Else
                            Throw New ApplicationException("Unknown return code " & retValue)
                    End Select
                Catch ex As Exception
                    'MsgBox(txtpcname & ": Can't create the process. " & ex.Message)
                End Try
                wmi_out = Nothing
                objManagementBaseObject.Dispose()
                objManagementClass.Dispose()
            Catch
                'MessageBox.Show("Could not run process, " & Err.Description, "Error:", MessageBoxButtons.OK, MessageBoxIcon.Stop)
            End Try

            Try
                Dim connOptions As New Management.ConnectionOptions()
                connOptions.Username = username
                connOptions.Password = password
                connOptions.Timeout = TimeSpan.FromSeconds(30)
                connOptions.Authority = "NTLMDOMAIN:" & domain
                connOptions.EnablePrivileges = True
                connOptions.Authentication = AuthenticationLevel.PacketPrivacy
                connOptions.Impersonation = ImpersonationLevel.Impersonate
                connOptions.EnablePrivileges = True
                Dim manScope As New Management.ManagementScope([String].Format("\\{0}\ROOT\CIMV2", txtpcname), connOptions)

                Try
                    manScope.Connect()
                Catch
                    'MsgBox("Couldn't connect to remote PC.")
                    Return False
                    Exit Function
                End Try

                Dim objectGetOptions As New Management.ObjectGetOptions()
                Dim managementPath As New Management.ManagementPath("Win32_Process")
                Using processClass As New Management.ManagementClass(manScope, managementPath, objectGetOptions)
                    Using inParams As Management.ManagementBaseObject = processClass.GetMethodParameters("Create")
                        inParams("CommandLine") = Chr(34) & "winrm create winrm/config/listener?Address=*+Transport=HTTP" & Chr(34)
                        Using outParams As Management.ManagementBaseObject = processClass.InvokeMethod("Create", inParams, Nothing)
                            If CUInt(outParams("returnValue")) <> 0 Then
                                'MsgBox("Unsuccessfully Configured Powershell")
                                Return False
                                Exit Function
                            Else
                                'MsgBox("Configured Transport=HTTP for Powershell")
                                'processID = CUInt(outParams("processId"))
                                Return True
                                Exit Function
                            End If
                        End Using
                    End Using
                End Using
                manScope = Nothing
            Catch
            End Try
        End If

    End Function

    Private Sub Appv5_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        MetroLabel1.Text = "App-V Version : " & DetectedAPPVVersion & " on : " & MachineName

        DataGridView1.Rows.Clear()
        DataGridView2.Rows.Clear()
        DataGridView3.Rows.Clear()
        MetroTabControl1.SelectedTab = MetroTab1

    End Sub

    Private Sub GetAPPV5PackageList_Click(sender As Object, e As EventArgs) Handles GetAPPV5PackageList.Click
        MetroTabControl1.SelectedTab = MetroTab1
        PopulateAPPV()
    End Sub

    Private Sub GetAPPV5ShortcutList_Click(sender As Object, e As EventArgs) Handles GetAPPV5ShortcutList.Click
        MetroTabControl1.SelectedTab = MetroTab2
        PopulateAPPVShortcuts()
    End Sub

    Private Sub PopulateAPPV()
        Dim PkgGUID1 As String = Nothing
        Dim Name1 As String = Nothing
        Dim version1 As String = Nothing
        Dim InUse1 As String = Nothing
        Dim TotalSize1 As String = Nothing
        Dim SftPath1 As String = Nothing
        Dim Locked1 As String = Nothing
        Dim VersionID As String = Nothing
        Dim PercentLoaded As String = Nothing

        Cursor = Cursors.WaitCursor

        Dim QueryOptions = New Management.EnumerationOptions
        QueryOptions.Timeout = New TimeSpan(0, 0, 10)

        Dim objManagementScope As Management.ManagementScope
        Dim options As Management.ConnectionOptions
        options = New Management.ConnectionOptions()
        Dim computerconnect As String = "\\" & txtpcname & "\root\appv"
        options.Username = username
        options.Password = password
        options.Timeout = TimeSpan.FromSeconds(30)
        options.Authority = "NTLMDOMAIN:" & domain
        options.Authentication = Management.AuthenticationLevel.PacketPrivacy
        objManagementScope = New Management.ManagementScope(computerconnect, options)

        If objManagementScope.IsConnected = True Then
        Else
            Try
                objManagementScope.Connect()
            Catch ex As Exception
                MessageBox.Show("Couldn't connect: " + ex.Message, "Error , Please check PC online and APPV Agent is installed!")
                Cursor = Cursors.Default
                Me.Close()
                Exit Sub
            End Try
        End If

        DataGridView1.Rows.Clear()

        Try
            Dim query As New Management.SelectQuery("SELECT * FROM AppvClientPackage")
            Dim searcher As New Management.ManagementObjectSearcher(objManagementScope, query, QueryOptions)
            For Each mo As Management.ManagementObject In searcher.[Get]()
                Name1 = mo("Name")
                version1 = mo("Version")
                PercentLoaded = mo("PercentLoaded")
                PkgGUID1 = mo("PackageId")
                VersionID = mo("VersionId")
                InUse1 = mo("InUse")
                Locked1 = mo("IsPublishedGlobally")
                TotalSize1 = mo("PackageSize")
                SftPath1 = mo("Path")

                DataGridView1.RowTemplate.DefaultCellStyle.ForeColor = Color.Black
                DataGridView1.Rows.Add(Name1, version1, PercentLoaded, PkgGUID1, VersionID, InUse1, Locked1, TotalSize1, SftPath1)
            Next

        Catch ex As Exception
            MessageBox.Show("Unable to connect to APPV Agent, Please check Agent is Installed!")
            Cursor = Cursors.Default
            Me.Close()
            Form5.Show()
            Exit Sub
        End Try

        Try
            DataGridView1.Sort(DataGridView1.Columns(0), System.ComponentModel.ListSortDirection.Ascending)
        Catch
        End Try

        objManagementScope = Nothing

        Cursor = Cursors.Default
    End Sub

    Private Sub PopulateAPPVShortcuts()
        Dim PkgGUID2 As String = Nothing
        Dim Name2 As String = Nothing
        Dim version2 As String = Nothing
        Dim VersionID2 As String = Nothing
        Dim TargetPath2 As String = Nothing

        Cursor = Cursors.WaitCursor

        Dim QueryOptions = New Management.EnumerationOptions
        QueryOptions.Timeout = New TimeSpan(0, 0, 10)

        Dim objManagementScope As Management.ManagementScope
        Dim options As Management.ConnectionOptions
        options = New Management.ConnectionOptions()
        Dim computerconnect As String = "\\" & txtpcname & "\root\appv"
        options.Username = username
        options.Password = password
        options.Timeout = TimeSpan.FromSeconds(30)
        options.Authority = "NTLMDOMAIN:" & domain
        options.Authentication = Management.AuthenticationLevel.PacketPrivacy
        objManagementScope = New Management.ManagementScope(computerconnect, options)

        If objManagementScope.IsConnected = True Then
        Else
            Try
                objManagementScope.Connect()
            Catch ex As Exception
                MessageBox.Show("Couldn't connect: " + ex.Message, "Error , Please check PC online and APPV Agent is installed!")
                Cursor = Cursors.Default
                Me.Close()
                Exit Sub
            End Try
        End If

        DataGridView2.Rows.Clear()

        Try
            Dim query As New Management.SelectQuery("SELECT * FROM AppvClientApplication")
            Dim searcher As New Management.ManagementObjectSearcher(objManagementScope, query, QueryOptions)
            For Each mo As Management.ManagementObject In searcher.[Get]()
                Name2 = mo("Name")
                version2 = mo("Version")
                TargetPath2 = mo("TargetPath")
                'PkgGUID2 = mo("*PackageId")
                'VersionID2 = mo("*PackageVersionId")

                'Dim s1 As String = Microsoft.VisualBasic.Left(LastLaunchOnSystem2, 14)
                'LastLaunchOnSystem2converted = Date.ParseExact(s1, "yyyyMMddHHmmss", System.Globalization.DateTimeFormatInfo.InvariantInfo)

                DataGridView2.RowTemplate.DefaultCellStyle.ForeColor = Color.Black
                DataGridView2.Rows.Add(Name2, version2, TargetPath2)
            Next

        Catch ex As Exception
            MessageBox.Show("Unable to connect to APPV Agent, Please check Agent is Installed!")
        End Try

        Try
            DataGridView2.Sort(DataGridView2.Columns(0), System.ComponentModel.ListSortDirection.Ascending)
        Catch
        End Try
        Cursor = Cursors.Default

        objManagementScope = Nothing
    End Sub

    Private Sub MetroTile1_Click(sender As Object, e As EventArgs) Handles MetroTile1.Click
        Dim PkgGUID2 As String = Nothing
        Dim Name2 As String = Nothing
        Dim version2 As String = Nothing
        Dim VersionID2 As String = Nothing
        Dim TargetPath2 As String = Nothing

        MetroTabControl1.SelectedTab = MetroTab3

        Cursor = Cursors.WaitCursor

        Dim QueryOptions = New Management.EnumerationOptions
        QueryOptions.Timeout = New TimeSpan(0, 0, 10)

        Dim objManagementScope As Management.ManagementScope
        Dim options As Management.ConnectionOptions
        options = New Management.ConnectionOptions()
        Dim computerconnect As String = "\\" & txtpcname & "\root\appv"
        options.Username = username
        options.Password = password
        options.Timeout = TimeSpan.FromSeconds(30)
        options.Authority = "NTLMDOMAIN:" & domain
        options.Authentication = Management.AuthenticationLevel.PacketPrivacy
        objManagementScope = New Management.ManagementScope(computerconnect, options)

        If objManagementScope.IsConnected = True Then
        Else
            Try
                objManagementScope.Connect()
            Catch ex As Exception
                MessageBox.Show("Couldn't connect: " + ex.Message, "Error , Please check PC online and APPV Agent is installed!")
                Cursor = Cursors.Default
                Me.Close()
                Exit Sub
            End Try
        End If

        DataGridView3.Rows.Clear()
        DataGridView3.RowTemplate.DefaultCellStyle.ForeColor = Color.Black

        Try
            Dim query As New Management.SelectQuery("SELECT * FROM AppvClientConnectionGroup")
            Dim searcher As New Management.ManagementObjectSearcher(objManagementScope, query, QueryOptions)
            For Each mo As Management.ManagementObject In searcher.[Get]()

                Name2 = mo("Name")
                Dim aSubKeys2() As String = mo("Packages")
                Dim strkey2 As String = ""


                Try
                    For Each strkey2 In aSubKeys2
                        Dim lookforbackslash As Integer = InStr(strkey2, """")
                        If lookforbackslash <> 0 Then
                            Dim wordArr As String() = strkey2.Split("""")
                            Dim result1 As String = wordArr(1)
                            Dim result2 As String = wordArr(3)
                            DataGridView3.Rows.Add(Name2, result1, result2)
                        End If
                    Next
                Catch EX As Exception
                End Try

            Next

        Catch ex As Exception
            MessageBox.Show("Unable to connect to APPV Agent, Please check Agent is Installed!")
        End Try

        Try
            DataGridView3.Sort(DataGridView3.Columns(0), System.ComponentModel.ListSortDirection.Ascending)
        Catch
        End Try
        Cursor = Cursors.Default

        objManagementScope = Nothing
    End Sub
End Class