﻿Imports System.Resources

Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("RDT")>
<Assembly: AssemblyDescription("Remote Diagnostics Tool for Windows PC Administrators")>
<Assembly: AssemblyCompany("")>
<Assembly: AssemblyProduct("Remote Diagnostics Tool")> 
<Assembly: AssemblyCopyright("This work is registered with UK Copyright Service")> 
<Assembly: AssemblyTrademark("Registration No: 284699836")> 

<Assembly: ComVisible(True)> 

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("4ec2fb3d-ebc2-493f-807f-fc833a0b4531")>

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("4.0.45.0")>
<Assembly: AssemblyFileVersion("4.0.45.0")>

<Assembly: NeutralResourcesLanguageAttribute("en-GB")> 