strComputer = "."
    
Set oWMI = GetObject("winmgmts:{impersonationLevel=impersonate}!\\" & strComputer & "\root\SecurityCenter2")
Set colItems = oWMI.ExecQuery("Select * from AntiVirusProduct")

For Each objItem in colItems
  With objItem
    WScript.Echo .displayName & " ~~ " & .timestamp & " ~~ " & .productState
  End With
Next

