﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Appv5
    Inherits MetroFramework.Forms.MetroForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.MetroLabel1 = New MetroFramework.Controls.MetroLabel()
        Me.MetroLabel3 = New MetroFramework.Controls.MetroLabel()
        Me.Powershell = New MetroFramework.Controls.MetroTile()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.MetroTabControl1 = New MetroFramework.Controls.MetroTabControl()
        Me.MetroTab1 = New MetroFramework.Controls.MetroTabPage()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.NameOfIt = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Version = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PercentLoaded = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FileLocation = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.VersionID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.UserDataDirectory = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DriveLetter = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SizeOfit = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SftPath = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MetroTab2 = New MetroFramework.Controls.MetroTabPage()
        Me.DataGridView2 = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.OriginalPath = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MetroTab3 = New System.Windows.Forms.TabPage()
        Me.DataGridView3 = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MetroTab4 = New MetroFramework.Controls.MetroTabPage()
        Me.APPV5HELPBOX = New System.Windows.Forms.ListBox()
        Me.GetAPPV5PackageList = New MetroFramework.Controls.MetroTile()
        Me.GetAPPV5ShortcutList = New MetroFramework.Controls.MetroTile()
        Me.MetroTile1 = New MetroFramework.Controls.MetroTile()
        Me.MetroTabControl1.SuspendLayout()
        Me.MetroTab1.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MetroTab2.SuspendLayout()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MetroTab3.SuspendLayout()
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MetroTab4.SuspendLayout()
        Me.SuspendLayout()
        '
        'MetroLabel1
        '
        Me.MetroLabel1.AutoSize = True
        Me.MetroLabel1.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.MetroLabel1.Location = New System.Drawing.Point(9, 13)
        Me.MetroLabel1.Name = "MetroLabel1"
        Me.MetroLabel1.Size = New System.Drawing.Size(64, 19)
        Me.MetroLabel1.TabIndex = 108
        Me.MetroLabel1.Text = "APPV 5 : "
        Me.MetroLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MetroLabel1.UseCustomForeColor = True
        '
        'MetroLabel3
        '
        Me.MetroLabel3.AutoSize = True
        Me.MetroLabel3.Location = New System.Drawing.Point(149, 49)
        Me.MetroLabel3.Name = "MetroLabel3"
        Me.MetroLabel3.Size = New System.Drawing.Size(685, 19)
        Me.MetroLabel3.TabIndex = 111
        Me.MetroLabel3.Text = "Select the command you wish to copy and paste into the Powershell Console Window " &
    "from the dropdown list below"
        '
        'Powershell
        '
        Me.Powershell.ActiveControl = Nothing
        Me.Powershell.Location = New System.Drawing.Point(759, 545)
        Me.Powershell.Name = "Powershell"
        Me.Powershell.Size = New System.Drawing.Size(224, 36)
        Me.Powershell.TabIndex = 112
        Me.Powershell.Text = "Start a remote Powershell Console"
        Me.Powershell.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Powershell.UseSelectable = True
        '
        'ComboBox1
        '
        Me.ComboBox1.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Items.AddRange(New Object() {"*** ADMINS NEED TO RUN THESE 3 COMMANDS ONCE TO BE ABLE TO ADMINISTER APPV5 ON TH" &
                "E REMOTE MACHINE ***", "winrm quickconfig -quiet ", "Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy Bypass -Force", "Import-Module appvclient", "*** ADMINS NEED TO RUN THESE 3 COMMANDS ONCE TO BE ABLE TO ADMINISTER APPV5 ON TH" &
                "E REMOTE MACHINE ***", "", "*** REMOTE CLIENT COMMANDS ***", "Get-AppvClientPackage -All", "Get-AppvClientPackage -Name ""*Citrix*"" -All", "Get-AppvClientConnectionGroup -All", "Add-AppvClientPackage", "Set-AppvClientPackage", "Publish-AppvClientPackage", "Unpublish-AppvClientPackage", "Remove-AppvClientPackage", "Mount AppvClientPackage", "Stop-AppvClientPackage", "Repair-AppvClientPackage", "Get-AppvVirtualProcess", "Start-AppvVirtualProcess", "Add-AppvPublishingServer", "Set-AppvPublishingServer", "Get-AppvPublishingServer", "Sync-AppvPublishingServer", "Add-AppvClientConnectionGroup", "Get-AppvClientConnectionGroup -All", "Stop-AppvClientConnectionGroup", "Mount-AppvClientConnectionGroup", "Remove-AppvClientConnectionGroup", "Disable-AppvClientConnectionGroup", "Enable-AppvClientConnectionGroup", "Get-AppvClientApplication -All", "Get-AppvClientConfiguration", "*** REMOTE CLIENT COMMANDS END ***", "", "***** CLEAR APPV CACHE TOTALLY *****", "Get-AppvClientConnectionGroup -all | Stop-AppvClientConnectionGroup | Remove-Appv" &
                "ClientConnectionGroup", "Get-AppvClientPackage -all | Stop-AppvClientPackage | Remove-AppvClientPackage", "***** CLEAR APPV CACHE TOTALLY END *****"})
        Me.ComboBox1.Location = New System.Drawing.Point(139, 71)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(706, 21)
        Me.ComboBox1.TabIndex = 113
        '
        'MetroTabControl1
        '
        Me.MetroTabControl1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.MetroTabControl1.Controls.Add(Me.MetroTab1)
        Me.MetroTabControl1.Controls.Add(Me.MetroTab2)
        Me.MetroTabControl1.Controls.Add(Me.MetroTab3)
        Me.MetroTabControl1.Controls.Add(Me.MetroTab4)
        Me.MetroTabControl1.Location = New System.Drawing.Point(37, 117)
        Me.MetroTabControl1.Name = "MetroTabControl1"
        Me.MetroTabControl1.SelectedIndex = 1
        Me.MetroTabControl1.Size = New System.Drawing.Size(950, 422)
        Me.MetroTabControl1.TabIndex = 114
        Me.MetroTabControl1.UseSelectable = True
        '
        'MetroTab1
        '
        Me.MetroTab1.Controls.Add(Me.DataGridView1)
        Me.MetroTab1.HorizontalScrollbarBarColor = False
        Me.MetroTab1.HorizontalScrollbarHighlightOnWheel = False
        Me.MetroTab1.HorizontalScrollbarSize = 0
        Me.MetroTab1.Location = New System.Drawing.Point(4, 38)
        Me.MetroTab1.Name = "MetroTab1"
        Me.MetroTab1.Size = New System.Drawing.Size(942, 380)
        Me.MetroTab1.TabIndex = 1
        Me.MetroTab1.Text = "Packages"
        Me.MetroTab1.VerticalScrollbarBarColor = False
        Me.MetroTab1.VerticalScrollbarHighlightOnWheel = False
        Me.MetroTab1.VerticalScrollbarSize = 0
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.AllowUserToOrderColumns = True
        Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.NameOfIt, Me.Version, Me.PercentLoaded, Me.FileLocation, Me.VersionID, Me.UserDataDirectory, Me.DriveLetter, Me.SizeOfit, Me.SftPath})
        Me.DataGridView1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DataGridView1.Location = New System.Drawing.Point(0, 0)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowHeadersVisible = False
        Me.DataGridView1.RowTemplate.Height = 24
        Me.DataGridView1.Size = New System.Drawing.Size(942, 380)
        Me.DataGridView1.TabIndex = 49
        '
        'NameOfIt
        '
        Me.NameOfIt.FillWeight = 15.0!
        Me.NameOfIt.HeaderText = "Name"
        Me.NameOfIt.Name = "NameOfIt"
        '
        'Version
        '
        Me.Version.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.Version.FillWeight = 5.03672!
        Me.Version.HeaderText = "Version"
        Me.Version.Name = "Version"
        Me.Version.ReadOnly = True
        '
        'PercentLoaded
        '
        Me.PercentLoaded.FillWeight = 5.0!
        Me.PercentLoaded.HeaderText = "% Loaded"
        Me.PercentLoaded.Name = "PercentLoaded"
        '
        'FileLocation
        '
        Me.FileLocation.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.FileLocation.FillWeight = 12.0!
        Me.FileLocation.HeaderText = "PackageID"
        Me.FileLocation.Name = "FileLocation"
        Me.FileLocation.ReadOnly = True
        '
        'VersionID
        '
        Me.VersionID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.VersionID.FillWeight = 12.0!
        Me.VersionID.HeaderText = "VersionID"
        Me.VersionID.Name = "VersionID"
        Me.VersionID.ReadOnly = True
        '
        'UserDataDirectory
        '
        Me.UserDataDirectory.FillWeight = 4.0!
        Me.UserDataDirectory.HeaderText = "InUse"
        Me.UserDataDirectory.MinimumWidth = 4
        Me.UserDataDirectory.Name = "UserDataDirectory"
        Me.UserDataDirectory.ReadOnly = True
        '
        'DriveLetter
        '
        Me.DriveLetter.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DriveLetter.FillWeight = 8.0!
        Me.DriveLetter.HeaderText = "IsPubGlobally"
        Me.DriveLetter.MinimumWidth = 8
        Me.DriveLetter.Name = "DriveLetter"
        Me.DriveLetter.ReadOnly = True
        '
        'SizeOfit
        '
        Me.SizeOfit.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.SizeOfit.FillWeight = 7.0!
        Me.SizeOfit.HeaderText = "Size"
        Me.SizeOfit.Name = "SizeOfit"
        Me.SizeOfit.ReadOnly = True
        '
        'SftPath
        '
        Me.SftPath.FillWeight = 30.0!
        Me.SftPath.HeaderText = "APPVPath"
        Me.SftPath.Name = "SftPath"
        '
        'MetroTab2
        '
        Me.MetroTab2.Controls.Add(Me.DataGridView2)
        Me.MetroTab2.HorizontalScrollbarBarColor = False
        Me.MetroTab2.HorizontalScrollbarHighlightOnWheel = False
        Me.MetroTab2.HorizontalScrollbarSize = 0
        Me.MetroTab2.Location = New System.Drawing.Point(4, 38)
        Me.MetroTab2.Name = "MetroTab2"
        Me.MetroTab2.Size = New System.Drawing.Size(942, 380)
        Me.MetroTab2.TabIndex = 2
        Me.MetroTab2.Text = "Shortcuts"
        Me.MetroTab2.VerticalScrollbarBarColor = False
        Me.MetroTab2.VerticalScrollbarHighlightOnWheel = False
        Me.MetroTab2.VerticalScrollbarSize = 0
        '
        'DataGridView2
        '
        Me.DataGridView2.AllowUserToAddRows = False
        Me.DataGridView2.AllowUserToDeleteRows = False
        Me.DataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.DataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView2.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4, Me.OriginalPath})
        Me.DataGridView2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DataGridView2.Location = New System.Drawing.Point(0, 0)
        Me.DataGridView2.Name = "DataGridView2"
        Me.DataGridView2.RowHeadersVisible = False
        Me.DataGridView2.RowTemplate.Height = 24
        Me.DataGridView2.Size = New System.Drawing.Size(942, 380)
        Me.DataGridView2.TabIndex = 53
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn3.FillWeight = 10.0!
        Me.DataGridViewTextBoxColumn3.HeaderText = "Shortcut"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.ReadOnly = True
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn4.FillWeight = 5.300864!
        Me.DataGridViewTextBoxColumn4.HeaderText = "Version"
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.ReadOnly = True
        '
        'OriginalPath
        '
        Me.OriginalPath.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.OriginalPath.FillWeight = 20.0!
        Me.OriginalPath.HeaderText = "Path"
        Me.OriginalPath.Name = "OriginalPath"
        '
        'MetroTab3
        '
        Me.MetroTab3.Controls.Add(Me.DataGridView3)
        Me.MetroTab3.Location = New System.Drawing.Point(4, 38)
        Me.MetroTab3.Name = "MetroTab3"
        Me.MetroTab3.Size = New System.Drawing.Size(942, 380)
        Me.MetroTab3.TabIndex = 4
        Me.MetroTab3.Text = "Connection Groups"
        '
        'DataGridView3
        '
        Me.DataGridView3.AllowUserToAddRows = False
        Me.DataGridView3.AllowUserToDeleteRows = False
        Me.DataGridView3.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.DataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView3.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn5})
        Me.DataGridView3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DataGridView3.Location = New System.Drawing.Point(0, 0)
        Me.DataGridView3.Name = "DataGridView3"
        Me.DataGridView3.RowHeadersVisible = False
        Me.DataGridView3.RowTemplate.Height = 24
        Me.DataGridView3.Size = New System.Drawing.Size(942, 380)
        Me.DataGridView3.TabIndex = 54
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn1.FillWeight = 10.0!
        Me.DataGridViewTextBoxColumn1.HeaderText = "GroupName"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.ReadOnly = True
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn2.FillWeight = 12.0!
        Me.DataGridViewTextBoxColumn2.HeaderText = "PackageID"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.ReadOnly = True
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn5.FillWeight = 12.0!
        Me.DataGridViewTextBoxColumn5.HeaderText = "VersionID"
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        '
        'MetroTab4
        '
        Me.MetroTab4.Controls.Add(Me.APPV5HELPBOX)
        Me.MetroTab4.HorizontalScrollbarBarColor = True
        Me.MetroTab4.HorizontalScrollbarHighlightOnWheel = False
        Me.MetroTab4.HorizontalScrollbarSize = 10
        Me.MetroTab4.Location = New System.Drawing.Point(4, 38)
        Me.MetroTab4.Name = "MetroTab4"
        Me.MetroTab4.Size = New System.Drawing.Size(942, 380)
        Me.MetroTab4.TabIndex = 3
        Me.MetroTab4.Text = "APPV5 - HELP"
        Me.MetroTab4.VerticalScrollbarBarColor = True
        Me.MetroTab4.VerticalScrollbarHighlightOnWheel = False
        Me.MetroTab4.VerticalScrollbarSize = 10
        '
        'APPV5HELPBOX
        '
        Me.APPV5HELPBOX.Dock = System.Windows.Forms.DockStyle.Fill
        Me.APPV5HELPBOX.FormattingEnabled = True
        Me.APPV5HELPBOX.Items.AddRange(New Object() {"1) ""C:\ProgramData\App-V"" is the location where the .APPV files are extracted / I" &
                "nstalled to by default", "", "2) The Registry.dat for each package is located in the package folders found loca" &
                "ted in ""C:\ProgramData\App-V"".", "These can be loaded into regedit as normal.", "", "3) The Virtual File Structure is under the VFS Folder of each package located in " &
                """C:\ProgramData\App-V"", which contains all the files for the virtual package.", "", "3) You can fault find a virtual application by breaking into the virtual applicat" &
                "ion bubble. To do this you'll need some information first.", "Example of running a command prompt in a virtual package bubble :- ""cmd.exe /appv" &
                "ve:<PACKAGEID_VERSIONID>""", "You can get this information from the new Packages table once populated or from a" &
                " powershell command like this :-", "Get-AppvClientPackage -All", "or ", "Get-AppvClientPackage -Name ""*Harmonie*"" -All", "", "4) Check the package is cached 100% into the APPV Client... or the above commands" &
                " should return ""PercentLoaded"" for each app.", "", "5) Check the .APPV file and its user and machine deployment configuration files a" &
                "re not corrupt in the SCCM cache on the PC.", "", "6) APPV5 packages are usually permissioned and Deployed via SCCM by User Groups p" &
                "ermissions. Check the user is in the correct group in AD.", "", "7) Check SCCM has the user in the ""User Collection"". Is there a collection setup " &
                "correctly for the Application. SCCM polls AD groups to get the users into the co" &
                "llection for deployment.", "", "8) APPV5 loads the users applications at logon time. (remember to log out and in " &
                "again)", "", "9) Reset or Repair an APPV5 package back to its original settings if needs be. (N" &
                "ot this will erase all user customisations if you do this but will fix missing o" &
                "r deleted shortcuts).", "Use the Application Virtualization GUI to repair a package", "or use the powershell command :- ", "Stop-AppvClientPackage ""packagename""", "Repair-AppvClientPackage ""packagename""", "", "10) Check the Application is set to run on your OS. APPV5 packages can be set to " &
                "run on x64 or x86 or Workstations only or Server Only etc ... Check the deployme" &
                "nt manifest to", "make sure that the OS is ""Blank"" which means run on all OS or what workstations a" &
                "re allowed. Some apps may be Win7 only. Some apps may be WINX only.", "", "11) If you need to look into the package the .APPV file can be renamed to .zip an" &
                "d extracted. It will not show you everything but may help checking settings and " &
                "files etc..."})
        Me.APPV5HELPBOX.Location = New System.Drawing.Point(0, 0)
        Me.APPV5HELPBOX.Name = "APPV5HELPBOX"
        Me.APPV5HELPBOX.Size = New System.Drawing.Size(942, 380)
        Me.APPV5HELPBOX.TabIndex = 2
        '
        'GetAPPV5PackageList
        '
        Me.GetAPPV5PackageList.ActiveControl = Nothing
        Me.GetAPPV5PackageList.Location = New System.Drawing.Point(41, 545)
        Me.GetAPPV5PackageList.Name = "GetAPPV5PackageList"
        Me.GetAPPV5PackageList.Size = New System.Drawing.Size(177, 32)
        Me.GetAPPV5PackageList.TabIndex = 115
        Me.GetAPPV5PackageList.Text = "Get APPV5 Package List"
        Me.GetAPPV5PackageList.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.GetAPPV5PackageList.UseSelectable = True
        '
        'GetAPPV5ShortcutList
        '
        Me.GetAPPV5ShortcutList.ActiveControl = Nothing
        Me.GetAPPV5ShortcutList.Location = New System.Drawing.Point(224, 545)
        Me.GetAPPV5ShortcutList.Name = "GetAPPV5ShortcutList"
        Me.GetAPPV5ShortcutList.Size = New System.Drawing.Size(181, 32)
        Me.GetAPPV5ShortcutList.TabIndex = 116
        Me.GetAPPV5ShortcutList.Text = "Get APPV5 Shortcut List"
        Me.GetAPPV5ShortcutList.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.GetAPPV5ShortcutList.UseSelectable = True
        '
        'MetroTile1
        '
        Me.MetroTile1.ActiveControl = Nothing
        Me.MetroTile1.Location = New System.Drawing.Point(411, 545)
        Me.MetroTile1.Name = "MetroTile1"
        Me.MetroTile1.Size = New System.Drawing.Size(196, 32)
        Me.MetroTile1.TabIndex = 117
        Me.MetroTile1.Text = "Get APPV5 Connection Groups"
        Me.MetroTile1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MetroTile1.UseSelectable = True
        '
        'Appv5
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BorderStyle = MetroFramework.Forms.MetroFormBorderStyle.FixedSingle
        Me.ClientSize = New System.Drawing.Size(1024, 600)
        Me.Controls.Add(Me.MetroTile1)
        Me.Controls.Add(Me.GetAPPV5ShortcutList)
        Me.Controls.Add(Me.GetAPPV5PackageList)
        Me.Controls.Add(Me.MetroTabControl1)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Me.Powershell)
        Me.Controls.Add(Me.MetroLabel3)
        Me.Controls.Add(Me.MetroLabel1)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Appv5"
        Me.Resizable = False
        Me.MetroTabControl1.ResumeLayout(False)
        Me.MetroTab1.ResumeLayout(False)
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MetroTab2.ResumeLayout(False)
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MetroTab3.ResumeLayout(False)
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MetroTab4.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MetroLabel1 As MetroFramework.Controls.MetroLabel
    Friend WithEvents MetroLabel3 As MetroFramework.Controls.MetroLabel
    Friend WithEvents Powershell As MetroFramework.Controls.MetroTile
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents MetroTabControl1 As MetroFramework.Controls.MetroTabControl
    Friend WithEvents MetroTab1 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents MetroTab2 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents DataGridView2 As DataGridView
    Friend WithEvents NameOfIt As DataGridViewTextBoxColumn
    Friend WithEvents Version As DataGridViewTextBoxColumn
    Friend WithEvents PercentLoaded As DataGridViewTextBoxColumn
    Friend WithEvents FileLocation As DataGridViewTextBoxColumn
    Friend WithEvents VersionID As DataGridViewTextBoxColumn
    Friend WithEvents UserDataDirectory As DataGridViewTextBoxColumn
    Friend WithEvents DriveLetter As DataGridViewTextBoxColumn
    Friend WithEvents SizeOfit As DataGridViewTextBoxColumn
    Friend WithEvents SftPath As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As DataGridViewTextBoxColumn
    Friend WithEvents OriginalPath As DataGridViewTextBoxColumn
    Friend WithEvents GetAPPV5PackageList As MetroFramework.Controls.MetroTile
    Friend WithEvents GetAPPV5ShortcutList As MetroFramework.Controls.MetroTile
    Friend WithEvents MetroTab4 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents APPV5HELPBOX As ListBox
    Friend WithEvents MetroTab3 As TabPage
    Friend WithEvents MetroTile1 As MetroFramework.Controls.MetroTile
    Friend WithEvents DataGridView3 As DataGridView
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As DataGridViewTextBoxColumn
End Class
