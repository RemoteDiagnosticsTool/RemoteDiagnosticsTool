<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CopyingFilesPopup
    Inherits MetroFramework.Forms.MetroForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(CopyingFilesPopup))
        Me.MetroLabel2 = New MetroFramework.Controls.MetroLabel()
        Me.ProgressBarCopy = New MetroFramework.Controls.MetroProgressBar()
        Me.SuspendLayout()
        '
        'MetroLabel2
        '
        Me.MetroLabel2.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.MetroLabel2.Location = New System.Drawing.Point(3, 11)
        Me.MetroLabel2.Name = "MetroLabel2"
        Me.MetroLabel2.Size = New System.Drawing.Size(582, 39)
        Me.MetroLabel2.TabIndex = 7
        Me.MetroLabel2.Text = "Copying"
        Me.MetroLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MetroLabel2.UseCustomForeColor = True
        Me.MetroLabel2.WrapToLine = True
        '
        'ProgressBarCopy
        '
        Me.ProgressBarCopy.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ProgressBarCopy.Location = New System.Drawing.Point(36, 63)
        Me.ProgressBarCopy.Name = "ProgressBarCopy"
        Me.ProgressBarCopy.Size = New System.Drawing.Size(515, 23)
        Me.ProgressBarCopy.TabIndex = 8
        '
        'CopyingFilesPopup
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoValidate = System.Windows.Forms.AutoValidate.EnableAllowFocusChange
        Me.BorderStyle = MetroFramework.Forms.MetroFormBorderStyle.FixedSingle
        Me.ClientSize = New System.Drawing.Size(590, 99)
        Me.ControlBox = False
        Me.Controls.Add(Me.ProgressBarCopy)
        Me.Controls.Add(Me.MetroLabel2)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "CopyingFilesPopup"
        Me.ShowInTaskbar = False
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents MetroLabel2 As MetroFramework.Controls.MetroLabel
    Friend WithEvents ProgressBarCopy As MetroFramework.Controls.MetroProgressBar
End Class
