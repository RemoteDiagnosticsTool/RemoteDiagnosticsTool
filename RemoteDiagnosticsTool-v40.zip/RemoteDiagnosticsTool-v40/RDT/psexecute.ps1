$argumentcount = $args.count

If ($argumentcount -lt 2) {Exit}

$argumentout0 = $args[0]
$argumentout1 = $args[1]
$argumentout2 = $args[2]
$argumentout3 = $args[3]
$argumentout4 = $args[4]
$argumentout5 = $args[5]
$argumentout6 = $args[6]
$argumentout7 = $args[7]

if ($argumentcount = 2){ $exeoutput="C:\RDT\RDT\" + $argumentout0 + "\" + $argumentout1}
if ($argumentcount = 3){ $exeoutput="C:\RDT\RDT\" + $argumentout0 + "\" + $argumentout1 + " " + $argumentout2}
if ($argumentcount = 4){ $exeoutput="C:\RDT\RDT\" + $argumentout0 + "\" + $argumentout1 + " " + $argumentout2 + " " + $argumentout3}
if ($argumentcount = 5){ $exeoutput="C:\RDT\RDT\" + $argumentout0 + "\" + $argumentout1 + " " + $argumentout2 + " " + $argumentout3 + " " + $argumentout4}
if ($argumentcount = 6){ $exeoutput="C:\RDT\RDT\" + $argumentout0 + "\" + $argumentout1 + " " + $argumentout2 + " " + $argumentout3 + " " + $argumentout4 + " " + $argumentout5}
if ($argumentcount = 7){ $exeoutput="C:\RDT\RDT\" + $argumentout0 + "\" + $argumentout1 + " " + $argumentout2 + " " + $argumentout3 + " " + $argumentout4 + " " + $argumentout5  + " " + $argumentout6}
if ($argumentcount = 8){ $exeoutput="C:\RDT\RDT\" + $argumentout0 + "\" + $argumentout1 + " " + $argumentout2 + " " + $argumentout3 + " " + $argumentout4 + " " + $argumentout5  + " " + $argumentout6 + " " + $argumentout7}

cmd.exe /c $exeoutput