﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form5
    Inherits MetroFramework.Forms.MetroForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form5))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim TreeNode1 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("          COMPUTER LIST          ")
        Me.ImageListSCCM = New System.Windows.Forms.ImageList(Me.components)
        Me.BackgroundWorker3 = New System.ComponentModel.BackgroundWorker()
        Me.Purchase = New MetroFramework.Controls.MetroTile()
        Me.Button2 = New MetroFramework.Controls.MetroTile()
        Me.Helpme = New MetroFramework.Controls.MetroTile()
        Me.FormTabControl = New MetroFramework.Controls.MetroTabControl()
        Me.HomeTab1 = New MetroFramework.Controls.MetroTabPage()
        Me.TableLayoutPanel24 = New System.Windows.Forms.TableLayoutPanel()
        Me.RunPSCommandButton = New MetroFramework.Controls.MetroTile()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.RunPSCommandTextBox = New MetroFramework.Controls.MetroTextBox()
        Me.TableLayoutPanel43 = New System.Windows.Forms.TableLayoutPanel()
        Me.Runcommandonly = New MetroFramework.Controls.MetroTile()
        Me.Label217 = New System.Windows.Forms.Label()
        Me.runcommandonlytext = New MetroFramework.Controls.MetroTextBox()
        Me.TableLayoutPanel34 = New System.Windows.Forms.TableLayoutPanel()
        Me.SaveEMAdetails = New MetroFramework.Controls.MetroTextBox()
        Me.Label208 = New System.Windows.Forms.Label()
        Me.DeleteEMAnumber = New MetroFramework.Controls.MetroTile()
        Me.TableLayoutPanel33 = New System.Windows.Forms.TableLayoutPanel()
        Me.SaveEMAnumber = New MetroFramework.Controls.MetroTile()
        Me.Label179 = New System.Windows.Forms.Label()
        Me.Helpdesknumber = New MetroFramework.Controls.MetroTextBox()
        Me.TableLayoutPanel9 = New System.Windows.Forms.TableLayoutPanel()
        Me.userdomainComboBox = New System.Windows.Forms.ComboBox()
        Me.GetMobileNumber = New MetroFramework.Controls.MetroTile()
        Me.GetPhoneNumber = New MetroFramework.Controls.MetroTile()
        Me.Reboot = New System.Windows.Forms.Label()
        Me.GetEmailAddress = New MetroFramework.Controls.MetroTile()
        Me.PhoneNumber1 = New System.Windows.Forms.Label()
        Me.EmailAddress = New System.Windows.Forms.Label()
        Me.Host = New System.Windows.Forms.Label()
        Me.ContextMenuCopyHOST2Clipboard = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.PhoneNumber2 = New System.Windows.Forms.Label()
        Me.MobileNumber = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.uptime1 = New System.Windows.Forms.Label()
        Me.GetUptime = New MetroFramework.Controls.MetroTile()
        Me.ShaddowUserSession = New MetroFramework.Controls.MetroTile()
        Me.TableLayoutPanel5 = New System.Windows.Forms.TableLayoutPanel()
        Me.StatusOfConnection = New System.Windows.Forms.Label()
        Me.Button1 = New MetroFramework.Controls.MetroTile()
        Me.MetroTile1 = New MetroFramework.Controls.MetroTile()
        Me.ProgressBar2 = New System.Windows.Forms.ProgressBar()
        Me.AliveButton = New System.Windows.Forms.Button()
        Me.Alive = New System.Windows.Forms.Label()
        Me.ContextMenuCopyIPAddress2Clipboard = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ForceReboot = New MetroFramework.Controls.MetroTile()
        Me.PCNAME = New System.Windows.Forms.Label()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.FileVersionFinder = New MetroFramework.Controls.MetroTile()
        Me.Eventlog = New MetroFramework.Controls.MetroTile()
        Me.StartupItemsList = New MetroFramework.Controls.MetroTile()
        Me.TaskSched = New MetroFramework.Controls.MetroTile()
        Me.PowershellCMD = New MetroFramework.Controls.MetroTile()
        Me.RDP = New MetroFramework.Controls.MetroTile()
        Me.RDTReadWriteRegistry = New MetroFramework.Controls.MetroTile()
        Me.NSlookup = New MetroFramework.Controls.MetroTile()
        Me.NLTEST = New MetroFramework.Controls.MetroTile()
        Me.btnOpenReg = New MetroFramework.Controls.MetroTile()
        Me.CompMgmt = New MetroFramework.Controls.MetroTile()
        Me.DetectAPPV = New MetroFramework.Controls.MetroTile()
        Me.DefragC = New MetroFramework.Controls.MetroTile()
        Me.CheckAntivirus = New MetroFramework.Controls.MetroTile()
        Me.BrowseAppslogs = New MetroFramework.Controls.MetroTile()
        Me.ADtab2 = New MetroFramework.Controls.MetroTabPage()
        Me.ListADGroups = New MetroFramework.Controls.MetroButton()
        Me.ListUsersInGroupBox = New MetroFramework.Controls.MetroTextBox()
        Me.ListUsersInGroupButton = New MetroFramework.Controls.MetroButton()
        Me.ListADUsers_Computers = New MetroFramework.Controls.MetroButton()
        Me.MetroPanel1 = New MetroFramework.Controls.MetroPanel()
        Me.ListViewAD = New System.Windows.Forms.ListView()
        Me.INFOTab3 = New MetroFramework.Controls.MetroTabPage()
        Me.GetHPBiosSettings = New MetroFramework.Controls.MetroButton()
        Me.GatherAudioInfo = New MetroFramework.Controls.MetroButton()
        Me.MetroTile2 = New MetroFramework.Controls.MetroTile()
        Me.MetroLabel10 = New MetroFramework.Controls.MetroLabel()
        Me.ExportDataGridViewDetails = New MetroFramework.Controls.MetroButton()
        Me.GatherNetworkInfo = New MetroFramework.Controls.MetroButton()
        Me.GatherVideoInfo = New MetroFramework.Controls.MetroButton()
        Me.GatherBIOSInfo = New MetroFramework.Controls.MetroButton()
        Me.GETpcDETAILSnow = New MetroFramework.Controls.MetroButton()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.PCnameFordetails = New System.Windows.Forms.Label()
        Me.TableLayoutPanel6 = New System.Windows.Forms.TableLayoutPanel()
        Me.DataGridViewDetails = New System.Windows.Forms.DataGridView()
        Me.Column8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DiskTab4 = New MetroFramework.Controls.MetroTabPage()
        Me.MetroTile3 = New MetroFramework.Controls.MetroTile()
        Me.Button14 = New MetroFramework.Controls.MetroButton()
        Me.Button13 = New MetroFramework.Controls.MetroButton()
        Me.ExportDISK_DETAILS = New MetroFramework.Controls.MetroButton()
        Me.DISK_DETAILS = New MetroFramework.Controls.MetroButton()
        Me.Label206 = New System.Windows.Forms.Label()
        Me.DataGridViewDisk2 = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Model = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SerialNumber = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label65 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label69 = New System.Windows.Forms.Label()
        Me.Label67 = New System.Windows.Forms.Label()
        Me.TotalPhysicalMemoryDetails = New System.Windows.Forms.Label()
        Me.PagefileDetails = New System.Windows.Forms.Label()
        Me.DataGridViewDisk = New System.Windows.Forms.DataGridView()
        Me.Drive = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Drivetype = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SizeDiskOut = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FreeSpace = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Used = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PercentFree = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PercentUsed = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label62 = New System.Windows.Forms.Label()
        Me.Label63 = New System.Windows.Forms.Label()
        Me.Label68 = New System.Windows.Forms.Label()
        Me.NetTab5 = New MetroFramework.Controls.MetroTabPage()
        Me.MetroTile20 = New MetroFramework.Controls.MetroTile()
        Me.ExportDOTNETlist = New MetroFramework.Controls.MetroButton()
        Me.DotNetDetect = New MetroFramework.Controls.MetroButton()
        Me.Label14a = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.MetroLabel18 = New MetroFramework.Controls.MetroLabel()
        Me.MetroLabel17 = New MetroFramework.Controls.MetroLabel()
        Me.MetroLabel16 = New MetroFramework.Controls.MetroLabel()
        Me.TableLayoutPanel42 = New System.Windows.Forms.TableLayoutPanel()
        Me.DataGridViewNetCore = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn31 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn32 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TableLayoutPanel41 = New System.Windows.Forms.TableLayoutPanel()
        Me.DataGridViewNet64 = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn27 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn28 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn29 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn30 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TableLayoutPanel39 = New System.Windows.Forms.TableLayoutPanel()
        Me.DataGridViewNet32 = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn21 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn24 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn25 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn26 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ExecuteTab6 = New MetroFramework.Controls.MetroTabPage()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.MetroLabel14 = New MetroFramework.Controls.MetroLabel()
        Me.MetroLabel13 = New MetroFramework.Controls.MetroLabel()
        Me.MetroLabel11 = New MetroFramework.Controls.MetroLabel()
        Me.TableLayoutPanel30 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.SDBoxFile = New MetroFramework.Controls.MetroTextBox()
        Me.TableLayoutPanel28 = New System.Windows.Forms.TableLayoutPanel()
        Me.SDList1Files = New System.Windows.Forms.ListBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TableLayoutPanel22 = New System.Windows.Forms.TableLayoutPanel()
        Me.PowershellCopyLocalExecuteButton = New MetroFramework.Controls.MetroButton()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.PSEXECUTEPackageText = New System.Windows.Forms.TextBox()
        Me.Label221 = New System.Windows.Forms.Label()
        Me.Label220 = New System.Windows.Forms.Label()
        Me.Label219 = New System.Windows.Forms.Label()
        Me.Label218 = New System.Windows.Forms.Label()
        Me.Label214 = New System.Windows.Forms.Label()
        Me.Label213 = New System.Windows.Forms.Label()
        Me.Label212 = New System.Windows.Forms.Label()
        Me.Label211 = New System.Windows.Forms.Label()
        Me.TableLayoutPanel32 = New System.Windows.Forms.TableLayoutPanel()
        Me.Inst_RemDriveLetter = New System.Windows.Forms.ComboBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.REMCOMPackageFromDOMAIN = New MetroFramework.Controls.MetroButton()
        Me.REMCOMPackageText = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TableLayoutPanel8 = New System.Windows.Forms.TableLayoutPanel()
        Me.SDListDirectory = New System.Windows.Forms.ComboBox()
        Me.SDlistpackages = New MetroFramework.Controls.MetroButton()
        Me.TableLayoutPanel4 = New System.Windows.Forms.TableLayoutPanel()
        Me.SDList1 = New System.Windows.Forms.ListBox()
        Me.TableLayoutPanel3 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label215 = New System.Windows.Forms.Label()
        Me.SDBOXFolder = New MetroFramework.Controls.MetroTextBox()
        Me.MetroTile6 = New MetroFramework.Controls.MetroTile()
        Me.FtypeTab7 = New MetroFramework.Controls.MetroTabPage()
        Me.ExportFileTypes = New MetroFramework.Controls.MetroButton()
        Me.Button3 = New MetroFramework.Controls.MetroButton()
        Me.Button66 = New MetroFramework.Controls.MetroButton()
        Me.TableLayoutPanel14 = New System.Windows.Forms.TableLayoutPanel()
        Me.FileTypes = New System.Windows.Forms.ListBox()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.MetroTile4 = New MetroFramework.Controls.MetroTile()
        Me.GroupsTab8 = New MetroFramework.Controls.MetroTabPage()
        Me.TableLayoutPanel27 = New System.Windows.Forms.TableLayoutPanel()
        Me.userlistbutton = New MetroFramework.Controls.MetroButton()
        Me.Button5 = New MetroFramework.Controls.MetroButton()
        Me.Groups = New MetroFramework.Controls.MetroButton()
        Me.groupview1 = New System.Windows.Forms.ListBox()
        Me.userview1 = New System.Windows.Forms.ListBox()
        Me.Userlist = New System.Windows.Forms.ListBox()
        Me.TableLayoutPanel26 = New System.Windows.Forms.TableLayoutPanel()
        Me.GROUPSVALUE2 = New MetroFramework.Controls.MetroTextBox()
        Me.GROUPSVALUE1 = New MetroFramework.Controls.MetroTextBox()
        Me.MetroLabel2 = New MetroFramework.Controls.MetroLabel()
        Me.MetroLabel1 = New MetroFramework.Controls.MetroLabel()
        Me.Label175 = New System.Windows.Forms.Label()
        Me.Label174 = New System.Windows.Forms.Label()
        Me.TableLayoutPanel25 = New System.Windows.Forms.TableLayoutPanel()
        Me.adddomaintolocal = New MetroFramework.Controls.MetroButton()
        Me.addlocalusertolocalgroup = New MetroFramework.Controls.MetroButton()
        Me.removeuser = New MetroFramework.Controls.MetroButton()
        Me.removelocaluser = New MetroFramework.Controls.MetroButton()
        Me.Addlocalgroup = New MetroFramework.Controls.MetroButton()
        Me.addlocaluser = New MetroFramework.Controls.MetroButton()
        Me.removedomainfromlocal = New MetroFramework.Controls.MetroButton()
        Me.removelocalgroup = New MetroFramework.Controls.MetroButton()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.MetroTile5 = New MetroFramework.Controls.MetroTile()
        Me.instSoftwareTab9 = New MetroFramework.Controls.MetroTabPage()
        Me.SearchProgramBox = New MetroFramework.Controls.MetroTextBox()
        Me.SearchProgramButton = New MetroFramework.Controls.MetroButton()
        Me.ExportFullSoftwareList = New MetroFramework.Controls.MetroButton()
        Me.GetSoftwareList = New MetroFramework.Controls.MetroButton()
        Me.TableLayoutPanel16 = New System.Windows.Forms.TableLayoutPanel()
        Me.TextBox1 = New MetroFramework.Controls.MetroTextBox()
        Me.MSIUNINSTALL = New MetroFramework.Controls.MetroButton()
        Me.TableLayoutPanel15 = New System.Windows.Forms.TableLayoutPanel()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.SoftwareName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SoftwareVersion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.InstallDate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.KeyName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.MetroTile8 = New MetroFramework.Controls.MetroTile()
        Me.WUtab10 = New MetroFramework.Controls.MetroTabPage()
        Me.TableLayoutPanel20 = New System.Windows.Forms.TableLayoutPanel()
        Me.KBTextBox = New MetroFramework.Controls.MetroTextBox()
        Me.KBRemoveButton = New MetroFramework.Controls.MetroButton()
        Me.UpdatesLabel = New MetroFramework.Controls.MetroLabel()
        Me.SecurityPatchesBUT = New MetroFramework.Controls.MetroButton()
        Me.ExportPatches = New MetroFramework.Controls.MetroButton()
        Me.OtherUpdates = New MetroFramework.Controls.MetroButton()
        Me.TableLayoutPanel37 = New System.Windows.Forms.TableLayoutPanel()
        Me.DataGridView10 = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn11 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn12 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn13 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.MetroTile7 = New MetroFramework.Controls.MetroTile()
        Me.MSITab12 = New MetroFramework.Controls.MetroTabPage()
        Me.MetroTile9 = New MetroFramework.Controls.MetroTile()
        Me.ExportSoftwareListMSI = New MetroFramework.Controls.MetroButton()
        Me.GetMSIList = New MetroFramework.Controls.MetroButton()
        Me.TableLayoutPanel19 = New System.Windows.Forms.TableLayoutPanel()
        Me.TextBoxMSIZAP = New MetroFramework.Controls.MetroTextBox()
        Me.MSIZAPbutton = New MetroFramework.Controls.MetroButton()
        Me.TableLayoutPanel17 = New System.Windows.Forms.TableLayoutPanel()
        Me.DataGridView6 = New System.Windows.Forms.DataGridView()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrKey = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.InstallTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Profiles14 = New MetroFramework.Controls.MetroTabPage()
        Me.DeleteProfile = New MetroFramework.Controls.MetroButton()
        Me.DetectProfiles = New MetroFramework.Controls.MetroButton()
        Me.TableLayoutPanel35 = New System.Windows.Forms.TableLayoutPanel()
        Me.DataGridViewProfiles = New System.Windows.Forms.DataGridView()
        Me.Column16 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn23 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column13 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column14 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column15 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LabelProfiles2 = New System.Windows.Forms.Label()
        Me.LabelProfiles1 = New System.Windows.Forms.Label()
        Me.MetroTile19 = New MetroFramework.Controls.MetroTile()
        Me.RebootChecker15 = New MetroFramework.Controls.MetroTabPage()
        Me.TableLayoutPanel44 = New System.Windows.Forms.TableLayoutPanel()
        Me.MetroLabel29 = New MetroFramework.Controls.MetroLabel()
        Me.MetroLabel26 = New MetroFramework.Controls.MetroLabel()
        Me.MetroLabel25 = New MetroFramework.Controls.MetroLabel()
        Me.MetroLabel24 = New MetroFramework.Controls.MetroLabel()
        Me.MetroLabel23 = New MetroFramework.Controls.MetroLabel()
        Me.RebootRequiredCheck1 = New MetroFramework.Controls.MetroLabel()
        Me.RebootRequiredCheck2 = New MetroFramework.Controls.MetroLabel()
        Me.RebootRequiredCheck3 = New MetroFramework.Controls.MetroLabel()
        Me.RebootRequiredCheck4 = New MetroFramework.Controls.MetroLabel()
        Me.RebootRequiredCheck5 = New MetroFramework.Controls.MetroLabel()
        Me.RebootButton1 = New MetroFramework.Controls.MetroButton()
        Me.MetroTile21 = New MetroFramework.Controls.MetroTile()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.SCCMtab16 = New MetroFramework.Controls.MetroTabPage()
        Me.TableLayoutPanel47 = New System.Windows.Forms.TableLayoutPanel()
        Me.TriggerScheduleSCCM_WMIC = New MetroFramework.Controls.MetroButton()
        Me.TriggerScheduleSCCM_Powershell = New MetroFramework.Controls.MetroButton()
        Me.TriggerScheduleSCCM_ComboBox = New MetroFramework.Controls.MetroComboBox()
        Me.ChangeCacheDirectory = New MetroFramework.Controls.MetroButton()
        Me.ChangeCacheSizeButton = New MetroFramework.Controls.MetroButton()
        Me.openSCCMCache = New MetroFramework.Controls.MetroButton()
        Me.GetSCCMinfo = New MetroFramework.Controls.MetroButton()
        Me.Button8 = New MetroFramework.Controls.MetroButton()
        Me.GetSCCMCacheSettings = New MetroFramework.Controls.MetroButton()
        Me.TableLayoutPanel7 = New System.Windows.Forms.TableLayoutPanel()
        Me.SCCMProvisioningMode = New MetroFramework.Controls.MetroLabel()
        Me.SCCMMODE = New MetroFramework.Controls.MetroButton()
        Me.SCCMTabControl = New System.Windows.Forms.TabControl()
        Me.ExecutionHistory = New System.Windows.Forms.TabPage()
        Me.ExportSCCMhistory = New MetroFramework.Controls.MetroButton()
        Me.GetSCCM2 = New MetroFramework.Controls.MetroButton()
        Me.DataGridView9 = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn10 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.EvaluationStateReason = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ADVMachine = New System.Windows.Forms.TabPage()
        Me.ReRunAdvertMachine = New MetroFramework.Controls.MetroButton()
        Me.GETSCCM = New MetroFramework.Controls.MetroButton()
        Me.AdvertNameMachine = New System.Windows.Forms.Label()
        Me.PkgIDMachine = New System.Windows.Forms.Label()
        Me.AdvIDMachine = New System.Windows.Forms.Label()
        Me.DataGridView8 = New System.Windows.Forms.DataGridView()
        Me.AdvID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ContentSize = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ADVLoggedOnUser = New System.Windows.Forms.TabPage()
        Me.AdvertisementsUser = New MetroFramework.Controls.MetroButton()
        Me.DataGridView25 = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn78 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn79 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ADVTaskSeq = New System.Windows.Forms.TabPage()
        Me.GetSCCMTaskSequences = New MetroFramework.Controls.MetroButton()
        Me.DataGridView11 = New System.Windows.Forms.DataGridView()
        Me.ADV_TS = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn14 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn15 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Live = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PKGInstallStats = New System.Windows.Forms.TabPage()
        Me.SCCMRunningJobs = New MetroFramework.Controls.MetroButton()
        Me.DataGridViewSCCMRunning = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn71 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn72 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn73 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn74 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Runningstate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.KB_EvaluationState = New System.Windows.Forms.TabPage()
        Me.KBStatus = New MetroFramework.Controls.MetroButton()
        Me.DataGridViewKBStatus = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn38 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn39 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PercentComplete = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ErrorCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SCCMmissUpdates = New System.Windows.Forms.TabPage()
        Me.SCCMPatchesMissing = New MetroFramework.Controls.MetroButton()
        Me.ListMissingUpdatesSCCMDatagrid = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn35 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PatchesIn = New System.Windows.Forms.TabPage()
        Me.SCCMPatchesInstalled = New MetroFramework.Controls.MetroButton()
        Me.SCCMPatchesInstalledDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn33 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SCCMcomplianceTab = New System.Windows.Forms.TabPage()
        Me.TableLayoutPanel46 = New System.Windows.Forms.TableLayoutPanel()
        Me.MetroLabel28 = New MetroFramework.Controls.MetroLabel()
        Me.MetroLabel27 = New MetroFramework.Controls.MetroLabel()
        Me.TableLayoutPanel45 = New System.Windows.Forms.TableLayoutPanel()
        Me.SCCMcomplianceDataGridView1 = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn34 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AssignmentID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SCCMcomplianceDataGridView2 = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn36 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn37 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SCCMcomplianceButton = New MetroFramework.Controls.MetroButton()
        Me.RemoteCommandsSCCM = New System.Windows.Forms.TabPage()
        Me.TableLayoutPanel29 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label226 = New System.Windows.Forms.Label()
        Me.Label173 = New System.Windows.Forms.Label()
        Me.Label194 = New System.Windows.Forms.Label()
        Me.Button173 = New MetroFramework.Controls.MetroButton()
        Me.SCCMREPAIRWMI = New MetroFramework.Controls.MetroButton()
        Me.Button9 = New MetroFramework.Controls.MetroButton()
        Me.TAPREPAIRSCCMCLIENT = New MetroFramework.Controls.MetroButton()
        Me.TAPREPAIRWMI = New MetroFramework.Controls.MetroButton()
        Me.TAPHRP = New MetroFramework.Controls.MetroButton()
        Me.ClientFullLog = New System.Windows.Forms.TabPage()
        Me.SCCMfullClientLog = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn40 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SCCMClientMessageSent = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SCCMClientMessageTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GetFullCLientLogSCCM = New MetroFramework.Controls.MetroButton()
        Me.CacheDirectoryChange = New System.Windows.Forms.TextBox()
        Me.CacheChangeSize = New System.Windows.Forms.TextBox()
        Me.Label166 = New System.Windows.Forms.Label()
        Me.SCCMCacheLabel = New System.Windows.Forms.Label()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.MetroTile11 = New MetroFramework.Controls.MetroTile()
        Me.ServicesTab17 = New MetroFramework.Controls.MetroTabPage()
        Me.ExportServices = New MetroFramework.Controls.MetroButton()
        Me.GetServices = New MetroFramework.Controls.MetroButton()
        Me.TableLayoutPanel18 = New System.Windows.Forms.TableLayoutPanel()
        Me.StartService = New MetroFramework.Controls.MetroButton()
        Me.Label209 = New System.Windows.Forms.Label()
        Me.DeleteServiceButton = New MetroFramework.Controls.MetroButton()
        Me.SetServiceStartDisabled = New MetroFramework.Controls.MetroButton()
        Me.SetServiceStartManual = New MetroFramework.Controls.MetroButton()
        Me.SetServiceStartAutomatic = New MetroFramework.Controls.MetroButton()
        Me.StopService = New MetroFramework.Controls.MetroButton()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.TableLayoutPanel12 = New System.Windows.Forms.TableLayoutPanel()
        Me.DataGridView7 = New System.Windows.Forms.DataGridView()
        Me.ServiceName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ServiceDescription = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StartedYesNo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Status = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.ServiceNameSelected = New System.Windows.Forms.TextBox()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.MetroTile12 = New MetroFramework.Controls.MetroTile()
        Me.StoreApps18 = New System.Windows.Forms.TabPage()
        Me.TableLayoutPanel31 = New System.Windows.Forms.TableLayoutPanel()
        Me.StoreAppsDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn17 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn18 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Architecture = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ProgramId = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Language = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Vendor = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ExportStoreApps = New MetroFramework.Controls.MetroButton()
        Me.ListStoreApps = New MetroFramework.Controls.MetroButton()
        Me.Labelstoreapps2 = New System.Windows.Forms.Label()
        Me.Labelstoreapps1 = New System.Windows.Forms.Label()
        Me.MetroTile16 = New MetroFramework.Controls.MetroTile()
        Me.TaskManTab19 = New MetroFramework.Controls.MetroTabPage()
        Me.cmdRefresh = New MetroFramework.Controls.MetroButton()
        Me.Exporttaskmanager = New MetroFramework.Controls.MetroButton()
        Me.endprocessbutton = New MetroFramework.Controls.MetroButton()
        Me.TableLayoutPanel11 = New System.Windows.Forms.TableLayoutPanel()
        Me.lvwProcesses = New System.Windows.Forms.ListView()
        Me.lchImage = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.lchID = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.WhoRun = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.exepath = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Label52 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.MetroTile14 = New MetroFramework.Controls.MetroTile()
        Me.UserTab20 = New MetroFramework.Controls.MetroTabPage()
        Me.FlowLayoutPanel9 = New System.Windows.Forms.FlowLayoutPanel()
        Me.userlogonserver = New System.Windows.Forms.Label()
        Me.FlowLayoutPanel10 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.FlowLayoutPanel8 = New System.Windows.Forms.FlowLayoutPanel()
        Me.userbeingqueried = New System.Windows.Forms.Label()
        Me.FlowLayoutPanel1 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.ExportUserDetails = New MetroFramework.Controls.MetroButton()
        Me.GetPrinters = New MetroFramework.Controls.MetroButton()
        Me.TableLayoutPanel36 = New System.Windows.Forms.TableLayoutPanel()
        Me.DataGridViewPrinters = New System.Windows.Forms.DataGridView()
        Me.PC_Name = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.UsernamePrinters = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn70 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewODBC = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn75 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn76 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn77 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewNetwork = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn68 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn67 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn69 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label191 = New System.Windows.Forms.Label()
        Me.Label193 = New System.Windows.Forms.Label()
        Me.FlowLayoutPanel7 = New System.Windows.Forms.FlowLayoutPanel()
        Me.KeyboardLayout = New System.Windows.Forms.Label()
        Me.FlowLayoutPanel6 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.FlowLayoutPanel5 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Label197 = New System.Windows.Forms.Label()
        Me.FlowLayoutPanel4 = New System.Windows.Forms.FlowLayoutPanel()
        Me.tnsadmin = New System.Windows.Forms.Label()
        Me.FlowLayoutPanel2 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Label177 = New System.Windows.Forms.Label()
        Me.FlowLayoutPanel3 = New System.Windows.Forms.FlowLayoutPanel()
        Me.DefaultPrinter = New System.Windows.Forms.Label()
        Me.MetroTile15 = New MetroFramework.Controls.MetroTile()
        Me.WIM_PnPSignedDriver21 = New MetroFramework.Controls.MetroTabPage()
        Me.MetroTile17 = New MetroFramework.Controls.MetroTile()
        Me.PnPSignedDriverExportButton = New MetroFramework.Controls.MetroButton()
        Me.PnPSignedDriverButton = New MetroFramework.Controls.MetroButton()
        Me.PnPSignedDriverLabel2 = New System.Windows.Forms.Label()
        Me.PnPSignedDriverLabel1 = New System.Windows.Forms.Label()
        Me.TableLayoutPanel23 = New System.Windows.Forms.TableLayoutPanel()
        Me.PnPSignedDriverDataGrid = New System.Windows.Forms.DataGridView()
        Me.DeviceClass = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DriverProviderName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn22 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn20 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn19 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DeviceID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.WIM_OptionalFeatures22 = New MetroFramework.Controls.MetroTabPage()
        Me.MetroTile18 = New MetroFramework.Controls.MetroTile()
        Me.WIM_OptionalFeaturesExportButton = New MetroFramework.Controls.MetroButton()
        Me.WIM_OptionalFeaturesButton = New MetroFramework.Controls.MetroButton()
        Me.WIM_OptionalFeaturesLabel2 = New System.Windows.Forms.Label()
        Me.WIM_OptionalFeaturesLabel1 = New System.Windows.Forms.Label()
        Me.TableLayoutPanel21 = New System.Windows.Forms.TableLayoutPanel()
        Me.OptionalFeaturesDataGrid = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn16 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PXETab23 = New MetroFramework.Controls.MetroTabPage()
        Me.MetroTile10 = New MetroFramework.Controls.MetroTile()
        Me.Gather1EResults = New MetroFramework.Controls.MetroButton()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.TableLayoutPanel40 = New System.Windows.Forms.TableLayoutPanel()
        Me.MetroLabel9 = New MetroFramework.Controls.MetroLabel()
        Me.PXElogOpen = New MetroFramework.Controls.MetroButton()
        Me.MetroLabel8 = New MetroFramework.Controls.MetroLabel()
        Me.OpenTftrootImages = New MetroFramework.Controls.MetroButton()
        Me.PXEFolderOpen = New MetroFramework.Controls.MetroButton()
        Me.PXEProductVersionValue = New System.Windows.Forms.Label()
        Me.PXEServiceValue = New System.Windows.Forms.Label()
        Me.TableLayoutPanel38 = New System.Windows.Forms.TableLayoutPanel()
        Me.MetroLabel3 = New MetroFramework.Controls.MetroLabel()
        Me.IPsubnetValue = New System.Windows.Forms.Label()
        Me.MetroLabel7 = New MetroFramework.Controls.MetroLabel()
        Me.IPAddressValue = New System.Windows.Forms.Label()
        Me.MetroLabel6 = New MetroFramework.Controls.MetroLabel()
        Me.OpenNomadLogFile = New MetroFramework.Controls.MetroButton()
        Me.OpenNomad = New MetroFramework.Controls.MetroButton()
        Me.MetroLabel4 = New MetroFramework.Controls.MetroLabel()
        Me.NomadProductVersionValue = New System.Windows.Forms.Label()
        Me.NomadServiceValue = New System.Windows.Forms.Label()
        Me.NomadFolderSizeValue = New System.Windows.Forms.Label()
        Me.MetroLabel5 = New MetroFramework.Controls.MetroLabel()
        Me.MBSAtab11 = New MetroFramework.Controls.MetroTabPage()
        Me.LabelMBSA2 = New System.Windows.Forms.Label()
        Me.LabelMBSA1 = New System.Windows.Forms.Label()
        Me.MetroTile22 = New MetroFramework.Controls.MetroTile()
        Me.MetroLabel22 = New MetroFramework.Controls.MetroLabel()
        Me.MetroLabel21 = New MetroFramework.Controls.MetroLabel()
        Me.MetroLinkWSUSSCN2AB = New MetroFramework.Controls.MetroLink()
        Me.MetroLabel20 = New MetroFramework.Controls.MetroLabel()
        Me.MBSAlistBox = New System.Windows.Forms.ListBox()
        Me.MBSATextBox = New MetroFramework.Controls.MetroTextBox()
        Me.MetroLabel19 = New MetroFramework.Controls.MetroLabel()
        Me.MBSA_Run = New MetroFramework.Controls.MetroButton()
        Me.ProcessorTab13 = New MetroFramework.Controls.MetroTabPage()
        Me.MetroTile13 = New MetroFramework.Controls.MetroTile()
        Me.ProcessorUsage = New MetroFramework.Controls.MetroButton()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.ListViewProcessorUsage = New System.Windows.Forms.ListView()
        Me.ColumnHeader5 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader6 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader8 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ContextMenu1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.AddPC = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.AddPCFromFile = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.CopyNameToClipBoardToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator6 = New System.Windows.Forms.ToolStripSeparator()
        Me.DeletePC = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.ClearAllComputers = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.PINGSinglePC = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator()
        Me.ConnectToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ImageList = New System.Windows.Forms.ImageList(Me.components)
        Me.BackgroundWorkerSpinner = New System.ComponentModel.BackgroundWorker()
        Me.MetroProgressBar = New MetroFramework.Controls.MetroProgressBar()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.BackgroundWorkerEval = New System.ComponentModel.BackgroundWorker()
        Me.MetroLabel12 = New MetroFramework.Controls.MetroLabel()
        Me.TableLayoutPanel10 = New System.Windows.Forms.TableLayoutPanel()
        Me.TreeView = New System.Windows.Forms.TreeView()
        Me.TableLayoutPanel13 = New System.Windows.Forms.TableLayoutPanel()
        Me.PrintScreenTip = New System.Windows.Forms.ToolTip(Me.components)
        Me.HelpTip = New System.Windows.Forms.ToolTip(Me.components)
        Me.Home = New MetroFramework.Controls.MetroButton()
        Me.PaypalTip = New System.Windows.Forms.ToolTip(Me.components)
        Me.MetroLabel15 = New MetroFramework.Controls.MetroLabel()
        Me.ContextMenu1ToolTip = New MetroFramework.Components.MetroToolTip()
        Me.MetroToolTip1 = New MetroFramework.Components.MetroToolTip()
        Me.FormTabControl.SuspendLayout()
        Me.HomeTab1.SuspendLayout()
        Me.TableLayoutPanel24.SuspendLayout()
        Me.TableLayoutPanel43.SuspendLayout()
        Me.TableLayoutPanel34.SuspendLayout()
        Me.TableLayoutPanel33.SuspendLayout()
        Me.TableLayoutPanel9.SuspendLayout()
        Me.ContextMenuCopyHOST2Clipboard.SuspendLayout()
        Me.TableLayoutPanel5.SuspendLayout()
        Me.ContextMenuCopyIPAddress2Clipboard.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.ADtab2.SuspendLayout()
        Me.MetroPanel1.SuspendLayout()
        Me.INFOTab3.SuspendLayout()
        Me.TableLayoutPanel6.SuspendLayout()
        CType(Me.DataGridViewDetails, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.DiskTab4.SuspendLayout()
        CType(Me.DataGridViewDisk2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridViewDisk, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.NetTab5.SuspendLayout()
        Me.TableLayoutPanel42.SuspendLayout()
        CType(Me.DataGridViewNetCore, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel41.SuspendLayout()
        CType(Me.DataGridViewNet64, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel39.SuspendLayout()
        CType(Me.DataGridViewNet32, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ExecuteTab6.SuspendLayout()
        Me.TableLayoutPanel30.SuspendLayout()
        Me.TableLayoutPanel28.SuspendLayout()
        Me.TableLayoutPanel22.SuspendLayout()
        Me.TableLayoutPanel32.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.TableLayoutPanel8.SuspendLayout()
        Me.TableLayoutPanel4.SuspendLayout()
        Me.TableLayoutPanel3.SuspendLayout()
        Me.FtypeTab7.SuspendLayout()
        Me.TableLayoutPanel14.SuspendLayout()
        Me.GroupsTab8.SuspendLayout()
        Me.TableLayoutPanel27.SuspendLayout()
        Me.TableLayoutPanel26.SuspendLayout()
        Me.TableLayoutPanel25.SuspendLayout()
        Me.instSoftwareTab9.SuspendLayout()
        Me.TableLayoutPanel16.SuspendLayout()
        Me.TableLayoutPanel15.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.WUtab10.SuspendLayout()
        Me.TableLayoutPanel20.SuspendLayout()
        Me.TableLayoutPanel37.SuspendLayout()
        CType(Me.DataGridView10, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MSITab12.SuspendLayout()
        Me.TableLayoutPanel19.SuspendLayout()
        Me.TableLayoutPanel17.SuspendLayout()
        CType(Me.DataGridView6, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Profiles14.SuspendLayout()
        Me.TableLayoutPanel35.SuspendLayout()
        CType(Me.DataGridViewProfiles, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.RebootChecker15.SuspendLayout()
        Me.TableLayoutPanel44.SuspendLayout()
        Me.SCCMtab16.SuspendLayout()
        Me.TableLayoutPanel47.SuspendLayout()
        Me.TableLayoutPanel7.SuspendLayout()
        Me.SCCMTabControl.SuspendLayout()
        Me.ExecutionHistory.SuspendLayout()
        CType(Me.DataGridView9, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ADVMachine.SuspendLayout()
        CType(Me.DataGridView8, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ADVLoggedOnUser.SuspendLayout()
        CType(Me.DataGridView25, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ADVTaskSeq.SuspendLayout()
        CType(Me.DataGridView11, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PKGInstallStats.SuspendLayout()
        CType(Me.DataGridViewSCCMRunning, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.KB_EvaluationState.SuspendLayout()
        CType(Me.DataGridViewKBStatus, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SCCMmissUpdates.SuspendLayout()
        CType(Me.ListMissingUpdatesSCCMDatagrid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PatchesIn.SuspendLayout()
        CType(Me.SCCMPatchesInstalledDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SCCMcomplianceTab.SuspendLayout()
        Me.TableLayoutPanel46.SuspendLayout()
        Me.TableLayoutPanel45.SuspendLayout()
        CType(Me.SCCMcomplianceDataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SCCMcomplianceDataGridView2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.RemoteCommandsSCCM.SuspendLayout()
        Me.TableLayoutPanel29.SuspendLayout()
        Me.ClientFullLog.SuspendLayout()
        CType(Me.SCCMfullClientLog, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ServicesTab17.SuspendLayout()
        Me.TableLayoutPanel18.SuspendLayout()
        Me.TableLayoutPanel12.SuspendLayout()
        CType(Me.DataGridView7, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.StoreApps18.SuspendLayout()
        Me.TableLayoutPanel31.SuspendLayout()
        CType(Me.StoreAppsDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TaskManTab19.SuspendLayout()
        Me.TableLayoutPanel11.SuspendLayout()
        Me.UserTab20.SuspendLayout()
        Me.FlowLayoutPanel9.SuspendLayout()
        Me.FlowLayoutPanel10.SuspendLayout()
        Me.FlowLayoutPanel8.SuspendLayout()
        Me.FlowLayoutPanel1.SuspendLayout()
        Me.TableLayoutPanel36.SuspendLayout()
        CType(Me.DataGridViewPrinters, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridViewODBC, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridViewNetwork, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.FlowLayoutPanel7.SuspendLayout()
        Me.FlowLayoutPanel6.SuspendLayout()
        Me.FlowLayoutPanel5.SuspendLayout()
        Me.FlowLayoutPanel4.SuspendLayout()
        Me.FlowLayoutPanel2.SuspendLayout()
        Me.FlowLayoutPanel3.SuspendLayout()
        Me.WIM_PnPSignedDriver21.SuspendLayout()
        Me.TableLayoutPanel23.SuspendLayout()
        CType(Me.PnPSignedDriverDataGrid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.WIM_OptionalFeatures22.SuspendLayout()
        Me.TableLayoutPanel21.SuspendLayout()
        CType(Me.OptionalFeaturesDataGrid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PXETab23.SuspendLayout()
        Me.TableLayoutPanel40.SuspendLayout()
        Me.TableLayoutPanel38.SuspendLayout()
        Me.MBSAtab11.SuspendLayout()
        Me.ProcessorTab13.SuspendLayout()
        Me.ContextMenu1.SuspendLayout()
        Me.TableLayoutPanel10.SuspendLayout()
        Me.TableLayoutPanel13.SuspendLayout()
        Me.SuspendLayout()
        '
        'ImageListSCCM
        '
        Me.ImageListSCCM.ImageStream = CType(resources.GetObject("ImageListSCCM.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageListSCCM.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageListSCCM.Images.SetKeyName(0, "3dlb-3d-Gear-wheel.ico")
        Me.ImageListSCCM.Images.SetKeyName(1, "Graphicloads-100-Flat-2-Man-2.ico")
        Me.ImageListSCCM.Images.SetKeyName(2, "Graphicloads-100-Flat-Phonebook.ico")
        Me.ImageListSCCM.Images.SetKeyName(3, "Graphicloads-100-Flat-Stat.ico")
        Me.ImageListSCCM.Images.SetKeyName(4, "Graphicloads-100-Flat-Summary.ico")
        Me.ImageListSCCM.Images.SetKeyName(5, "Graphicloads-100-Flat-Warning.ico")
        Me.ImageListSCCM.Images.SetKeyName(6, "Graphicloads-100-Flat-Stat.ico")
        Me.ImageListSCCM.Images.SetKeyName(7, "Paomedia-Small-N-Flat-Monitor.ico")
        Me.ImageListSCCM.Images.SetKeyName(8, "Double-J-Design-Super-Mono-3d-Button-bubble-info.ico")
        Me.ImageListSCCM.Images.SetKeyName(9, "Oxygen-Icons.org-Oxygen-Actions-view-list-details.ico")
        '
        'BackgroundWorker3
        '
        '
        'Purchase
        '
        Me.Purchase.ActiveControl = Nothing
        Me.Purchase.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Purchase.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Purchase.BackColor = System.Drawing.Color.Transparent
        Me.Purchase.Location = New System.Drawing.Point(1169, 8)
        Me.Purchase.Name = "Purchase"
        Me.Purchase.Size = New System.Drawing.Size(39, 28)
        Me.Purchase.TabIndex = 6
        Me.Purchase.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Purchase.TileImage = CType(resources.GetObject("Purchase.TileImage"), System.Drawing.Image)
        Me.Purchase.TileImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.PaypalTip.SetToolTip(Me.Purchase, "Donations Welcome (Paypal / Visa / Mastercard)")
        Me.Purchase.UseCustomBackColor = True
        Me.Purchase.UseCustomForeColor = True
        Me.Purchase.UseSelectable = True
        Me.Purchase.UseTileImage = True
        '
        'Button2
        '
        Me.Button2.ActiveControl = Nothing
        Me.Button2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button2.BackColor = System.Drawing.Color.Transparent
        Me.Button2.Location = New System.Drawing.Point(1214, 9)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(27, 27)
        Me.Button2.TabIndex = 7
        Me.Button2.Tag = ""
        Me.Button2.TileImage = CType(resources.GetObject("Button2.TileImage"), System.Drawing.Image)
        Me.Button2.TileImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.PrintScreenTip.SetToolTip(Me.Button2, "Print Screen")
        Me.Button2.UseCustomBackColor = True
        Me.Button2.UseCustomForeColor = True
        Me.Button2.UseSelectable = True
        Me.Button2.UseTileImage = True
        '
        'Helpme
        '
        Me.Helpme.ActiveControl = Nothing
        Me.Helpme.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Helpme.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Helpme.BackColor = System.Drawing.Color.Transparent
        Me.Helpme.Location = New System.Drawing.Point(1247, 9)
        Me.Helpme.Name = "Helpme"
        Me.Helpme.Size = New System.Drawing.Size(34, 27)
        Me.Helpme.TabIndex = 8
        Me.Helpme.TileImage = CType(resources.GetObject("Helpme.TileImage"), System.Drawing.Image)
        Me.Helpme.TileImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.HelpTip.SetToolTip(Me.Helpme, "Launch PDF help file")
        Me.Helpme.UseCustomBackColor = True
        Me.Helpme.UseCustomForeColor = True
        Me.Helpme.UseSelectable = True
        Me.Helpme.UseTileImage = True
        '
        'FormTabControl
        '
        Me.FormTabControl.Controls.Add(Me.HomeTab1)
        Me.FormTabControl.Controls.Add(Me.ADtab2)
        Me.FormTabControl.Controls.Add(Me.INFOTab3)
        Me.FormTabControl.Controls.Add(Me.DiskTab4)
        Me.FormTabControl.Controls.Add(Me.NetTab5)
        Me.FormTabControl.Controls.Add(Me.ExecuteTab6)
        Me.FormTabControl.Controls.Add(Me.FtypeTab7)
        Me.FormTabControl.Controls.Add(Me.GroupsTab8)
        Me.FormTabControl.Controls.Add(Me.instSoftwareTab9)
        Me.FormTabControl.Controls.Add(Me.WUtab10)
        Me.FormTabControl.Controls.Add(Me.MBSAtab11)
        Me.FormTabControl.Controls.Add(Me.MSITab12)
        Me.FormTabControl.Controls.Add(Me.ProcessorTab13)
        Me.FormTabControl.Controls.Add(Me.Profiles14)
        Me.FormTabControl.Controls.Add(Me.RebootChecker15)
        Me.FormTabControl.Controls.Add(Me.SCCMtab16)
        Me.FormTabControl.Controls.Add(Me.ServicesTab17)
        Me.FormTabControl.Controls.Add(Me.StoreApps18)
        Me.FormTabControl.Controls.Add(Me.TaskManTab19)
        Me.FormTabControl.Controls.Add(Me.UserTab20)
        Me.FormTabControl.Controls.Add(Me.WIM_PnPSignedDriver21)
        Me.FormTabControl.Controls.Add(Me.WIM_OptionalFeatures22)
        Me.FormTabControl.Controls.Add(Me.PXETab23)
        Me.FormTabControl.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FormTabControl.FontSize = MetroFramework.MetroTabControlSize.Small
        Me.FormTabControl.ItemSize = New System.Drawing.Size(60, 30)
        Me.FormTabControl.Location = New System.Drawing.Point(3, 3)
        Me.FormTabControl.Name = "FormTabControl"
        Me.FormTabControl.SelectedIndex = 0
        Me.FormTabControl.Size = New System.Drawing.Size(1083, 716)
        Me.FormTabControl.TabIndex = 117
        Me.FormTabControl.UseSelectable = True
        '
        'HomeTab1
        '
        Me.HomeTab1.BackColor = System.Drawing.Color.Transparent
        Me.HomeTab1.Controls.Add(Me.TableLayoutPanel24)
        Me.HomeTab1.Controls.Add(Me.TableLayoutPanel43)
        Me.HomeTab1.Controls.Add(Me.TableLayoutPanel34)
        Me.HomeTab1.Controls.Add(Me.TableLayoutPanel33)
        Me.HomeTab1.Controls.Add(Me.TableLayoutPanel9)
        Me.HomeTab1.Controls.Add(Me.TableLayoutPanel5)
        Me.HomeTab1.Controls.Add(Me.TableLayoutPanel2)
        Me.HomeTab1.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.HomeTab1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.HomeTab1.HorizontalScrollbarBarColor = False
        Me.HomeTab1.HorizontalScrollbarHighlightOnWheel = False
        Me.HomeTab1.HorizontalScrollbarSize = 0
        Me.HomeTab1.ImageIndex = 0
        Me.HomeTab1.Location = New System.Drawing.Point(4, 34)
        Me.HomeTab1.Name = "HomeTab1"
        Me.HomeTab1.Size = New System.Drawing.Size(1075, 678)
        Me.HomeTab1.TabIndex = 0
        Me.HomeTab1.Text = "Home"
        Me.HomeTab1.VerticalScrollbarBarColor = False
        Me.HomeTab1.VerticalScrollbarHighlightOnWheel = False
        Me.HomeTab1.VerticalScrollbarSize = 0
        '
        'TableLayoutPanel24
        '
        Me.TableLayoutPanel24.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.TableLayoutPanel24.ColumnCount = 3
        Me.TableLayoutPanel24.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 18.05416!))
        Me.TableLayoutPanel24.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 66.04651!))
        Me.TableLayoutPanel24.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15.90698!))
        Me.TableLayoutPanel24.Controls.Add(Me.RunPSCommandButton, 2, 0)
        Me.TableLayoutPanel24.Controls.Add(Me.Label9, 0, 0)
        Me.TableLayoutPanel24.Controls.Add(Me.RunPSCommandTextBox, 1, 0)
        Me.TableLayoutPanel24.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.TableLayoutPanel24.Location = New System.Drawing.Point(0, 624)
        Me.TableLayoutPanel24.Margin = New System.Windows.Forms.Padding(2)
        Me.TableLayoutPanel24.Name = "TableLayoutPanel24"
        Me.TableLayoutPanel24.RowCount = 1
        Me.TableLayoutPanel24.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel24.Size = New System.Drawing.Size(1075, 27)
        Me.TableLayoutPanel24.TabIndex = 124
        '
        'RunPSCommandButton
        '
        Me.RunPSCommandButton.ActiveControl = Nothing
        Me.RunPSCommandButton.BackColor = System.Drawing.Color.AliceBlue
        Me.RunPSCommandButton.Dock = System.Windows.Forms.DockStyle.Fill
        Me.RunPSCommandButton.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.RunPSCommandButton.Location = New System.Drawing.Point(906, 3)
        Me.RunPSCommandButton.Name = "RunPSCommandButton"
        Me.RunPSCommandButton.Size = New System.Drawing.Size(166, 21)
        Me.RunPSCommandButton.TabIndex = 25
        Me.RunPSCommandButton.Text = "< Invoke Command (P$)"
        Me.RunPSCommandButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.RunPSCommandButton.TileImage = CType(resources.GetObject("RunPSCommandButton.TileImage"), System.Drawing.Image)
        Me.RunPSCommandButton.TileImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.RunPSCommandButton.TileTextFontSize = MetroFramework.MetroTileTextSize.Small
        Me.RunPSCommandButton.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular
        Me.RunPSCommandButton.UseCustomBackColor = True
        Me.RunPSCommandButton.UseCustomForeColor = True
        Me.RunPSCommandButton.UseSelectable = True
        Me.RunPSCommandButton.UseTileImage = True
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label9.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Label9.Location = New System.Drawing.Point(3, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(188, 27)
        Me.Label9.TabIndex = 62
        Me.Label9.Text = "P$ command to run on remote PC >"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'RunPSCommandTextBox
        '
        '
        '
        '
        Me.RunPSCommandTextBox.CustomButton.Image = Nothing
        Me.RunPSCommandTextBox.CustomButton.Location = New System.Drawing.Point(683, 1)
        Me.RunPSCommandTextBox.CustomButton.Name = ""
        Me.RunPSCommandTextBox.CustomButton.Size = New System.Drawing.Size(19, 19)
        Me.RunPSCommandTextBox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue
        Me.RunPSCommandTextBox.CustomButton.TabIndex = 1
        Me.RunPSCommandTextBox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light
        Me.RunPSCommandTextBox.CustomButton.UseSelectable = True
        Me.RunPSCommandTextBox.CustomButton.Visible = False
        Me.RunPSCommandTextBox.Dock = System.Windows.Forms.DockStyle.Fill
        Me.RunPSCommandTextBox.Lines = New String() {"Get-PSDrive"}
        Me.RunPSCommandTextBox.Location = New System.Drawing.Point(197, 3)
        Me.RunPSCommandTextBox.MaxLength = 32767
        Me.RunPSCommandTextBox.Name = "RunPSCommandTextBox"
        Me.RunPSCommandTextBox.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.RunPSCommandTextBox.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.RunPSCommandTextBox.SelectedText = ""
        Me.RunPSCommandTextBox.SelectionLength = 0
        Me.RunPSCommandTextBox.SelectionStart = 0
        Me.RunPSCommandTextBox.Size = New System.Drawing.Size(703, 21)
        Me.RunPSCommandTextBox.TabIndex = 119
        Me.RunPSCommandTextBox.Text = "Get-PSDrive"
        Me.RunPSCommandTextBox.UseSelectable = True
        Me.RunPSCommandTextBox.WaterMarkColor = System.Drawing.Color.FromArgb(CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.RunPSCommandTextBox.WaterMarkFont = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel)
        '
        'TableLayoutPanel43
        '
        Me.TableLayoutPanel43.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.TableLayoutPanel43.ColumnCount = 3
        Me.TableLayoutPanel43.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 18.05416!))
        Me.TableLayoutPanel43.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 66.04651!))
        Me.TableLayoutPanel43.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15.90698!))
        Me.TableLayoutPanel43.Controls.Add(Me.Runcommandonly, 2, 0)
        Me.TableLayoutPanel43.Controls.Add(Me.Label217, 0, 0)
        Me.TableLayoutPanel43.Controls.Add(Me.runcommandonlytext, 1, 0)
        Me.TableLayoutPanel43.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.TableLayoutPanel43.Location = New System.Drawing.Point(0, 651)
        Me.TableLayoutPanel43.Margin = New System.Windows.Forms.Padding(2)
        Me.TableLayoutPanel43.Name = "TableLayoutPanel43"
        Me.TableLayoutPanel43.RowCount = 1
        Me.TableLayoutPanel43.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel43.Size = New System.Drawing.Size(1075, 27)
        Me.TableLayoutPanel43.TabIndex = 122
        '
        'Runcommandonly
        '
        Me.Runcommandonly.ActiveControl = Nothing
        Me.Runcommandonly.BackColor = System.Drawing.Color.AliceBlue
        Me.Runcommandonly.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Runcommandonly.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.Runcommandonly.Location = New System.Drawing.Point(906, 3)
        Me.Runcommandonly.Name = "Runcommandonly"
        Me.Runcommandonly.Size = New System.Drawing.Size(166, 21)
        Me.Runcommandonly.TabIndex = 25
        Me.Runcommandonly.Text = "< Run Command (WMI)"
        Me.Runcommandonly.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Runcommandonly.TileImage = CType(resources.GetObject("Runcommandonly.TileImage"), System.Drawing.Image)
        Me.Runcommandonly.TileImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Runcommandonly.TileTextFontSize = MetroFramework.MetroTileTextSize.Small
        Me.Runcommandonly.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular
        Me.Runcommandonly.UseCustomBackColor = True
        Me.Runcommandonly.UseCustomForeColor = True
        Me.Runcommandonly.UseSelectable = True
        Me.Runcommandonly.UseTileImage = True
        '
        'Label217
        '
        Me.Label217.AutoSize = True
        Me.Label217.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label217.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Label217.Location = New System.Drawing.Point(3, 0)
        Me.Label217.Name = "Label217"
        Me.Label217.Size = New System.Drawing.Size(188, 27)
        Me.Label217.TabIndex = 62
        Me.Label217.Text = "Command to run on remote PC >"
        Me.Label217.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'runcommandonlytext
        '
        '
        '
        '
        Me.runcommandonlytext.CustomButton.Image = Nothing
        Me.runcommandonlytext.CustomButton.Location = New System.Drawing.Point(683, 1)
        Me.runcommandonlytext.CustomButton.Name = ""
        Me.runcommandonlytext.CustomButton.Size = New System.Drawing.Size(19, 19)
        Me.runcommandonlytext.CustomButton.Style = MetroFramework.MetroColorStyle.Blue
        Me.runcommandonlytext.CustomButton.TabIndex = 1
        Me.runcommandonlytext.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light
        Me.runcommandonlytext.CustomButton.UseSelectable = True
        Me.runcommandonlytext.CustomButton.Visible = False
        Me.runcommandonlytext.Dock = System.Windows.Forms.DockStyle.Fill
        Me.runcommandonlytext.Lines = New String() {"CMD.EXE /C Del C:\Windows\Temp\*.* /F /Q"}
        Me.runcommandonlytext.Location = New System.Drawing.Point(197, 3)
        Me.runcommandonlytext.MaxLength = 32767
        Me.runcommandonlytext.Name = "runcommandonlytext"
        Me.runcommandonlytext.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.runcommandonlytext.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.runcommandonlytext.SelectedText = ""
        Me.runcommandonlytext.SelectionLength = 0
        Me.runcommandonlytext.SelectionStart = 0
        Me.runcommandonlytext.Size = New System.Drawing.Size(703, 21)
        Me.runcommandonlytext.TabIndex = 119
        Me.runcommandonlytext.Text = "CMD.EXE /C Del C:\Windows\Temp\*.* /F /Q"
        Me.runcommandonlytext.UseSelectable = True
        Me.runcommandonlytext.WaterMarkColor = System.Drawing.Color.FromArgb(CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.runcommandonlytext.WaterMarkFont = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel)
        '
        'TableLayoutPanel34
        '
        Me.TableLayoutPanel34.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel34.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.TableLayoutPanel34.BackColor = System.Drawing.Color.Transparent
        Me.TableLayoutPanel34.ColumnCount = 3
        Me.TableLayoutPanel34.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.528688!))
        Me.TableLayoutPanel34.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 73.02325!))
        Me.TableLayoutPanel34.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.48837!))
        Me.TableLayoutPanel34.Controls.Add(Me.SaveEMAdetails, 1, 0)
        Me.TableLayoutPanel34.Controls.Add(Me.Label208, 0, 0)
        Me.TableLayoutPanel34.Controls.Add(Me.DeleteEMAnumber, 2, 0)
        Me.TableLayoutPanel34.Location = New System.Drawing.Point(0, 223)
        Me.TableLayoutPanel34.Name = "TableLayoutPanel34"
        Me.TableLayoutPanel34.RowCount = 1
        Me.TableLayoutPanel34.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel34.Size = New System.Drawing.Size(1075, 35)
        Me.TableLayoutPanel34.TabIndex = 121
        '
        'SaveEMAdetails
        '
        Me.SaveEMAdetails.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        '
        '
        '
        Me.SaveEMAdetails.CustomButton.Image = Nothing
        Me.SaveEMAdetails.CustomButton.Location = New System.Drawing.Point(750, 1)
        Me.SaveEMAdetails.CustomButton.Name = ""
        Me.SaveEMAdetails.CustomButton.Size = New System.Drawing.Size(27, 27)
        Me.SaveEMAdetails.CustomButton.Style = MetroFramework.MetroColorStyle.Blue
        Me.SaveEMAdetails.CustomButton.TabIndex = 1
        Me.SaveEMAdetails.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light
        Me.SaveEMAdetails.CustomButton.UseSelectable = True
        Me.SaveEMAdetails.CustomButton.Visible = False
        Me.SaveEMAdetails.Lines = New String(-1) {}
        Me.SaveEMAdetails.Location = New System.Drawing.Point(105, 3)
        Me.SaveEMAdetails.MaxLength = 32767
        Me.SaveEMAdetails.Name = "SaveEMAdetails"
        Me.SaveEMAdetails.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.SaveEMAdetails.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.SaveEMAdetails.SelectedText = ""
        Me.SaveEMAdetails.SelectionLength = 0
        Me.SaveEMAdetails.SelectionStart = 0
        Me.SaveEMAdetails.Size = New System.Drawing.Size(778, 29)
        Me.SaveEMAdetails.TabIndex = 119
        Me.SaveEMAdetails.UseSelectable = True
        Me.SaveEMAdetails.WaterMarkColor = System.Drawing.Color.FromArgb(CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.SaveEMAdetails.WaterMarkFont = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel)
        '
        'Label208
        '
        Me.Label208.AutoSize = True
        Me.Label208.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label208.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label208.Location = New System.Drawing.Point(3, 0)
        Me.Label208.Name = "Label208"
        Me.Label208.Size = New System.Drawing.Size(96, 35)
        Me.Label208.TabIndex = 105
        Me.Label208.Text = "Helpdesk Details >"
        Me.Label208.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'DeleteEMAnumber
        '
        Me.DeleteEMAnumber.ActiveControl = Nothing
        Me.DeleteEMAnumber.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DeleteEMAnumber.BackColor = System.Drawing.Color.AliceBlue
        Me.DeleteEMAnumber.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.DeleteEMAnumber.Location = New System.Drawing.Point(889, 3)
        Me.DeleteEMAnumber.Name = "DeleteEMAnumber"
        Me.DeleteEMAnumber.Size = New System.Drawing.Size(183, 29)
        Me.DeleteEMAnumber.TabIndex = 133
        Me.DeleteEMAnumber.Text = "Delete helpdesk details"
        Me.DeleteEMAnumber.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.DeleteEMAnumber.TileImage = CType(resources.GetObject("DeleteEMAnumber.TileImage"), System.Drawing.Image)
        Me.DeleteEMAnumber.TileImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.DeleteEMAnumber.TileTextFontSize = MetroFramework.MetroTileTextSize.Small
        Me.DeleteEMAnumber.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular
        Me.DeleteEMAnumber.UseCustomBackColor = True
        Me.DeleteEMAnumber.UseCustomForeColor = True
        Me.DeleteEMAnumber.UseSelectable = True
        Me.DeleteEMAnumber.UseTileImage = True
        '
        'TableLayoutPanel33
        '
        Me.TableLayoutPanel33.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel33.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.TableLayoutPanel33.BackColor = System.Drawing.Color.Transparent
        Me.TableLayoutPanel33.ColumnCount = 3
        Me.TableLayoutPanel33.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.528688!))
        Me.TableLayoutPanel33.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 73.02325!))
        Me.TableLayoutPanel33.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.48837!))
        Me.TableLayoutPanel33.Controls.Add(Me.SaveEMAnumber, 2, 1)
        Me.TableLayoutPanel33.Controls.Add(Me.Label179, 0, 1)
        Me.TableLayoutPanel33.Controls.Add(Me.Helpdesknumber, 1, 1)
        Me.TableLayoutPanel33.Location = New System.Drawing.Point(0, 159)
        Me.TableLayoutPanel33.Name = "TableLayoutPanel33"
        Me.TableLayoutPanel33.RowCount = 2
        Me.TableLayoutPanel33.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 43.33333!))
        Me.TableLayoutPanel33.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 56.66667!))
        Me.TableLayoutPanel33.Size = New System.Drawing.Size(1075, 61)
        Me.TableLayoutPanel33.TabIndex = 120
        '
        'SaveEMAnumber
        '
        Me.SaveEMAnumber.ActiveControl = Nothing
        Me.SaveEMAnumber.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.SaveEMAnumber.BackColor = System.Drawing.Color.AliceBlue
        Me.SaveEMAnumber.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.SaveEMAnumber.Location = New System.Drawing.Point(889, 29)
        Me.SaveEMAnumber.Name = "SaveEMAnumber"
        Me.SaveEMAnumber.Size = New System.Drawing.Size(183, 29)
        Me.SaveEMAnumber.TabIndex = 8
        Me.SaveEMAnumber.Text = "Save helpdesk details"
        Me.SaveEMAnumber.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.SaveEMAnumber.TileImage = CType(resources.GetObject("SaveEMAnumber.TileImage"), System.Drawing.Image)
        Me.SaveEMAnumber.TileImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.SaveEMAnumber.TileTextFontSize = MetroFramework.MetroTileTextSize.Small
        Me.SaveEMAnumber.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular
        Me.SaveEMAnumber.UseCustomBackColor = True
        Me.SaveEMAnumber.UseCustomForeColor = True
        Me.SaveEMAnumber.UseSelectable = True
        Me.SaveEMAnumber.UseTileImage = True
        '
        'Label179
        '
        Me.Label179.AutoSize = True
        Me.Label179.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label179.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Label179.Location = New System.Drawing.Point(3, 26)
        Me.Label179.Name = "Label179"
        Me.Label179.Size = New System.Drawing.Size(96, 35)
        Me.Label179.TabIndex = 125
        Me.Label179.Text = "Helpdesk No. >"
        Me.Label179.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Helpdesknumber
        '
        Me.Helpdesknumber.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        '
        '
        '
        Me.Helpdesknumber.CustomButton.Image = Nothing
        Me.Helpdesknumber.CustomButton.Location = New System.Drawing.Point(750, 1)
        Me.Helpdesknumber.CustomButton.Name = ""
        Me.Helpdesknumber.CustomButton.Size = New System.Drawing.Size(27, 27)
        Me.Helpdesknumber.CustomButton.Style = MetroFramework.MetroColorStyle.Blue
        Me.Helpdesknumber.CustomButton.TabIndex = 1
        Me.Helpdesknumber.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light
        Me.Helpdesknumber.CustomButton.UseSelectable = True
        Me.Helpdesknumber.CustomButton.Visible = False
        Me.Helpdesknumber.Lines = New String(-1) {}
        Me.Helpdesknumber.Location = New System.Drawing.Point(105, 29)
        Me.Helpdesknumber.MaxLength = 32767
        Me.Helpdesknumber.Name = "Helpdesknumber"
        Me.Helpdesknumber.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.Helpdesknumber.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.Helpdesknumber.SelectedText = ""
        Me.Helpdesknumber.SelectionLength = 0
        Me.Helpdesknumber.SelectionStart = 0
        Me.Helpdesknumber.Size = New System.Drawing.Size(778, 29)
        Me.Helpdesknumber.TabIndex = 132
        Me.Helpdesknumber.UseSelectable = True
        Me.Helpdesknumber.WaterMarkColor = System.Drawing.Color.FromArgb(CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.Helpdesknumber.WaterMarkFont = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel)
        '
        'TableLayoutPanel9
        '
        Me.TableLayoutPanel9.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.TableLayoutPanel9.BackColor = System.Drawing.Color.Transparent
        Me.TableLayoutPanel9.ColumnCount = 5
        Me.TableLayoutPanel9.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.543569!))
        Me.TableLayoutPanel9.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 38.90041!))
        Me.TableLayoutPanel9.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.29918!))
        Me.TableLayoutPanel9.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.95349!))
        Me.TableLayoutPanel9.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.48837!))
        Me.TableLayoutPanel9.Controls.Add(Me.userdomainComboBox, 1, 1)
        Me.TableLayoutPanel9.Controls.Add(Me.GetMobileNumber, 2, 2)
        Me.TableLayoutPanel9.Controls.Add(Me.GetPhoneNumber, 2, 1)
        Me.TableLayoutPanel9.Controls.Add(Me.Reboot, 4, 0)
        Me.TableLayoutPanel9.Controls.Add(Me.GetEmailAddress, 2, 0)
        Me.TableLayoutPanel9.Controls.Add(Me.PhoneNumber1, 3, 1)
        Me.TableLayoutPanel9.Controls.Add(Me.EmailAddress, 3, 0)
        Me.TableLayoutPanel9.Controls.Add(Me.Host, 1, 0)
        Me.TableLayoutPanel9.Controls.Add(Me.Label24, 0, 0)
        Me.TableLayoutPanel9.Controls.Add(Me.PhoneNumber2, 4, 1)
        Me.TableLayoutPanel9.Controls.Add(Me.MobileNumber, 3, 2)
        Me.TableLayoutPanel9.Controls.Add(Me.Label25, 0, 1)
        Me.TableLayoutPanel9.Controls.Add(Me.uptime1, 3, 3)
        Me.TableLayoutPanel9.Controls.Add(Me.GetUptime, 2, 3)
        Me.TableLayoutPanel9.Controls.Add(Me.ShaddowUserSession, 1, 2)
        Me.TableLayoutPanel9.Dock = System.Windows.Forms.DockStyle.Top
        Me.TableLayoutPanel9.Location = New System.Drawing.Point(0, 30)
        Me.TableLayoutPanel9.Margin = New System.Windows.Forms.Padding(2)
        Me.TableLayoutPanel9.Name = "TableLayoutPanel9"
        Me.TableLayoutPanel9.RowCount = 4
        Me.TableLayoutPanel9.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 32.29167!))
        Me.TableLayoutPanel9.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel9.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 34.375!))
        Me.TableLayoutPanel9.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34.0!))
        Me.TableLayoutPanel9.Size = New System.Drawing.Size(1075, 131)
        Me.TableLayoutPanel9.TabIndex = 119
        '
        'userdomainComboBox
        '
        Me.userdomainComboBox.BackColor = System.Drawing.Color.White
        Me.userdomainComboBox.Dock = System.Windows.Forms.DockStyle.Fill
        Me.userdomainComboBox.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.userdomainComboBox.FormattingEnabled = True
        Me.userdomainComboBox.Location = New System.Drawing.Point(105, 34)
        Me.userdomainComboBox.Name = "userdomainComboBox"
        Me.userdomainComboBox.Size = New System.Drawing.Size(411, 21)
        Me.userdomainComboBox.TabIndex = 121
        '
        'GetMobileNumber
        '
        Me.GetMobileNumber.ActiveControl = Nothing
        Me.GetMobileNumber.BackColor = System.Drawing.Color.AliceBlue
        Me.GetMobileNumber.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GetMobileNumber.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.GetMobileNumber.Location = New System.Drawing.Point(522, 66)
        Me.GetMobileNumber.Name = "GetMobileNumber"
        Me.GetMobileNumber.Size = New System.Drawing.Size(83, 27)
        Me.GetMobileNumber.TabIndex = 6
        Me.GetMobileNumber.Text = "Get Mobile"
        Me.GetMobileNumber.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.GetMobileNumber.TileTextFontSize = MetroFramework.MetroTileTextSize.Small
        Me.GetMobileNumber.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular
        Me.GetMobileNumber.UseCustomBackColor = True
        Me.GetMobileNumber.UseCustomForeColor = True
        Me.GetMobileNumber.UseSelectable = True
        '
        'GetPhoneNumber
        '
        Me.GetPhoneNumber.ActiveControl = Nothing
        Me.GetPhoneNumber.BackColor = System.Drawing.Color.AliceBlue
        Me.GetPhoneNumber.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GetPhoneNumber.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.GetPhoneNumber.Location = New System.Drawing.Point(522, 34)
        Me.GetPhoneNumber.Name = "GetPhoneNumber"
        Me.GetPhoneNumber.Size = New System.Drawing.Size(83, 26)
        Me.GetPhoneNumber.TabIndex = 5
        Me.GetPhoneNumber.Text = "Get Phone"
        Me.GetPhoneNumber.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.GetPhoneNumber.TileTextFontSize = MetroFramework.MetroTileTextSize.Small
        Me.GetPhoneNumber.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular
        Me.GetPhoneNumber.UseCustomBackColor = True
        Me.GetPhoneNumber.UseCustomForeColor = True
        Me.GetPhoneNumber.UseSelectable = True
        '
        'Reboot
        '
        Me.Reboot.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Reboot.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Reboot.Location = New System.Drawing.Point(889, 3)
        Me.Reboot.Name = "Reboot"
        Me.Reboot.Size = New System.Drawing.Size(183, 24)
        Me.Reboot.TabIndex = 65
        Me.Reboot.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GetEmailAddress
        '
        Me.GetEmailAddress.ActiveControl = Nothing
        Me.GetEmailAddress.BackColor = System.Drawing.Color.AliceBlue
        Me.GetEmailAddress.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GetEmailAddress.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.GetEmailAddress.Location = New System.Drawing.Point(522, 3)
        Me.GetEmailAddress.Name = "GetEmailAddress"
        Me.GetEmailAddress.Size = New System.Drawing.Size(83, 25)
        Me.GetEmailAddress.TabIndex = 4
        Me.GetEmailAddress.Text = "Get Email"
        Me.GetEmailAddress.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.GetEmailAddress.TileTextFontSize = MetroFramework.MetroTileTextSize.Small
        Me.GetEmailAddress.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular
        Me.GetEmailAddress.UseCustomBackColor = True
        Me.GetEmailAddress.UseCustomForeColor = True
        Me.GetEmailAddress.UseSelectable = True
        '
        'PhoneNumber1
        '
        Me.PhoneNumber1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PhoneNumber1.Location = New System.Drawing.Point(611, 31)
        Me.PhoneNumber1.Name = "PhoneNumber1"
        Me.PhoneNumber1.Size = New System.Drawing.Size(272, 32)
        Me.PhoneNumber1.TabIndex = 112
        Me.PhoneNumber1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'EmailAddress
        '
        Me.EmailAddress.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.EmailAddress.Location = New System.Drawing.Point(611, 0)
        Me.EmailAddress.Name = "EmailAddress"
        Me.EmailAddress.Size = New System.Drawing.Size(272, 31)
        Me.EmailAddress.TabIndex = 111
        Me.EmailAddress.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Host
        '
        Me.Host.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Host.ContextMenuStrip = Me.ContextMenuCopyHOST2Clipboard
        Me.Host.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Host.Location = New System.Drawing.Point(105, 3)
        Me.Host.Name = "Host"
        Me.Host.Size = New System.Drawing.Size(411, 24)
        Me.Host.TabIndex = 78
        Me.Host.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.MetroToolTip1.SetToolTip(Me.Host, "Right Click")
        '
        'ContextMenuCopyHOST2Clipboard
        '
        Me.ContextMenuCopyHOST2Clipboard.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem1})
        Me.ContextMenuCopyHOST2Clipboard.Name = "ContextMenuCopyPCNameConnected"
        Me.ContextMenuCopyHOST2Clipboard.Size = New System.Drawing.Size(230, 26)
        Me.MetroToolTip1.SetToolTip(Me.ContextMenuCopyHOST2Clipboard, "Right Click")
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Image = Global.RDT.My.Resources.Resources.Oxygen_Icons_org_Oxygen_Devices_printer_laser
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(229, 22)
        Me.ToolStripMenuItem1.Text = "Copy Hostname to Clipboard"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label24.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(3, 0)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(96, 31)
        Me.Label24.TabIndex = 75
        Me.Label24.Text = "Connected to >"
        Me.Label24.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'PhoneNumber2
        '
        Me.PhoneNumber2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PhoneNumber2.Location = New System.Drawing.Point(889, 31)
        Me.PhoneNumber2.Name = "PhoneNumber2"
        Me.PhoneNumber2.Size = New System.Drawing.Size(183, 32)
        Me.PhoneNumber2.TabIndex = 113
        Me.PhoneNumber2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'MobileNumber
        '
        Me.MobileNumber.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.MobileNumber.Location = New System.Drawing.Point(611, 63)
        Me.MobileNumber.Name = "MobileNumber"
        Me.MobileNumber.Size = New System.Drawing.Size(272, 33)
        Me.MobileNumber.TabIndex = 114
        Me.MobileNumber.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label25.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Label25.ForeColor = System.Drawing.Color.Black
        Me.Label25.Image = CType(resources.GetObject("Label25.Image"), System.Drawing.Image)
        Me.Label25.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Label25.Location = New System.Drawing.Point(3, 31)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(96, 32)
        Me.Label25.TabIndex = 76
        Me.Label25.Text = "User (s) >"
        Me.Label25.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'uptime1
        '
        Me.uptime1.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.uptime1.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.uptime1.Location = New System.Drawing.Point(611, 104)
        Me.uptime1.Name = "uptime1"
        Me.uptime1.Size = New System.Drawing.Size(272, 19)
        Me.uptime1.TabIndex = 74
        Me.uptime1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'GetUptime
        '
        Me.GetUptime.ActiveControl = Nothing
        Me.GetUptime.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GetUptime.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.GetUptime.BackColor = System.Drawing.Color.AliceBlue
        Me.GetUptime.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.GetUptime.Location = New System.Drawing.Point(522, 99)
        Me.GetUptime.Name = "GetUptime"
        Me.GetUptime.Size = New System.Drawing.Size(83, 29)
        Me.GetUptime.TabIndex = 26
        Me.GetUptime.Text = "Start Time ?"
        Me.GetUptime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.GetUptime.TileImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.GetUptime.TileTextFontSize = MetroFramework.MetroTileTextSize.Small
        Me.GetUptime.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular
        Me.GetUptime.UseCustomBackColor = True
        Me.GetUptime.UseCustomForeColor = True
        Me.GetUptime.UseSelectable = True
        '
        'ShaddowUserSession
        '
        Me.ShaddowUserSession.ActiveControl = Nothing
        Me.ShaddowUserSession.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ShaddowUserSession.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.ShaddowUserSession.BackColor = System.Drawing.Color.AliceBlue
        Me.ShaddowUserSession.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.ShaddowUserSession.Location = New System.Drawing.Point(105, 66)
        Me.ShaddowUserSession.Name = "ShaddowUserSession"
        Me.ShaddowUserSession.Size = New System.Drawing.Size(411, 27)
        Me.ShaddowUserSession.TabIndex = 122
        Me.ShaddowUserSession.Text = "   Shadow Desktop (Select a user with a session number) (Asks Perm User)"
        Me.ShaddowUserSession.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ShaddowUserSession.TileImage = CType(resources.GetObject("ShaddowUserSession.TileImage"), System.Drawing.Image)
        Me.ShaddowUserSession.TileImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.ShaddowUserSession.TileTextFontSize = MetroFramework.MetroTileTextSize.Small
        Me.ShaddowUserSession.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular
        Me.ShaddowUserSession.UseCustomBackColor = True
        Me.ShaddowUserSession.UseCustomForeColor = True
        Me.ShaddowUserSession.UseSelectable = True
        Me.ShaddowUserSession.UseTileImage = True
        '
        'TableLayoutPanel5
        '
        Me.TableLayoutPanel5.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.TableLayoutPanel5.BackColor = System.Drawing.Color.Transparent
        Me.TableLayoutPanel5.ColumnCount = 9
        Me.TableLayoutPanel5.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.913794!))
        Me.TableLayoutPanel5.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.64655!))
        Me.TableLayoutPanel5.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.8667!))
        Me.TableLayoutPanel5.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel5.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.8667!))
        Me.TableLayoutPanel5.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel5.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.8667!))
        Me.TableLayoutPanel5.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.8667!))
        Me.TableLayoutPanel5.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.8667!))
        Me.TableLayoutPanel5.Controls.Add(Me.StatusOfConnection, 6, 0)
        Me.TableLayoutPanel5.Controls.Add(Me.Button1, 8, 0)
        Me.TableLayoutPanel5.Controls.Add(Me.MetroTile1, 0, 0)
        Me.TableLayoutPanel5.Controls.Add(Me.ProgressBar2, 5, 0)
        Me.TableLayoutPanel5.Controls.Add(Me.AliveButton, 3, 0)
        Me.TableLayoutPanel5.Controls.Add(Me.Alive, 4, 0)
        Me.TableLayoutPanel5.Controls.Add(Me.ForceReboot, 7, 0)
        Me.TableLayoutPanel5.Controls.Add(Me.PCNAME, 1, 0)
        Me.TableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Top
        Me.TableLayoutPanel5.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel5.Margin = New System.Windows.Forms.Padding(2)
        Me.TableLayoutPanel5.Name = "TableLayoutPanel5"
        Me.TableLayoutPanel5.RowCount = 1
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel5.Size = New System.Drawing.Size(1075, 30)
        Me.TableLayoutPanel5.TabIndex = 118
        '
        'StatusOfConnection
        '
        Me.StatusOfConnection.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.StatusOfConnection.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.StatusOfConnection.Location = New System.Drawing.Point(674, 3)
        Me.StatusOfConnection.Name = "StatusOfConnection"
        Me.StatusOfConnection.Size = New System.Drawing.Size(127, 24)
        Me.StatusOfConnection.TabIndex = 122
        Me.StatusOfConnection.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Button1
        '
        Me.Button1.ActiveControl = Nothing
        Me.Button1.BackColor = System.Drawing.Color.AliceBlue
        Me.Button1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button1.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.Button1.Location = New System.Drawing.Point(940, 3)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(132, 24)
        Me.Button1.TabIndex = 3
        Me.Button1.Text = "Login Credentials"
        Me.Button1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Button1.TileImage = CType(resources.GetObject("Button1.TileImage"), System.Drawing.Image)
        Me.Button1.TileImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button1.TileTextFontSize = MetroFramework.MetroTileTextSize.Small
        Me.Button1.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular
        Me.Button1.UseCustomBackColor = True
        Me.Button1.UseCustomForeColor = True
        Me.Button1.UseSelectable = True
        Me.Button1.UseTileImage = True
        '
        'MetroTile1
        '
        Me.MetroTile1.ActiveControl = Nothing
        Me.MetroTile1.BackColor = System.Drawing.Color.Transparent
        Me.MetroTile1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.MetroTile1.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.MetroTile1.Location = New System.Drawing.Point(3, 3)
        Me.MetroTile1.Name = "MetroTile1"
        Me.MetroTile1.Size = New System.Drawing.Size(97, 24)
        Me.MetroTile1.TabIndex = 121
        Me.MetroTile1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.MetroTile1.TileImage = CType(resources.GetObject("MetroTile1.TileImage"), System.Drawing.Image)
        Me.MetroTile1.TileImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MetroTile1.TileTextFontSize = MetroFramework.MetroTileTextSize.Small
        Me.MetroTile1.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Bold
        Me.MetroTile1.UseCustomBackColor = True
        Me.MetroTile1.UseCustomForeColor = True
        Me.MetroTile1.UseSelectable = True
        Me.MetroTile1.UseTileImage = True
        '
        'ProgressBar2
        '
        Me.ProgressBar2.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ProgressBar2.BackColor = System.Drawing.Color.White
        Me.ProgressBar2.ForeColor = System.Drawing.Color.Green
        Me.ProgressBar2.Location = New System.Drawing.Point(657, 5)
        Me.ProgressBar2.Name = "ProgressBar2"
        Me.ProgressBar2.Size = New System.Drawing.Size(11, 20)
        Me.ProgressBar2.Style = System.Windows.Forms.ProgressBarStyle.Continuous
        Me.ProgressBar2.TabIndex = 82
        '
        'AliveButton
        '
        Me.AliveButton.AccessibleRole = System.Windows.Forms.AccessibleRole.None
        Me.AliveButton.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.AliveButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.AliveButton.ForeColor = System.Drawing.SystemColors.Window
        Me.AliveButton.Location = New System.Drawing.Point(505, 3)
        Me.AliveButton.Name = "AliveButton"
        Me.AliveButton.Size = New System.Drawing.Size(13, 24)
        Me.AliveButton.TabIndex = 83
        Me.AliveButton.UseVisualStyleBackColor = True
        '
        'Alive
        '
        Me.Alive.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Alive.ContextMenuStrip = Me.ContextMenuCopyIPAddress2Clipboard
        Me.Alive.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Alive.Location = New System.Drawing.Point(524, 5)
        Me.Alive.Name = "Alive"
        Me.Alive.Size = New System.Drawing.Size(127, 20)
        Me.Alive.TabIndex = 80
        Me.Alive.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MetroToolTip1.SetToolTip(Me.Alive, "Right Click")
        '
        'ContextMenuCopyIPAddress2Clipboard
        '
        Me.ContextMenuCopyIPAddress2Clipboard.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem2})
        Me.ContextMenuCopyIPAddress2Clipboard.Name = "ContextMenuCopyPCNameConnected"
        Me.ContextMenuCopyIPAddress2Clipboard.Size = New System.Drawing.Size(236, 26)
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.Image = Global.RDT.My.Resources.Resources.Oxygen_Icons_org_Oxygen_Devices_printer_laser
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(235, 22)
        Me.ToolStripMenuItem2.Text = "Copy I.P. Address to Clipboard"
        '
        'ForceReboot
        '
        Me.ForceReboot.ActiveControl = Nothing
        Me.ForceReboot.BackColor = System.Drawing.Color.AliceBlue
        Me.ForceReboot.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ForceReboot.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.ForceReboot.Location = New System.Drawing.Point(807, 3)
        Me.ForceReboot.Name = "ForceReboot"
        Me.ForceReboot.Size = New System.Drawing.Size(127, 24)
        Me.ForceReboot.TabIndex = 2
        Me.ForceReboot.Text = "Restart PC ?"
        Me.ForceReboot.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ForceReboot.TileImage = CType(resources.GetObject("ForceReboot.TileImage"), System.Drawing.Image)
        Me.ForceReboot.TileImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.ForceReboot.TileTextFontSize = MetroFramework.MetroTileTextSize.Small
        Me.ForceReboot.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular
        Me.ForceReboot.UseCustomBackColor = True
        Me.ForceReboot.UseCustomForeColor = True
        Me.ForceReboot.UseSelectable = True
        Me.ForceReboot.UseTileImage = True
        '
        'PCNAME
        '
        Me.PCNAME.AutoSize = True
        Me.PCNAME.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PCNAME.ForeColor = System.Drawing.Color.LimeGreen
        Me.PCNAME.Location = New System.Drawing.Point(106, 0)
        Me.PCNAME.Name = "PCNAME"
        Me.PCNAME.Size = New System.Drawing.Size(260, 30)
        Me.PCNAME.TabIndex = 123
        Me.PCNAME.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.TableLayoutPanel2.ColumnCount = 4
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel2.Controls.Add(Me.FileVersionFinder, 2, 3)
        Me.TableLayoutPanel2.Controls.Add(Me.Eventlog, 3, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.StartupItemsList, 1, 3)
        Me.TableLayoutPanel2.Controls.Add(Me.TaskSched, 1, 2)
        Me.TableLayoutPanel2.Controls.Add(Me.PowershellCMD, 0, 3)
        Me.TableLayoutPanel2.Controls.Add(Me.RDP, 3, 2)
        Me.TableLayoutPanel2.Controls.Add(Me.RDTReadWriteRegistry, 2, 2)
        Me.TableLayoutPanel2.Controls.Add(Me.NSlookup, 0, 2)
        Me.TableLayoutPanel2.Controls.Add(Me.NLTEST, 3, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.btnOpenReg, 2, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.CompMgmt, 1, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.DetectAPPV, 0, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.DefragC, 2, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.CheckAntivirus, 1, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.BrowseAppslogs, 0, 0)
        Me.TableLayoutPanel2.GrowStyle = System.Windows.Forms.TableLayoutPanelGrowStyle.FixedSize
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(105, 283)
        Me.TableLayoutPanel2.Margin = New System.Windows.Forms.Padding(1)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 4
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(873, 314)
        Me.TableLayoutPanel2.TabIndex = 117
        '
        'FileVersionFinder
        '
        Me.FileVersionFinder.ActiveControl = Nothing
        Me.FileVersionFinder.BackColor = System.Drawing.Color.AliceBlue
        Me.FileVersionFinder.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FileVersionFinder.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.FileVersionFinder.Location = New System.Drawing.Point(439, 237)
        Me.FileVersionFinder.Name = "FileVersionFinder"
        Me.FileVersionFinder.Size = New System.Drawing.Size(212, 74)
        Me.FileVersionFinder.TabIndex = 29
        Me.FileVersionFinder.Text = "File Version finder"
        Me.FileVersionFinder.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.FileVersionFinder.TileImage = CType(resources.GetObject("FileVersionFinder.TileImage"), System.Drawing.Image)
        Me.FileVersionFinder.TileTextFontSize = MetroFramework.MetroTileTextSize.Small
        Me.FileVersionFinder.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular
        Me.FileVersionFinder.UseCustomBackColor = True
        Me.FileVersionFinder.UseCustomForeColor = True
        Me.FileVersionFinder.UseSelectable = True
        Me.FileVersionFinder.UseTileImage = True
        '
        'Eventlog
        '
        Me.Eventlog.ActiveControl = Nothing
        Me.Eventlog.BackColor = System.Drawing.Color.AliceBlue
        Me.Eventlog.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Eventlog.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.Eventlog.Location = New System.Drawing.Point(657, 3)
        Me.Eventlog.Name = "Eventlog"
        Me.Eventlog.Size = New System.Drawing.Size(213, 72)
        Me.Eventlog.TabIndex = 28
        Me.Eventlog.Text = "Microsoft Eventlog"
        Me.Eventlog.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Eventlog.TileImage = CType(resources.GetObject("Eventlog.TileImage"), System.Drawing.Image)
        Me.Eventlog.TileTextFontSize = MetroFramework.MetroTileTextSize.Small
        Me.Eventlog.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular
        Me.Eventlog.UseCustomBackColor = True
        Me.Eventlog.UseCustomForeColor = True
        Me.Eventlog.UseSelectable = True
        Me.Eventlog.UseTileImage = True
        '
        'StartupItemsList
        '
        Me.StartupItemsList.ActiveControl = Nothing
        Me.StartupItemsList.BackColor = System.Drawing.Color.AliceBlue
        Me.StartupItemsList.Dock = System.Windows.Forms.DockStyle.Fill
        Me.StartupItemsList.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.StartupItemsList.Location = New System.Drawing.Point(221, 237)
        Me.StartupItemsList.Name = "StartupItemsList"
        Me.StartupItemsList.Size = New System.Drawing.Size(212, 74)
        Me.StartupItemsList.TabIndex = 27
        Me.StartupItemsList.Text = "Start-up Items"
        Me.StartupItemsList.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.StartupItemsList.TileImage = CType(resources.GetObject("StartupItemsList.TileImage"), System.Drawing.Image)
        Me.StartupItemsList.TileTextFontSize = MetroFramework.MetroTileTextSize.Small
        Me.StartupItemsList.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular
        Me.StartupItemsList.UseCustomBackColor = True
        Me.StartupItemsList.UseCustomForeColor = True
        Me.StartupItemsList.UseSelectable = True
        Me.StartupItemsList.UseTileImage = True
        '
        'TaskSched
        '
        Me.TaskSched.ActiveControl = Nothing
        Me.TaskSched.BackColor = System.Drawing.Color.AliceBlue
        Me.TaskSched.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TaskSched.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.TaskSched.Location = New System.Drawing.Point(221, 159)
        Me.TaskSched.Name = "TaskSched"
        Me.TaskSched.Size = New System.Drawing.Size(212, 72)
        Me.TaskSched.TabIndex = 26
        Me.TaskSched.Text = "Microsoft Task Scheduler"
        Me.TaskSched.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.TaskSched.TileImage = CType(resources.GetObject("TaskSched.TileImage"), System.Drawing.Image)
        Me.TaskSched.TileTextFontSize = MetroFramework.MetroTileTextSize.Small
        Me.TaskSched.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular
        Me.TaskSched.UseCustomBackColor = True
        Me.TaskSched.UseCustomForeColor = True
        Me.TaskSched.UseSelectable = True
        Me.TaskSched.UseTileImage = True
        '
        'PowershellCMD
        '
        Me.PowershellCMD.ActiveControl = Nothing
        Me.PowershellCMD.BackColor = System.Drawing.Color.AliceBlue
        Me.PowershellCMD.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PowershellCMD.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.PowershellCMD.Location = New System.Drawing.Point(3, 237)
        Me.PowershellCMD.Name = "PowershellCMD"
        Me.PowershellCMD.Size = New System.Drawing.Size(212, 74)
        Me.PowershellCMD.TabIndex = 25
        Me.PowershellCMD.Text = "Remote Powershell > As You"
        Me.PowershellCMD.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.PowershellCMD.TileImage = CType(resources.GetObject("PowershellCMD.TileImage"), System.Drawing.Image)
        Me.PowershellCMD.TileTextFontSize = MetroFramework.MetroTileTextSize.Small
        Me.PowershellCMD.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular
        Me.PowershellCMD.UseCustomBackColor = True
        Me.PowershellCMD.UseCustomForeColor = True
        Me.PowershellCMD.UseSelectable = True
        Me.PowershellCMD.UseTileImage = True
        '
        'RDP
        '
        Me.RDP.ActiveControl = Nothing
        Me.RDP.BackColor = System.Drawing.Color.AliceBlue
        Me.RDP.Dock = System.Windows.Forms.DockStyle.Fill
        Me.RDP.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.RDP.Location = New System.Drawing.Point(657, 159)
        Me.RDP.Name = "RDP"
        Me.RDP.Size = New System.Drawing.Size(213, 72)
        Me.RDP.TabIndex = 20
        Me.RDP.Text = "Microsoft RDP (As - Admin)"
        Me.RDP.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.RDP.TileImage = CType(resources.GetObject("RDP.TileImage"), System.Drawing.Image)
        Me.RDP.TileTextFontSize = MetroFramework.MetroTileTextSize.Small
        Me.RDP.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular
        Me.RDP.UseCustomBackColor = True
        Me.RDP.UseCustomForeColor = True
        Me.RDP.UseSelectable = True
        Me.RDP.UseTileImage = True
        '
        'RDTReadWriteRegistry
        '
        Me.RDTReadWriteRegistry.ActiveControl = Nothing
        Me.RDTReadWriteRegistry.BackColor = System.Drawing.Color.AliceBlue
        Me.RDTReadWriteRegistry.Dock = System.Windows.Forms.DockStyle.Fill
        Me.RDTReadWriteRegistry.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.RDTReadWriteRegistry.Location = New System.Drawing.Point(439, 159)
        Me.RDTReadWriteRegistry.Name = "RDTReadWriteRegistry"
        Me.RDTReadWriteRegistry.Size = New System.Drawing.Size(212, 72)
        Me.RDTReadWriteRegistry.TabIndex = 19
        Me.RDTReadWriteRegistry.Text = "RDT Registry Editor"
        Me.RDTReadWriteRegistry.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.RDTReadWriteRegistry.TileImage = CType(resources.GetObject("RDTReadWriteRegistry.TileImage"), System.Drawing.Image)
        Me.RDTReadWriteRegistry.TileTextFontSize = MetroFramework.MetroTileTextSize.Small
        Me.RDTReadWriteRegistry.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular
        Me.RDTReadWriteRegistry.UseCustomBackColor = True
        Me.RDTReadWriteRegistry.UseCustomForeColor = True
        Me.RDTReadWriteRegistry.UseSelectable = True
        Me.RDTReadWriteRegistry.UseTileImage = True
        '
        'NSlookup
        '
        Me.NSlookup.ActiveControl = Nothing
        Me.NSlookup.BackColor = System.Drawing.Color.AliceBlue
        Me.NSlookup.Dock = System.Windows.Forms.DockStyle.Fill
        Me.NSlookup.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.NSlookup.Location = New System.Drawing.Point(3, 159)
        Me.NSlookup.Name = "NSlookup"
        Me.NSlookup.Size = New System.Drawing.Size(212, 72)
        Me.NSlookup.TabIndex = 17
        Me.NSlookup.Text = "NS lookup (Resolve IP)"
        Me.NSlookup.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.NSlookup.TileImage = CType(resources.GetObject("NSlookup.TileImage"), System.Drawing.Image)
        Me.NSlookup.TileTextFontSize = MetroFramework.MetroTileTextSize.Small
        Me.NSlookup.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular
        Me.NSlookup.UseCustomBackColor = True
        Me.NSlookup.UseCustomForeColor = True
        Me.NSlookup.UseSelectable = True
        Me.NSlookup.UseTileImage = True
        '
        'NLTEST
        '
        Me.NLTEST.ActiveControl = Nothing
        Me.NLTEST.BackColor = System.Drawing.Color.AliceBlue
        Me.NLTEST.Dock = System.Windows.Forms.DockStyle.Fill
        Me.NLTEST.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.NLTEST.Location = New System.Drawing.Point(657, 81)
        Me.NLTEST.Name = "NLTEST"
        Me.NLTEST.Size = New System.Drawing.Size(213, 72)
        Me.NLTEST.TabIndex = 16
        Me.NLTEST.Text = "What Logon Server (User)"
        Me.NLTEST.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.NLTEST.TileImage = CType(resources.GetObject("NLTEST.TileImage"), System.Drawing.Image)
        Me.NLTEST.TileTextFontSize = MetroFramework.MetroTileTextSize.Small
        Me.NLTEST.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular
        Me.NLTEST.UseCustomBackColor = True
        Me.NLTEST.UseCustomForeColor = True
        Me.NLTEST.UseSelectable = True
        Me.NLTEST.UseTileImage = True
        '
        'btnOpenReg
        '
        Me.btnOpenReg.ActiveControl = Nothing
        Me.btnOpenReg.BackColor = System.Drawing.Color.AliceBlue
        Me.btnOpenReg.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnOpenReg.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.btnOpenReg.Location = New System.Drawing.Point(439, 81)
        Me.btnOpenReg.Name = "btnOpenReg"
        Me.btnOpenReg.Size = New System.Drawing.Size(212, 72)
        Me.btnOpenReg.TabIndex = 15
        Me.btnOpenReg.Text = "Microsoft Registry Editor"
        Me.btnOpenReg.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnOpenReg.TileImage = CType(resources.GetObject("btnOpenReg.TileImage"), System.Drawing.Image)
        Me.btnOpenReg.TileTextFontSize = MetroFramework.MetroTileTextSize.Small
        Me.btnOpenReg.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular
        Me.btnOpenReg.UseCustomBackColor = True
        Me.btnOpenReg.UseCustomForeColor = True
        Me.btnOpenReg.UseSelectable = True
        Me.btnOpenReg.UseTileImage = True
        '
        'CompMgmt
        '
        Me.CompMgmt.ActiveControl = Nothing
        Me.CompMgmt.BackColor = System.Drawing.Color.AliceBlue
        Me.CompMgmt.Dock = System.Windows.Forms.DockStyle.Fill
        Me.CompMgmt.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.CompMgmt.Location = New System.Drawing.Point(221, 81)
        Me.CompMgmt.Name = "CompMgmt"
        Me.CompMgmt.Size = New System.Drawing.Size(212, 72)
        Me.CompMgmt.TabIndex = 14
        Me.CompMgmt.Text = "Microsoft Manage Computer"
        Me.CompMgmt.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.CompMgmt.TileImage = CType(resources.GetObject("CompMgmt.TileImage"), System.Drawing.Image)
        Me.CompMgmt.TileTextFontSize = MetroFramework.MetroTileTextSize.Small
        Me.CompMgmt.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular
        Me.CompMgmt.UseCustomBackColor = True
        Me.CompMgmt.UseCustomForeColor = True
        Me.CompMgmt.UseSelectable = True
        Me.CompMgmt.UseTileImage = True
        '
        'DetectAPPV
        '
        Me.DetectAPPV.ActiveControl = Nothing
        Me.DetectAPPV.BackColor = System.Drawing.Color.AliceBlue
        Me.DetectAPPV.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DetectAPPV.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.DetectAPPV.Location = New System.Drawing.Point(3, 81)
        Me.DetectAPPV.Name = "DetectAPPV"
        Me.DetectAPPV.Size = New System.Drawing.Size(212, 72)
        Me.DetectAPPV.TabIndex = 13
        Me.DetectAPPV.Text = "Gather APPV Details"
        Me.DetectAPPV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.DetectAPPV.TileImage = CType(resources.GetObject("DetectAPPV.TileImage"), System.Drawing.Image)
        Me.DetectAPPV.TileTextFontSize = MetroFramework.MetroTileTextSize.Small
        Me.DetectAPPV.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular
        Me.DetectAPPV.UseCustomBackColor = True
        Me.DetectAPPV.UseCustomForeColor = True
        Me.DetectAPPV.UseSelectable = True
        Me.DetectAPPV.UseTileImage = True
        '
        'DefragC
        '
        Me.DefragC.ActiveControl = Nothing
        Me.DefragC.BackColor = System.Drawing.Color.AliceBlue
        Me.DefragC.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DefragC.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.DefragC.Location = New System.Drawing.Point(439, 3)
        Me.DefragC.Name = "DefragC"
        Me.DefragC.Size = New System.Drawing.Size(212, 72)
        Me.DefragC.TabIndex = 11
        Me.DefragC.Text = "Remote Defrag C: Drive"
        Me.DefragC.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.DefragC.TileImage = CType(resources.GetObject("DefragC.TileImage"), System.Drawing.Image)
        Me.DefragC.TileTextFontSize = MetroFramework.MetroTileTextSize.Small
        Me.DefragC.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular
        Me.DefragC.UseCustomBackColor = True
        Me.DefragC.UseCustomForeColor = True
        Me.DefragC.UseSelectable = True
        Me.DefragC.UseTileImage = True
        '
        'CheckAntivirus
        '
        Me.CheckAntivirus.ActiveControl = Nothing
        Me.CheckAntivirus.BackColor = System.Drawing.Color.AliceBlue
        Me.CheckAntivirus.Dock = System.Windows.Forms.DockStyle.Fill
        Me.CheckAntivirus.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.CheckAntivirus.Location = New System.Drawing.Point(221, 3)
        Me.CheckAntivirus.Name = "CheckAntivirus"
        Me.CheckAntivirus.Size = New System.Drawing.Size(212, 72)
        Me.CheckAntivirus.TabIndex = 10
        Me.CheckAntivirus.Text = "Check Anti-virus Software"
        Me.CheckAntivirus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.CheckAntivirus.TileImage = CType(resources.GetObject("CheckAntivirus.TileImage"), System.Drawing.Image)
        Me.CheckAntivirus.TileTextFontSize = MetroFramework.MetroTileTextSize.Small
        Me.CheckAntivirus.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular
        Me.CheckAntivirus.UseCustomBackColor = True
        Me.CheckAntivirus.UseCustomForeColor = True
        Me.CheckAntivirus.UseSelectable = True
        Me.CheckAntivirus.UseTileImage = True
        '
        'BrowseAppslogs
        '
        Me.BrowseAppslogs.ActiveControl = Nothing
        Me.BrowseAppslogs.BackColor = System.Drawing.Color.AliceBlue
        Me.BrowseAppslogs.Dock = System.Windows.Forms.DockStyle.Fill
        Me.BrowseAppslogs.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.BrowseAppslogs.Location = New System.Drawing.Point(3, 3)
        Me.BrowseAppslogs.Name = "BrowseAppslogs"
        Me.BrowseAppslogs.Size = New System.Drawing.Size(212, 72)
        Me.BrowseAppslogs.TabIndex = 9
        Me.BrowseAppslogs.Text = "\\ RemotePC \ C$"
        Me.BrowseAppslogs.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.BrowseAppslogs.TileImage = CType(resources.GetObject("BrowseAppslogs.TileImage"), System.Drawing.Image)
        Me.BrowseAppslogs.TileTextFontSize = MetroFramework.MetroTileTextSize.Small
        Me.BrowseAppslogs.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular
        Me.BrowseAppslogs.UseCustomBackColor = True
        Me.BrowseAppslogs.UseCustomForeColor = True
        Me.BrowseAppslogs.UseSelectable = True
        Me.BrowseAppslogs.UseTileImage = True
        '
        'ADtab2
        '
        Me.ADtab2.Controls.Add(Me.ListADGroups)
        Me.ADtab2.Controls.Add(Me.ListUsersInGroupBox)
        Me.ADtab2.Controls.Add(Me.ListUsersInGroupButton)
        Me.ADtab2.Controls.Add(Me.ListADUsers_Computers)
        Me.ADtab2.Controls.Add(Me.MetroPanel1)
        Me.ADtab2.HorizontalScrollbarBarColor = True
        Me.ADtab2.HorizontalScrollbarHighlightOnWheel = False
        Me.ADtab2.HorizontalScrollbarSize = 10
        Me.ADtab2.Location = New System.Drawing.Point(4, 34)
        Me.ADtab2.Name = "ADtab2"
        Me.ADtab2.Size = New System.Drawing.Size(1075, 678)
        Me.ADtab2.TabIndex = 20
        Me.ADtab2.Text = "AD"
        Me.ADtab2.VerticalScrollbarBarColor = True
        Me.ADtab2.VerticalScrollbarHighlightOnWheel = False
        Me.ADtab2.VerticalScrollbarSize = 10
        '
        'ListADGroups
        '
        Me.ListADGroups.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ListADGroups.BackColor = System.Drawing.Color.AliceBlue
        Me.ListADGroups.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.ListADGroups.Location = New System.Drawing.Point(601, 82)
        Me.ListADGroups.Name = "ListADGroups"
        Me.ListADGroups.Size = New System.Drawing.Size(230, 28)
        Me.ListADGroups.TabIndex = 134
        Me.ListADGroups.Text = "List All Groups in local Active Directory"
        Me.ListADGroups.UseCustomBackColor = True
        Me.ListADGroups.UseCustomForeColor = True
        Me.ListADGroups.UseSelectable = True
        '
        'ListUsersInGroupBox
        '
        Me.ListUsersInGroupBox.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        '
        '
        '
        Me.ListUsersInGroupBox.CustomButton.Image = Nothing
        Me.ListUsersInGroupBox.CustomButton.Location = New System.Drawing.Point(449, 1)
        Me.ListUsersInGroupBox.CustomButton.Name = ""
        Me.ListUsersInGroupBox.CustomButton.Size = New System.Drawing.Size(21, 21)
        Me.ListUsersInGroupBox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue
        Me.ListUsersInGroupBox.CustomButton.TabIndex = 1
        Me.ListUsersInGroupBox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light
        Me.ListUsersInGroupBox.CustomButton.UseSelectable = True
        Me.ListUsersInGroupBox.CustomButton.Visible = False
        Me.ListUsersInGroupBox.Lines = New String(-1) {}
        Me.ListUsersInGroupBox.Location = New System.Drawing.Point(601, 180)
        Me.ListUsersInGroupBox.MaxLength = 32767
        Me.ListUsersInGroupBox.Name = "ListUsersInGroupBox"
        Me.ListUsersInGroupBox.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.ListUsersInGroupBox.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.ListUsersInGroupBox.SelectedText = ""
        Me.ListUsersInGroupBox.SelectionLength = 0
        Me.ListUsersInGroupBox.SelectionStart = 0
        Me.ListUsersInGroupBox.Size = New System.Drawing.Size(471, 23)
        Me.ListUsersInGroupBox.TabIndex = 133
        Me.ListUsersInGroupBox.UseSelectable = True
        Me.ListUsersInGroupBox.WaterMarkColor = System.Drawing.Color.FromArgb(CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.ListUsersInGroupBox.WaterMarkFont = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel)
        '
        'ListUsersInGroupButton
        '
        Me.ListUsersInGroupButton.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ListUsersInGroupButton.BackColor = System.Drawing.Color.AliceBlue
        Me.ListUsersInGroupButton.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.ListUsersInGroupButton.Location = New System.Drawing.Point(601, 146)
        Me.ListUsersInGroupButton.Name = "ListUsersInGroupButton"
        Me.ListUsersInGroupButton.Size = New System.Drawing.Size(155, 28)
        Me.ListUsersInGroupButton.TabIndex = 132
        Me.ListUsersInGroupButton.Text = "List Users in Selected Group"
        Me.ListUsersInGroupButton.UseCustomBackColor = True
        Me.ListUsersInGroupButton.UseCustomForeColor = True
        Me.ListUsersInGroupButton.UseSelectable = True
        '
        'ListADUsers_Computers
        '
        Me.ListADUsers_Computers.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ListADUsers_Computers.BackColor = System.Drawing.Color.AliceBlue
        Me.ListADUsers_Computers.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.ListADUsers_Computers.Location = New System.Drawing.Point(601, 14)
        Me.ListADUsers_Computers.Name = "ListADUsers_Computers"
        Me.ListADUsers_Computers.Size = New System.Drawing.Size(282, 28)
        Me.ListADUsers_Computers.TabIndex = 131
        Me.ListADUsers_Computers.Text = "List All Users && Computers in local Active Directory"
        Me.ListADUsers_Computers.UseCustomBackColor = True
        Me.ListADUsers_Computers.UseCustomForeColor = True
        Me.ListADUsers_Computers.UseSelectable = True
        '
        'MetroPanel1
        '
        Me.MetroPanel1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.MetroPanel1.Controls.Add(Me.ListViewAD)
        Me.MetroPanel1.HorizontalScrollbarBarColor = True
        Me.MetroPanel1.HorizontalScrollbarHighlightOnWheel = False
        Me.MetroPanel1.HorizontalScrollbarSize = 10
        Me.MetroPanel1.Location = New System.Drawing.Point(3, 14)
        Me.MetroPanel1.Name = "MetroPanel1"
        Me.MetroPanel1.Size = New System.Drawing.Size(592, 652)
        Me.MetroPanel1.TabIndex = 2
        Me.MetroPanel1.VerticalScrollbarBarColor = True
        Me.MetroPanel1.VerticalScrollbarHighlightOnWheel = False
        Me.MetroPanel1.VerticalScrollbarSize = 10
        '
        'ListViewAD
        '
        Me.ListViewAD.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ListViewAD.LabelWrap = False
        Me.ListViewAD.Location = New System.Drawing.Point(0, 0)
        Me.ListViewAD.MultiSelect = False
        Me.ListViewAD.Name = "ListViewAD"
        Me.ListViewAD.ShowGroups = False
        Me.ListViewAD.Size = New System.Drawing.Size(592, 652)
        Me.ListViewAD.Sorting = System.Windows.Forms.SortOrder.Ascending
        Me.ListViewAD.TabIndex = 4
        Me.ListViewAD.UseCompatibleStateImageBehavior = False
        Me.ListViewAD.View = System.Windows.Forms.View.List
        '
        'INFOTab3
        '
        Me.INFOTab3.Controls.Add(Me.GetHPBiosSettings)
        Me.INFOTab3.Controls.Add(Me.GatherAudioInfo)
        Me.INFOTab3.Controls.Add(Me.MetroTile2)
        Me.INFOTab3.Controls.Add(Me.MetroLabel10)
        Me.INFOTab3.Controls.Add(Me.ExportDataGridViewDetails)
        Me.INFOTab3.Controls.Add(Me.GatherNetworkInfo)
        Me.INFOTab3.Controls.Add(Me.GatherVideoInfo)
        Me.INFOTab3.Controls.Add(Me.GatherBIOSInfo)
        Me.INFOTab3.Controls.Add(Me.GETpcDETAILSnow)
        Me.INFOTab3.Controls.Add(Me.Label11)
        Me.INFOTab3.Controls.Add(Me.PCnameFordetails)
        Me.INFOTab3.Controls.Add(Me.TableLayoutPanel6)
        Me.INFOTab3.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.INFOTab3.HorizontalScrollbarBarColor = True
        Me.INFOTab3.HorizontalScrollbarHighlightOnWheel = False
        Me.INFOTab3.HorizontalScrollbarSize = 10
        Me.INFOTab3.Location = New System.Drawing.Point(4, 34)
        Me.INFOTab3.Name = "INFOTab3"
        Me.INFOTab3.Size = New System.Drawing.Size(1075, 678)
        Me.INFOTab3.TabIndex = 1
        Me.INFOTab3.Text = "Info"
        Me.INFOTab3.VerticalScrollbarBarColor = True
        Me.INFOTab3.VerticalScrollbarHighlightOnWheel = False
        Me.INFOTab3.VerticalScrollbarSize = 10
        '
        'GetHPBiosSettings
        '
        Me.GetHPBiosSettings.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.GetHPBiosSettings.BackColor = System.Drawing.Color.AliceBlue
        Me.GetHPBiosSettings.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.GetHPBiosSettings.Location = New System.Drawing.Point(889, 14)
        Me.GetHPBiosSettings.Name = "GetHPBiosSettings"
        Me.GetHPBiosSettings.Size = New System.Drawing.Size(70, 28)
        Me.GetHPBiosSettings.TabIndex = 128
        Me.GetHPBiosSettings.Text = "HP Bios"
        Me.GetHPBiosSettings.UseCustomBackColor = True
        Me.GetHPBiosSettings.UseCustomForeColor = True
        Me.GetHPBiosSettings.UseSelectable = True
        '
        'GatherAudioInfo
        '
        Me.GatherAudioInfo.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.GatherAudioInfo.BackColor = System.Drawing.Color.AliceBlue
        Me.GatherAudioInfo.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.GatherAudioInfo.Location = New System.Drawing.Point(776, 14)
        Me.GatherAudioInfo.Name = "GatherAudioInfo"
        Me.GatherAudioInfo.Size = New System.Drawing.Size(108, 28)
        Me.GatherAudioInfo.TabIndex = 127
        Me.GatherAudioInfo.Text = "Display Audio Info"
        Me.GatherAudioInfo.UseCustomBackColor = True
        Me.GatherAudioInfo.UseCustomForeColor = True
        Me.GatherAudioInfo.UseSelectable = True
        '
        'MetroTile2
        '
        Me.MetroTile2.ActiveControl = Nothing
        Me.MetroTile2.BackColor = System.Drawing.Color.Transparent
        Me.MetroTile2.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.MetroTile2.Location = New System.Drawing.Point(3, 3)
        Me.MetroTile2.Name = "MetroTile2"
        Me.MetroTile2.Size = New System.Drawing.Size(38, 43)
        Me.MetroTile2.TabIndex = 122
        Me.MetroTile2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MetroTile2.TileImage = CType(resources.GetObject("MetroTile2.TileImage"), System.Drawing.Image)
        Me.MetroTile2.TileImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MetroTile2.TileTextFontSize = MetroFramework.MetroTileTextSize.Small
        Me.MetroTile2.UseCustomBackColor = True
        Me.MetroTile2.UseCustomForeColor = True
        Me.MetroTile2.UseSelectable = True
        Me.MetroTile2.UseTileImage = True
        '
        'MetroLabel10
        '
        Me.MetroLabel10.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.MetroLabel10.AutoSize = True
        Me.MetroLabel10.Location = New System.Drawing.Point(291, 659)
        Me.MetroLabel10.Name = "MetroLabel10"
        Me.MetroLabel10.Size = New System.Drawing.Size(374, 19)
        Me.MetroLabel10.TabIndex = 126
        Me.MetroLabel10.Text = "Information : Java version 10. x = 1.7  &&  Java version 11.x = 1.8 "
        '
        'ExportDataGridViewDetails
        '
        Me.ExportDataGridViewDetails.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ExportDataGridViewDetails.BackColor = System.Drawing.Color.AliceBlue
        Me.ExportDataGridViewDetails.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.ExportDataGridViewDetails.Location = New System.Drawing.Point(967, 14)
        Me.ExportDataGridViewDetails.Name = "ExportDataGridViewDetails"
        Me.ExportDataGridViewDetails.Size = New System.Drawing.Size(86, 28)
        Me.ExportDataGridViewDetails.TabIndex = 125
        Me.ExportDataGridViewDetails.Text = "Export to CSV"
        Me.ExportDataGridViewDetails.UseCustomBackColor = True
        Me.ExportDataGridViewDetails.UseCustomForeColor = True
        Me.ExportDataGridViewDetails.UseSelectable = True
        '
        'GatherNetworkInfo
        '
        Me.GatherNetworkInfo.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.GatherNetworkInfo.BackColor = System.Drawing.Color.AliceBlue
        Me.GatherNetworkInfo.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.GatherNetworkInfo.Location = New System.Drawing.Point(662, 14)
        Me.GatherNetworkInfo.Name = "GatherNetworkInfo"
        Me.GatherNetworkInfo.Size = New System.Drawing.Size(108, 28)
        Me.GatherNetworkInfo.TabIndex = 124
        Me.GatherNetworkInfo.Text = "Display NIC Info"
        Me.GatherNetworkInfo.UseCustomBackColor = True
        Me.GatherNetworkInfo.UseCustomForeColor = True
        Me.GatherNetworkInfo.UseSelectable = True
        '
        'GatherVideoInfo
        '
        Me.GatherVideoInfo.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.GatherVideoInfo.BackColor = System.Drawing.Color.AliceBlue
        Me.GatherVideoInfo.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.GatherVideoInfo.Location = New System.Drawing.Point(544, 14)
        Me.GatherVideoInfo.Name = "GatherVideoInfo"
        Me.GatherVideoInfo.Size = New System.Drawing.Size(112, 28)
        Me.GatherVideoInfo.TabIndex = 123
        Me.GatherVideoInfo.Text = "Display Video Info"
        Me.GatherVideoInfo.UseCustomBackColor = True
        Me.GatherVideoInfo.UseCustomForeColor = True
        Me.GatherVideoInfo.UseSelectable = True
        '
        'GatherBIOSInfo
        '
        Me.GatherBIOSInfo.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.GatherBIOSInfo.BackColor = System.Drawing.Color.AliceBlue
        Me.GatherBIOSInfo.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.GatherBIOSInfo.Location = New System.Drawing.Point(428, 14)
        Me.GatherBIOSInfo.Name = "GatherBIOSInfo"
        Me.GatherBIOSInfo.Size = New System.Drawing.Size(110, 28)
        Me.GatherBIOSInfo.TabIndex = 122
        Me.GatherBIOSInfo.Text = "Display BIOS Info"
        Me.GatherBIOSInfo.UseCustomBackColor = True
        Me.GatherBIOSInfo.UseCustomForeColor = True
        Me.GatherBIOSInfo.UseSelectable = True
        '
        'GETpcDETAILSnow
        '
        Me.GETpcDETAILSnow.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.GETpcDETAILSnow.BackColor = System.Drawing.Color.AliceBlue
        Me.GETpcDETAILSnow.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.GETpcDETAILSnow.Location = New System.Drawing.Point(308, 14)
        Me.GETpcDETAILSnow.Name = "GETpcDETAILSnow"
        Me.GETpcDETAILSnow.Size = New System.Drawing.Size(114, 28)
        Me.GETpcDETAILSnow.TabIndex = 121
        Me.GETpcDETAILSnow.Text = "Display Main Info"
        Me.GETpcDETAILSnow.UseCustomBackColor = True
        Me.GETpcDETAILSnow.UseCustomForeColor = True
        Me.GETpcDETAILSnow.UseSelectable = True
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(57, 20)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(0, 16)
        Me.Label11.TabIndex = 115
        '
        'PCnameFordetails
        '
        Me.PCnameFordetails.AutoSize = True
        Me.PCnameFordetails.BackColor = System.Drawing.Color.Transparent
        Me.PCnameFordetails.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PCnameFordetails.Location = New System.Drawing.Point(57, 3)
        Me.PCnameFordetails.Name = "PCnameFordetails"
        Me.PCnameFordetails.Size = New System.Drawing.Size(0, 16)
        Me.PCnameFordetails.TabIndex = 112
        '
        'TableLayoutPanel6
        '
        Me.TableLayoutPanel6.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel6.BackColor = System.Drawing.Color.Transparent
        Me.TableLayoutPanel6.ColumnCount = 1
        Me.TableLayoutPanel6.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel6.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel6.Controls.Add(Me.DataGridViewDetails, 0, 0)
        Me.TableLayoutPanel6.Location = New System.Drawing.Point(20, 49)
        Me.TableLayoutPanel6.Margin = New System.Windows.Forms.Padding(2)
        Me.TableLayoutPanel6.Name = "TableLayoutPanel6"
        Me.TableLayoutPanel6.RowCount = 1
        Me.TableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 608.0!))
        Me.TableLayoutPanel6.Size = New System.Drawing.Size(1033, 608)
        Me.TableLayoutPanel6.TabIndex = 110
        '
        'DataGridViewDetails
        '
        Me.DataGridViewDetails.AllowUserToAddRows = False
        Me.DataGridViewDetails.AllowUserToDeleteRows = False
        Me.DataGridViewDetails.AllowUserToResizeColumns = False
        Me.DataGridViewDetails.AllowUserToResizeRows = False
        Me.DataGridViewDetails.BackgroundColor = System.Drawing.SystemColors.Window
        Me.DataGridViewDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewDetails.ColumnHeadersVisible = False
        Me.DataGridViewDetails.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column8, Me.Column9})
        Me.DataGridViewDetails.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DataGridViewDetails.Location = New System.Drawing.Point(3, 3)
        Me.DataGridViewDetails.Name = "DataGridViewDetails"
        Me.DataGridViewDetails.RowHeadersVisible = False
        Me.DataGridViewDetails.Size = New System.Drawing.Size(1027, 602)
        Me.DataGridViewDetails.TabIndex = 0
        '
        'Column8
        '
        Me.Column8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.Column8.HeaderText = "Column8"
        Me.Column8.Name = "Column8"
        '
        'Column9
        '
        Me.Column9.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.Column9.HeaderText = "Column9"
        Me.Column9.Name = "Column9"
        '
        'DiskTab4
        '
        Me.DiskTab4.Controls.Add(Me.MetroTile3)
        Me.DiskTab4.Controls.Add(Me.Button14)
        Me.DiskTab4.Controls.Add(Me.Button13)
        Me.DiskTab4.Controls.Add(Me.ExportDISK_DETAILS)
        Me.DiskTab4.Controls.Add(Me.DISK_DETAILS)
        Me.DiskTab4.Controls.Add(Me.Label206)
        Me.DiskTab4.Controls.Add(Me.DataGridViewDisk2)
        Me.DiskTab4.Controls.Add(Me.Label65)
        Me.DiskTab4.Controls.Add(Me.Label2)
        Me.DiskTab4.Controls.Add(Me.Label69)
        Me.DiskTab4.Controls.Add(Me.Label67)
        Me.DiskTab4.Controls.Add(Me.TotalPhysicalMemoryDetails)
        Me.DiskTab4.Controls.Add(Me.PagefileDetails)
        Me.DiskTab4.Controls.Add(Me.DataGridViewDisk)
        Me.DiskTab4.Controls.Add(Me.Label62)
        Me.DiskTab4.Controls.Add(Me.Label63)
        Me.DiskTab4.Controls.Add(Me.Label68)
        Me.DiskTab4.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.DiskTab4.HorizontalScrollbarBarColor = True
        Me.DiskTab4.HorizontalScrollbarHighlightOnWheel = False
        Me.DiskTab4.HorizontalScrollbarSize = 10
        Me.DiskTab4.Location = New System.Drawing.Point(4, 34)
        Me.DiskTab4.Name = "DiskTab4"
        Me.DiskTab4.Size = New System.Drawing.Size(1075, 678)
        Me.DiskTab4.TabIndex = 2
        Me.DiskTab4.Text = "Disk"
        Me.DiskTab4.VerticalScrollbarBarColor = True
        Me.DiskTab4.VerticalScrollbarHighlightOnWheel = False
        Me.DiskTab4.VerticalScrollbarSize = 10
        '
        'MetroTile3
        '
        Me.MetroTile3.ActiveControl = Nothing
        Me.MetroTile3.BackColor = System.Drawing.Color.Transparent
        Me.MetroTile3.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.MetroTile3.Location = New System.Drawing.Point(3, 3)
        Me.MetroTile3.Name = "MetroTile3"
        Me.MetroTile3.Size = New System.Drawing.Size(38, 43)
        Me.MetroTile3.TabIndex = 123
        Me.MetroTile3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MetroTile3.TileImage = CType(resources.GetObject("MetroTile3.TileImage"), System.Drawing.Image)
        Me.MetroTile3.TileImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MetroTile3.TileTextFontSize = MetroFramework.MetroTileTextSize.Small
        Me.MetroTile3.UseCustomBackColor = True
        Me.MetroTile3.UseCustomForeColor = True
        Me.MetroTile3.UseSelectable = True
        Me.MetroTile3.UseTileImage = True
        '
        'Button14
        '
        Me.Button14.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Button14.BackColor = System.Drawing.Color.AliceBlue
        Me.Button14.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.Button14.Location = New System.Drawing.Point(465, 572)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(375, 28)
        Me.Button14.TabIndex = 135
        Me.Button14.Text = "Change Page File Location to E:\Pagefile.sys (Mem x 1.5) (Mem x 1.5)"
        Me.Button14.UseCustomBackColor = True
        Me.Button14.UseCustomForeColor = True
        Me.Button14.UseSelectable = True
        '
        'Button13
        '
        Me.Button13.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Button13.BackColor = System.Drawing.Color.AliceBlue
        Me.Button13.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.Button13.Location = New System.Drawing.Point(465, 538)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(375, 28)
        Me.Button13.TabIndex = 134
        Me.Button13.Text = "Change Page File Location to D:\Pagefile.sys (Mem x 1.5) (Mem x 1.5)"
        Me.Button13.UseCustomBackColor = True
        Me.Button13.UseCustomForeColor = True
        Me.Button13.UseSelectable = True
        '
        'ExportDISK_DETAILS
        '
        Me.ExportDISK_DETAILS.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ExportDISK_DETAILS.BackColor = System.Drawing.Color.AliceBlue
        Me.ExportDISK_DETAILS.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.ExportDISK_DETAILS.Location = New System.Drawing.Point(915, 12)
        Me.ExportDISK_DETAILS.Name = "ExportDISK_DETAILS"
        Me.ExportDISK_DETAILS.Size = New System.Drawing.Size(86, 28)
        Me.ExportDISK_DETAILS.TabIndex = 133
        Me.ExportDISK_DETAILS.Text = "Export to CSV"
        Me.ExportDISK_DETAILS.UseCustomBackColor = True
        Me.ExportDISK_DETAILS.UseCustomForeColor = True
        Me.ExportDISK_DETAILS.UseSelectable = True
        '
        'DISK_DETAILS
        '
        Me.DISK_DETAILS.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.DISK_DETAILS.BackColor = System.Drawing.Color.AliceBlue
        Me.DISK_DETAILS.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.DISK_DETAILS.Location = New System.Drawing.Point(402, 12)
        Me.DISK_DETAILS.Name = "DISK_DETAILS"
        Me.DISK_DETAILS.Size = New System.Drawing.Size(158, 28)
        Me.DISK_DETAILS.TabIndex = 132
        Me.DISK_DETAILS.Text = "Display Disk Details"
        Me.DISK_DETAILS.UseCustomBackColor = True
        Me.DISK_DETAILS.UseCustomForeColor = True
        Me.DISK_DETAILS.UseSelectable = True
        '
        'Label206
        '
        Me.Label206.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label206.AutoSize = True
        Me.Label206.BackColor = System.Drawing.Color.Transparent
        Me.Label206.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Label206.Location = New System.Drawing.Point(51, 275)
        Me.Label206.Name = "Label206"
        Me.Label206.Size = New System.Drawing.Size(104, 13)
        Me.Label206.TabIndex = 130
        Me.Label206.Text = "Partition information"
        '
        'DataGridViewDisk2
        '
        Me.DataGridViewDisk2.AllowUserToOrderColumns = True
        Me.DataGridViewDisk2.AllowUserToResizeRows = False
        Me.DataGridViewDisk2.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.DataGridViewDisk2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridViewDisk2.BackgroundColor = System.Drawing.Color.White
        Me.DataGridViewDisk2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewDisk2.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn4, Me.Model, Me.SerialNumber, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn1})
        Me.DataGridViewDisk2.Location = New System.Drawing.Point(54, 70)
        Me.DataGridViewDisk2.Name = "DataGridViewDisk2"
        Me.DataGridViewDisk2.RowHeadersVisible = False
        Me.DataGridViewDisk2.RowTemplate.Height = 24
        Me.DataGridViewDisk2.Size = New System.Drawing.Size(947, 190)
        Me.DataGridViewDisk2.TabIndex = 129
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.FillWeight = 8.0!
        Me.DataGridViewTextBoxColumn4.HeaderText = "Name"
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        '
        'Model
        '
        Me.Model.FillWeight = 18.99665!
        Me.Model.HeaderText = "Model"
        Me.Model.Name = "Model"
        '
        'SerialNumber
        '
        Me.SerialNumber.FillWeight = 8.0!
        Me.SerialNumber.HeaderText = "Serial Number"
        Me.SerialNumber.Name = "SerialNumber"
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.FillWeight = 5.0!
        Me.DataGridViewTextBoxColumn2.HeaderText = "Size (GB)"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.FillWeight = 5.0!
        Me.DataGridViewTextBoxColumn1.HeaderText = "Partitions"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        '
        'Label65
        '
        Me.Label65.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label65.AutoSize = True
        Me.Label65.BackColor = System.Drawing.Color.Transparent
        Me.Label65.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Label65.Location = New System.Drawing.Point(51, 54)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(130, 13)
        Me.Label65.TabIndex = 128
        Me.Label65.Text = "Physical Drive information"
        '
        'Label2
        '
        Me.Label2.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.White
        Me.Label2.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Label2.ForeColor = System.Drawing.Color.Red
        Me.Label2.Image = CType(resources.GetObject("Label2.Image"), System.Drawing.Image)
        Me.Label2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Label2.Location = New System.Drawing.Point(846, 546)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(127, 13)
        Me.Label2.TabIndex = 126
        Me.Label2.Text = "      Reboot Required       "
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label69
        '
        Me.Label69.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label69.BackColor = System.Drawing.Color.White
        Me.Label69.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Label69.ForeColor = System.Drawing.Color.Red
        Me.Label69.Location = New System.Drawing.Point(424, 605)
        Me.Label69.Name = "Label69"
        Me.Label69.Size = New System.Drawing.Size(527, 55)
        Me.Label69.TabIndex = 125
        Me.Label69.Text = resources.GetString("Label69.Text")
        '
        'Label67
        '
        Me.Label67.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label67.AutoSize = True
        Me.Label67.BackColor = System.Drawing.Color.White
        Me.Label67.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Label67.Location = New System.Drawing.Point(55, 548)
        Me.Label67.Name = "Label67"
        Me.Label67.Size = New System.Drawing.Size(95, 13)
        Me.Label67.TabIndex = 122
        Me.Label67.Text = "Page File Details : "
        '
        'TotalPhysicalMemoryDetails
        '
        Me.TotalPhysicalMemoryDetails.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.TotalPhysicalMemoryDetails.AutoSize = True
        Me.TotalPhysicalMemoryDetails.BackColor = System.Drawing.Color.White
        Me.TotalPhysicalMemoryDetails.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.TotalPhysicalMemoryDetails.Location = New System.Drawing.Point(55, 596)
        Me.TotalPhysicalMemoryDetails.Name = "TotalPhysicalMemoryDetails"
        Me.TotalPhysicalMemoryDetails.Size = New System.Drawing.Size(123, 13)
        Me.TotalPhysicalMemoryDetails.TabIndex = 120
        Me.TotalPhysicalMemoryDetails.Text = "Total Physical Memory : "
        '
        'PagefileDetails
        '
        Me.PagefileDetails.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.PagefileDetails.AutoSize = True
        Me.PagefileDetails.Location = New System.Drawing.Point(160, 548)
        Me.PagefileDetails.Name = "PagefileDetails"
        Me.PagefileDetails.Size = New System.Drawing.Size(0, 13)
        Me.PagefileDetails.TabIndex = 119
        '
        'DataGridViewDisk
        '
        Me.DataGridViewDisk.AllowUserToOrderColumns = True
        Me.DataGridViewDisk.AllowUserToResizeRows = False
        Me.DataGridViewDisk.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.DataGridViewDisk.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridViewDisk.BackgroundColor = System.Drawing.Color.White
        Me.DataGridViewDisk.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewDisk.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Drive, Me.Drivetype, Me.SizeDiskOut, Me.FreeSpace, Me.Used, Me.PercentFree, Me.PercentUsed})
        Me.DataGridViewDisk.Location = New System.Drawing.Point(54, 291)
        Me.DataGridViewDisk.Name = "DataGridViewDisk"
        Me.DataGridViewDisk.RowHeadersVisible = False
        Me.DataGridViewDisk.RowTemplate.Height = 24
        Me.DataGridViewDisk.Size = New System.Drawing.Size(947, 241)
        Me.DataGridViewDisk.TabIndex = 116
        '
        'Drive
        '
        Me.Drive.HeaderText = "Partition"
        Me.Drive.Name = "Drive"
        '
        'Drivetype
        '
        Me.Drivetype.FillWeight = 30.0!
        Me.Drivetype.HeaderText = "Type"
        Me.Drivetype.Name = "Drivetype"
        '
        'SizeDiskOut
        '
        Me.SizeDiskOut.FillWeight = 50.0!
        Me.SizeDiskOut.HeaderText = "Size (GB)"
        Me.SizeDiskOut.Name = "SizeDiskOut"
        '
        'FreeSpace
        '
        Me.FreeSpace.HeaderText = "FreeSpace (GB)"
        Me.FreeSpace.Name = "FreeSpace"
        '
        'Used
        '
        Me.Used.HeaderText = "Used (GB)"
        Me.Used.Name = "Used"
        '
        'PercentFree
        '
        Me.PercentFree.FillWeight = 50.0!
        Me.PercentFree.HeaderText = "(%) Free"
        Me.PercentFree.Name = "PercentFree"
        '
        'PercentUsed
        '
        Me.PercentUsed.FillWeight = 50.0!
        Me.PercentUsed.HeaderText = "(%) Used"
        Me.PercentUsed.Name = "PercentUsed"
        '
        'Label62
        '
        Me.Label62.AutoSize = True
        Me.Label62.BackColor = System.Drawing.Color.Transparent
        Me.Label62.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label62.Location = New System.Drawing.Point(57, 20)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(0, 16)
        Me.Label62.TabIndex = 115
        '
        'Label63
        '
        Me.Label63.AutoSize = True
        Me.Label63.BackColor = System.Drawing.Color.Transparent
        Me.Label63.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label63.Location = New System.Drawing.Point(57, 3)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(0, 16)
        Me.Label63.TabIndex = 114
        '
        'Label68
        '
        Me.Label68.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label68.AutoSize = True
        Me.Label68.BackColor = System.Drawing.Color.White
        Me.Label68.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Label68.ForeColor = System.Drawing.Color.Red
        Me.Label68.Image = CType(resources.GetObject("Label68.Image"), System.Drawing.Image)
        Me.Label68.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Label68.Location = New System.Drawing.Point(846, 572)
        Me.Label68.Name = "Label68"
        Me.Label68.Size = New System.Drawing.Size(127, 13)
        Me.Label68.TabIndex = 124
        Me.Label68.Text = "      Reboot Required       "
        Me.Label68.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'NetTab5
        '
        Me.NetTab5.Controls.Add(Me.MetroTile20)
        Me.NetTab5.Controls.Add(Me.ExportDOTNETlist)
        Me.NetTab5.Controls.Add(Me.DotNetDetect)
        Me.NetTab5.Controls.Add(Me.Label14a)
        Me.NetTab5.Controls.Add(Me.Label14)
        Me.NetTab5.Controls.Add(Me.MetroLabel18)
        Me.NetTab5.Controls.Add(Me.MetroLabel17)
        Me.NetTab5.Controls.Add(Me.MetroLabel16)
        Me.NetTab5.Controls.Add(Me.TableLayoutPanel42)
        Me.NetTab5.Controls.Add(Me.TableLayoutPanel41)
        Me.NetTab5.Controls.Add(Me.TableLayoutPanel39)
        Me.NetTab5.HorizontalScrollbarBarColor = True
        Me.NetTab5.HorizontalScrollbarHighlightOnWheel = False
        Me.NetTab5.HorizontalScrollbarSize = 10
        Me.NetTab5.Location = New System.Drawing.Point(4, 34)
        Me.NetTab5.Name = "NetTab5"
        Me.NetTab5.Size = New System.Drawing.Size(1075, 678)
        Me.NetTab5.TabIndex = 21
        Me.NetTab5.Text = "DotNet"
        Me.NetTab5.VerticalScrollbarBarColor = True
        Me.NetTab5.VerticalScrollbarHighlightOnWheel = False
        Me.NetTab5.VerticalScrollbarSize = 10
        '
        'MetroTile20
        '
        Me.MetroTile20.ActiveControl = Nothing
        Me.MetroTile20.BackColor = System.Drawing.Color.Transparent
        Me.MetroTile20.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.MetroTile20.Location = New System.Drawing.Point(6, 3)
        Me.MetroTile20.Name = "MetroTile20"
        Me.MetroTile20.Size = New System.Drawing.Size(38, 43)
        Me.MetroTile20.TabIndex = 136
        Me.MetroTile20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MetroTile20.TileImage = CType(resources.GetObject("MetroTile20.TileImage"), System.Drawing.Image)
        Me.MetroTile20.TileImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MetroTile20.TileTextFontSize = MetroFramework.MetroTileTextSize.Small
        Me.MetroTile20.UseCustomBackColor = True
        Me.MetroTile20.UseCustomForeColor = True
        Me.MetroTile20.UseSelectable = True
        Me.MetroTile20.UseTileImage = True
        '
        'ExportDOTNETlist
        '
        Me.ExportDOTNETlist.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ExportDOTNETlist.BackColor = System.Drawing.Color.AliceBlue
        Me.ExportDOTNETlist.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.ExportDOTNETlist.Location = New System.Drawing.Point(977, 8)
        Me.ExportDOTNETlist.Name = "ExportDOTNETlist"
        Me.ExportDOTNETlist.Size = New System.Drawing.Size(86, 28)
        Me.ExportDOTNETlist.TabIndex = 138
        Me.ExportDOTNETlist.Text = "Export to CSV"
        Me.ExportDOTNETlist.UseCustomBackColor = True
        Me.ExportDOTNETlist.UseCustomForeColor = True
        Me.ExportDOTNETlist.UseSelectable = True
        '
        'DotNetDetect
        '
        Me.DotNetDetect.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.DotNetDetect.BackColor = System.Drawing.Color.AliceBlue
        Me.DotNetDetect.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.DotNetDetect.Location = New System.Drawing.Point(364, 20)
        Me.DotNetDetect.Name = "DotNetDetect"
        Me.DotNetDetect.Size = New System.Drawing.Size(248, 28)
        Me.DotNetDetect.TabIndex = 137
        Me.DotNetDetect.Text = "Display .NetCore && .Net Framework Details"
        Me.DotNetDetect.UseCustomBackColor = True
        Me.DotNetDetect.UseCustomForeColor = True
        Me.DotNetDetect.UseSelectable = True
        '
        'Label14a
        '
        Me.Label14a.AutoSize = True
        Me.Label14a.BackColor = System.Drawing.Color.Transparent
        Me.Label14a.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14a.Location = New System.Drawing.Point(60, 20)
        Me.Label14a.Name = "Label14a"
        Me.Label14a.Size = New System.Drawing.Size(0, 16)
        Me.Label14a.TabIndex = 135
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.BackColor = System.Drawing.Color.Transparent
        Me.Label14.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(60, 3)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(0, 16)
        Me.Label14.TabIndex = 134
        '
        'MetroLabel18
        '
        Me.MetroLabel18.AutoSize = True
        Me.MetroLabel18.Location = New System.Drawing.Point(3, 441)
        Me.MetroLabel18.Name = "MetroLabel18"
        Me.MetroLabel18.Size = New System.Drawing.Size(184, 19)
        Me.MetroLabel18.TabIndex = 127
        Me.MetroLabel18.Text = ".Net Framework Runtimes x86"
        '
        'MetroLabel17
        '
        Me.MetroLabel17.AutoSize = True
        Me.MetroLabel17.Location = New System.Drawing.Point(6, 234)
        Me.MetroLabel17.Name = "MetroLabel17"
        Me.MetroLabel17.Size = New System.Drawing.Size(184, 19)
        Me.MetroLabel17.TabIndex = 126
        Me.MetroLabel17.Text = ".Net Framework Runtimes x64"
        '
        'MetroLabel16
        '
        Me.MetroLabel16.AutoSize = True
        Me.MetroLabel16.Location = New System.Drawing.Point(3, 66)
        Me.MetroLabel16.Name = "MetroLabel16"
        Me.MetroLabel16.Size = New System.Drawing.Size(119, 19)
        Me.MetroLabel16.TabIndex = 125
        Me.MetroLabel16.Text = ".NetCore Runtimes"
        '
        'TableLayoutPanel42
        '
        Me.TableLayoutPanel42.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel42.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.TableLayoutPanel42.BackColor = System.Drawing.Color.Transparent
        Me.TableLayoutPanel42.ColumnCount = 1
        Me.TableLayoutPanel42.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel42.Controls.Add(Me.DataGridViewNetCore, 0, 0)
        Me.TableLayoutPanel42.Location = New System.Drawing.Point(6, 85)
        Me.TableLayoutPanel42.Name = "TableLayoutPanel42"
        Me.TableLayoutPanel42.RowCount = 1
        Me.TableLayoutPanel42.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel42.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 146.0!))
        Me.TableLayoutPanel42.Size = New System.Drawing.Size(1069, 146)
        Me.TableLayoutPanel42.TabIndex = 124
        '
        'DataGridViewNetCore
        '
        Me.DataGridViewNetCore.AllowUserToDeleteRows = False
        Me.DataGridViewNetCore.AllowUserToOrderColumns = True
        Me.DataGridViewNetCore.AllowUserToResizeRows = False
        Me.DataGridViewNetCore.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DataGridViewNetCore.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridViewNetCore.BackgroundColor = System.Drawing.SystemColors.Window
        Me.DataGridViewNetCore.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewNetCore.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn31, Me.DataGridViewTextBoxColumn32})
        Me.DataGridViewNetCore.Location = New System.Drawing.Point(3, 3)
        Me.DataGridViewNetCore.Name = "DataGridViewNetCore"
        Me.DataGridViewNetCore.RowHeadersVisible = False
        Me.DataGridViewNetCore.RowTemplate.Height = 24
        Me.DataGridViewNetCore.Size = New System.Drawing.Size(1063, 140)
        Me.DataGridViewNetCore.TabIndex = 86
        '
        'DataGridViewTextBoxColumn31
        '
        Me.DataGridViewTextBoxColumn31.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn31.FillWeight = 60.0!
        Me.DataGridViewTextBoxColumn31.HeaderText = "Name"
        Me.DataGridViewTextBoxColumn31.Name = "DataGridViewTextBoxColumn31"
        Me.DataGridViewTextBoxColumn31.ReadOnly = True
        '
        'DataGridViewTextBoxColumn32
        '
        Me.DataGridViewTextBoxColumn32.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn32.FillWeight = 40.0!
        Me.DataGridViewTextBoxColumn32.HeaderText = "Version"
        Me.DataGridViewTextBoxColumn32.Name = "DataGridViewTextBoxColumn32"
        Me.DataGridViewTextBoxColumn32.ReadOnly = True
        '
        'TableLayoutPanel41
        '
        Me.TableLayoutPanel41.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel41.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.TableLayoutPanel41.BackColor = System.Drawing.Color.Transparent
        Me.TableLayoutPanel41.ColumnCount = 1
        Me.TableLayoutPanel41.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel41.Controls.Add(Me.DataGridViewNet64, 0, 0)
        Me.TableLayoutPanel41.Location = New System.Drawing.Point(6, 253)
        Me.TableLayoutPanel41.Name = "TableLayoutPanel41"
        Me.TableLayoutPanel41.RowCount = 1
        Me.TableLayoutPanel41.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel41.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 185.0!))
        Me.TableLayoutPanel41.Size = New System.Drawing.Size(1069, 185)
        Me.TableLayoutPanel41.TabIndex = 123
        '
        'DataGridViewNet64
        '
        Me.DataGridViewNet64.AllowUserToOrderColumns = True
        Me.DataGridViewNet64.AllowUserToResizeRows = False
        Me.DataGridViewNet64.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DataGridViewNet64.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridViewNet64.BackgroundColor = System.Drawing.SystemColors.Window
        Me.DataGridViewNet64.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewNet64.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn27, Me.DataGridViewTextBoxColumn28, Me.DataGridViewTextBoxColumn29, Me.DataGridViewTextBoxColumn30})
        Me.DataGridViewNet64.Location = New System.Drawing.Point(3, 3)
        Me.DataGridViewNet64.Name = "DataGridViewNet64"
        Me.DataGridViewNet64.RowHeadersVisible = False
        Me.DataGridViewNet64.RowTemplate.Height = 24
        Me.DataGridViewNet64.Size = New System.Drawing.Size(1063, 179)
        Me.DataGridViewNet64.TabIndex = 86
        '
        'DataGridViewTextBoxColumn27
        '
        Me.DataGridViewTextBoxColumn27.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn27.FillWeight = 50.0!
        Me.DataGridViewTextBoxColumn27.HeaderText = "Name"
        Me.DataGridViewTextBoxColumn27.Name = "DataGridViewTextBoxColumn27"
        Me.DataGridViewTextBoxColumn27.ReadOnly = True
        '
        'DataGridViewTextBoxColumn28
        '
        Me.DataGridViewTextBoxColumn28.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        Me.DataGridViewTextBoxColumn28.FillWeight = 50.0!
        Me.DataGridViewTextBoxColumn28.HeaderText = "Version"
        Me.DataGridViewTextBoxColumn28.Name = "DataGridViewTextBoxColumn28"
        Me.DataGridViewTextBoxColumn28.ReadOnly = True
        Me.DataGridViewTextBoxColumn28.Width = 200
        '
        'DataGridViewTextBoxColumn29
        '
        Me.DataGridViewTextBoxColumn29.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        Me.DataGridViewTextBoxColumn29.FillWeight = 50.0!
        Me.DataGridViewTextBoxColumn29.HeaderText = "ServicePack"
        Me.DataGridViewTextBoxColumn29.Name = "DataGridViewTextBoxColumn29"
        Me.DataGridViewTextBoxColumn29.ReadOnly = True
        '
        'DataGridViewTextBoxColumn30
        '
        Me.DataGridViewTextBoxColumn30.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        Me.DataGridViewTextBoxColumn30.FillWeight = 50.0!
        Me.DataGridViewTextBoxColumn30.HeaderText = "ReleaseVersion"
        Me.DataGridViewTextBoxColumn30.Name = "DataGridViewTextBoxColumn30"
        Me.DataGridViewTextBoxColumn30.ReadOnly = True
        Me.DataGridViewTextBoxColumn30.Width = 200
        '
        'TableLayoutPanel39
        '
        Me.TableLayoutPanel39.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel39.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.TableLayoutPanel39.BackColor = System.Drawing.Color.Transparent
        Me.TableLayoutPanel39.ColumnCount = 1
        Me.TableLayoutPanel39.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel39.Controls.Add(Me.DataGridViewNet32, 0, 0)
        Me.TableLayoutPanel39.Location = New System.Drawing.Point(3, 463)
        Me.TableLayoutPanel39.Name = "TableLayoutPanel39"
        Me.TableLayoutPanel39.RowCount = 1
        Me.TableLayoutPanel39.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel39.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 212.0!))
        Me.TableLayoutPanel39.Size = New System.Drawing.Size(1069, 212)
        Me.TableLayoutPanel39.TabIndex = 122
        '
        'DataGridViewNet32
        '
        Me.DataGridViewNet32.AllowUserToOrderColumns = True
        Me.DataGridViewNet32.AllowUserToResizeRows = False
        Me.DataGridViewNet32.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DataGridViewNet32.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridViewNet32.BackgroundColor = System.Drawing.SystemColors.Window
        Me.DataGridViewNet32.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewNet32.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn21, Me.DataGridViewTextBoxColumn24, Me.DataGridViewTextBoxColumn25, Me.DataGridViewTextBoxColumn26})
        Me.DataGridViewNet32.Location = New System.Drawing.Point(3, 3)
        Me.DataGridViewNet32.Name = "DataGridViewNet32"
        Me.DataGridViewNet32.RowHeadersVisible = False
        Me.DataGridViewNet32.RowTemplate.Height = 24
        Me.DataGridViewNet32.Size = New System.Drawing.Size(1063, 206)
        Me.DataGridViewNet32.TabIndex = 85
        '
        'DataGridViewTextBoxColumn21
        '
        Me.DataGridViewTextBoxColumn21.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn21.FillWeight = 50.0!
        Me.DataGridViewTextBoxColumn21.HeaderText = "Name"
        Me.DataGridViewTextBoxColumn21.Name = "DataGridViewTextBoxColumn21"
        Me.DataGridViewTextBoxColumn21.ReadOnly = True
        '
        'DataGridViewTextBoxColumn24
        '
        Me.DataGridViewTextBoxColumn24.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        Me.DataGridViewTextBoxColumn24.FillWeight = 50.0!
        Me.DataGridViewTextBoxColumn24.HeaderText = "Version"
        Me.DataGridViewTextBoxColumn24.Name = "DataGridViewTextBoxColumn24"
        Me.DataGridViewTextBoxColumn24.ReadOnly = True
        Me.DataGridViewTextBoxColumn24.Width = 200
        '
        'DataGridViewTextBoxColumn25
        '
        Me.DataGridViewTextBoxColumn25.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        Me.DataGridViewTextBoxColumn25.FillWeight = 50.0!
        Me.DataGridViewTextBoxColumn25.HeaderText = "ServicePack"
        Me.DataGridViewTextBoxColumn25.Name = "DataGridViewTextBoxColumn25"
        Me.DataGridViewTextBoxColumn25.ReadOnly = True
        '
        'DataGridViewTextBoxColumn26
        '
        Me.DataGridViewTextBoxColumn26.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        Me.DataGridViewTextBoxColumn26.FillWeight = 50.0!
        Me.DataGridViewTextBoxColumn26.HeaderText = "ReleaseVersion"
        Me.DataGridViewTextBoxColumn26.Name = "DataGridViewTextBoxColumn26"
        Me.DataGridViewTextBoxColumn26.ReadOnly = True
        Me.DataGridViewTextBoxColumn26.Width = 200
        '
        'ExecuteTab6
        '
        Me.ExecuteTab6.Controls.Add(Me.Label12)
        Me.ExecuteTab6.Controls.Add(Me.MetroLabel14)
        Me.ExecuteTab6.Controls.Add(Me.MetroLabel13)
        Me.ExecuteTab6.Controls.Add(Me.MetroLabel11)
        Me.ExecuteTab6.Controls.Add(Me.TableLayoutPanel30)
        Me.ExecuteTab6.Controls.Add(Me.TableLayoutPanel28)
        Me.ExecuteTab6.Controls.Add(Me.Label7)
        Me.ExecuteTab6.Controls.Add(Me.TableLayoutPanel22)
        Me.ExecuteTab6.Controls.Add(Me.Label221)
        Me.ExecuteTab6.Controls.Add(Me.Label220)
        Me.ExecuteTab6.Controls.Add(Me.Label219)
        Me.ExecuteTab6.Controls.Add(Me.Label218)
        Me.ExecuteTab6.Controls.Add(Me.Label214)
        Me.ExecuteTab6.Controls.Add(Me.Label213)
        Me.ExecuteTab6.Controls.Add(Me.Label212)
        Me.ExecuteTab6.Controls.Add(Me.Label211)
        Me.ExecuteTab6.Controls.Add(Me.TableLayoutPanel32)
        Me.ExecuteTab6.Controls.Add(Me.Label17)
        Me.ExecuteTab6.Controls.Add(Me.Label19)
        Me.ExecuteTab6.Controls.Add(Me.TableLayoutPanel1)
        Me.ExecuteTab6.Controls.Add(Me.TableLayoutPanel8)
        Me.ExecuteTab6.Controls.Add(Me.TableLayoutPanel4)
        Me.ExecuteTab6.Controls.Add(Me.TableLayoutPanel3)
        Me.ExecuteTab6.Controls.Add(Me.MetroTile6)
        Me.ExecuteTab6.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.ExecuteTab6.HorizontalScrollbarBarColor = True
        Me.ExecuteTab6.HorizontalScrollbarHighlightOnWheel = False
        Me.ExecuteTab6.HorizontalScrollbarSize = 10
        Me.ExecuteTab6.Location = New System.Drawing.Point(4, 34)
        Me.ExecuteTab6.Name = "ExecuteTab6"
        Me.ExecuteTab6.Size = New System.Drawing.Size(1075, 678)
        Me.ExecuteTab6.TabIndex = 5
        Me.ExecuteTab6.Text = "Execute"
        Me.ExecuteTab6.VerticalScrollbarBarColor = True
        Me.ExecuteTab6.VerticalScrollbarHighlightOnWheel = False
        Me.ExecuteTab6.VerticalScrollbarSize = 10
        '
        'Label12
        '
        Me.Label12.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Label12.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.Label12.Location = New System.Drawing.Point(175, 479)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(796, 13)
        Me.Label12.TabIndex = 157
        Me.Label12.Text = "Powershell Executer! Copy package to computer > Execute the command below. (eg. """ &
    "Selected File"" fom above or INSTALL.BAT or MYSCRIPT.VBS or SETUP.EXE /S)"
        '
        'MetroLabel14
        '
        Me.MetroLabel14.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.MetroLabel14.AutoSize = True
        Me.MetroLabel14.Location = New System.Drawing.Point(676, 428)
        Me.MetroLabel14.Name = "MetroLabel14"
        Me.MetroLabel14.Size = New System.Drawing.Size(82, 19)
        Me.MetroLabel14.TabIndex = 156
        Me.MetroLabel14.Text = "Selected File"
        '
        'MetroLabel13
        '
        Me.MetroLabel13.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.MetroLabel13.AutoSize = True
        Me.MetroLabel13.Location = New System.Drawing.Point(188, 428)
        Me.MetroLabel13.Name = "MetroLabel13"
        Me.MetroLabel13.Size = New System.Drawing.Size(100, 19)
        Me.MetroLabel13.TabIndex = 155
        Me.MetroLabel13.Text = "Selected Folder"
        '
        'MetroLabel11
        '
        Me.MetroLabel11.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.MetroLabel11.AutoSize = True
        Me.MetroLabel11.Location = New System.Drawing.Point(676, 42)
        Me.MetroLabel11.Name = "MetroLabel11"
        Me.MetroLabel11.Size = New System.Drawing.Size(34, 19)
        Me.MetroLabel11.TabIndex = 154
        Me.MetroLabel11.Text = "Files"
        '
        'TableLayoutPanel30
        '
        Me.TableLayoutPanel30.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.TableLayoutPanel30.BackColor = System.Drawing.Color.Transparent
        Me.TableLayoutPanel30.ColumnCount = 2
        Me.TableLayoutPanel30.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel30.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 775.0!))
        Me.TableLayoutPanel30.Controls.Add(Me.Label10, 0, 0)
        Me.TableLayoutPanel30.Controls.Add(Me.SDBoxFile, 1, 0)
        Me.TableLayoutPanel30.Location = New System.Drawing.Point(670, 398)
        Me.TableLayoutPanel30.Margin = New System.Windows.Forms.Padding(2)
        Me.TableLayoutPanel30.Name = "TableLayoutPanel30"
        Me.TableLayoutPanel30.RowCount = 1
        Me.TableLayoutPanel30.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel30.Size = New System.Drawing.Size(348, 30)
        Me.TableLayoutPanel30.TabIndex = 153
        '
        'Label10
        '
        Me.Label10.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.White
        Me.Label10.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Label10.Location = New System.Drawing.Point(3, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(1, 30)
        Me.Label10.TabIndex = 115
        Me.Label10.Text = "  Selected folder ="
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'SDBoxFile
        '
        Me.SDBoxFile.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        '
        '
        '
        Me.SDBoxFile.CustomButton.Image = Nothing
        Me.SDBoxFile.CustomButton.Location = New System.Drawing.Point(317, 2)
        Me.SDBoxFile.CustomButton.Name = ""
        Me.SDBoxFile.CustomButton.Size = New System.Drawing.Size(19, 19)
        Me.SDBoxFile.CustomButton.Style = MetroFramework.MetroColorStyle.Blue
        Me.SDBoxFile.CustomButton.TabIndex = 1
        Me.SDBoxFile.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light
        Me.SDBoxFile.CustomButton.UseSelectable = True
        Me.SDBoxFile.CustomButton.Visible = False
        Me.SDBoxFile.ForeColor = System.Drawing.Color.Blue
        Me.SDBoxFile.Lines = New String(-1) {}
        Me.SDBoxFile.Location = New System.Drawing.Point(6, 3)
        Me.SDBoxFile.MaxLength = 32767
        Me.SDBoxFile.Name = "SDBoxFile"
        Me.SDBoxFile.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.SDBoxFile.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.SDBoxFile.SelectedText = ""
        Me.SDBoxFile.SelectionLength = 0
        Me.SDBoxFile.SelectionStart = 0
        Me.SDBoxFile.Size = New System.Drawing.Size(339, 24)
        Me.SDBoxFile.TabIndex = 116
        Me.SDBoxFile.UseSelectable = True
        Me.SDBoxFile.WaterMarkColor = System.Drawing.Color.FromArgb(CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.SDBoxFile.WaterMarkFont = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel)
        '
        'TableLayoutPanel28
        '
        Me.TableLayoutPanel28.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel28.BackColor = System.Drawing.Color.Transparent
        Me.TableLayoutPanel28.ColumnCount = 1
        Me.TableLayoutPanel28.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel28.Controls.Add(Me.SDList1Files, 0, 0)
        Me.TableLayoutPanel28.Location = New System.Drawing.Point(670, 65)
        Me.TableLayoutPanel28.Margin = New System.Windows.Forms.Padding(2)
        Me.TableLayoutPanel28.Name = "TableLayoutPanel28"
        Me.TableLayoutPanel28.RowCount = 1
        Me.TableLayoutPanel28.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel28.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 329.0!))
        Me.TableLayoutPanel28.Size = New System.Drawing.Size(348, 329)
        Me.TableLayoutPanel28.TabIndex = 152
        '
        'SDList1Files
        '
        Me.SDList1Files.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SDList1Files.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.SDList1Files.FormattingEnabled = True
        Me.SDList1Files.Location = New System.Drawing.Point(3, 3)
        Me.SDList1Files.Name = "SDList1Files"
        Me.SDList1Files.Size = New System.Drawing.Size(342, 323)
        Me.SDList1Files.TabIndex = 55
        '
        'Label7
        '
        Me.Label7.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Label7.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.Label7.Location = New System.Drawing.Point(175, 584)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(796, 13)
        Me.Label7.TabIndex = 151
        Me.Label7.Text = "Powershell Executer! Copy package to computer > Execute the command below. (eg. """ &
    "Selected File"" fom above or INSTALL.BAT or MYSCRIPT.VBS or SETUP.EXE /S)"
        '
        'TableLayoutPanel22
        '
        Me.TableLayoutPanel22.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.TableLayoutPanel22.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.TableLayoutPanel22.BackColor = System.Drawing.Color.Transparent
        Me.TableLayoutPanel22.ColumnCount = 3
        Me.TableLayoutPanel22.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.47401!))
        Me.TableLayoutPanel22.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 63.72141!))
        Me.TableLayoutPanel22.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 23.90852!))
        Me.TableLayoutPanel22.Controls.Add(Me.PowershellCopyLocalExecuteButton, 2, 0)
        Me.TableLayoutPanel22.Controls.Add(Me.Label8, 0, 0)
        Me.TableLayoutPanel22.Controls.Add(Me.PSEXECUTEPackageText, 1, 0)
        Me.TableLayoutPanel22.Location = New System.Drawing.Point(57, 599)
        Me.TableLayoutPanel22.Margin = New System.Windows.Forms.Padding(2)
        Me.TableLayoutPanel22.Name = "TableLayoutPanel22"
        Me.TableLayoutPanel22.RowCount = 1
        Me.TableLayoutPanel22.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel22.Size = New System.Drawing.Size(962, 28)
        Me.TableLayoutPanel22.TabIndex = 150
        '
        'PowershellCopyLocalExecuteButton
        '
        Me.PowershellCopyLocalExecuteButton.BackColor = System.Drawing.Color.AliceBlue
        Me.PowershellCopyLocalExecuteButton.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PowershellCopyLocalExecuteButton.ForeColor = System.Drawing.SystemColors.InfoText
        Me.PowershellCopyLocalExecuteButton.Location = New System.Drawing.Point(734, 3)
        Me.PowershellCopyLocalExecuteButton.Name = "PowershellCopyLocalExecuteButton"
        Me.PowershellCopyLocalExecuteButton.Size = New System.Drawing.Size(225, 22)
        Me.PowershellCopyLocalExecuteButton.TabIndex = 151
        Me.PowershellCopyLocalExecuteButton.Text = "< Execute (Drive Letter && Manual checks)"
        Me.PowershellCopyLocalExecuteButton.UseCustomBackColor = True
        Me.PowershellCopyLocalExecuteButton.UseCustomForeColor = True
        Me.PowershellCopyLocalExecuteButton.UseSelectable = True
        '
        'Label8
        '
        Me.Label8.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(3, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(113, 28)
        Me.Label8.TabIndex = 153
        Me.Label8.Text = "File to Execute >"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'PSEXECUTEPackageText
        '
        Me.PSEXECUTEPackageText.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.PSEXECUTEPackageText.Location = New System.Drawing.Point(122, 3)
        Me.PSEXECUTEPackageText.Name = "PSEXECUTEPackageText"
        Me.PSEXECUTEPackageText.Size = New System.Drawing.Size(606, 21)
        Me.PSEXECUTEPackageText.TabIndex = 61
        '
        'Label221
        '
        Me.Label221.AutoSize = True
        Me.Label221.BackColor = System.Drawing.Color.Transparent
        Me.Label221.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Label221.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.Label221.Location = New System.Drawing.Point(6, 116)
        Me.Label221.Name = "Label221"
        Me.Label221.Size = New System.Drawing.Size(51, 13)
        Me.Label221.TabIndex = 147
        Me.Label221.Text = "1 = Error"
        '
        'Label220
        '
        Me.Label220.AutoSize = True
        Me.Label220.BackColor = System.Drawing.Color.Transparent
        Me.Label220.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Label220.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.Label220.Location = New System.Drawing.Point(8, 185)
        Me.Label220.Name = "Label220"
        Me.Label220.Size = New System.Drawing.Size(141, 13)
        Me.Label220.TabIndex = 146
        Me.Label220.Text = "3010 = MSI reboot required"
        '
        'Label219
        '
        Me.Label219.AutoSize = True
        Me.Label219.BackColor = System.Drawing.Color.Transparent
        Me.Label219.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Label219.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.Label219.Location = New System.Drawing.Point(6, 139)
        Me.Label219.Name = "Label219"
        Me.Label219.Size = New System.Drawing.Size(90, 13)
        Me.Label219.TabIndex = 145
        Me.Label219.Text = "1603 = MSI error"
        '
        'Label218
        '
        Me.Label218.AutoSize = True
        Me.Label218.BackColor = System.Drawing.Color.Transparent
        Me.Label218.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Label218.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.Label218.Location = New System.Drawing.Point(6, 162)
        Me.Label218.Name = "Label218"
        Me.Label218.Size = New System.Drawing.Size(144, 13)
        Me.Label218.TabIndex = 144
        Me.Label218.Text = "1605 = MSI already installed"
        '
        'Label214
        '
        Me.Label214.AutoSize = True
        Me.Label214.BackColor = System.Drawing.Color.Transparent
        Me.Label214.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Label214.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.Label214.Location = New System.Drawing.Point(8, 209)
        Me.Label214.Name = "Label214"
        Me.Label214.Size = New System.Drawing.Size(109, 13)
        Me.Label214.TabIndex = 143
        Me.Label214.Text = "9009 = file not found"
        '
        'Label213
        '
        Me.Label213.AutoSize = True
        Me.Label213.BackColor = System.Drawing.Color.Transparent
        Me.Label213.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Label213.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.Label213.Location = New System.Drawing.Point(4, 76)
        Me.Label213.Name = "Label213"
        Me.Label213.Size = New System.Drawing.Size(147, 13)
        Me.Label213.TabIndex = 142
        Me.Label213.Text = "-----------------------------------"
        '
        'Label212
        '
        Me.Label212.AutoSize = True
        Me.Label212.BackColor = System.Drawing.Color.Transparent
        Me.Label212.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Label212.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.Label212.Location = New System.Drawing.Point(6, 93)
        Me.Label212.Name = "Label212"
        Me.Label212.Size = New System.Drawing.Size(65, 13)
        Me.Label212.TabIndex = 141
        Me.Label212.Text = "0 = Success"
        '
        'Label211
        '
        Me.Label211.AutoSize = True
        Me.Label211.BackColor = System.Drawing.Color.Transparent
        Me.Label211.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Label211.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.Label211.Location = New System.Drawing.Point(6, 65)
        Me.Label211.Name = "Label211"
        Me.Label211.Size = New System.Drawing.Size(102, 13)
        Me.Label211.TabIndex = 140
        Me.Label211.Text = "General ExitCodes :"
        '
        'TableLayoutPanel32
        '
        Me.TableLayoutPanel32.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.TableLayoutPanel32.BackColor = System.Drawing.Color.Transparent
        Me.TableLayoutPanel32.ColumnCount = 2
        Me.TableLayoutPanel32.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel32.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 251.0!))
        Me.TableLayoutPanel32.Controls.Add(Me.Inst_RemDriveLetter, 0, 0)
        Me.TableLayoutPanel32.Controls.Add(Me.Label26, 1, 0)
        Me.TableLayoutPanel32.Location = New System.Drawing.Point(178, 553)
        Me.TableLayoutPanel32.Name = "TableLayoutPanel32"
        Me.TableLayoutPanel32.RowCount = 1
        Me.TableLayoutPanel32.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel32.Size = New System.Drawing.Size(312, 28)
        Me.TableLayoutPanel32.TabIndex = 136
        '
        'Inst_RemDriveLetter
        '
        Me.Inst_RemDriveLetter.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Inst_RemDriveLetter.BackColor = System.Drawing.SystemColors.Window
        Me.Inst_RemDriveLetter.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Inst_RemDriveLetter.FormattingEnabled = True
        Me.Inst_RemDriveLetter.Items.AddRange(New Object() {"A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"})
        Me.Inst_RemDriveLetter.Location = New System.Drawing.Point(3, 3)
        Me.Inst_RemDriveLetter.Name = "Inst_RemDriveLetter"
        Me.Inst_RemDriveLetter.Size = New System.Drawing.Size(55, 21)
        Me.Inst_RemDriveLetter.TabIndex = 1
        '
        'Label26
        '
        Me.Label26.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Label26.ForeColor = System.Drawing.Color.Blue
        Me.Label26.Location = New System.Drawing.Point(67, 7)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(242, 13)
        Me.Label26.TabIndex = 2
        Me.Label26.Text = "Please select a Drive Letter to use. (Default = A)"
        Me.Label26.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.BackColor = System.Drawing.Color.Transparent
        Me.Label17.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(53, 22)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(0, 16)
        Me.Label17.TabIndex = 134
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.BackColor = System.Drawing.Color.Transparent
        Me.Label19.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(53, 5)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(0, 16)
        Me.Label19.TabIndex = 132
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.TableLayoutPanel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.TableLayoutPanel1.BackColor = System.Drawing.Color.Transparent
        Me.TableLayoutPanel1.ColumnCount = 3
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.80773!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 63.21839!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 24.81828!))
        Me.TableLayoutPanel1.Controls.Add(Me.REMCOMPackageFromDOMAIN, 2, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.REMCOMPackageText, 1, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label3, 0, 0)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(62, 494)
        Me.TableLayoutPanel1.Margin = New System.Windows.Forms.Padding(2)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 1
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(957, 28)
        Me.TableLayoutPanel1.TabIndex = 130
        '
        'REMCOMPackageFromDOMAIN
        '
        Me.REMCOMPackageFromDOMAIN.BackColor = System.Drawing.Color.AliceBlue
        Me.REMCOMPackageFromDOMAIN.Dock = System.Windows.Forms.DockStyle.Fill
        Me.REMCOMPackageFromDOMAIN.ForeColor = System.Drawing.SystemColors.InfoText
        Me.REMCOMPackageFromDOMAIN.Location = New System.Drawing.Point(721, 3)
        Me.REMCOMPackageFromDOMAIN.Name = "REMCOMPackageFromDOMAIN"
        Me.REMCOMPackageFromDOMAIN.Size = New System.Drawing.Size(233, 22)
        Me.REMCOMPackageFromDOMAIN.TabIndex = 151
        Me.REMCOMPackageFromDOMAIN.Text = " < Execute (No Drive Letter required)"
        Me.REMCOMPackageFromDOMAIN.UseCustomBackColor = True
        Me.REMCOMPackageFromDOMAIN.UseCustomForeColor = True
        Me.REMCOMPackageFromDOMAIN.UseSelectable = True
        '
        'REMCOMPackageText
        '
        Me.REMCOMPackageText.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.REMCOMPackageText.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.REMCOMPackageText.Location = New System.Drawing.Point(116, 3)
        Me.REMCOMPackageText.Name = "REMCOMPackageText"
        Me.REMCOMPackageText.Size = New System.Drawing.Size(599, 21)
        Me.REMCOMPackageText.TabIndex = 59
        '
        'Label3
        '
        Me.Label3.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(3, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(107, 28)
        Me.Label3.TabIndex = 60
        Me.Label3.Text = "File to Execute >"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'TableLayoutPanel8
        '
        Me.TableLayoutPanel8.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.TableLayoutPanel8.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.TableLayoutPanel8.BackColor = System.Drawing.Color.Transparent
        Me.TableLayoutPanel8.ColumnCount = 1
        Me.TableLayoutPanel8.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel8.Controls.Add(Me.SDListDirectory, 0, 0)
        Me.TableLayoutPanel8.Controls.Add(Me.SDlistpackages, 0, 1)
        Me.TableLayoutPanel8.Location = New System.Drawing.Point(187, 5)
        Me.TableLayoutPanel8.Margin = New System.Windows.Forms.Padding(2)
        Me.TableLayoutPanel8.Name = "TableLayoutPanel8"
        Me.TableLayoutPanel8.RowCount = 2
        Me.TableLayoutPanel8.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 48.27586!))
        Me.TableLayoutPanel8.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 51.72414!))
        Me.TableLayoutPanel8.Size = New System.Drawing.Size(479, 56)
        Me.TableLayoutPanel8.TabIndex = 129
        '
        'SDListDirectory
        '
        Me.SDListDirectory.BackColor = System.Drawing.SystemColors.Window
        Me.SDListDirectory.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SDListDirectory.DropDownWidth = 600
        Me.SDListDirectory.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.SDListDirectory.FormattingEnabled = True
        Me.SDListDirectory.Items.AddRange(New Object() {"", "\\SERVERNAME\SHARENAME"})
        Me.SDListDirectory.Location = New System.Drawing.Point(2, 2)
        Me.SDListDirectory.Margin = New System.Windows.Forms.Padding(2)
        Me.SDListDirectory.Name = "SDListDirectory"
        Me.SDListDirectory.Size = New System.Drawing.Size(475, 21)
        Me.SDListDirectory.Sorted = True
        Me.SDListDirectory.TabIndex = 89
        '
        'SDlistpackages
        '
        Me.SDlistpackages.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.SDlistpackages.BackColor = System.Drawing.Color.AliceBlue
        Me.SDlistpackages.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.SDlistpackages.Location = New System.Drawing.Point(3, 30)
        Me.SDlistpackages.Name = "SDlistpackages"
        Me.SDlistpackages.Size = New System.Drawing.Size(128, 23)
        Me.SDlistpackages.TabIndex = 150
        Me.SDlistpackages.Text = "List Folders on Share"
        Me.SDlistpackages.UseCustomBackColor = True
        Me.SDlistpackages.UseCustomForeColor = True
        Me.SDlistpackages.UseSelectable = True
        '
        'TableLayoutPanel4
        '
        Me.TableLayoutPanel4.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel4.BackColor = System.Drawing.Color.Transparent
        Me.TableLayoutPanel4.ColumnCount = 1
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel4.Controls.Add(Me.SDList1, 0, 0)
        Me.TableLayoutPanel4.Location = New System.Drawing.Point(188, 65)
        Me.TableLayoutPanel4.Margin = New System.Windows.Forms.Padding(2)
        Me.TableLayoutPanel4.Name = "TableLayoutPanel4"
        Me.TableLayoutPanel4.RowCount = 1
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 329.0!))
        Me.TableLayoutPanel4.Size = New System.Drawing.Size(478, 329)
        Me.TableLayoutPanel4.TabIndex = 128
        '
        'SDList1
        '
        Me.SDList1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SDList1.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.SDList1.FormattingEnabled = True
        Me.SDList1.Location = New System.Drawing.Point(3, 3)
        Me.SDList1.Name = "SDList1"
        Me.SDList1.Size = New System.Drawing.Size(472, 323)
        Me.SDList1.TabIndex = 55
        '
        'TableLayoutPanel3
        '
        Me.TableLayoutPanel3.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.TableLayoutPanel3.BackColor = System.Drawing.Color.Transparent
        Me.TableLayoutPanel3.ColumnCount = 2
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 775.0!))
        Me.TableLayoutPanel3.Controls.Add(Me.Label215, 0, 0)
        Me.TableLayoutPanel3.Controls.Add(Me.SDBOXFolder, 1, 0)
        Me.TableLayoutPanel3.Location = New System.Drawing.Point(189, 398)
        Me.TableLayoutPanel3.Margin = New System.Windows.Forms.Padding(2)
        Me.TableLayoutPanel3.Name = "TableLayoutPanel3"
        Me.TableLayoutPanel3.RowCount = 1
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel3.Size = New System.Drawing.Size(477, 30)
        Me.TableLayoutPanel3.TabIndex = 127
        '
        'Label215
        '
        Me.Label215.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label215.AutoSize = True
        Me.Label215.BackColor = System.Drawing.Color.White
        Me.Label215.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Label215.Location = New System.Drawing.Point(3, 0)
        Me.Label215.Name = "Label215"
        Me.Label215.Size = New System.Drawing.Size(1, 30)
        Me.Label215.TabIndex = 115
        Me.Label215.Text = "  Selected folder ="
        Me.Label215.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'SDBOXFolder
        '
        Me.SDBOXFolder.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        '
        '
        '
        Me.SDBOXFolder.CustomButton.Image = Nothing
        Me.SDBOXFolder.CustomButton.Location = New System.Drawing.Point(450, 2)
        Me.SDBOXFolder.CustomButton.Name = ""
        Me.SDBOXFolder.CustomButton.Size = New System.Drawing.Size(19, 19)
        Me.SDBOXFolder.CustomButton.Style = MetroFramework.MetroColorStyle.Blue
        Me.SDBOXFolder.CustomButton.TabIndex = 1
        Me.SDBOXFolder.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light
        Me.SDBOXFolder.CustomButton.UseSelectable = True
        Me.SDBOXFolder.CustomButton.Visible = False
        Me.SDBOXFolder.ForeColor = System.Drawing.Color.Blue
        Me.SDBOXFolder.Lines = New String(-1) {}
        Me.SDBOXFolder.Location = New System.Drawing.Point(2, 3)
        Me.SDBOXFolder.MaxLength = 32767
        Me.SDBOXFolder.Name = "SDBOXFolder"
        Me.SDBOXFolder.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.SDBOXFolder.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.SDBOXFolder.SelectedText = ""
        Me.SDBOXFolder.SelectionLength = 0
        Me.SDBOXFolder.SelectionStart = 0
        Me.SDBOXFolder.Size = New System.Drawing.Size(472, 24)
        Me.SDBOXFolder.TabIndex = 116
        Me.SDBOXFolder.UseSelectable = True
        Me.SDBOXFolder.WaterMarkColor = System.Drawing.Color.FromArgb(CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.SDBOXFolder.WaterMarkFont = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel)
        '
        'MetroTile6
        '
        Me.MetroTile6.ActiveControl = Nothing
        Me.MetroTile6.BackColor = System.Drawing.Color.Transparent
        Me.MetroTile6.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.MetroTile6.Location = New System.Drawing.Point(3, 2)
        Me.MetroTile6.Name = "MetroTile6"
        Me.MetroTile6.Size = New System.Drawing.Size(38, 43)
        Me.MetroTile6.TabIndex = 125
        Me.MetroTile6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MetroTile6.TileImage = CType(resources.GetObject("MetroTile6.TileImage"), System.Drawing.Image)
        Me.MetroTile6.TileImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MetroTile6.TileTextFontSize = MetroFramework.MetroTileTextSize.Small
        Me.MetroTile6.UseCustomBackColor = True
        Me.MetroTile6.UseCustomForeColor = True
        Me.MetroTile6.UseSelectable = True
        Me.MetroTile6.UseTileImage = True
        '
        'FtypeTab7
        '
        Me.FtypeTab7.Controls.Add(Me.ExportFileTypes)
        Me.FtypeTab7.Controls.Add(Me.Button3)
        Me.FtypeTab7.Controls.Add(Me.Button66)
        Me.FtypeTab7.Controls.Add(Me.TableLayoutPanel14)
        Me.FtypeTab7.Controls.Add(Me.Label53)
        Me.FtypeTab7.Controls.Add(Me.Label40)
        Me.FtypeTab7.Controls.Add(Me.MetroTile4)
        Me.FtypeTab7.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.FtypeTab7.HorizontalScrollbarBarColor = True
        Me.FtypeTab7.HorizontalScrollbarHighlightOnWheel = False
        Me.FtypeTab7.HorizontalScrollbarSize = 10
        Me.FtypeTab7.Location = New System.Drawing.Point(4, 34)
        Me.FtypeTab7.Name = "FtypeTab7"
        Me.FtypeTab7.Size = New System.Drawing.Size(1075, 678)
        Me.FtypeTab7.TabIndex = 3
        Me.FtypeTab7.Text = "FType"
        Me.FtypeTab7.VerticalScrollbarBarColor = True
        Me.FtypeTab7.VerticalScrollbarHighlightOnWheel = False
        Me.FtypeTab7.VerticalScrollbarSize = 10
        '
        'ExportFileTypes
        '
        Me.ExportFileTypes.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ExportFileTypes.BackColor = System.Drawing.Color.AliceBlue
        Me.ExportFileTypes.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.ExportFileTypes.Location = New System.Drawing.Point(975, 8)
        Me.ExportFileTypes.Name = "ExportFileTypes"
        Me.ExportFileTypes.Size = New System.Drawing.Size(86, 28)
        Me.ExportFileTypes.TabIndex = 126
        Me.ExportFileTypes.Text = "Export to CSV"
        Me.ExportFileTypes.UseCustomBackColor = True
        Me.ExportFileTypes.UseCustomForeColor = True
        Me.ExportFileTypes.UseSelectable = True
        '
        'Button3
        '
        Me.Button3.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Button3.BackColor = System.Drawing.Color.AliceBlue
        Me.Button3.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.Button3.Location = New System.Drawing.Point(505, 18)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(140, 28)
        Me.Button3.TabIndex = 123
        Me.Button3.Text = "Get Associated Program"
        Me.Button3.UseCustomBackColor = True
        Me.Button3.UseCustomForeColor = True
        Me.Button3.UseSelectable = True
        '
        'Button66
        '
        Me.Button66.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Button66.BackColor = System.Drawing.Color.AliceBlue
        Me.Button66.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.Button66.Location = New System.Drawing.Point(376, 18)
        Me.Button66.Name = "Button66"
        Me.Button66.Size = New System.Drawing.Size(123, 28)
        Me.Button66.TabIndex = 122
        Me.Button66.Text = "Get File Associations"
        Me.Button66.UseCustomBackColor = True
        Me.Button66.UseCustomForeColor = True
        Me.Button66.UseSelectable = True
        '
        'TableLayoutPanel14
        '
        Me.TableLayoutPanel14.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel14.BackColor = System.Drawing.Color.Transparent
        Me.TableLayoutPanel14.ColumnCount = 1
        Me.TableLayoutPanel14.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel14.Controls.Add(Me.FileTypes, 0, 0)
        Me.TableLayoutPanel14.Location = New System.Drawing.Point(16, 51)
        Me.TableLayoutPanel14.Margin = New System.Windows.Forms.Padding(2)
        Me.TableLayoutPanel14.Name = "TableLayoutPanel14"
        Me.TableLayoutPanel14.RowCount = 1
        Me.TableLayoutPanel14.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel14.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 625.0!))
        Me.TableLayoutPanel14.Size = New System.Drawing.Size(1048, 625)
        Me.TableLayoutPanel14.TabIndex = 117
        '
        'FileTypes
        '
        Me.FileTypes.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.FileTypes.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.FileTypes.FormattingEnabled = True
        Me.FileTypes.Location = New System.Drawing.Point(3, 3)
        Me.FileTypes.Name = "FileTypes"
        Me.FileTypes.ScrollAlwaysVisible = True
        Me.FileTypes.Size = New System.Drawing.Size(1042, 615)
        Me.FileTypes.TabIndex = 76
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.BackColor = System.Drawing.Color.Transparent
        Me.Label53.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label53.Location = New System.Drawing.Point(59, 20)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(0, 16)
        Me.Label53.TabIndex = 116
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.BackColor = System.Drawing.Color.Transparent
        Me.Label40.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label40.Location = New System.Drawing.Point(59, 3)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(0, 16)
        Me.Label40.TabIndex = 113
        '
        'MetroTile4
        '
        Me.MetroTile4.ActiveControl = Nothing
        Me.MetroTile4.BackColor = System.Drawing.Color.Transparent
        Me.MetroTile4.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.MetroTile4.Location = New System.Drawing.Point(3, 3)
        Me.MetroTile4.Name = "MetroTile4"
        Me.MetroTile4.Size = New System.Drawing.Size(38, 43)
        Me.MetroTile4.TabIndex = 123
        Me.MetroTile4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MetroTile4.TileImage = CType(resources.GetObject("MetroTile4.TileImage"), System.Drawing.Image)
        Me.MetroTile4.TileImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MetroTile4.TileTextFontSize = MetroFramework.MetroTileTextSize.Small
        Me.MetroTile4.UseCustomBackColor = True
        Me.MetroTile4.UseCustomForeColor = True
        Me.MetroTile4.UseSelectable = True
        Me.MetroTile4.UseTileImage = True
        '
        'GroupsTab8
        '
        Me.GroupsTab8.Controls.Add(Me.TableLayoutPanel27)
        Me.GroupsTab8.Controls.Add(Me.TableLayoutPanel26)
        Me.GroupsTab8.Controls.Add(Me.TableLayoutPanel25)
        Me.GroupsTab8.Controls.Add(Me.Label59)
        Me.GroupsTab8.Controls.Add(Me.Label60)
        Me.GroupsTab8.Controls.Add(Me.MetroTile5)
        Me.GroupsTab8.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.GroupsTab8.HorizontalScrollbarBarColor = True
        Me.GroupsTab8.HorizontalScrollbarHighlightOnWheel = False
        Me.GroupsTab8.HorizontalScrollbarSize = 10
        Me.GroupsTab8.Location = New System.Drawing.Point(4, 34)
        Me.GroupsTab8.Name = "GroupsTab8"
        Me.GroupsTab8.Size = New System.Drawing.Size(1075, 678)
        Me.GroupsTab8.TabIndex = 4
        Me.GroupsTab8.Text = "Groups    "
        Me.GroupsTab8.VerticalScrollbarBarColor = True
        Me.GroupsTab8.VerticalScrollbarHighlightOnWheel = False
        Me.GroupsTab8.VerticalScrollbarSize = 10
        '
        'TableLayoutPanel27
        '
        Me.TableLayoutPanel27.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel27.BackColor = System.Drawing.Color.White
        Me.TableLayoutPanel27.ColumnCount = 3
        Me.TableLayoutPanel27.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40.0!))
        Me.TableLayoutPanel27.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40.0!))
        Me.TableLayoutPanel27.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20.0!))
        Me.TableLayoutPanel27.Controls.Add(Me.userlistbutton, 2, 0)
        Me.TableLayoutPanel27.Controls.Add(Me.Button5, 1, 0)
        Me.TableLayoutPanel27.Controls.Add(Me.Groups, 0, 0)
        Me.TableLayoutPanel27.Controls.Add(Me.groupview1, 0, 1)
        Me.TableLayoutPanel27.Controls.Add(Me.userview1, 1, 1)
        Me.TableLayoutPanel27.Controls.Add(Me.Userlist, 2, 1)
        Me.TableLayoutPanel27.Location = New System.Drawing.Point(0, 46)
        Me.TableLayoutPanel27.Margin = New System.Windows.Forms.Padding(2)
        Me.TableLayoutPanel27.Name = "TableLayoutPanel27"
        Me.TableLayoutPanel27.RowCount = 2
        Me.TableLayoutPanel27.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.064327!))
        Me.TableLayoutPanel27.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90.93567!))
        Me.TableLayoutPanel27.Size = New System.Drawing.Size(1072, 508)
        Me.TableLayoutPanel27.TabIndex = 92
        '
        'userlistbutton
        '
        Me.userlistbutton.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.userlistbutton.BackColor = System.Drawing.Color.AliceBlue
        Me.userlistbutton.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.userlistbutton.Location = New System.Drawing.Point(915, 19)
        Me.userlistbutton.Name = "userlistbutton"
        Me.userlistbutton.Size = New System.Drawing.Size(98, 24)
        Me.userlistbutton.TabIndex = 124
        Me.userlistbutton.Text = "Local User list"
        Me.userlistbutton.UseCustomBackColor = True
        Me.userlistbutton.UseCustomForeColor = True
        Me.userlistbutton.UseSelectable = True
        '
        'Button5
        '
        Me.Button5.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.Button5.BackColor = System.Drawing.Color.AliceBlue
        Me.Button5.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.Button5.Location = New System.Drawing.Point(568, 19)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(148, 24)
        Me.Button5.TabIndex = 123
        Me.Button5.Text = "Members of Local Group"
        Me.Button5.UseCustomBackColor = True
        Me.Button5.UseCustomForeColor = True
        Me.Button5.UseSelectable = True
        '
        'Groups
        '
        Me.Groups.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.Groups.BackColor = System.Drawing.Color.AliceBlue
        Me.Groups.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.Groups.Location = New System.Drawing.Point(165, 19)
        Me.Groups.Name = "Groups"
        Me.Groups.Size = New System.Drawing.Size(97, 24)
        Me.Groups.TabIndex = 122
        Me.Groups.Text = "Local Groups"
        Me.Groups.UseCustomBackColor = True
        Me.Groups.UseCustomForeColor = True
        Me.Groups.UseSelectable = True
        '
        'groupview1
        '
        Me.groupview1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.groupview1.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.groupview1.FormattingEnabled = True
        Me.groupview1.Location = New System.Drawing.Point(3, 49)
        Me.groupview1.Name = "groupview1"
        Me.groupview1.Size = New System.Drawing.Size(422, 456)
        Me.groupview1.TabIndex = 4
        '
        'userview1
        '
        Me.userview1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.userview1.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.userview1.FormattingEnabled = True
        Me.userview1.Location = New System.Drawing.Point(431, 49)
        Me.userview1.Name = "userview1"
        Me.userview1.Size = New System.Drawing.Size(422, 456)
        Me.userview1.TabIndex = 5
        '
        'Userlist
        '
        Me.Userlist.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Userlist.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Userlist.FormattingEnabled = True
        Me.Userlist.Location = New System.Drawing.Point(859, 49)
        Me.Userlist.Name = "Userlist"
        Me.Userlist.Size = New System.Drawing.Size(210, 456)
        Me.Userlist.TabIndex = 6
        '
        'TableLayoutPanel26
        '
        Me.TableLayoutPanel26.BackColor = System.Drawing.Color.White
        Me.TableLayoutPanel26.ColumnCount = 3
        Me.TableLayoutPanel26.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49.94965!))
        Me.TableLayoutPanel26.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 42.29607!))
        Me.TableLayoutPanel26.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.854985!))
        Me.TableLayoutPanel26.Controls.Add(Me.GROUPSVALUE2, 1, 1)
        Me.TableLayoutPanel26.Controls.Add(Me.GROUPSVALUE1, 1, 0)
        Me.TableLayoutPanel26.Controls.Add(Me.MetroLabel2, 0, 1)
        Me.TableLayoutPanel26.Controls.Add(Me.MetroLabel1, 0, 0)
        Me.TableLayoutPanel26.Controls.Add(Me.Label175, 2, 1)
        Me.TableLayoutPanel26.Controls.Add(Me.Label174, 2, 0)
        Me.TableLayoutPanel26.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.TableLayoutPanel26.Location = New System.Drawing.Point(0, 558)
        Me.TableLayoutPanel26.Margin = New System.Windows.Forms.Padding(2)
        Me.TableLayoutPanel26.Name = "TableLayoutPanel26"
        Me.TableLayoutPanel26.RowCount = 2
        Me.TableLayoutPanel26.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 52.30769!))
        Me.TableLayoutPanel26.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 47.69231!))
        Me.TableLayoutPanel26.Size = New System.Drawing.Size(1075, 65)
        Me.TableLayoutPanel26.TabIndex = 91
        '
        'GROUPSVALUE2
        '
        '
        '
        '
        Me.GROUPSVALUE2.CustomButton.Image = Nothing
        Me.GROUPSVALUE2.CustomButton.Location = New System.Drawing.Point(424, 2)
        Me.GROUPSVALUE2.CustomButton.Name = ""
        Me.GROUPSVALUE2.CustomButton.Size = New System.Drawing.Size(21, 21)
        Me.GROUPSVALUE2.CustomButton.Style = MetroFramework.MetroColorStyle.Blue
        Me.GROUPSVALUE2.CustomButton.TabIndex = 1
        Me.GROUPSVALUE2.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light
        Me.GROUPSVALUE2.CustomButton.UseSelectable = True
        Me.GROUPSVALUE2.CustomButton.Visible = False
        Me.GROUPSVALUE2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GROUPSVALUE2.Lines = New String() {"Users"}
        Me.GROUPSVALUE2.Location = New System.Drawing.Point(539, 36)
        Me.GROUPSVALUE2.MaxLength = 32767
        Me.GROUPSVALUE2.Name = "GROUPSVALUE2"
        Me.GROUPSVALUE2.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.GROUPSVALUE2.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.GROUPSVALUE2.SelectedText = ""
        Me.GROUPSVALUE2.SelectionLength = 0
        Me.GROUPSVALUE2.SelectionStart = 0
        Me.GROUPSVALUE2.Size = New System.Drawing.Size(448, 26)
        Me.GROUPSVALUE2.TabIndex = 94
        Me.GROUPSVALUE2.Text = "Users"
        Me.GROUPSVALUE2.UseSelectable = True
        Me.GROUPSVALUE2.WaterMarkColor = System.Drawing.Color.FromArgb(CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.GROUPSVALUE2.WaterMarkFont = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel)
        '
        'GROUPSVALUE1
        '
        '
        '
        '
        Me.GROUPSVALUE1.CustomButton.Image = Nothing
        Me.GROUPSVALUE1.CustomButton.Location = New System.Drawing.Point(422, 1)
        Me.GROUPSVALUE1.CustomButton.Name = ""
        Me.GROUPSVALUE1.CustomButton.Size = New System.Drawing.Size(25, 25)
        Me.GROUPSVALUE1.CustomButton.Style = MetroFramework.MetroColorStyle.Blue
        Me.GROUPSVALUE1.CustomButton.TabIndex = 1
        Me.GROUPSVALUE1.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light
        Me.GROUPSVALUE1.CustomButton.UseSelectable = True
        Me.GROUPSVALUE1.CustomButton.Visible = False
        Me.GROUPSVALUE1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GROUPSVALUE1.Lines = New String() {"Domain Users"}
        Me.GROUPSVALUE1.Location = New System.Drawing.Point(539, 3)
        Me.GROUPSVALUE1.MaxLength = 32767
        Me.GROUPSVALUE1.Name = "GROUPSVALUE1"
        Me.GROUPSVALUE1.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.GROUPSVALUE1.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.GROUPSVALUE1.SelectedText = ""
        Me.GROUPSVALUE1.SelectionLength = 0
        Me.GROUPSVALUE1.SelectionStart = 0
        Me.GROUPSVALUE1.Size = New System.Drawing.Size(448, 27)
        Me.GROUPSVALUE1.TabIndex = 94
        Me.GROUPSVALUE1.Text = "Domain Users"
        Me.GROUPSVALUE1.UseSelectable = True
        Me.GROUPSVALUE1.WaterMarkColor = System.Drawing.Color.FromArgb(CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.GROUPSVALUE1.WaterMarkFont = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel)
        '
        'MetroLabel2
        '
        Me.MetroLabel2.AutoSize = True
        Me.MetroLabel2.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.MetroLabel2.FontSize = MetroFramework.MetroLabelSize.Small
        Me.MetroLabel2.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.MetroLabel2.Location = New System.Drawing.Point(3, 33)
        Me.MetroLabel2.Name = "MetroLabel2"
        Me.MetroLabel2.Size = New System.Drawing.Size(530, 32)
        Me.MetroLabel2.TabIndex = 95
        Me.MetroLabel2.Text = "Select from ""Local Groups"" List above or Type ""Username"" or ""Groupname"" here  , e" &
    ".g. >"
        Me.MetroLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.MetroLabel2.UseCustomBackColor = True
        Me.MetroLabel2.UseCustomForeColor = True
        '
        'MetroLabel1
        '
        Me.MetroLabel1.AutoSize = True
        Me.MetroLabel1.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.MetroLabel1.FontSize = MetroFramework.MetroLabelSize.Small
        Me.MetroLabel1.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.MetroLabel1.Location = New System.Drawing.Point(3, 0)
        Me.MetroLabel1.Name = "MetroLabel1"
        Me.MetroLabel1.Size = New System.Drawing.Size(530, 33)
        Me.MetroLabel1.TabIndex = 94
        Me.MetroLabel1.Text = "Type here ""Username"" or ""Groupname"" or ""Domain Group name"" , e.g. >"
        Me.MetroLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.MetroLabel1.UseCustomBackColor = True
        Me.MetroLabel1.UseCustomForeColor = True
        '
        'Label175
        '
        Me.Label175.AutoSize = True
        Me.Label175.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label175.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Label175.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.Label175.Location = New System.Drawing.Point(993, 33)
        Me.Label175.Name = "Label175"
        Me.Label175.Size = New System.Drawing.Size(79, 32)
        Me.Label175.TabIndex = 86
        Me.Label175.Text = "< {BOTTOM}"
        Me.Label175.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label174
        '
        Me.Label174.AutoSize = True
        Me.Label174.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label174.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Label174.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.Label174.Location = New System.Drawing.Point(993, 0)
        Me.Label174.Name = "Label174"
        Me.Label174.Size = New System.Drawing.Size(79, 33)
        Me.Label174.TabIndex = 16
        Me.Label174.Text = "< {TOP}"
        Me.Label174.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TableLayoutPanel25
        '
        Me.TableLayoutPanel25.BackColor = System.Drawing.Color.Transparent
        Me.TableLayoutPanel25.ColumnCount = 4
        Me.TableLayoutPanel25.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 18.95492!))
        Me.TableLayoutPanel25.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.0082!))
        Me.TableLayoutPanel25.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 28.89344!))
        Me.TableLayoutPanel25.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 35.34836!))
        Me.TableLayoutPanel25.Controls.Add(Me.adddomaintolocal, 3, 0)
        Me.TableLayoutPanel25.Controls.Add(Me.addlocalusertolocalgroup, 2, 0)
        Me.TableLayoutPanel25.Controls.Add(Me.removeuser, 0, 1)
        Me.TableLayoutPanel25.Controls.Add(Me.removelocaluser, 0, 1)
        Me.TableLayoutPanel25.Controls.Add(Me.Addlocalgroup, 0, 0)
        Me.TableLayoutPanel25.Controls.Add(Me.addlocaluser, 1, 0)
        Me.TableLayoutPanel25.Controls.Add(Me.removedomainfromlocal, 2, 1)
        Me.TableLayoutPanel25.Controls.Add(Me.removelocalgroup, 0, 1)
        Me.TableLayoutPanel25.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.TableLayoutPanel25.Location = New System.Drawing.Point(0, 623)
        Me.TableLayoutPanel25.Margin = New System.Windows.Forms.Padding(2)
        Me.TableLayoutPanel25.Name = "TableLayoutPanel25"
        Me.TableLayoutPanel25.RowCount = 2
        Me.TableLayoutPanel25.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel25.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel25.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel25.Size = New System.Drawing.Size(1075, 55)
        Me.TableLayoutPanel25.TabIndex = 90
        '
        'adddomaintolocal
        '
        Me.adddomaintolocal.BackColor = System.Drawing.Color.Transparent
        Me.adddomaintolocal.Dock = System.Windows.Forms.DockStyle.Fill
        Me.adddomaintolocal.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.adddomaintolocal.Location = New System.Drawing.Point(697, 3)
        Me.adddomaintolocal.Name = "adddomaintolocal"
        Me.adddomaintolocal.Size = New System.Drawing.Size(375, 21)
        Me.adddomaintolocal.TabIndex = 127
        Me.adddomaintolocal.Text = "Add Domain User or Group {TOP} into Local Group {BOTTOM}"
        Me.adddomaintolocal.UseCustomBackColor = True
        Me.adddomaintolocal.UseCustomForeColor = True
        Me.adddomaintolocal.UseSelectable = True
        '
        'addlocalusertolocalgroup
        '
        Me.addlocalusertolocalgroup.BackColor = System.Drawing.Color.Transparent
        Me.addlocalusertolocalgroup.Dock = System.Windows.Forms.DockStyle.Fill
        Me.addlocalusertolocalgroup.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.addlocalusertolocalgroup.Location = New System.Drawing.Point(388, 3)
        Me.addlocalusertolocalgroup.Name = "addlocalusertolocalgroup"
        Me.addlocalusertolocalgroup.Size = New System.Drawing.Size(303, 21)
        Me.addlocalusertolocalgroup.TabIndex = 127
        Me.addlocalusertolocalgroup.Text = "Add Local User {TOP} into Local Group {BOTTOM}"
        Me.addlocalusertolocalgroup.UseCustomBackColor = True
        Me.addlocalusertolocalgroup.UseCustomForeColor = True
        Me.addlocalusertolocalgroup.UseSelectable = True
        '
        'removeuser
        '
        Me.removeuser.BackColor = System.Drawing.Color.Transparent
        Me.removeuser.Dock = System.Windows.Forms.DockStyle.Fill
        Me.removeuser.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.removeuser.Location = New System.Drawing.Point(206, 30)
        Me.removeuser.Name = "removeuser"
        Me.removeuser.Size = New System.Drawing.Size(176, 22)
        Me.removeuser.TabIndex = 130
        Me.removeuser.Text = "Remove Local User {TOP}"
        Me.removeuser.UseCustomBackColor = True
        Me.removeuser.UseCustomForeColor = True
        Me.removeuser.UseSelectable = True
        '
        'removelocaluser
        '
        Me.removelocaluser.BackColor = System.Drawing.Color.Transparent
        Me.removelocaluser.Dock = System.Windows.Forms.DockStyle.Fill
        Me.removelocaluser.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.removelocaluser.Location = New System.Drawing.Point(388, 30)
        Me.removelocaluser.Name = "removelocaluser"
        Me.removelocaluser.Size = New System.Drawing.Size(303, 22)
        Me.removelocaluser.TabIndex = 127
        Me.removelocaluser.Text = "Rem Local User {TOP} from Local Group {BOTTOM}"
        Me.removelocaluser.UseCustomBackColor = True
        Me.removelocaluser.UseCustomForeColor = True
        Me.removelocaluser.UseSelectable = True
        '
        'Addlocalgroup
        '
        Me.Addlocalgroup.BackColor = System.Drawing.Color.Transparent
        Me.Addlocalgroup.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Addlocalgroup.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.Addlocalgroup.Location = New System.Drawing.Point(3, 3)
        Me.Addlocalgroup.Name = "Addlocalgroup"
        Me.Addlocalgroup.Size = New System.Drawing.Size(197, 21)
        Me.Addlocalgroup.TabIndex = 124
        Me.Addlocalgroup.Text = "Add Local Group {TOP}"
        Me.Addlocalgroup.UseCustomBackColor = True
        Me.Addlocalgroup.UseCustomForeColor = True
        Me.Addlocalgroup.UseSelectable = True
        '
        'addlocaluser
        '
        Me.addlocaluser.BackColor = System.Drawing.Color.Transparent
        Me.addlocaluser.Dock = System.Windows.Forms.DockStyle.Fill
        Me.addlocaluser.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.addlocaluser.Location = New System.Drawing.Point(206, 3)
        Me.addlocaluser.Name = "addlocaluser"
        Me.addlocaluser.Size = New System.Drawing.Size(176, 21)
        Me.addlocaluser.TabIndex = 126
        Me.addlocaluser.Text = "Add Local User {TOP}"
        Me.addlocaluser.UseCustomBackColor = True
        Me.addlocaluser.UseCustomForeColor = True
        Me.addlocaluser.UseSelectable = True
        '
        'removedomainfromlocal
        '
        Me.removedomainfromlocal.BackColor = System.Drawing.Color.Transparent
        Me.removedomainfromlocal.Dock = System.Windows.Forms.DockStyle.Fill
        Me.removedomainfromlocal.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.removedomainfromlocal.Location = New System.Drawing.Point(697, 30)
        Me.removedomainfromlocal.Name = "removedomainfromlocal"
        Me.removedomainfromlocal.Size = New System.Drawing.Size(375, 22)
        Me.removedomainfromlocal.TabIndex = 129
        Me.removedomainfromlocal.Text = "Rem Domain User or Group {TOP} from Local Group {BOTTOM}"
        Me.removedomainfromlocal.UseCustomBackColor = True
        Me.removedomainfromlocal.UseCustomForeColor = True
        Me.removedomainfromlocal.UseSelectable = True
        '
        'removelocalgroup
        '
        Me.removelocalgroup.BackColor = System.Drawing.Color.Transparent
        Me.removelocalgroup.Dock = System.Windows.Forms.DockStyle.Fill
        Me.removelocalgroup.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.removelocalgroup.Location = New System.Drawing.Point(3, 30)
        Me.removelocalgroup.Name = "removelocalgroup"
        Me.removelocalgroup.Size = New System.Drawing.Size(197, 22)
        Me.removelocalgroup.TabIndex = 128
        Me.removelocalgroup.Text = "Remove Local Group {BOTTOM}"
        Me.removelocalgroup.UseCustomBackColor = True
        Me.removelocalgroup.UseCustomForeColor = True
        Me.removelocalgroup.UseSelectable = True
        '
        'Label59
        '
        Me.Label59.AutoSize = True
        Me.Label59.BackColor = System.Drawing.Color.Transparent
        Me.Label59.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label59.Location = New System.Drawing.Point(59, 20)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(0, 16)
        Me.Label59.TabIndex = 89
        '
        'Label60
        '
        Me.Label60.AutoSize = True
        Me.Label60.BackColor = System.Drawing.Color.Transparent
        Me.Label60.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label60.Location = New System.Drawing.Point(59, 3)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(0, 16)
        Me.Label60.TabIndex = 88
        '
        'MetroTile5
        '
        Me.MetroTile5.ActiveControl = Nothing
        Me.MetroTile5.BackColor = System.Drawing.Color.Transparent
        Me.MetroTile5.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.MetroTile5.Location = New System.Drawing.Point(3, 3)
        Me.MetroTile5.Name = "MetroTile5"
        Me.MetroTile5.Size = New System.Drawing.Size(38, 43)
        Me.MetroTile5.TabIndex = 124
        Me.MetroTile5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MetroTile5.TileImage = CType(resources.GetObject("MetroTile5.TileImage"), System.Drawing.Image)
        Me.MetroTile5.TileImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MetroTile5.TileTextFontSize = MetroFramework.MetroTileTextSize.Small
        Me.MetroTile5.UseCustomBackColor = True
        Me.MetroTile5.UseCustomForeColor = True
        Me.MetroTile5.UseSelectable = True
        Me.MetroTile5.UseTileImage = True
        '
        'instSoftwareTab9
        '
        Me.instSoftwareTab9.Controls.Add(Me.SearchProgramBox)
        Me.instSoftwareTab9.Controls.Add(Me.SearchProgramButton)
        Me.instSoftwareTab9.Controls.Add(Me.ExportFullSoftwareList)
        Me.instSoftwareTab9.Controls.Add(Me.GetSoftwareList)
        Me.instSoftwareTab9.Controls.Add(Me.TableLayoutPanel16)
        Me.instSoftwareTab9.Controls.Add(Me.TableLayoutPanel15)
        Me.instSoftwareTab9.Controls.Add(Me.Label54)
        Me.instSoftwareTab9.Controls.Add(Me.Label44)
        Me.instSoftwareTab9.Controls.Add(Me.MetroTile8)
        Me.instSoftwareTab9.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.instSoftwareTab9.HorizontalScrollbar = True
        Me.instSoftwareTab9.HorizontalScrollbarBarColor = True
        Me.instSoftwareTab9.HorizontalScrollbarHighlightOnWheel = False
        Me.instSoftwareTab9.HorizontalScrollbarSize = 10
        Me.instSoftwareTab9.Location = New System.Drawing.Point(4, 34)
        Me.instSoftwareTab9.Name = "instSoftwareTab9"
        Me.instSoftwareTab9.Size = New System.Drawing.Size(1075, 678)
        Me.instSoftwareTab9.TabIndex = 10
        Me.instSoftwareTab9.Text = "Installed Software"
        Me.instSoftwareTab9.VerticalScrollbarBarColor = True
        Me.instSoftwareTab9.VerticalScrollbarHighlightOnWheel = False
        Me.instSoftwareTab9.VerticalScrollbarSize = 10
        '
        'SearchProgramBox
        '
        Me.SearchProgramBox.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        '
        '
        '
        Me.SearchProgramBox.CustomButton.Image = Nothing
        Me.SearchProgramBox.CustomButton.Location = New System.Drawing.Point(196, 1)
        Me.SearchProgramBox.CustomButton.Name = ""
        Me.SearchProgramBox.CustomButton.Size = New System.Drawing.Size(21, 21)
        Me.SearchProgramBox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue
        Me.SearchProgramBox.CustomButton.TabIndex = 1
        Me.SearchProgramBox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light
        Me.SearchProgramBox.CustomButton.UseSelectable = True
        Me.SearchProgramBox.CustomButton.Visible = False
        Me.SearchProgramBox.Lines = New String() {"Search.."}
        Me.SearchProgramBox.Location = New System.Drawing.Point(632, 12)
        Me.SearchProgramBox.MaxLength = 32767
        Me.SearchProgramBox.Name = "SearchProgramBox"
        Me.SearchProgramBox.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.SearchProgramBox.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.SearchProgramBox.SelectedText = ""
        Me.SearchProgramBox.SelectionLength = 0
        Me.SearchProgramBox.SelectionStart = 0
        Me.SearchProgramBox.Size = New System.Drawing.Size(218, 23)
        Me.SearchProgramBox.TabIndex = 129
        Me.SearchProgramBox.Text = "Search.."
        Me.SearchProgramBox.UseSelectable = True
        Me.SearchProgramBox.WaterMarkColor = System.Drawing.Color.FromArgb(CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.SearchProgramBox.WaterMarkFont = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel)
        '
        'SearchProgramButton
        '
        Me.SearchProgramButton.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.SearchProgramButton.BackColor = System.Drawing.Color.AliceBlue
        Me.SearchProgramButton.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.SearchProgramButton.Location = New System.Drawing.Point(856, 7)
        Me.SearchProgramButton.Name = "SearchProgramButton"
        Me.SearchProgramButton.Size = New System.Drawing.Size(121, 28)
        Me.SearchProgramButton.TabIndex = 128
        Me.SearchProgramButton.Text = "Search for a Program"
        Me.SearchProgramButton.UseCustomBackColor = True
        Me.SearchProgramButton.UseCustomForeColor = True
        Me.SearchProgramButton.UseSelectable = True
        '
        'ExportFullSoftwareList
        '
        Me.ExportFullSoftwareList.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ExportFullSoftwareList.BackColor = System.Drawing.Color.AliceBlue
        Me.ExportFullSoftwareList.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.ExportFullSoftwareList.Location = New System.Drawing.Point(983, 7)
        Me.ExportFullSoftwareList.Name = "ExportFullSoftwareList"
        Me.ExportFullSoftwareList.Size = New System.Drawing.Size(86, 28)
        Me.ExportFullSoftwareList.TabIndex = 127
        Me.ExportFullSoftwareList.Text = "Export to CSV"
        Me.ExportFullSoftwareList.UseCustomBackColor = True
        Me.ExportFullSoftwareList.UseCustomForeColor = True
        Me.ExportFullSoftwareList.UseSelectable = True
        '
        'GetSoftwareList
        '
        Me.GetSoftwareList.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.GetSoftwareList.BackColor = System.Drawing.Color.AliceBlue
        Me.GetSoftwareList.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.GetSoftwareList.Location = New System.Drawing.Point(375, 7)
        Me.GetSoftwareList.Name = "GetSoftwareList"
        Me.GetSoftwareList.Size = New System.Drawing.Size(158, 28)
        Me.GetSoftwareList.TabIndex = 126
        Me.GetSoftwareList.Text = "List All Programs && Features"
        Me.GetSoftwareList.UseCustomBackColor = True
        Me.GetSoftwareList.UseCustomForeColor = True
        Me.GetSoftwareList.UseSelectable = True
        '
        'TableLayoutPanel16
        '
        Me.TableLayoutPanel16.BackColor = System.Drawing.Color.Transparent
        Me.TableLayoutPanel16.ColumnCount = 2
        Me.TableLayoutPanel16.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60.78629!))
        Me.TableLayoutPanel16.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 39.21371!))
        Me.TableLayoutPanel16.Controls.Add(Me.TextBox1, 0, 0)
        Me.TableLayoutPanel16.Controls.Add(Me.MSIUNINSTALL, 1, 0)
        Me.TableLayoutPanel16.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.TableLayoutPanel16.Location = New System.Drawing.Point(0, 646)
        Me.TableLayoutPanel16.Margin = New System.Windows.Forms.Padding(2)
        Me.TableLayoutPanel16.Name = "TableLayoutPanel16"
        Me.TableLayoutPanel16.RowCount = 1
        Me.TableLayoutPanel16.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel16.Size = New System.Drawing.Size(1075, 32)
        Me.TableLayoutPanel16.TabIndex = 119
        '
        'TextBox1
        '
        '
        '
        '
        Me.TextBox1.CustomButton.Image = Nothing
        Me.TextBox1.CustomButton.Location = New System.Drawing.Point(623, 2)
        Me.TextBox1.CustomButton.Name = ""
        Me.TextBox1.CustomButton.Size = New System.Drawing.Size(21, 21)
        Me.TextBox1.CustomButton.Style = MetroFramework.MetroColorStyle.Blue
        Me.TextBox1.CustomButton.TabIndex = 1
        Me.TextBox1.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light
        Me.TextBox1.CustomButton.UseSelectable = True
        Me.TextBox1.CustomButton.Visible = False
        Me.TextBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TextBox1.Lines = New String(-1) {}
        Me.TextBox1.Location = New System.Drawing.Point(3, 3)
        Me.TextBox1.MaxLength = 32767
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TextBox1.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.TextBox1.SelectedText = ""
        Me.TextBox1.SelectionLength = 0
        Me.TextBox1.SelectionStart = 0
        Me.TextBox1.Size = New System.Drawing.Size(647, 26)
        Me.TextBox1.TabIndex = 128
        Me.TextBox1.UseSelectable = True
        Me.TextBox1.WaterMarkColor = System.Drawing.Color.FromArgb(CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.TextBox1.WaterMarkFont = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel)
        '
        'MSIUNINSTALL
        '
        Me.MSIUNINSTALL.BackColor = System.Drawing.Color.Transparent
        Me.MSIUNINSTALL.Dock = System.Windows.Forms.DockStyle.Fill
        Me.MSIUNINSTALL.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.MSIUNINSTALL.Location = New System.Drawing.Point(656, 3)
        Me.MSIUNINSTALL.Name = "MSIUNINSTALL"
        Me.MSIUNINSTALL.Size = New System.Drawing.Size(416, 26)
        Me.MSIUNINSTALL.TabIndex = 128
        Me.MSIUNINSTALL.Text = "Uninstall software highlighted above using this button. (MSI only!)"
        Me.MSIUNINSTALL.UseCustomBackColor = True
        Me.MSIUNINSTALL.UseCustomForeColor = True
        Me.MSIUNINSTALL.UseSelectable = True
        '
        'TableLayoutPanel15
        '
        Me.TableLayoutPanel15.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel15.BackColor = System.Drawing.Color.Transparent
        Me.TableLayoutPanel15.ColumnCount = 1
        Me.TableLayoutPanel15.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel15.Controls.Add(Me.DataGridView1, 0, 0)
        Me.TableLayoutPanel15.Location = New System.Drawing.Point(0, 43)
        Me.TableLayoutPanel15.Margin = New System.Windows.Forms.Padding(2)
        Me.TableLayoutPanel15.Name = "TableLayoutPanel15"
        Me.TableLayoutPanel15.RowCount = 1
        Me.TableLayoutPanel15.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel15.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 599.0!))
        Me.TableLayoutPanel15.Size = New System.Drawing.Size(1072, 599)
        Me.TableLayoutPanel15.TabIndex = 118
        '
        'DataGridView1
        '
        Me.DataGridView1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView1.BackgroundColor = System.Drawing.SystemColors.Window
        Me.DataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.SoftwareName, Me.SoftwareVersion, Me.InstallDate, Me.KeyName})
        Me.DataGridView1.Location = New System.Drawing.Point(3, 3)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowHeadersVisible = False
        Me.DataGridView1.RowTemplate.Height = 24
        Me.DataGridView1.Size = New System.Drawing.Size(1066, 593)
        Me.DataGridView1.TabIndex = 56
        '
        'SoftwareName
        '
        Me.SoftwareName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.SoftwareName.HeaderText = "SoftwareName"
        Me.SoftwareName.Name = "SoftwareName"
        Me.SoftwareName.ReadOnly = True
        '
        'SoftwareVersion
        '
        Me.SoftwareVersion.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.SoftwareVersion.FillWeight = 40.0!
        Me.SoftwareVersion.HeaderText = "SoftwareVersion"
        Me.SoftwareVersion.Name = "SoftwareVersion"
        Me.SoftwareVersion.ReadOnly = True
        '
        'InstallDate
        '
        Me.InstallDate.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.InstallDate.FillWeight = 33.0!
        Me.InstallDate.HeaderText = "Install Date"
        Me.InstallDate.MinimumWidth = 10
        Me.InstallDate.Name = "InstallDate"
        Me.InstallDate.ReadOnly = True
        Me.InstallDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'KeyName
        '
        Me.KeyName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.KeyName.HeaderText = "KeyName"
        Me.KeyName.Name = "KeyName"
        Me.KeyName.ReadOnly = True
        '
        'Label54
        '
        Me.Label54.AutoSize = True
        Me.Label54.BackColor = System.Drawing.Color.Transparent
        Me.Label54.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label54.Location = New System.Drawing.Point(57, 20)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(0, 16)
        Me.Label54.TabIndex = 117
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.BackColor = System.Drawing.Color.Transparent
        Me.Label44.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label44.Location = New System.Drawing.Point(57, 3)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(0, 16)
        Me.Label44.TabIndex = 115
        '
        'MetroTile8
        '
        Me.MetroTile8.ActiveControl = Nothing
        Me.MetroTile8.BackColor = System.Drawing.Color.Transparent
        Me.MetroTile8.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.MetroTile8.Location = New System.Drawing.Point(3, 3)
        Me.MetroTile8.Name = "MetroTile8"
        Me.MetroTile8.Size = New System.Drawing.Size(38, 43)
        Me.MetroTile8.TabIndex = 127
        Me.MetroTile8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MetroTile8.TileImage = CType(resources.GetObject("MetroTile8.TileImage"), System.Drawing.Image)
        Me.MetroTile8.TileImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MetroTile8.TileTextFontSize = MetroFramework.MetroTileTextSize.Small
        Me.MetroTile8.UseCustomBackColor = True
        Me.MetroTile8.UseCustomForeColor = True
        Me.MetroTile8.UseSelectable = True
        Me.MetroTile8.UseTileImage = True
        '
        'WUtab10
        '
        Me.WUtab10.Controls.Add(Me.TableLayoutPanel20)
        Me.WUtab10.Controls.Add(Me.UpdatesLabel)
        Me.WUtab10.Controls.Add(Me.SecurityPatchesBUT)
        Me.WUtab10.Controls.Add(Me.ExportPatches)
        Me.WUtab10.Controls.Add(Me.OtherUpdates)
        Me.WUtab10.Controls.Add(Me.TableLayoutPanel37)
        Me.WUtab10.Controls.Add(Me.Label55)
        Me.WUtab10.Controls.Add(Me.Label46)
        Me.WUtab10.Controls.Add(Me.MetroTile7)
        Me.WUtab10.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.WUtab10.HorizontalScrollbarBarColor = True
        Me.WUtab10.HorizontalScrollbarHighlightOnWheel = False
        Me.WUtab10.HorizontalScrollbarSize = 10
        Me.WUtab10.Location = New System.Drawing.Point(4, 34)
        Me.WUtab10.Name = "WUtab10"
        Me.WUtab10.Size = New System.Drawing.Size(1075, 678)
        Me.WUtab10.TabIndex = 6
        Me.WUtab10.Text = "KB-Installed"
        Me.WUtab10.VerticalScrollbarBarColor = True
        Me.WUtab10.VerticalScrollbarHighlightOnWheel = False
        Me.WUtab10.VerticalScrollbarSize = 10
        '
        'TableLayoutPanel20
        '
        Me.TableLayoutPanel20.BackColor = System.Drawing.Color.Transparent
        Me.TableLayoutPanel20.ColumnCount = 1
        Me.TableLayoutPanel20.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel20.Controls.Add(Me.KBTextBox, 0, 0)
        Me.TableLayoutPanel20.Controls.Add(Me.KBRemoveButton, 0, 1)
        Me.TableLayoutPanel20.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.TableLayoutPanel20.Location = New System.Drawing.Point(0, 618)
        Me.TableLayoutPanel20.Margin = New System.Windows.Forms.Padding(2)
        Me.TableLayoutPanel20.Name = "TableLayoutPanel20"
        Me.TableLayoutPanel20.RowCount = 2
        Me.TableLayoutPanel20.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 43.63636!))
        Me.TableLayoutPanel20.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 56.36364!))
        Me.TableLayoutPanel20.Size = New System.Drawing.Size(1075, 60)
        Me.TableLayoutPanel20.TabIndex = 130
        '
        'KBTextBox
        '
        '
        '
        '
        Me.KBTextBox.CustomButton.Image = Nothing
        Me.KBTextBox.CustomButton.Location = New System.Drawing.Point(1051, 2)
        Me.KBTextBox.CustomButton.Name = ""
        Me.KBTextBox.CustomButton.Size = New System.Drawing.Size(15, 15)
        Me.KBTextBox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue
        Me.KBTextBox.CustomButton.TabIndex = 1
        Me.KBTextBox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light
        Me.KBTextBox.CustomButton.UseSelectable = True
        Me.KBTextBox.CustomButton.Visible = False
        Me.KBTextBox.Dock = System.Windows.Forms.DockStyle.Fill
        Me.KBTextBox.Lines = New String(-1) {}
        Me.KBTextBox.Location = New System.Drawing.Point(3, 3)
        Me.KBTextBox.MaxLength = 32767
        Me.KBTextBox.Name = "KBTextBox"
        Me.KBTextBox.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.KBTextBox.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.KBTextBox.SelectedText = ""
        Me.KBTextBox.SelectionLength = 0
        Me.KBTextBox.SelectionStart = 0
        Me.KBTextBox.Size = New System.Drawing.Size(1069, 20)
        Me.KBTextBox.TabIndex = 130
        Me.KBTextBox.UseSelectable = True
        Me.KBTextBox.WaterMarkColor = System.Drawing.Color.FromArgb(CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.KBTextBox.WaterMarkFont = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel)
        '
        'KBRemoveButton
        '
        Me.KBRemoveButton.BackColor = System.Drawing.Color.AliceBlue
        Me.KBRemoveButton.Dock = System.Windows.Forms.DockStyle.Fill
        Me.KBRemoveButton.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.KBRemoveButton.Location = New System.Drawing.Point(3, 29)
        Me.KBRemoveButton.Name = "KBRemoveButton"
        Me.KBRemoveButton.Size = New System.Drawing.Size(1069, 28)
        Me.KBRemoveButton.TabIndex = 130
        Me.KBRemoveButton.Text = "Select KB from table above. Uninstall using this button (Windows 7 or newer) Comm" &
    "and string will get generated and then executed."
        Me.KBRemoveButton.UseCustomBackColor = True
        Me.KBRemoveButton.UseCustomForeColor = True
        Me.KBRemoveButton.UseSelectable = True
        '
        'UpdatesLabel
        '
        Me.UpdatesLabel.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.UpdatesLabel.BackColor = System.Drawing.Color.Transparent
        Me.UpdatesLabel.FontSize = MetroFramework.MetroLabelSize.Small
        Me.UpdatesLabel.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.UpdatesLabel.Location = New System.Drawing.Point(723, 10)
        Me.UpdatesLabel.Name = "UpdatesLabel"
        Me.UpdatesLabel.Size = New System.Drawing.Size(216, 27)
        Me.UpdatesLabel.TabIndex = 129
        Me.UpdatesLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'SecurityPatchesBUT
        '
        Me.SecurityPatchesBUT.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.SecurityPatchesBUT.BackColor = System.Drawing.Color.AliceBlue
        Me.SecurityPatchesBUT.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.SecurityPatchesBUT.Location = New System.Drawing.Point(376, 8)
        Me.SecurityPatchesBUT.Name = "SecurityPatchesBUT"
        Me.SecurityPatchesBUT.Size = New System.Drawing.Size(155, 28)
        Me.SecurityPatchesBUT.TabIndex = 128
        Me.SecurityPatchesBUT.Text = "Display Windows Updates"
        Me.SecurityPatchesBUT.UseCustomBackColor = True
        Me.SecurityPatchesBUT.UseCustomForeColor = True
        Me.SecurityPatchesBUT.UseSelectable = True
        '
        'ExportPatches
        '
        Me.ExportPatches.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ExportPatches.BackColor = System.Drawing.Color.AliceBlue
        Me.ExportPatches.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.ExportPatches.Location = New System.Drawing.Point(983, 9)
        Me.ExportPatches.Name = "ExportPatches"
        Me.ExportPatches.Size = New System.Drawing.Size(86, 28)
        Me.ExportPatches.TabIndex = 127
        Me.ExportPatches.Text = "Export to CSV"
        Me.ExportPatches.UseCustomBackColor = True
        Me.ExportPatches.UseCustomForeColor = True
        Me.ExportPatches.UseSelectable = True
        '
        'OtherUpdates
        '
        Me.OtherUpdates.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.OtherUpdates.BackColor = System.Drawing.Color.AliceBlue
        Me.OtherUpdates.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.OtherUpdates.Location = New System.Drawing.Point(537, 8)
        Me.OtherUpdates.Name = "OtherUpdates"
        Me.OtherUpdates.Size = New System.Drawing.Size(142, 28)
        Me.OtherUpdates.TabIndex = 126
        Me.OtherUpdates.Text = "Display Other Updates"
        Me.OtherUpdates.UseCustomBackColor = True
        Me.OtherUpdates.UseCustomForeColor = True
        Me.OtherUpdates.UseSelectable = True
        '
        'TableLayoutPanel37
        '
        Me.TableLayoutPanel37.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel37.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.TableLayoutPanel37.BackColor = System.Drawing.Color.Transparent
        Me.TableLayoutPanel37.ColumnCount = 1
        Me.TableLayoutPanel37.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel37.Controls.Add(Me.DataGridView10, 0, 0)
        Me.TableLayoutPanel37.Location = New System.Drawing.Point(3, 47)
        Me.TableLayoutPanel37.Name = "TableLayoutPanel37"
        Me.TableLayoutPanel37.RowCount = 1
        Me.TableLayoutPanel37.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel37.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 566.0!))
        Me.TableLayoutPanel37.Size = New System.Drawing.Size(1069, 566)
        Me.TableLayoutPanel37.TabIndex = 121
        '
        'DataGridView10
        '
        Me.DataGridView10.AllowUserToOrderColumns = True
        Me.DataGridView10.AllowUserToResizeRows = False
        Me.DataGridView10.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DataGridView10.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView10.BackgroundColor = System.Drawing.SystemColors.Window
        Me.DataGridView10.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView10.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn7, Me.DataGridViewTextBoxColumn11, Me.DataGridViewTextBoxColumn12, Me.DataGridViewTextBoxColumn13})
        Me.DataGridView10.Location = New System.Drawing.Point(3, 3)
        Me.DataGridView10.Name = "DataGridView10"
        Me.DataGridView10.RowHeadersVisible = False
        Me.DataGridView10.RowTemplate.Height = 24
        Me.DataGridView10.Size = New System.Drawing.Size(1063, 560)
        Me.DataGridView10.TabIndex = 86
        '
        'DataGridViewTextBoxColumn7
        '
        Me.DataGridViewTextBoxColumn7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        Me.DataGridViewTextBoxColumn7.FillWeight = 50.0!
        Me.DataGridViewTextBoxColumn7.Frozen = True
        Me.DataGridViewTextBoxColumn7.HeaderText = "HotFixID"
        Me.DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7"
        Me.DataGridViewTextBoxColumn7.ReadOnly = True
        Me.DataGridViewTextBoxColumn7.Width = 186
        '
        'DataGridViewTextBoxColumn11
        '
        Me.DataGridViewTextBoxColumn11.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        Me.DataGridViewTextBoxColumn11.FillWeight = 50.0!
        Me.DataGridViewTextBoxColumn11.HeaderText = "Installed On Date"
        Me.DataGridViewTextBoxColumn11.Name = "DataGridViewTextBoxColumn11"
        Me.DataGridViewTextBoxColumn11.ReadOnly = True
        Me.DataGridViewTextBoxColumn11.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn11.Width = 185
        '
        'DataGridViewTextBoxColumn12
        '
        Me.DataGridViewTextBoxColumn12.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn12.FillWeight = 50.0!
        Me.DataGridViewTextBoxColumn12.HeaderText = "Description"
        Me.DataGridViewTextBoxColumn12.MinimumWidth = 10
        Me.DataGridViewTextBoxColumn12.Name = "DataGridViewTextBoxColumn12"
        Me.DataGridViewTextBoxColumn12.ReadOnly = True
        '
        'DataGridViewTextBoxColumn13
        '
        Me.DataGridViewTextBoxColumn13.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn13.FillWeight = 50.0!
        Me.DataGridViewTextBoxColumn13.HeaderText = "Caption"
        Me.DataGridViewTextBoxColumn13.Name = "DataGridViewTextBoxColumn13"
        Me.DataGridViewTextBoxColumn13.ReadOnly = True
        '
        'Label55
        '
        Me.Label55.AutoSize = True
        Me.Label55.BackColor = System.Drawing.Color.Transparent
        Me.Label55.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label55.Location = New System.Drawing.Point(61, 20)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(0, 16)
        Me.Label55.TabIndex = 116
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.BackColor = System.Drawing.Color.Transparent
        Me.Label46.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label46.Location = New System.Drawing.Point(61, 3)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(0, 16)
        Me.Label46.TabIndex = 114
        '
        'MetroTile7
        '
        Me.MetroTile7.ActiveControl = Nothing
        Me.MetroTile7.BackColor = System.Drawing.Color.Transparent
        Me.MetroTile7.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.MetroTile7.Location = New System.Drawing.Point(3, 3)
        Me.MetroTile7.Name = "MetroTile7"
        Me.MetroTile7.Size = New System.Drawing.Size(38, 43)
        Me.MetroTile7.TabIndex = 126
        Me.MetroTile7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MetroTile7.TileImage = CType(resources.GetObject("MetroTile7.TileImage"), System.Drawing.Image)
        Me.MetroTile7.TileImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MetroTile7.TileTextFontSize = MetroFramework.MetroTileTextSize.Small
        Me.MetroTile7.UseCustomBackColor = True
        Me.MetroTile7.UseCustomForeColor = True
        Me.MetroTile7.UseSelectable = True
        Me.MetroTile7.UseTileImage = True
        '
        'MSITab12
        '
        Me.MSITab12.Controls.Add(Me.MetroTile9)
        Me.MSITab12.Controls.Add(Me.ExportSoftwareListMSI)
        Me.MSITab12.Controls.Add(Me.GetMSIList)
        Me.MSITab12.Controls.Add(Me.TableLayoutPanel19)
        Me.MSITab12.Controls.Add(Me.TableLayoutPanel17)
        Me.MSITab12.Controls.Add(Me.Label51)
        Me.MSITab12.Controls.Add(Me.Label23)
        Me.MSITab12.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.MSITab12.HorizontalScrollbarBarColor = True
        Me.MSITab12.HorizontalScrollbarHighlightOnWheel = False
        Me.MSITab12.HorizontalScrollbarSize = 10
        Me.MSITab12.Location = New System.Drawing.Point(4, 34)
        Me.MSITab12.Name = "MSITab12"
        Me.MSITab12.Size = New System.Drawing.Size(1075, 678)
        Me.MSITab12.TabIndex = 11
        Me.MSITab12.Text = "MSI       "
        Me.MSITab12.VerticalScrollbarBarColor = True
        Me.MSITab12.VerticalScrollbarHighlightOnWheel = False
        Me.MSITab12.VerticalScrollbarSize = 10
        '
        'MetroTile9
        '
        Me.MetroTile9.ActiveControl = Nothing
        Me.MetroTile9.BackColor = System.Drawing.Color.Transparent
        Me.MetroTile9.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.MetroTile9.Location = New System.Drawing.Point(3, 2)
        Me.MetroTile9.Name = "MetroTile9"
        Me.MetroTile9.Size = New System.Drawing.Size(38, 43)
        Me.MetroTile9.TabIndex = 128
        Me.MetroTile9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MetroTile9.TileImage = CType(resources.GetObject("MetroTile9.TileImage"), System.Drawing.Image)
        Me.MetroTile9.TileImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MetroTile9.TileTextFontSize = MetroFramework.MetroTileTextSize.Small
        Me.MetroTile9.UseCustomBackColor = True
        Me.MetroTile9.UseCustomForeColor = True
        Me.MetroTile9.UseSelectable = True
        Me.MetroTile9.UseTileImage = True
        '
        'ExportSoftwareListMSI
        '
        Me.ExportSoftwareListMSI.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ExportSoftwareListMSI.BackColor = System.Drawing.Color.AliceBlue
        Me.ExportSoftwareListMSI.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.ExportSoftwareListMSI.Location = New System.Drawing.Point(983, 7)
        Me.ExportSoftwareListMSI.Name = "ExportSoftwareListMSI"
        Me.ExportSoftwareListMSI.Size = New System.Drawing.Size(86, 28)
        Me.ExportSoftwareListMSI.TabIndex = 129
        Me.ExportSoftwareListMSI.Text = "Export to CSV"
        Me.ExportSoftwareListMSI.UseCustomBackColor = True
        Me.ExportSoftwareListMSI.UseCustomForeColor = True
        Me.ExportSoftwareListMSI.UseSelectable = True
        '
        'GetMSIList
        '
        Me.GetMSIList.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.GetMSIList.BackColor = System.Drawing.Color.AliceBlue
        Me.GetMSIList.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.GetMSIList.Location = New System.Drawing.Point(389, 7)
        Me.GetMSIList.Name = "GetMSIList"
        Me.GetMSIList.Size = New System.Drawing.Size(158, 28)
        Me.GetMSIList.TabIndex = 128
        Me.GetMSIList.Text = "Display MSI List"
        Me.GetMSIList.UseCustomBackColor = True
        Me.GetMSIList.UseCustomForeColor = True
        Me.GetMSIList.UseSelectable = True
        '
        'TableLayoutPanel19
        '
        Me.TableLayoutPanel19.BackColor = System.Drawing.Color.Transparent
        Me.TableLayoutPanel19.ColumnCount = 1
        Me.TableLayoutPanel19.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel19.Controls.Add(Me.TextBoxMSIZAP, 0, 0)
        Me.TableLayoutPanel19.Controls.Add(Me.MSIZAPbutton, 0, 1)
        Me.TableLayoutPanel19.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.TableLayoutPanel19.Location = New System.Drawing.Point(0, 618)
        Me.TableLayoutPanel19.Margin = New System.Windows.Forms.Padding(2)
        Me.TableLayoutPanel19.Name = "TableLayoutPanel19"
        Me.TableLayoutPanel19.RowCount = 2
        Me.TableLayoutPanel19.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 43.63636!))
        Me.TableLayoutPanel19.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 56.36364!))
        Me.TableLayoutPanel19.Size = New System.Drawing.Size(1075, 60)
        Me.TableLayoutPanel19.TabIndex = 120
        '
        'TextBoxMSIZAP
        '
        '
        '
        '
        Me.TextBoxMSIZAP.CustomButton.Image = Nothing
        Me.TextBoxMSIZAP.CustomButton.Location = New System.Drawing.Point(1051, 2)
        Me.TextBoxMSIZAP.CustomButton.Name = ""
        Me.TextBoxMSIZAP.CustomButton.Size = New System.Drawing.Size(15, 15)
        Me.TextBoxMSIZAP.CustomButton.Style = MetroFramework.MetroColorStyle.Blue
        Me.TextBoxMSIZAP.CustomButton.TabIndex = 1
        Me.TextBoxMSIZAP.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light
        Me.TextBoxMSIZAP.CustomButton.UseSelectable = True
        Me.TextBoxMSIZAP.CustomButton.Visible = False
        Me.TextBoxMSIZAP.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TextBoxMSIZAP.Lines = New String(-1) {}
        Me.TextBoxMSIZAP.Location = New System.Drawing.Point(3, 3)
        Me.TextBoxMSIZAP.MaxLength = 32767
        Me.TextBoxMSIZAP.Name = "TextBoxMSIZAP"
        Me.TextBoxMSIZAP.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TextBoxMSIZAP.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.TextBoxMSIZAP.SelectedText = ""
        Me.TextBoxMSIZAP.SelectionLength = 0
        Me.TextBoxMSIZAP.SelectionStart = 0
        Me.TextBoxMSIZAP.Size = New System.Drawing.Size(1069, 20)
        Me.TextBoxMSIZAP.TabIndex = 130
        Me.TextBoxMSIZAP.UseSelectable = True
        Me.TextBoxMSIZAP.WaterMarkColor = System.Drawing.Color.FromArgb(CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.TextBoxMSIZAP.WaterMarkFont = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel)
        '
        'MSIZAPbutton
        '
        Me.MSIZAPbutton.BackColor = System.Drawing.Color.AliceBlue
        Me.MSIZAPbutton.Dock = System.Windows.Forms.DockStyle.Fill
        Me.MSIZAPbutton.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.MSIZAPbutton.Location = New System.Drawing.Point(3, 29)
        Me.MSIZAPbutton.Name = "MSIZAPbutton"
        Me.MSIZAPbutton.Size = New System.Drawing.Size(1069, 28)
        Me.MSIZAPbutton.TabIndex = 130
        Me.MSIZAPbutton.Text = "Select any MSI from table above, then Uninstall using the command here /\ . Log f" &
    "ile generated = C:\Windows\Installer\MSI_Removal.log"
        Me.MSIZAPbutton.UseCustomBackColor = True
        Me.MSIZAPbutton.UseCustomForeColor = True
        Me.MSIZAPbutton.UseSelectable = True
        '
        'TableLayoutPanel17
        '
        Me.TableLayoutPanel17.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel17.BackColor = System.Drawing.Color.Transparent
        Me.TableLayoutPanel17.ColumnCount = 1
        Me.TableLayoutPanel17.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel17.Controls.Add(Me.DataGridView6, 0, 0)
        Me.TableLayoutPanel17.Location = New System.Drawing.Point(3, 47)
        Me.TableLayoutPanel17.Margin = New System.Windows.Forms.Padding(2)
        Me.TableLayoutPanel17.Name = "TableLayoutPanel17"
        Me.TableLayoutPanel17.RowCount = 1
        Me.TableLayoutPanel17.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel17.Size = New System.Drawing.Size(1069, 567)
        Me.TableLayoutPanel17.TabIndex = 119
        '
        'DataGridView6
        '
        Me.DataGridView6.BackgroundColor = System.Drawing.SystemColors.Window
        Me.DataGridView6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView6.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.StrKey, Me.Column2, Me.InstallTime})
        Me.DataGridView6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DataGridView6.Location = New System.Drawing.Point(3, 3)
        Me.DataGridView6.Name = "DataGridView6"
        Me.DataGridView6.RowHeadersVisible = False
        Me.DataGridView6.RowTemplate.Height = 24
        Me.DataGridView6.Size = New System.Drawing.Size(1063, 561)
        Me.DataGridView6.TabIndex = 46
        '
        'Column1
        '
        Me.Column1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.Column1.FillWeight = 30.0!
        Me.Column1.HeaderText = "MSI Application Name"
        Me.Column1.Name = "Column1"
        Me.Column1.ReadOnly = True
        '
        'StrKey
        '
        Me.StrKey.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.StrKey.FillWeight = 10.0!
        Me.StrKey.HeaderText = "Version"
        Me.StrKey.Name = "StrKey"
        Me.StrKey.ReadOnly = True
        '
        'Column2
        '
        Me.Column2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.Column2.FillWeight = 20.0!
        Me.Column2.HeaderText = "MSI filename"
        Me.Column2.Name = "Column2"
        Me.Column2.ReadOnly = True
        '
        'InstallTime
        '
        Me.InstallTime.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.InstallTime.FillWeight = 15.0!
        Me.InstallTime.HeaderText = "(dd/mm/yyyy) MSI First Install Date"
        Me.InstallTime.Name = "InstallTime"
        Me.InstallTime.ReadOnly = True
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.BackColor = System.Drawing.Color.Transparent
        Me.Label51.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label51.Location = New System.Drawing.Point(58, 19)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(0, 16)
        Me.Label51.TabIndex = 118
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.BackColor = System.Drawing.Color.Transparent
        Me.Label23.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(58, 2)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(0, 16)
        Me.Label23.TabIndex = 116
        '
        'Profiles14
        '
        Me.Profiles14.Controls.Add(Me.DeleteProfile)
        Me.Profiles14.Controls.Add(Me.DetectProfiles)
        Me.Profiles14.Controls.Add(Me.TableLayoutPanel35)
        Me.Profiles14.Controls.Add(Me.LabelProfiles2)
        Me.Profiles14.Controls.Add(Me.LabelProfiles1)
        Me.Profiles14.Controls.Add(Me.MetroTile19)
        Me.Profiles14.HorizontalScrollbarBarColor = True
        Me.Profiles14.HorizontalScrollbarHighlightOnWheel = False
        Me.Profiles14.HorizontalScrollbarSize = 10
        Me.Profiles14.Location = New System.Drawing.Point(4, 34)
        Me.Profiles14.Name = "Profiles14"
        Me.Profiles14.Size = New System.Drawing.Size(1075, 678)
        Me.Profiles14.TabIndex = 19
        Me.Profiles14.Text = "Profiles"
        Me.Profiles14.VerticalScrollbarBarColor = True
        Me.Profiles14.VerticalScrollbarHighlightOnWheel = False
        Me.Profiles14.VerticalScrollbarSize = 10
        '
        'DeleteProfile
        '
        Me.DeleteProfile.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DeleteProfile.BackColor = System.Drawing.Color.AliceBlue
        Me.DeleteProfile.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.DeleteProfile.Location = New System.Drawing.Point(879, 18)
        Me.DeleteProfile.Name = "DeleteProfile"
        Me.DeleteProfile.Size = New System.Drawing.Size(190, 28)
        Me.DeleteProfile.TabIndex = 138
        Me.DeleteProfile.Text = "Delete Profile(s) Selected Below"
        Me.DeleteProfile.UseCustomBackColor = True
        Me.DeleteProfile.UseCustomForeColor = True
        Me.DeleteProfile.UseSelectable = True
        '
        'DetectProfiles
        '
        Me.DetectProfiles.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.DetectProfiles.BackColor = System.Drawing.Color.AliceBlue
        Me.DetectProfiles.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.DetectProfiles.Location = New System.Drawing.Point(395, 18)
        Me.DetectProfiles.Name = "DetectProfiles"
        Me.DetectProfiles.Size = New System.Drawing.Size(123, 28)
        Me.DetectProfiles.TabIndex = 137
        Me.DetectProfiles.Text = "Detect Profile Sizes"
        Me.DetectProfiles.UseCustomBackColor = True
        Me.DetectProfiles.UseCustomForeColor = True
        Me.DetectProfiles.UseSelectable = True
        '
        'TableLayoutPanel35
        '
        Me.TableLayoutPanel35.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel35.ColumnCount = 1
        Me.TableLayoutPanel35.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 59.49555!))
        Me.TableLayoutPanel35.Controls.Add(Me.DataGridViewProfiles, 0, 0)
        Me.TableLayoutPanel35.Location = New System.Drawing.Point(3, 52)
        Me.TableLayoutPanel35.Name = "TableLayoutPanel35"
        Me.TableLayoutPanel35.RowCount = 1
        Me.TableLayoutPanel35.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel35.Size = New System.Drawing.Size(1069, 626)
        Me.TableLayoutPanel35.TabIndex = 136
        '
        'DataGridViewProfiles
        '
        Me.DataGridViewProfiles.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DataGridViewProfiles.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewProfiles.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column16, Me.DataGridViewTextBoxColumn23, Me.Column13, Me.Column14, Me.Column15})
        Me.DataGridViewProfiles.Location = New System.Drawing.Point(3, 3)
        Me.DataGridViewProfiles.Name = "DataGridViewProfiles"
        Me.DataGridViewProfiles.RowHeadersVisible = False
        Me.DataGridViewProfiles.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridViewProfiles.Size = New System.Drawing.Size(1063, 620)
        Me.DataGridViewProfiles.TabIndex = 0
        '
        'Column16
        '
        Me.Column16.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.Column16.HeaderText = "LocalFolder"
        Me.Column16.MinimumWidth = 100
        Me.Column16.Name = "Column16"
        '
        'DataGridViewTextBoxColumn23
        '
        Me.DataGridViewTextBoxColumn23.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn23.FillWeight = 80.0!
        Me.DataGridViewTextBoxColumn23.HeaderText = "LocalFolder Size (MB)"
        Me.DataGridViewTextBoxColumn23.MinimumWidth = 80
        Me.DataGridViewTextBoxColumn23.Name = "DataGridViewTextBoxColumn23"
        '
        'Column13
        '
        Me.Column13.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader
        Me.Column13.HeaderText = "Currently Loaded"
        Me.Column13.Name = "Column13"
        Me.Column13.Width = 105
        '
        'Column14
        '
        Me.Column14.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader
        Me.Column14.HeaderText = "Time of last profile use"
        Me.Column14.Name = "Column14"
        Me.Column14.Width = 113
        '
        'Column15
        '
        Me.Column15.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.Column15.HeaderText = "SID"
        Me.Column15.MinimumWidth = 100
        Me.Column15.Name = "Column15"
        '
        'LabelProfiles2
        '
        Me.LabelProfiles2.AutoSize = True
        Me.LabelProfiles2.BackColor = System.Drawing.Color.Transparent
        Me.LabelProfiles2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelProfiles2.Location = New System.Drawing.Point(59, 20)
        Me.LabelProfiles2.Name = "LabelProfiles2"
        Me.LabelProfiles2.Size = New System.Drawing.Size(0, 13)
        Me.LabelProfiles2.TabIndex = 134
        '
        'LabelProfiles1
        '
        Me.LabelProfiles1.AutoSize = True
        Me.LabelProfiles1.BackColor = System.Drawing.Color.Transparent
        Me.LabelProfiles1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelProfiles1.Location = New System.Drawing.Point(59, 3)
        Me.LabelProfiles1.Name = "LabelProfiles1"
        Me.LabelProfiles1.Size = New System.Drawing.Size(0, 13)
        Me.LabelProfiles1.TabIndex = 133
        '
        'MetroTile19
        '
        Me.MetroTile19.ActiveControl = Nothing
        Me.MetroTile19.BackColor = System.Drawing.Color.Transparent
        Me.MetroTile19.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.MetroTile19.Location = New System.Drawing.Point(3, 3)
        Me.MetroTile19.Name = "MetroTile19"
        Me.MetroTile19.Size = New System.Drawing.Size(38, 43)
        Me.MetroTile19.TabIndex = 135
        Me.MetroTile19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MetroTile19.TileImage = CType(resources.GetObject("MetroTile19.TileImage"), System.Drawing.Image)
        Me.MetroTile19.TileImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MetroTile19.TileTextFontSize = MetroFramework.MetroTileTextSize.Small
        Me.MetroTile19.UseCustomBackColor = True
        Me.MetroTile19.UseCustomForeColor = True
        Me.MetroTile19.UseSelectable = True
        Me.MetroTile19.UseTileImage = True
        '
        'RebootChecker15
        '
        Me.RebootChecker15.Controls.Add(Me.TableLayoutPanel44)
        Me.RebootChecker15.Controls.Add(Me.RebootButton1)
        Me.RebootChecker15.Controls.Add(Me.MetroTile21)
        Me.RebootChecker15.Controls.Add(Me.Label1)
        Me.RebootChecker15.Controls.Add(Me.Label16)
        Me.RebootChecker15.HorizontalScrollbarBarColor = True
        Me.RebootChecker15.HorizontalScrollbarHighlightOnWheel = False
        Me.RebootChecker15.HorizontalScrollbarSize = 10
        Me.RebootChecker15.Location = New System.Drawing.Point(4, 34)
        Me.RebootChecker15.Name = "RebootChecker15"
        Me.RebootChecker15.Size = New System.Drawing.Size(1075, 678)
        Me.RebootChecker15.TabIndex = 23
        Me.RebootChecker15.Text = "Reboot?"
        Me.RebootChecker15.VerticalScrollbarBarColor = True
        Me.RebootChecker15.VerticalScrollbarHighlightOnWheel = False
        Me.RebootChecker15.VerticalScrollbarSize = 10
        '
        'TableLayoutPanel44
        '
        Me.TableLayoutPanel44.BackColor = System.Drawing.SystemColors.Window
        Me.TableLayoutPanel44.ColumnCount = 2
        Me.TableLayoutPanel44.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 69.12442!))
        Me.TableLayoutPanel44.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30.87558!))
        Me.TableLayoutPanel44.Controls.Add(Me.MetroLabel29, 0, 4)
        Me.TableLayoutPanel44.Controls.Add(Me.MetroLabel26, 0, 3)
        Me.TableLayoutPanel44.Controls.Add(Me.MetroLabel25, 0, 2)
        Me.TableLayoutPanel44.Controls.Add(Me.MetroLabel24, 0, 1)
        Me.TableLayoutPanel44.Controls.Add(Me.MetroLabel23, 0, 0)
        Me.TableLayoutPanel44.Controls.Add(Me.RebootRequiredCheck1, 1, 0)
        Me.TableLayoutPanel44.Controls.Add(Me.RebootRequiredCheck2, 1, 1)
        Me.TableLayoutPanel44.Controls.Add(Me.RebootRequiredCheck3, 1, 2)
        Me.TableLayoutPanel44.Controls.Add(Me.RebootRequiredCheck4, 1, 3)
        Me.TableLayoutPanel44.Controls.Add(Me.RebootRequiredCheck5, 1, 4)
        Me.TableLayoutPanel44.Location = New System.Drawing.Point(193, 120)
        Me.TableLayoutPanel44.Name = "TableLayoutPanel44"
        Me.TableLayoutPanel44.RowCount = 5
        Me.TableLayoutPanel44.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20.0!))
        Me.TableLayoutPanel44.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20.0!))
        Me.TableLayoutPanel44.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20.0!))
        Me.TableLayoutPanel44.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20.0!))
        Me.TableLayoutPanel44.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20.0!))
        Me.TableLayoutPanel44.Size = New System.Drawing.Size(651, 163)
        Me.TableLayoutPanel44.TabIndex = 146
        '
        'MetroLabel29
        '
        Me.MetroLabel29.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.MetroLabel29.AutoSize = True
        Me.MetroLabel29.ForeColor = System.Drawing.Color.Black
        Me.MetroLabel29.Location = New System.Drawing.Point(3, 128)
        Me.MetroLabel29.Name = "MetroLabel29"
        Me.MetroLabel29.Size = New System.Drawing.Size(443, 35)
        Me.MetroLabel29.TabIndex = 8
        Me.MetroLabel29.Text = "Reboot Check (""Software\Microsoft\Updates\UpdateExeVolatile) ="
        Me.MetroLabel29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'MetroLabel26
        '
        Me.MetroLabel26.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.MetroLabel26.AutoSize = True
        Me.MetroLabel26.ForeColor = System.Drawing.Color.Black
        Me.MetroLabel26.Location = New System.Drawing.Point(3, 96)
        Me.MetroLabel26.Name = "MetroLabel26"
        Me.MetroLabel26.Size = New System.Drawing.Size(443, 32)
        Me.MetroLabel26.TabIndex = 7
        Me.MetroLabel26.Text = "Reboot Needed Check 4 = "
        Me.MetroLabel26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'MetroLabel25
        '
        Me.MetroLabel25.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.MetroLabel25.AutoSize = True
        Me.MetroLabel25.ForeColor = System.Drawing.Color.Black
        Me.MetroLabel25.Location = New System.Drawing.Point(3, 64)
        Me.MetroLabel25.Name = "MetroLabel25"
        Me.MetroLabel25.Size = New System.Drawing.Size(443, 32)
        Me.MetroLabel25.TabIndex = 6
        Me.MetroLabel25.Text = "Reboot Check (SCCM - KB - SoftReboot) = "
        Me.MetroLabel25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'MetroLabel24
        '
        Me.MetroLabel24.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.MetroLabel24.AutoSize = True
        Me.MetroLabel24.ForeColor = System.Drawing.Color.Black
        Me.MetroLabel24.Location = New System.Drawing.Point(3, 32)
        Me.MetroLabel24.Name = "MetroLabel24"
        Me.MetroLabel24.Size = New System.Drawing.Size(443, 32)
        Me.MetroLabel24.TabIndex = 5
        Me.MetroLabel24.Text = "Reboot Check (PendingFileRenameOperations2) = "
        Me.MetroLabel24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'MetroLabel23
        '
        Me.MetroLabel23.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.MetroLabel23.AutoSize = True
        Me.MetroLabel23.ForeColor = System.Drawing.Color.Black
        Me.MetroLabel23.Location = New System.Drawing.Point(3, 0)
        Me.MetroLabel23.Name = "MetroLabel23"
        Me.MetroLabel23.Size = New System.Drawing.Size(443, 32)
        Me.MetroLabel23.TabIndex = 4
        Me.MetroLabel23.Text = "Reboot Check (PendingFileRenameOperations) = "
        Me.MetroLabel23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'RebootRequiredCheck1
        '
        Me.RebootRequiredCheck1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.RebootRequiredCheck1.AutoSize = True
        Me.RebootRequiredCheck1.ForeColor = System.Drawing.Color.Black
        Me.RebootRequiredCheck1.Location = New System.Drawing.Point(452, 0)
        Me.RebootRequiredCheck1.Name = "RebootRequiredCheck1"
        Me.RebootRequiredCheck1.Size = New System.Drawing.Size(196, 32)
        Me.RebootRequiredCheck1.TabIndex = 0
        Me.RebootRequiredCheck1.Text = "False"
        Me.RebootRequiredCheck1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.RebootRequiredCheck1.UseCustomForeColor = True
        '
        'RebootRequiredCheck2
        '
        Me.RebootRequiredCheck2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.RebootRequiredCheck2.AutoSize = True
        Me.RebootRequiredCheck2.Location = New System.Drawing.Point(452, 32)
        Me.RebootRequiredCheck2.Name = "RebootRequiredCheck2"
        Me.RebootRequiredCheck2.Size = New System.Drawing.Size(196, 32)
        Me.RebootRequiredCheck2.TabIndex = 1
        Me.RebootRequiredCheck2.Text = "False"
        Me.RebootRequiredCheck2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.RebootRequiredCheck2.UseCustomForeColor = True
        '
        'RebootRequiredCheck3
        '
        Me.RebootRequiredCheck3.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.RebootRequiredCheck3.AutoSize = True
        Me.RebootRequiredCheck3.Location = New System.Drawing.Point(452, 64)
        Me.RebootRequiredCheck3.Name = "RebootRequiredCheck3"
        Me.RebootRequiredCheck3.Size = New System.Drawing.Size(196, 32)
        Me.RebootRequiredCheck3.TabIndex = 2
        Me.RebootRequiredCheck3.Text = "False"
        Me.RebootRequiredCheck3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.RebootRequiredCheck3.UseCustomForeColor = True
        '
        'RebootRequiredCheck4
        '
        Me.RebootRequiredCheck4.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.RebootRequiredCheck4.AutoSize = True
        Me.RebootRequiredCheck4.Location = New System.Drawing.Point(452, 96)
        Me.RebootRequiredCheck4.Name = "RebootRequiredCheck4"
        Me.RebootRequiredCheck4.Size = New System.Drawing.Size(196, 32)
        Me.RebootRequiredCheck4.TabIndex = 3
        Me.RebootRequiredCheck4.Text = "False"
        Me.RebootRequiredCheck4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.RebootRequiredCheck4.UseCustomForeColor = True
        '
        'RebootRequiredCheck5
        '
        Me.RebootRequiredCheck5.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.RebootRequiredCheck5.AutoSize = True
        Me.RebootRequiredCheck5.Location = New System.Drawing.Point(452, 128)
        Me.RebootRequiredCheck5.Name = "RebootRequiredCheck5"
        Me.RebootRequiredCheck5.Size = New System.Drawing.Size(196, 35)
        Me.RebootRequiredCheck5.TabIndex = 9
        Me.RebootRequiredCheck5.Text = "False"
        Me.RebootRequiredCheck5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.RebootRequiredCheck5.UseCustomForeColor = True
        '
        'RebootButton1
        '
        Me.RebootButton1.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.RebootButton1.BackColor = System.Drawing.Color.AliceBlue
        Me.RebootButton1.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.RebootButton1.Location = New System.Drawing.Point(436, 20)
        Me.RebootButton1.Name = "RebootButton1"
        Me.RebootButton1.Size = New System.Drawing.Size(174, 28)
        Me.RebootButton1.TabIndex = 145
        Me.RebootButton1.Text = "Check if a ""Reboot"" flag is set"
        Me.RebootButton1.UseCustomBackColor = True
        Me.RebootButton1.UseCustomForeColor = True
        Me.RebootButton1.UseSelectable = True
        '
        'MetroTile21
        '
        Me.MetroTile21.ActiveControl = Nothing
        Me.MetroTile21.BackColor = System.Drawing.Color.Transparent
        Me.MetroTile21.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.MetroTile21.Location = New System.Drawing.Point(0, 3)
        Me.MetroTile21.Name = "MetroTile21"
        Me.MetroTile21.Size = New System.Drawing.Size(38, 43)
        Me.MetroTile21.TabIndex = 125
        Me.MetroTile21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MetroTile21.TileImage = CType(resources.GetObject("MetroTile21.TileImage"), System.Drawing.Image)
        Me.MetroTile21.TileImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MetroTile21.TileTextFontSize = MetroFramework.MetroTileTextSize.Small
        Me.MetroTile21.UseCustomBackColor = True
        Me.MetroTile21.UseCustomForeColor = True
        Me.MetroTile21.UseSelectable = True
        Me.MetroTile21.UseTileImage = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(54, 20)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(0, 16)
        Me.Label1.TabIndex = 124
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.BackColor = System.Drawing.Color.Transparent
        Me.Label16.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(54, 3)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(0, 16)
        Me.Label16.TabIndex = 123
        '
        'SCCMtab16
        '
        Me.SCCMtab16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.SCCMtab16.Controls.Add(Me.TableLayoutPanel47)
        Me.SCCMtab16.Controls.Add(Me.ChangeCacheDirectory)
        Me.SCCMtab16.Controls.Add(Me.ChangeCacheSizeButton)
        Me.SCCMtab16.Controls.Add(Me.openSCCMCache)
        Me.SCCMtab16.Controls.Add(Me.GetSCCMinfo)
        Me.SCCMtab16.Controls.Add(Me.Button8)
        Me.SCCMtab16.Controls.Add(Me.GetSCCMCacheSettings)
        Me.SCCMtab16.Controls.Add(Me.TableLayoutPanel7)
        Me.SCCMtab16.Controls.Add(Me.SCCMTabControl)
        Me.SCCMtab16.Controls.Add(Me.CacheDirectoryChange)
        Me.SCCMtab16.Controls.Add(Me.CacheChangeSize)
        Me.SCCMtab16.Controls.Add(Me.Label166)
        Me.SCCMtab16.Controls.Add(Me.SCCMCacheLabel)
        Me.SCCMtab16.Controls.Add(Me.Label56)
        Me.SCCMtab16.Controls.Add(Me.Label34)
        Me.SCCMtab16.Controls.Add(Me.MetroTile11)
        Me.SCCMtab16.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.SCCMtab16.HorizontalScrollbarBarColor = True
        Me.SCCMtab16.HorizontalScrollbarHighlightOnWheel = False
        Me.SCCMtab16.HorizontalScrollbarSize = 10
        Me.SCCMtab16.Location = New System.Drawing.Point(4, 34)
        Me.SCCMtab16.Name = "SCCMtab16"
        Me.SCCMtab16.Size = New System.Drawing.Size(1075, 678)
        Me.SCCMtab16.TabIndex = 8
        Me.SCCMtab16.Text = "SCCM      "
        Me.SCCMtab16.VerticalScrollbarBarColor = True
        Me.SCCMtab16.VerticalScrollbarHighlightOnWheel = False
        Me.SCCMtab16.VerticalScrollbarSize = 10
        '
        'TableLayoutPanel47
        '
        Me.TableLayoutPanel47.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel47.ColumnCount = 3
        Me.TableLayoutPanel47.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49.71098!))
        Me.TableLayoutPanel47.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.28902!))
        Me.TableLayoutPanel47.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 707.0!))
        Me.TableLayoutPanel47.Controls.Add(Me.TriggerScheduleSCCM_WMIC, 0, 0)
        Me.TableLayoutPanel47.Controls.Add(Me.TriggerScheduleSCCM_Powershell, 0, 0)
        Me.TableLayoutPanel47.Controls.Add(Me.TriggerScheduleSCCM_ComboBox, 2, 0)
        Me.TableLayoutPanel47.Location = New System.Drawing.Point(10, 639)
        Me.TableLayoutPanel47.Name = "TableLayoutPanel47"
        Me.TableLayoutPanel47.RowCount = 1
        Me.TableLayoutPanel47.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel47.Size = New System.Drawing.Size(1052, 35)
        Me.TableLayoutPanel47.TabIndex = 139
        '
        'TriggerScheduleSCCM_WMIC
        '
        Me.TriggerScheduleSCCM_WMIC.BackColor = System.Drawing.Color.Transparent
        Me.TriggerScheduleSCCM_WMIC.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TriggerScheduleSCCM_WMIC.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.TriggerScheduleSCCM_WMIC.Location = New System.Drawing.Point(174, 3)
        Me.TriggerScheduleSCCM_WMIC.Name = "TriggerScheduleSCCM_WMIC"
        Me.TriggerScheduleSCCM_WMIC.Size = New System.Drawing.Size(167, 29)
        Me.TriggerScheduleSCCM_WMIC.TabIndex = 178
        Me.TriggerScheduleSCCM_WMIC.Text = "Trigger Action - WMIC"
        Me.TriggerScheduleSCCM_WMIC.UseCustomBackColor = True
        Me.TriggerScheduleSCCM_WMIC.UseCustomForeColor = True
        Me.TriggerScheduleSCCM_WMIC.UseSelectable = True
        '
        'TriggerScheduleSCCM_Powershell
        '
        Me.TriggerScheduleSCCM_Powershell.BackColor = System.Drawing.Color.Transparent
        Me.TriggerScheduleSCCM_Powershell.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TriggerScheduleSCCM_Powershell.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.TriggerScheduleSCCM_Powershell.Location = New System.Drawing.Point(3, 3)
        Me.TriggerScheduleSCCM_Powershell.Name = "TriggerScheduleSCCM_Powershell"
        Me.TriggerScheduleSCCM_Powershell.Size = New System.Drawing.Size(165, 29)
        Me.TriggerScheduleSCCM_Powershell.TabIndex = 177
        Me.TriggerScheduleSCCM_Powershell.Text = "Trigger Action - PowerShell"
        Me.TriggerScheduleSCCM_Powershell.UseCustomBackColor = True
        Me.TriggerScheduleSCCM_Powershell.UseCustomForeColor = True
        Me.TriggerScheduleSCCM_Powershell.UseSelectable = True
        '
        'TriggerScheduleSCCM_ComboBox
        '
        Me.TriggerScheduleSCCM_ComboBox.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TriggerScheduleSCCM_ComboBox.FormattingEnabled = True
        Me.TriggerScheduleSCCM_ComboBox.ItemHeight = 23
        Me.TriggerScheduleSCCM_ComboBox.Items.AddRange(New Object() {"Hardware Inventory                                                           |{00" &
                "000000-0000-0000-0000-000000000001}", "Software Inventory                                                            |{0" &
                "0000000-0000-0000-0000-000000000002}", "Data Discovery Record                                                      |{0000" &
                "0000-0000-0000-0000-000000000003}", "File Collection                                                                  " &
                "  |{00000000-0000-0000-0000-000000000010}", "IDMIF Collection                                                                |" &
                "{00000000-0000-0000-0000-000000000011}", "Client Machine Authentication                                           |{0000000" &
                "0-0000-0000-0000-000000000012}", "Machine Policy Assignments Request                                 |{00000000-000" &
                "0-0000-0000-000000000021}", "Machine Policy Evaluation                                                   |{000" &
                "00000-0000-0000-0000-000000000022}", "Refresh Default MP Task                                                      |{00" &
                "000000-0000-0000-0000-000000000023}", "LS (Location Service) Refresh Locations Task                       |{00000000-000" &
                "0-0000-0000-000000000024}", "LS (Location Service) Timeout Refresh Task                         |{00000000-000" &
                "0-0000-0000-000000000025}", "Policy Agent Request Assignment (User)                             |{00000000-000" &
                "0-0000-0000-000000000026}", "Policy Agent Evaluate Assignment (User)                            |{00000000-000" &
                "0-0000-0000-000000000027}", "Software Metering Generating Usage Report                     |{00000000-0000-000" &
                "0-0000-000000000031}", "Source Update Message                                                     |{00000" &
                "000-0000-0000-0000-000000000037}", "Machine Policy Agent Cleanup" & Global.Microsoft.VisualBasic.ChrW(9) & "                                           |{0000000" &
                "0-0000-0000-0000-000000000040}", "User Policy Agent Cleanup                                                  |{0000" &
                "0000-0000-0000-0000-000000000041}", "Policy Agent Validate Machine Policy / Assignment             |{00000000-0000-000" &
                "0-0000-000000000042}", "Policy Agent Validate User Policy / Assignment                   |{00000000-0000-" &
                "0000-0000-000000000043}", "Retrying/Refreshing certificates in AD on MP" & Global.Microsoft.VisualBasic.ChrW(9) & "                       |{00000000-00" &
                "00-0000-0000-000000000051}", "Peer DP Status reporting" & Global.Microsoft.VisualBasic.ChrW(9) & "                                                     |{0" &
                "0000000-0000-0000-0000-000000000061}", "Peer DP Pending package check schedule" & Global.Microsoft.VisualBasic.ChrW(9) & "                            |{00000000-000" &
                "0-0000-0000-000000000062}", "SUM Updates install schedule" & Global.Microsoft.VisualBasic.ChrW(9) & "                                             |{00000" &
                "000-0000-0000-0000-000000000063}", "Hardware Inventory Collection Cycle" & Global.Microsoft.VisualBasic.ChrW(9) & "                                   |{00000000" &
                "-0000-0000-0000-000000000101}", "Software Inventory Collection Cycle                                     |{0000000" &
                "0-0000-0000-0000-000000000102}", "Discovery Data Collection Cycle                                           |{00000" &
                "000-0000-0000-0000-000000000103}", "File Collection Cycle                                                            " &
                " |{00000000-0000-0000-0000-000000000104}", "IDMIF Collection Cycle                                                         |{" &
                "00000000-0000-0000-0000-000000000105}", "Software Metering Usage Report Cycle                                |{00000000-00" &
                "00-0000-0000-000000000106}", "Windows Installer Source List Update Cycle                         |{00000000-000" &
                "0-0000-0000-000000000107}", "Software Updates Assignments Evaluation Cycle                  |{00000000-0000-00" &
                "00-0000-000000000108}", "Branch Distribution Point Maintenance Task                         |{00000000-000" &
                "0-0000-0000-000000000109}", "Send Unsent State Message                                                 |{00000" &
                "000-0000-0000-0000-000000000111}", "State System policy cache cleanout                                      |{0000000" &
                "0-0000-0000-0000-000000000112}", "Scan by Update Source                                                        |{00" &
                "000000-0000-0000-0000-000000000113}", "Update Store Policy                                                             |" &
                "{00000000-0000-0000-0000-000000000114}", "State system policy bulk send high                                      |{0000000" &
                "0-0000-0000-0000-000000000115}", "State system policy bulk send low                                        |{000000" &
                "00-0000-0000-0000-000000000116}", "Application manager policy action                                        |{000000" &
                "00-0000-0000-0000-000000000121}", "Application manager user policy action                                 |{00000000" &
                "-0000-0000-0000-000000000122}", "Application manager global evaluation action                       |{00000000-000" &
                "0-0000-0000-000000000123}", "Power management start summarizer                                  |{00000000-000" &
                "0-0000-0000-000000000131}", "Endpoint deployment reevaluate                                         |{00000000" &
                "-0000-0000-0000-000000000221}", "Endpoint AM policy reevaluate                                           |{0000000" &
                "0-0000-0000-0000-000000000222}", "External event detection                                                      |{0" &
                "0000000-0000-0000-0000-000000000223}"})
        Me.TriggerScheduleSCCM_ComboBox.Location = New System.Drawing.Point(347, 3)
        Me.TriggerScheduleSCCM_ComboBox.Name = "TriggerScheduleSCCM_ComboBox"
        Me.TriggerScheduleSCCM_ComboBox.Size = New System.Drawing.Size(702, 29)
        Me.TriggerScheduleSCCM_ComboBox.TabIndex = 179
        Me.TriggerScheduleSCCM_ComboBox.UseSelectable = True
        '
        'ChangeCacheDirectory
        '
        Me.ChangeCacheDirectory.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.ChangeCacheDirectory.BackColor = System.Drawing.Color.Transparent
        Me.ChangeCacheDirectory.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.ChangeCacheDirectory.Location = New System.Drawing.Point(570, 56)
        Me.ChangeCacheDirectory.Name = "ChangeCacheDirectory"
        Me.ChangeCacheDirectory.Size = New System.Drawing.Size(138, 21)
        Me.ChangeCacheDirectory.TabIndex = 138
        Me.ChangeCacheDirectory.Text = "Set Cache Directory to >"
        Me.ChangeCacheDirectory.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.ChangeCacheDirectory.UseCustomBackColor = True
        Me.ChangeCacheDirectory.UseCustomForeColor = True
        Me.ChangeCacheDirectory.UseSelectable = True
        '
        'ChangeCacheSizeButton
        '
        Me.ChangeCacheSizeButton.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.ChangeCacheSizeButton.BackColor = System.Drawing.Color.Transparent
        Me.ChangeCacheSizeButton.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.ChangeCacheSizeButton.Location = New System.Drawing.Point(712, 30)
        Me.ChangeCacheSizeButton.Name = "ChangeCacheSizeButton"
        Me.ChangeCacheSizeButton.Size = New System.Drawing.Size(140, 21)
        Me.ChangeCacheSizeButton.TabIndex = 137
        Me.ChangeCacheSizeButton.Text = "Set Cache Size to >"
        Me.ChangeCacheSizeButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.ChangeCacheSizeButton.UseCustomBackColor = True
        Me.ChangeCacheSizeButton.UseCustomForeColor = True
        Me.ChangeCacheSizeButton.UseSelectable = True
        '
        'openSCCMCache
        '
        Me.openSCCMCache.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.openSCCMCache.BackColor = System.Drawing.Color.Transparent
        Me.openSCCMCache.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.openSCCMCache.Location = New System.Drawing.Point(570, 30)
        Me.openSCCMCache.Name = "openSCCMCache"
        Me.openSCCMCache.Size = New System.Drawing.Size(138, 21)
        Me.openSCCMCache.TabIndex = 136
        Me.openSCCMCache.Text = "Open Cache Folder"
        Me.openSCCMCache.UseCustomBackColor = True
        Me.openSCCMCache.UseCustomForeColor = True
        Me.openSCCMCache.UseSelectable = True
        '
        'GetSCCMinfo
        '
        Me.GetSCCMinfo.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.GetSCCMinfo.BackColor = System.Drawing.Color.Transparent
        Me.GetSCCMinfo.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.GetSCCMinfo.Location = New System.Drawing.Point(416, 56)
        Me.GetSCCMinfo.Name = "GetSCCMinfo"
        Me.GetSCCMinfo.Size = New System.Drawing.Size(148, 22)
        Me.GetSCCMinfo.TabIndex = 135
        Me.GetSCCMinfo.Text = "Display Client Information"
        Me.GetSCCMinfo.UseCustomBackColor = True
        Me.GetSCCMinfo.UseCustomForeColor = True
        Me.GetSCCMinfo.UseSelectable = True
        '
        'Button8
        '
        Me.Button8.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Button8.BackColor = System.Drawing.Color.Transparent
        Me.Button8.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.Button8.Location = New System.Drawing.Point(416, 30)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(148, 20)
        Me.Button8.TabIndex = 134
        Me.Button8.Text = "Open SCCM Logs Folder"
        Me.Button8.UseCustomBackColor = True
        Me.Button8.UseCustomForeColor = True
        Me.Button8.UseSelectable = True
        '
        'GetSCCMCacheSettings
        '
        Me.GetSCCMCacheSettings.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.GetSCCMCacheSettings.BackColor = System.Drawing.Color.Transparent
        Me.GetSCCMCacheSettings.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.GetSCCMCacheSettings.Location = New System.Drawing.Point(416, 3)
        Me.GetSCCMCacheSettings.Name = "GetSCCMCacheSettings"
        Me.GetSCCMCacheSettings.Size = New System.Drawing.Size(148, 21)
        Me.GetSCCMCacheSettings.TabIndex = 133
        Me.GetSCCMCacheSettings.Text = "Get Cache Settings"
        Me.GetSCCMCacheSettings.UseCustomBackColor = True
        Me.GetSCCMCacheSettings.UseCustomForeColor = True
        Me.GetSCCMCacheSettings.UseSelectable = True
        '
        'TableLayoutPanel7
        '
        Me.TableLayoutPanel7.BackColor = System.Drawing.Color.Transparent
        Me.TableLayoutPanel7.ColumnCount = 2
        Me.TableLayoutPanel7.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 53.69775!))
        Me.TableLayoutPanel7.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 46.30225!))
        Me.TableLayoutPanel7.Controls.Add(Me.SCCMProvisioningMode, 1, 0)
        Me.TableLayoutPanel7.Controls.Add(Me.SCCMMODE, 0, 0)
        Me.TableLayoutPanel7.Location = New System.Drawing.Point(10, 46)
        Me.TableLayoutPanel7.Name = "TableLayoutPanel7"
        Me.TableLayoutPanel7.RowCount = 1
        Me.TableLayoutPanel7.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel7.Size = New System.Drawing.Size(311, 27)
        Me.TableLayoutPanel7.TabIndex = 128
        '
        'SCCMProvisioningMode
        '
        Me.SCCMProvisioningMode.AutoSize = True
        Me.SCCMProvisioningMode.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SCCMProvisioningMode.Location = New System.Drawing.Point(170, 0)
        Me.SCCMProvisioningMode.Name = "SCCMProvisioningMode"
        Me.SCCMProvisioningMode.Size = New System.Drawing.Size(138, 27)
        Me.SCCMProvisioningMode.TabIndex = 136
        Me.SCCMProvisioningMode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'SCCMMODE
        '
        Me.SCCMMODE.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.SCCMMODE.BackColor = System.Drawing.Color.Transparent
        Me.SCCMMODE.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.SCCMMODE.Location = New System.Drawing.Point(5, 3)
        Me.SCCMMODE.Name = "SCCMMODE"
        Me.SCCMMODE.Size = New System.Drawing.Size(157, 21)
        Me.SCCMMODE.TabIndex = 136
        Me.SCCMMODE.Text = "SCCM Provisioning Mode >"
        Me.SCCMMODE.UseCustomBackColor = True
        Me.SCCMMODE.UseCustomForeColor = True
        Me.SCCMMODE.UseSelectable = True
        '
        'SCCMTabControl
        '
        Me.SCCMTabControl.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.SCCMTabControl.Controls.Add(Me.ExecutionHistory)
        Me.SCCMTabControl.Controls.Add(Me.ADVMachine)
        Me.SCCMTabControl.Controls.Add(Me.ADVLoggedOnUser)
        Me.SCCMTabControl.Controls.Add(Me.ADVTaskSeq)
        Me.SCCMTabControl.Controls.Add(Me.PKGInstallStats)
        Me.SCCMTabControl.Controls.Add(Me.KB_EvaluationState)
        Me.SCCMTabControl.Controls.Add(Me.SCCMmissUpdates)
        Me.SCCMTabControl.Controls.Add(Me.PatchesIn)
        Me.SCCMTabControl.Controls.Add(Me.SCCMcomplianceTab)
        Me.SCCMTabControl.Controls.Add(Me.RemoteCommandsSCCM)
        Me.SCCMTabControl.Controls.Add(Me.ClientFullLog)
        Me.SCCMTabControl.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.SCCMTabControl.ImageList = Me.ImageListSCCM
        Me.SCCMTabControl.Location = New System.Drawing.Point(6, 84)
        Me.SCCMTabControl.Name = "SCCMTabControl"
        Me.SCCMTabControl.SelectedIndex = 0
        Me.SCCMTabControl.Size = New System.Drawing.Size(1056, 552)
        Me.SCCMTabControl.TabIndex = 117
        '
        'ExecutionHistory
        '
        Me.ExecutionHistory.Controls.Add(Me.ExportSCCMhistory)
        Me.ExecutionHistory.Controls.Add(Me.GetSCCM2)
        Me.ExecutionHistory.Controls.Add(Me.DataGridView9)
        Me.ExecutionHistory.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ExecutionHistory.ImageIndex = 3
        Me.ExecutionHistory.Location = New System.Drawing.Point(4, 23)
        Me.ExecutionHistory.Name = "ExecutionHistory"
        Me.ExecutionHistory.Padding = New System.Windows.Forms.Padding(3)
        Me.ExecutionHistory.Size = New System.Drawing.Size(1048, 525)
        Me.ExecutionHistory.TabIndex = 2
        Me.ExecutionHistory.Text = "Execution History (All)"
        Me.ExecutionHistory.UseVisualStyleBackColor = True
        '
        'ExportSCCMhistory
        '
        Me.ExportSCCMhistory.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ExportSCCMhistory.BackColor = System.Drawing.Color.AliceBlue
        Me.ExportSCCMhistory.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.ExportSCCMhistory.Location = New System.Drawing.Point(959, 3)
        Me.ExportSCCMhistory.Name = "ExportSCCMhistory"
        Me.ExportSCCMhistory.Size = New System.Drawing.Size(86, 25)
        Me.ExportSCCMhistory.TabIndex = 140
        Me.ExportSCCMhistory.Text = "Export to CSV"
        Me.ExportSCCMhistory.UseCustomBackColor = True
        Me.ExportSCCMhistory.UseCustomForeColor = True
        Me.ExportSCCMhistory.UseSelectable = True
        '
        'GetSCCM2
        '
        Me.GetSCCM2.BackColor = System.Drawing.Color.AliceBlue
        Me.GetSCCM2.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.GetSCCM2.Location = New System.Drawing.Point(5, 3)
        Me.GetSCCM2.Name = "GetSCCM2"
        Me.GetSCCM2.Size = New System.Drawing.Size(157, 25)
        Me.GetSCCM2.TabIndex = 139
        Me.GetSCCM2.Text = "List Execution History (All)"
        Me.GetSCCM2.UseCustomBackColor = True
        Me.GetSCCM2.UseCustomForeColor = True
        Me.GetSCCM2.UseSelectable = True
        '
        'DataGridView9
        '
        Me.DataGridView9.AllowUserToResizeRows = False
        Me.DataGridView9.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DataGridView9.BackgroundColor = System.Drawing.SystemColors.Window
        Me.DataGridView9.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView9.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn6, Me.DataGridViewTextBoxColumn9, Me.DataGridViewTextBoxColumn5, Me.DataGridViewTextBoxColumn8, Me.DataGridViewTextBoxColumn10, Me.EvaluationStateReason})
        Me.DataGridView9.Location = New System.Drawing.Point(5, 29)
        Me.DataGridView9.Name = "DataGridView9"
        Me.DataGridView9.RowHeadersVisible = False
        Me.DataGridView9.RowTemplate.Height = 21
        Me.DataGridView9.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridView9.Size = New System.Drawing.Size(1037, 493)
        Me.DataGridView9.TabIndex = 1
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn6.FillWeight = 11.0!
        Me.DataGridViewTextBoxColumn6.HeaderText = "PkgID or Version"
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        Me.DataGridViewTextBoxColumn6.ReadOnly = True
        '
        'DataGridViewTextBoxColumn9
        '
        Me.DataGridViewTextBoxColumn9.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn9.FillWeight = 38.0!
        Me.DataGridViewTextBoxColumn9.HeaderText = "Applications & Programs"
        Me.DataGridViewTextBoxColumn9.Name = "DataGridViewTextBoxColumn9"
        Me.DataGridViewTextBoxColumn9.ReadOnly = True
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        DataGridViewCellStyle1.Format = "G"
        DataGridViewCellStyle1.NullValue = Nothing
        Me.DataGridViewTextBoxColumn5.DefaultCellStyle = DataGridViewCellStyle1
        Me.DataGridViewTextBoxColumn5.FillWeight = 15.0!
        Me.DataGridViewTextBoxColumn5.HeaderText = "Date / Time Run"
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        Me.DataGridViewTextBoxColumn5.ReadOnly = True
        '
        'DataGridViewTextBoxColumn8
        '
        Me.DataGridViewTextBoxColumn8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn8.FillWeight = 10.0!
        Me.DataGridViewTextBoxColumn8.HeaderText = "State"
        Me.DataGridViewTextBoxColumn8.Name = "DataGridViewTextBoxColumn8"
        Me.DataGridViewTextBoxColumn8.ReadOnly = True
        '
        'DataGridViewTextBoxColumn10
        '
        Me.DataGridViewTextBoxColumn10.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn10.FillWeight = 10.0!
        Me.DataGridViewTextBoxColumn10.HeaderText = "Exitcode"
        Me.DataGridViewTextBoxColumn10.Name = "DataGridViewTextBoxColumn10"
        Me.DataGridViewTextBoxColumn10.ReadOnly = True
        '
        'EvaluationStateReason
        '
        Me.EvaluationStateReason.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.EvaluationStateReason.FillWeight = 20.0!
        Me.EvaluationStateReason.HeaderText = "EvaluationState / Reason"
        Me.EvaluationStateReason.Name = "EvaluationStateReason"
        '
        'ADVMachine
        '
        Me.ADVMachine.Controls.Add(Me.ReRunAdvertMachine)
        Me.ADVMachine.Controls.Add(Me.GETSCCM)
        Me.ADVMachine.Controls.Add(Me.AdvertNameMachine)
        Me.ADVMachine.Controls.Add(Me.PkgIDMachine)
        Me.ADVMachine.Controls.Add(Me.AdvIDMachine)
        Me.ADVMachine.Controls.Add(Me.DataGridView8)
        Me.ADVMachine.ImageIndex = 2
        Me.ADVMachine.Location = New System.Drawing.Point(4, 23)
        Me.ADVMachine.Name = "ADVMachine"
        Me.ADVMachine.Padding = New System.Windows.Forms.Padding(3)
        Me.ADVMachine.Size = New System.Drawing.Size(1048, 525)
        Me.ADVMachine.TabIndex = 0
        Me.ADVMachine.Text = "ADV (Machine)"
        Me.ADVMachine.UseVisualStyleBackColor = True
        '
        'ReRunAdvertMachine
        '
        Me.ReRunAdvertMachine.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ReRunAdvertMachine.BackColor = System.Drawing.Color.Transparent
        Me.ReRunAdvertMachine.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.ReRunAdvertMachine.Location = New System.Drawing.Point(893, 3)
        Me.ReRunAdvertMachine.Name = "ReRunAdvertMachine"
        Me.ReRunAdvertMachine.Size = New System.Drawing.Size(149, 25)
        Me.ReRunAdvertMachine.TabIndex = 142
        Me.ReRunAdvertMachine.Text = "ReRun machine advert"
        Me.ReRunAdvertMachine.UseCustomBackColor = True
        Me.ReRunAdvertMachine.UseCustomForeColor = True
        Me.ReRunAdvertMachine.UseSelectable = True
        '
        'GETSCCM
        '
        Me.GETSCCM.BackColor = System.Drawing.Color.Transparent
        Me.GETSCCM.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.GETSCCM.Location = New System.Drawing.Point(3, 3)
        Me.GETSCCM.Name = "GETSCCM"
        Me.GETSCCM.Size = New System.Drawing.Size(175, 25)
        Me.GETSCCM.TabIndex = 141
        Me.GETSCCM.Text = "List Machine Advertisements"
        Me.GETSCCM.UseCustomBackColor = True
        Me.GETSCCM.UseCustomForeColor = True
        Me.GETSCCM.UseSelectable = True
        '
        'AdvertNameMachine
        '
        Me.AdvertNameMachine.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.AdvertNameMachine.AutoSize = True
        Me.AdvertNameMachine.Location = New System.Drawing.Point(604, 8)
        Me.AdvertNameMachine.Name = "AdvertNameMachine"
        Me.AdvertNameMachine.Size = New System.Drawing.Size(67, 13)
        Me.AdvertNameMachine.TabIndex = 85
        Me.AdvertNameMachine.Text = "AdvertName"
        '
        'PkgIDMachine
        '
        Me.PkgIDMachine.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.PkgIDMachine.AutoSize = True
        Me.PkgIDMachine.Location = New System.Drawing.Point(515, 8)
        Me.PkgIDMachine.Name = "PkgIDMachine"
        Me.PkgIDMachine.Size = New System.Drawing.Size(35, 13)
        Me.PkgIDMachine.TabIndex = 84
        Me.PkgIDMachine.Text = "PkgID"
        '
        'AdvIDMachine
        '
        Me.AdvIDMachine.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.AdvIDMachine.AutoSize = True
        Me.AdvIDMachine.Location = New System.Drawing.Point(418, 8)
        Me.AdvIDMachine.Name = "AdvIDMachine"
        Me.AdvIDMachine.Size = New System.Drawing.Size(37, 13)
        Me.AdvIDMachine.TabIndex = 83
        Me.AdvIDMachine.Text = "AdvID"
        '
        'DataGridView8
        '
        Me.DataGridView8.AllowUserToResizeRows = False
        Me.DataGridView8.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DataGridView8.BackgroundColor = System.Drawing.SystemColors.Window
        Me.DataGridView8.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView8.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.AdvID, Me.Column3, Me.Column4, Me.ContentSize, Me.Column5, Me.Column6, Me.Column7})
        Me.DataGridView8.Location = New System.Drawing.Point(3, 29)
        Me.DataGridView8.Name = "DataGridView8"
        Me.DataGridView8.RowHeadersVisible = False
        Me.DataGridView8.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.White
        Me.DataGridView8.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Black
        Me.DataGridView8.RowTemplate.Height = 21
        Me.DataGridView8.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridView8.Size = New System.Drawing.Size(1038, 490)
        Me.DataGridView8.TabIndex = 0
        '
        'AdvID
        '
        Me.AdvID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.AdvID.FillWeight = 7.0!
        Me.AdvID.HeaderText = "AdvID"
        Me.AdvID.Name = "AdvID"
        Me.AdvID.ReadOnly = True
        '
        'Column3
        '
        Me.Column3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.Column3.FillWeight = 7.0!
        Me.Column3.HeaderText = "PkgID"
        Me.Column3.Name = "Column3"
        Me.Column3.ReadOnly = True
        '
        'Column4
        '
        Me.Column4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.Column4.FillWeight = 30.0!
        Me.Column4.HeaderText = "Name"
        Me.Column4.Name = "Column4"
        Me.Column4.ReadOnly = True
        '
        'ContentSize
        '
        Me.ContentSize.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.ContentSize.FillWeight = 8.0!
        Me.ContentSize.HeaderText = "Size (KB)"
        Me.ContentSize.Name = "ContentSize"
        Me.ContentSize.ReadOnly = True
        '
        'Column5
        '
        Me.Column5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.Column5.FillWeight = 6.0!
        Me.Column5.HeaderText = "SftVer"
        Me.Column5.Name = "Column5"
        Me.Column5.ReadOnly = True
        '
        'Column6
        '
        Me.Column6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.Column6.FillWeight = 20.0!
        Me.Column6.HeaderText = "Program"
        Me.Column6.Name = "Column6"
        Me.Column6.ReadOnly = True
        '
        'Column7
        '
        Me.Column7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.Column7.FillWeight = 20.0!
        Me.Column7.HeaderText = "Command"
        Me.Column7.Name = "Column7"
        Me.Column7.ReadOnly = True
        '
        'ADVLoggedOnUser
        '
        Me.ADVLoggedOnUser.Controls.Add(Me.AdvertisementsUser)
        Me.ADVLoggedOnUser.Controls.Add(Me.DataGridView25)
        Me.ADVLoggedOnUser.ImageIndex = 1
        Me.ADVLoggedOnUser.Location = New System.Drawing.Point(4, 23)
        Me.ADVLoggedOnUser.Name = "ADVLoggedOnUser"
        Me.ADVLoggedOnUser.Size = New System.Drawing.Size(1048, 525)
        Me.ADVLoggedOnUser.TabIndex = 6
        Me.ADVLoggedOnUser.Text = "ADV (LoggedOnUser)"
        Me.ADVLoggedOnUser.UseVisualStyleBackColor = True
        '
        'AdvertisementsUser
        '
        Me.AdvertisementsUser.BackColor = System.Drawing.Color.Transparent
        Me.AdvertisementsUser.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.AdvertisementsUser.Location = New System.Drawing.Point(2, 3)
        Me.AdvertisementsUser.Name = "AdvertisementsUser"
        Me.AdvertisementsUser.Size = New System.Drawing.Size(168, 25)
        Me.AdvertisementsUser.TabIndex = 143
        Me.AdvertisementsUser.Text = "List User Advertisements"
        Me.AdvertisementsUser.UseCustomBackColor = True
        Me.AdvertisementsUser.UseCustomForeColor = True
        Me.AdvertisementsUser.UseSelectable = True
        '
        'DataGridView25
        '
        Me.DataGridView25.AllowUserToResizeRows = False
        Me.DataGridView25.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DataGridView25.BackgroundColor = System.Drawing.SystemColors.Window
        Me.DataGridView25.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView25.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn78, Me.DataGridViewTextBoxColumn79})
        Me.DataGridView25.Location = New System.Drawing.Point(0, 30)
        Me.DataGridView25.Name = "DataGridView25"
        Me.DataGridView25.RowHeadersVisible = False
        Me.DataGridView25.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.White
        Me.DataGridView25.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Black
        Me.DataGridView25.RowTemplate.Height = 21
        Me.DataGridView25.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridView25.Size = New System.Drawing.Size(1044, 492)
        Me.DataGridView25.TabIndex = 1
        '
        'DataGridViewTextBoxColumn78
        '
        Me.DataGridViewTextBoxColumn78.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn78.FillWeight = 7.0!
        Me.DataGridViewTextBoxColumn78.HeaderText = "AssignmentName"
        Me.DataGridViewTextBoxColumn78.Name = "DataGridViewTextBoxColumn78"
        Me.DataGridViewTextBoxColumn78.ReadOnly = True
        '
        'DataGridViewTextBoxColumn79
        '
        Me.DataGridViewTextBoxColumn79.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn79.FillWeight = 7.0!
        Me.DataGridViewTextBoxColumn79.HeaderText = "AssignmentID"
        Me.DataGridViewTextBoxColumn79.Name = "DataGridViewTextBoxColumn79"
        Me.DataGridViewTextBoxColumn79.ReadOnly = True
        '
        'ADVTaskSeq
        '
        Me.ADVTaskSeq.Controls.Add(Me.GetSCCMTaskSequences)
        Me.ADVTaskSeq.Controls.Add(Me.DataGridView11)
        Me.ADVTaskSeq.ImageIndex = 0
        Me.ADVTaskSeq.Location = New System.Drawing.Point(4, 23)
        Me.ADVTaskSeq.Margin = New System.Windows.Forms.Padding(2)
        Me.ADVTaskSeq.Name = "ADVTaskSeq"
        Me.ADVTaskSeq.Padding = New System.Windows.Forms.Padding(2)
        Me.ADVTaskSeq.Size = New System.Drawing.Size(1048, 525)
        Me.ADVTaskSeq.TabIndex = 3
        Me.ADVTaskSeq.Text = "ADV (Task Seq)"
        Me.ADVTaskSeq.UseVisualStyleBackColor = True
        '
        'GetSCCMTaskSequences
        '
        Me.GetSCCMTaskSequences.BackColor = System.Drawing.Color.Transparent
        Me.GetSCCMTaskSequences.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.GetSCCMTaskSequences.Location = New System.Drawing.Point(5, 5)
        Me.GetSCCMTaskSequences.Name = "GetSCCMTaskSequences"
        Me.GetSCCMTaskSequences.Size = New System.Drawing.Size(138, 25)
        Me.GetSCCMTaskSequences.TabIndex = 143
        Me.GetSCCMTaskSequences.Text = "List Task Sequences"
        Me.GetSCCMTaskSequences.UseCustomBackColor = True
        Me.GetSCCMTaskSequences.UseCustomForeColor = True
        Me.GetSCCMTaskSequences.UseSelectable = True
        '
        'DataGridView11
        '
        Me.DataGridView11.AllowUserToResizeRows = False
        Me.DataGridView11.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DataGridView11.BackgroundColor = System.Drawing.SystemColors.Window
        Me.DataGridView11.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView11.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.ADV_TS, Me.DataGridViewTextBoxColumn14, Me.DataGridViewTextBoxColumn15, Me.Live})
        Me.DataGridView11.Location = New System.Drawing.Point(2, 33)
        Me.DataGridView11.Name = "DataGridView11"
        Me.DataGridView11.RowHeadersVisible = False
        Me.DataGridView11.RowTemplate.Height = 21
        Me.DataGridView11.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridView11.Size = New System.Drawing.Size(1040, 489)
        Me.DataGridView11.TabIndex = 2
        '
        'ADV_TS
        '
        Me.ADV_TS.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.ADV_TS.FillWeight = 16.64375!
        Me.ADV_TS.HeaderText = "AdvTS"
        Me.ADV_TS.Name = "ADV_TS"
        Me.ADV_TS.ReadOnly = True
        '
        'DataGridViewTextBoxColumn14
        '
        Me.DataGridViewTextBoxColumn14.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn14.FillWeight = 18.0679!
        Me.DataGridViewTextBoxColumn14.HeaderText = "PkgID"
        Me.DataGridViewTextBoxColumn14.Name = "DataGridViewTextBoxColumn14"
        Me.DataGridViewTextBoxColumn14.ReadOnly = True
        '
        'DataGridViewTextBoxColumn15
        '
        Me.DataGridViewTextBoxColumn15.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn15.FillWeight = 68.65804!
        Me.DataGridViewTextBoxColumn15.HeaderText = "Name"
        Me.DataGridViewTextBoxColumn15.Name = "DataGridViewTextBoxColumn15"
        Me.DataGridViewTextBoxColumn15.ReadOnly = True
        '
        'Live
        '
        Me.Live.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.Live.FillWeight = 27.78308!
        Me.Live.HeaderText = "Live/Published"
        Me.Live.Name = "Live"
        '
        'PKGInstallStats
        '
        Me.PKGInstallStats.Controls.Add(Me.SCCMRunningJobs)
        Me.PKGInstallStats.Controls.Add(Me.DataGridViewSCCMRunning)
        Me.PKGInstallStats.ImageIndex = 4
        Me.PKGInstallStats.Location = New System.Drawing.Point(4, 23)
        Me.PKGInstallStats.Name = "PKGInstallStats"
        Me.PKGInstallStats.Padding = New System.Windows.Forms.Padding(3)
        Me.PKGInstallStats.Size = New System.Drawing.Size(1048, 525)
        Me.PKGInstallStats.TabIndex = 5
        Me.PKGInstallStats.Text = "PKG && TS Status"
        Me.PKGInstallStats.UseVisualStyleBackColor = True
        '
        'SCCMRunningJobs
        '
        Me.SCCMRunningJobs.BackColor = System.Drawing.Color.Transparent
        Me.SCCMRunningJobs.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.SCCMRunningJobs.Location = New System.Drawing.Point(3, 3)
        Me.SCCMRunningJobs.Name = "SCCMRunningJobs"
        Me.SCCMRunningJobs.Size = New System.Drawing.Size(243, 25)
        Me.SCCMRunningJobs.TabIndex = 142
        Me.SCCMRunningJobs.Text = "List Installing Packages && Task Sequences"
        Me.SCCMRunningJobs.UseCustomBackColor = True
        Me.SCCMRunningJobs.UseCustomForeColor = True
        Me.SCCMRunningJobs.UseSelectable = True
        '
        'DataGridViewSCCMRunning
        '
        Me.DataGridViewSCCMRunning.AllowUserToResizeRows = False
        Me.DataGridViewSCCMRunning.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DataGridViewSCCMRunning.BackgroundColor = System.Drawing.SystemColors.Window
        Me.DataGridViewSCCMRunning.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewSCCMRunning.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn71, Me.DataGridViewTextBoxColumn72, Me.DataGridViewTextBoxColumn73, Me.DataGridViewTextBoxColumn74, Me.Runningstate})
        Me.DataGridViewSCCMRunning.Location = New System.Drawing.Point(3, 32)
        Me.DataGridViewSCCMRunning.Name = "DataGridViewSCCMRunning"
        Me.DataGridViewSCCMRunning.RowHeadersVisible = False
        Me.DataGridViewSCCMRunning.RowTemplate.Height = 21
        Me.DataGridViewSCCMRunning.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridViewSCCMRunning.Size = New System.Drawing.Size(1038, 493)
        Me.DataGridViewSCCMRunning.TabIndex = 3
        '
        'DataGridViewTextBoxColumn71
        '
        Me.DataGridViewTextBoxColumn71.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn71.FillWeight = 16.64375!
        Me.DataGridViewTextBoxColumn71.HeaderText = "AdvID"
        Me.DataGridViewTextBoxColumn71.Name = "DataGridViewTextBoxColumn71"
        Me.DataGridViewTextBoxColumn71.ReadOnly = True
        '
        'DataGridViewTextBoxColumn72
        '
        Me.DataGridViewTextBoxColumn72.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn72.FillWeight = 18.0679!
        Me.DataGridViewTextBoxColumn72.HeaderText = "PkgID"
        Me.DataGridViewTextBoxColumn72.Name = "DataGridViewTextBoxColumn72"
        Me.DataGridViewTextBoxColumn72.ReadOnly = True
        '
        'DataGridViewTextBoxColumn73
        '
        Me.DataGridViewTextBoxColumn73.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn73.FillWeight = 68.65804!
        Me.DataGridViewTextBoxColumn73.HeaderText = "Name"
        Me.DataGridViewTextBoxColumn73.Name = "DataGridViewTextBoxColumn73"
        Me.DataGridViewTextBoxColumn73.ReadOnly = True
        '
        'DataGridViewTextBoxColumn74
        '
        Me.DataGridViewTextBoxColumn74.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn74.FillWeight = 27.78308!
        Me.DataGridViewTextBoxColumn74.HeaderText = "State"
        Me.DataGridViewTextBoxColumn74.Name = "DataGridViewTextBoxColumn74"
        '
        'Runningstate
        '
        Me.Runningstate.HeaderText = "Running State"
        Me.Runningstate.MinimumWidth = 10
        Me.Runningstate.Name = "Runningstate"
        '
        'KB_EvaluationState
        '
        Me.KB_EvaluationState.Controls.Add(Me.KBStatus)
        Me.KB_EvaluationState.Controls.Add(Me.DataGridViewKBStatus)
        Me.KB_EvaluationState.ImageKey = "Oxygen-Icons.org-Oxygen-Actions-view-list-details.ico"
        Me.KB_EvaluationState.Location = New System.Drawing.Point(4, 23)
        Me.KB_EvaluationState.Name = "KB_EvaluationState"
        Me.KB_EvaluationState.Size = New System.Drawing.Size(1048, 525)
        Me.KB_EvaluationState.TabIndex = 9
        Me.KB_EvaluationState.Text = "KB - Install - Status"
        Me.KB_EvaluationState.UseVisualStyleBackColor = True
        '
        'KBStatus
        '
        Me.KBStatus.BackColor = System.Drawing.Color.Transparent
        Me.KBStatus.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.KBStatus.Location = New System.Drawing.Point(5, 3)
        Me.KBStatus.Name = "KBStatus"
        Me.KBStatus.Size = New System.Drawing.Size(136, 25)
        Me.KBStatus.TabIndex = 145
        Me.KBStatus.Text = "List installing KB - Status"
        Me.KBStatus.UseCustomBackColor = True
        Me.KBStatus.UseCustomForeColor = True
        Me.KBStatus.UseSelectable = True
        '
        'DataGridViewKBStatus
        '
        Me.DataGridViewKBStatus.AllowUserToResizeRows = False
        Me.DataGridViewKBStatus.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DataGridViewKBStatus.BackgroundColor = System.Drawing.SystemColors.Window
        Me.DataGridViewKBStatus.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewKBStatus.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn38, Me.DataGridViewTextBoxColumn39, Me.PercentComplete, Me.ErrorCode})
        Me.DataGridViewKBStatus.Location = New System.Drawing.Point(3, 29)
        Me.DataGridViewKBStatus.Name = "DataGridViewKBStatus"
        Me.DataGridViewKBStatus.RowHeadersVisible = False
        Me.DataGridViewKBStatus.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.White
        Me.DataGridViewKBStatus.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Black
        Me.DataGridViewKBStatus.RowTemplate.Height = 21
        Me.DataGridViewKBStatus.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridViewKBStatus.Size = New System.Drawing.Size(1044, 493)
        Me.DataGridViewKBStatus.TabIndex = 144
        '
        'DataGridViewTextBoxColumn38
        '
        Me.DataGridViewTextBoxColumn38.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn38.FillWeight = 60.0!
        Me.DataGridViewTextBoxColumn38.HeaderText = "Name"
        Me.DataGridViewTextBoxColumn38.Name = "DataGridViewTextBoxColumn38"
        Me.DataGridViewTextBoxColumn38.ReadOnly = True
        '
        'DataGridViewTextBoxColumn39
        '
        Me.DataGridViewTextBoxColumn39.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn39.FillWeight = 20.0!
        Me.DataGridViewTextBoxColumn39.HeaderText = "Current Status"
        Me.DataGridViewTextBoxColumn39.Name = "DataGridViewTextBoxColumn39"
        Me.DataGridViewTextBoxColumn39.ReadOnly = True
        '
        'PercentComplete
        '
        Me.PercentComplete.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.PercentComplete.FillWeight = 15.0!
        Me.PercentComplete.HeaderText = "PercentComplete"
        Me.PercentComplete.Name = "PercentComplete"
        '
        'ErrorCode
        '
        Me.ErrorCode.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.ErrorCode.FillWeight = 15.0!
        Me.ErrorCode.HeaderText = "ErrorCode"
        Me.ErrorCode.Name = "ErrorCode"
        '
        'SCCMmissUpdates
        '
        Me.SCCMmissUpdates.Controls.Add(Me.SCCMPatchesMissing)
        Me.SCCMmissUpdates.Controls.Add(Me.ListMissingUpdatesSCCMDatagrid)
        Me.SCCMmissUpdates.ImageKey = "Graphicloads-100-Flat-Warning.ico"
        Me.SCCMmissUpdates.Location = New System.Drawing.Point(4, 23)
        Me.SCCMmissUpdates.Name = "SCCMmissUpdates"
        Me.SCCMmissUpdates.Padding = New System.Windows.Forms.Padding(3)
        Me.SCCMmissUpdates.Size = New System.Drawing.Size(1048, 525)
        Me.SCCMmissUpdates.TabIndex = 7
        Me.SCCMmissUpdates.Text = "KB - Missing"
        Me.SCCMmissUpdates.UseVisualStyleBackColor = True
        '
        'SCCMPatchesMissing
        '
        Me.SCCMPatchesMissing.BackColor = System.Drawing.Color.Transparent
        Me.SCCMPatchesMissing.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.SCCMPatchesMissing.Location = New System.Drawing.Point(6, 6)
        Me.SCCMPatchesMissing.Name = "SCCMPatchesMissing"
        Me.SCCMPatchesMissing.Size = New System.Drawing.Size(138, 25)
        Me.SCCMPatchesMissing.TabIndex = 145
        Me.SCCMPatchesMissing.Text = "SCCM - List missing KB"
        Me.SCCMPatchesMissing.UseCustomBackColor = True
        Me.SCCMPatchesMissing.UseCustomForeColor = True
        Me.SCCMPatchesMissing.UseSelectable = True
        '
        'ListMissingUpdatesSCCMDatagrid
        '
        Me.ListMissingUpdatesSCCMDatagrid.AllowUserToResizeRows = False
        Me.ListMissingUpdatesSCCMDatagrid.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ListMissingUpdatesSCCMDatagrid.BackgroundColor = System.Drawing.SystemColors.Window
        Me.ListMissingUpdatesSCCMDatagrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.ListMissingUpdatesSCCMDatagrid.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn35})
        Me.ListMissingUpdatesSCCMDatagrid.Location = New System.Drawing.Point(3, 34)
        Me.ListMissingUpdatesSCCMDatagrid.Name = "ListMissingUpdatesSCCMDatagrid"
        Me.ListMissingUpdatesSCCMDatagrid.RowHeadersVisible = False
        Me.ListMissingUpdatesSCCMDatagrid.RowTemplate.Height = 21
        Me.ListMissingUpdatesSCCMDatagrid.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.ListMissingUpdatesSCCMDatagrid.Size = New System.Drawing.Size(1040, 488)
        Me.ListMissingUpdatesSCCMDatagrid.TabIndex = 144
        '
        'DataGridViewTextBoxColumn35
        '
        Me.DataGridViewTextBoxColumn35.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn35.FillWeight = 68.65804!
        Me.DataGridViewTextBoxColumn35.HeaderText = "Missing KB Title"
        Me.DataGridViewTextBoxColumn35.Name = "DataGridViewTextBoxColumn35"
        Me.DataGridViewTextBoxColumn35.ReadOnly = True
        '
        'PatchesIn
        '
        Me.PatchesIn.Controls.Add(Me.SCCMPatchesInstalled)
        Me.PatchesIn.Controls.Add(Me.SCCMPatchesInstalledDataGridView)
        Me.PatchesIn.ImageKey = "Paomedia-Small-N-Flat-Monitor.ico"
        Me.PatchesIn.Location = New System.Drawing.Point(4, 23)
        Me.PatchesIn.Name = "PatchesIn"
        Me.PatchesIn.Padding = New System.Windows.Forms.Padding(3)
        Me.PatchesIn.Size = New System.Drawing.Size(1048, 525)
        Me.PatchesIn.TabIndex = 8
        Me.PatchesIn.Text = "KB - Installed"
        Me.PatchesIn.UseVisualStyleBackColor = True
        '
        'SCCMPatchesInstalled
        '
        Me.SCCMPatchesInstalled.BackColor = System.Drawing.Color.Transparent
        Me.SCCMPatchesInstalled.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.SCCMPatchesInstalled.Location = New System.Drawing.Point(7, 4)
        Me.SCCMPatchesInstalled.Name = "SCCMPatchesInstalled"
        Me.SCCMPatchesInstalled.Size = New System.Drawing.Size(138, 25)
        Me.SCCMPatchesInstalled.TabIndex = 147
        Me.SCCMPatchesInstalled.Text = "SCCM - List Installed KB"
        Me.SCCMPatchesInstalled.UseCustomBackColor = True
        Me.SCCMPatchesInstalled.UseCustomForeColor = True
        Me.SCCMPatchesInstalled.UseSelectable = True
        '
        'SCCMPatchesInstalledDataGridView
        '
        Me.SCCMPatchesInstalledDataGridView.AllowUserToResizeRows = False
        Me.SCCMPatchesInstalledDataGridView.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.SCCMPatchesInstalledDataGridView.BackgroundColor = System.Drawing.SystemColors.Window
        Me.SCCMPatchesInstalledDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.SCCMPatchesInstalledDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn33})
        Me.SCCMPatchesInstalledDataGridView.Location = New System.Drawing.Point(4, 32)
        Me.SCCMPatchesInstalledDataGridView.Name = "SCCMPatchesInstalledDataGridView"
        Me.SCCMPatchesInstalledDataGridView.RowHeadersVisible = False
        Me.SCCMPatchesInstalledDataGridView.RowTemplate.Height = 21
        Me.SCCMPatchesInstalledDataGridView.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.SCCMPatchesInstalledDataGridView.Size = New System.Drawing.Size(1040, 490)
        Me.SCCMPatchesInstalledDataGridView.TabIndex = 146
        '
        'DataGridViewTextBoxColumn33
        '
        Me.DataGridViewTextBoxColumn33.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn33.FillWeight = 68.65804!
        Me.DataGridViewTextBoxColumn33.HeaderText = "Installed KB Title"
        Me.DataGridViewTextBoxColumn33.Name = "DataGridViewTextBoxColumn33"
        Me.DataGridViewTextBoxColumn33.ReadOnly = True
        '
        'SCCMcomplianceTab
        '
        Me.SCCMcomplianceTab.BackColor = System.Drawing.Color.White
        Me.SCCMcomplianceTab.Controls.Add(Me.TableLayoutPanel46)
        Me.SCCMcomplianceTab.Controls.Add(Me.TableLayoutPanel45)
        Me.SCCMcomplianceTab.Controls.Add(Me.SCCMcomplianceButton)
        Me.SCCMcomplianceTab.ImageIndex = 8
        Me.SCCMcomplianceTab.Location = New System.Drawing.Point(4, 23)
        Me.SCCMcomplianceTab.Name = "SCCMcomplianceTab"
        Me.SCCMcomplianceTab.Size = New System.Drawing.Size(1048, 525)
        Me.SCCMcomplianceTab.TabIndex = 0
        Me.SCCMcomplianceTab.Text = "KB  - Compliance"
        '
        'TableLayoutPanel46
        '
        Me.TableLayoutPanel46.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel46.ColumnCount = 1
        Me.TableLayoutPanel46.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel46.Controls.Add(Me.MetroLabel28, 0, 1)
        Me.TableLayoutPanel46.Controls.Add(Me.MetroLabel27, 0, 0)
        Me.TableLayoutPanel46.Location = New System.Drawing.Point(5, 61)
        Me.TableLayoutPanel46.Name = "TableLayoutPanel46"
        Me.TableLayoutPanel46.RowCount = 2
        Me.TableLayoutPanel46.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 48.87064!))
        Me.TableLayoutPanel46.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 51.12936!))
        Me.TableLayoutPanel46.Size = New System.Drawing.Size(136, 502)
        Me.TableLayoutPanel46.TabIndex = 153
        '
        'MetroLabel28
        '
        Me.MetroLabel28.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.MetroLabel28.AutoSize = True
        Me.MetroLabel28.ForeColor = System.Drawing.SystemColors.Highlight
        Me.MetroLabel28.Location = New System.Drawing.Point(3, 245)
        Me.MetroLabel28.Name = "MetroLabel28"
        Me.MetroLabel28.Size = New System.Drawing.Size(130, 19)
        Me.MetroLabel28.TabIndex = 150
        Me.MetroLabel28.Text = "SoftUpdtGrpDeploy"
        Me.MetroLabel28.UseCustomForeColor = True
        '
        'MetroLabel27
        '
        Me.MetroLabel27.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.MetroLabel27.AutoSize = True
        Me.MetroLabel27.ForeColor = System.Drawing.SystemColors.Highlight
        Me.MetroLabel27.Location = New System.Drawing.Point(3, 0)
        Me.MetroLabel27.Name = "MetroLabel27"
        Me.MetroLabel27.Size = New System.Drawing.Size(130, 19)
        Me.MetroLabel27.TabIndex = 149
        Me.MetroLabel27.Text = "Policy Assignments"
        Me.MetroLabel27.UseCustomForeColor = True
        '
        'TableLayoutPanel45
        '
        Me.TableLayoutPanel45.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel45.ColumnCount = 1
        Me.TableLayoutPanel45.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel45.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel45.Controls.Add(Me.SCCMcomplianceDataGridView1, 0, 0)
        Me.TableLayoutPanel45.Controls.Add(Me.SCCMcomplianceDataGridView2, 0, 1)
        Me.TableLayoutPanel45.Location = New System.Drawing.Point(147, 58)
        Me.TableLayoutPanel45.Name = "TableLayoutPanel45"
        Me.TableLayoutPanel45.RowCount = 2
        Me.TableLayoutPanel45.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 48.07302!))
        Me.TableLayoutPanel45.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 51.92698!))
        Me.TableLayoutPanel45.Size = New System.Drawing.Size(898, 464)
        Me.TableLayoutPanel45.TabIndex = 152
        '
        'SCCMcomplianceDataGridView1
        '
        Me.SCCMcomplianceDataGridView1.AllowDrop = True
        Me.SCCMcomplianceDataGridView1.AllowUserToResizeRows = False
        Me.SCCMcomplianceDataGridView1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.SCCMcomplianceDataGridView1.BackgroundColor = System.Drawing.SystemColors.Window
        Me.SCCMcomplianceDataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.SCCMcomplianceDataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn34, Me.AssignmentID})
        Me.SCCMcomplianceDataGridView1.Location = New System.Drawing.Point(3, 3)
        Me.SCCMcomplianceDataGridView1.Name = "SCCMcomplianceDataGridView1"
        Me.SCCMcomplianceDataGridView1.RowHeadersVisible = False
        Me.SCCMcomplianceDataGridView1.RowTemplate.Height = 21
        Me.SCCMcomplianceDataGridView1.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.SCCMcomplianceDataGridView1.Size = New System.Drawing.Size(892, 217)
        Me.SCCMcomplianceDataGridView1.TabIndex = 147
        '
        'DataGridViewTextBoxColumn34
        '
        Me.DataGridViewTextBoxColumn34.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn34.HeaderText = "Assignment Name"
        Me.DataGridViewTextBoxColumn34.Name = "DataGridViewTextBoxColumn34"
        Me.DataGridViewTextBoxColumn34.ReadOnly = True
        '
        'AssignmentID
        '
        Me.AssignmentID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.AssignmentID.HeaderText = "Assignment ID"
        Me.AssignmentID.Name = "AssignmentID"
        '
        'SCCMcomplianceDataGridView2
        '
        Me.SCCMcomplianceDataGridView2.AllowDrop = True
        Me.SCCMcomplianceDataGridView2.AllowUserToResizeRows = False
        Me.SCCMcomplianceDataGridView2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.SCCMcomplianceDataGridView2.BackgroundColor = System.Drawing.SystemColors.Window
        Me.SCCMcomplianceDataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.SCCMcomplianceDataGridView2.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn36, Me.DataGridViewTextBoxColumn37})
        Me.SCCMcomplianceDataGridView2.Location = New System.Drawing.Point(3, 226)
        Me.SCCMcomplianceDataGridView2.Name = "SCCMcomplianceDataGridView2"
        Me.SCCMcomplianceDataGridView2.RowHeadersVisible = False
        Me.SCCMcomplianceDataGridView2.RowTemplate.Height = 21
        Me.SCCMcomplianceDataGridView2.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.SCCMcomplianceDataGridView2.Size = New System.Drawing.Size(892, 235)
        Me.SCCMcomplianceDataGridView2.TabIndex = 148
        '
        'DataGridViewTextBoxColumn36
        '
        Me.DataGridViewTextBoxColumn36.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn36.HeaderText = "Assignment ID"
        Me.DataGridViewTextBoxColumn36.Name = "DataGridViewTextBoxColumn36"
        Me.DataGridViewTextBoxColumn36.ReadOnly = True
        '
        'DataGridViewTextBoxColumn37
        '
        Me.DataGridViewTextBoxColumn37.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn37.HeaderText = "IsCompliant"
        Me.DataGridViewTextBoxColumn37.Name = "DataGridViewTextBoxColumn37"
        '
        'SCCMcomplianceButton
        '
        Me.SCCMcomplianceButton.BackColor = System.Drawing.Color.Transparent
        Me.SCCMcomplianceButton.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.SCCMcomplianceButton.Location = New System.Drawing.Point(18, 16)
        Me.SCCMcomplianceButton.Name = "SCCMcomplianceButton"
        Me.SCCMcomplianceButton.Size = New System.Drawing.Size(174, 25)
        Me.SCCMcomplianceButton.TabIndex = 151
        Me.SCCMcomplianceButton.Text = "SCCM - Compliance Checker"
        Me.SCCMcomplianceButton.UseCustomBackColor = True
        Me.SCCMcomplianceButton.UseCustomForeColor = True
        Me.SCCMcomplianceButton.UseSelectable = True
        '
        'RemoteCommandsSCCM
        '
        Me.RemoteCommandsSCCM.Controls.Add(Me.TableLayoutPanel29)
        Me.RemoteCommandsSCCM.ImageIndex = 3
        Me.RemoteCommandsSCCM.Location = New System.Drawing.Point(4, 23)
        Me.RemoteCommandsSCCM.Margin = New System.Windows.Forms.Padding(2)
        Me.RemoteCommandsSCCM.Name = "RemoteCommandsSCCM"
        Me.RemoteCommandsSCCM.Padding = New System.Windows.Forms.Padding(2)
        Me.RemoteCommandsSCCM.Size = New System.Drawing.Size(1048, 525)
        Me.RemoteCommandsSCCM.TabIndex = 4
        Me.RemoteCommandsSCCM.Text = "Remote Commands"
        Me.RemoteCommandsSCCM.UseVisualStyleBackColor = True
        '
        'TableLayoutPanel29
        '
        Me.TableLayoutPanel29.AutoSize = True
        Me.TableLayoutPanel29.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.TableLayoutPanel29.ColumnCount = 3
        Me.TableLayoutPanel29.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel29.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel29.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel29.Controls.Add(Me.Label226, 0, 2)
        Me.TableLayoutPanel29.Controls.Add(Me.Label173, 0, 0)
        Me.TableLayoutPanel29.Controls.Add(Me.Label194, 0, 1)
        Me.TableLayoutPanel29.Controls.Add(Me.Button173, 2, 0)
        Me.TableLayoutPanel29.Controls.Add(Me.SCCMREPAIRWMI, 2, 1)
        Me.TableLayoutPanel29.Controls.Add(Me.Button9, 2, 2)
        Me.TableLayoutPanel29.Controls.Add(Me.TAPREPAIRSCCMCLIENT, 1, 0)
        Me.TableLayoutPanel29.Controls.Add(Me.TAPREPAIRWMI, 1, 1)
        Me.TableLayoutPanel29.Controls.Add(Me.TAPHRP, 1, 2)
        Me.TableLayoutPanel29.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel29.Location = New System.Drawing.Point(2, 2)
        Me.TableLayoutPanel29.Margin = New System.Windows.Forms.Padding(2)
        Me.TableLayoutPanel29.Name = "TableLayoutPanel29"
        Me.TableLayoutPanel29.RowCount = 3
        Me.TableLayoutPanel29.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 31.47793!))
        Me.TableLayoutPanel29.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.39731!))
        Me.TableLayoutPanel29.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 34.93282!))
        Me.TableLayoutPanel29.Size = New System.Drawing.Size(1044, 521)
        Me.TableLayoutPanel29.TabIndex = 0
        '
        'Label226
        '
        Me.Label226.AutoSize = True
        Me.Label226.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label226.Location = New System.Drawing.Point(2, 338)
        Me.Label226.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label226.Name = "Label226"
        Me.Label226.Size = New System.Drawing.Size(344, 183)
        Me.Label226.TabIndex = 145
        Me.Label226.Text = "Hard Reset SCCM Client Policy >"
        Me.Label226.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label173
        '
        Me.Label173.AutoSize = True
        Me.Label173.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label173.Location = New System.Drawing.Point(2, 0)
        Me.Label173.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label173.Name = "Label173"
        Me.Label173.Size = New System.Drawing.Size(344, 164)
        Me.Label173.TabIndex = 48
        Me.Label173.Text = "Repair SCCM Client On Asset>"
        Me.Label173.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label194
        '
        Me.Label194.AutoSize = True
        Me.Label194.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label194.Location = New System.Drawing.Point(2, 164)
        Me.Label194.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label194.Name = "Label194"
        Me.Label194.Size = New System.Drawing.Size(344, 174)
        Me.Label194.TabIndex = 56
        Me.Label194.Text = "REPAIR WMI On Asset>"
        Me.Label194.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Button173
        '
        Me.Button173.BackColor = System.Drawing.Color.Transparent
        Me.Button173.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button173.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.Button173.Location = New System.Drawing.Point(699, 3)
        Me.Button173.Name = "Button173"
        Me.Button173.Size = New System.Drawing.Size(342, 158)
        Me.Button173.TabIndex = 154
        Me.Button173.Text = "Trigger Action - WMIC"
        Me.Button173.UseCustomBackColor = True
        Me.Button173.UseCustomForeColor = True
        Me.Button173.UseSelectable = True
        '
        'SCCMREPAIRWMI
        '
        Me.SCCMREPAIRWMI.BackColor = System.Drawing.Color.Transparent
        Me.SCCMREPAIRWMI.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SCCMREPAIRWMI.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.SCCMREPAIRWMI.Location = New System.Drawing.Point(699, 167)
        Me.SCCMREPAIRWMI.Name = "SCCMREPAIRWMI"
        Me.SCCMREPAIRWMI.Size = New System.Drawing.Size(342, 168)
        Me.SCCMREPAIRWMI.TabIndex = 152
        Me.SCCMREPAIRWMI.Text = "Trigger Action - WMIC"
        Me.SCCMREPAIRWMI.UseCustomBackColor = True
        Me.SCCMREPAIRWMI.UseCustomForeColor = True
        Me.SCCMREPAIRWMI.UseSelectable = True
        '
        'Button9
        '
        Me.Button9.BackColor = System.Drawing.Color.Transparent
        Me.Button9.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button9.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.Button9.Location = New System.Drawing.Point(699, 341)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(342, 177)
        Me.Button9.TabIndex = 149
        Me.Button9.Text = "Trigger Action - WMIC"
        Me.Button9.UseCustomBackColor = True
        Me.Button9.UseCustomForeColor = True
        Me.Button9.UseSelectable = True
        '
        'TAPREPAIRSCCMCLIENT
        '
        Me.TAPREPAIRSCCMCLIENT.BackColor = System.Drawing.Color.Transparent
        Me.TAPREPAIRSCCMCLIENT.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TAPREPAIRSCCMCLIENT.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.TAPREPAIRSCCMCLIENT.Location = New System.Drawing.Point(351, 3)
        Me.TAPREPAIRSCCMCLIENT.Name = "TAPREPAIRSCCMCLIENT"
        Me.TAPREPAIRSCCMCLIENT.Size = New System.Drawing.Size(342, 158)
        Me.TAPREPAIRSCCMCLIENT.TabIndex = 171
        Me.TAPREPAIRSCCMCLIENT.Text = "Trigger Action - PowerShell"
        Me.TAPREPAIRSCCMCLIENT.UseCustomBackColor = True
        Me.TAPREPAIRSCCMCLIENT.UseCustomForeColor = True
        Me.TAPREPAIRSCCMCLIENT.UseSelectable = True
        '
        'TAPREPAIRWMI
        '
        Me.TAPREPAIRWMI.BackColor = System.Drawing.Color.Transparent
        Me.TAPREPAIRWMI.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TAPREPAIRWMI.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.TAPREPAIRWMI.Location = New System.Drawing.Point(351, 167)
        Me.TAPREPAIRWMI.Name = "TAPREPAIRWMI"
        Me.TAPREPAIRWMI.Size = New System.Drawing.Size(342, 168)
        Me.TAPREPAIRWMI.TabIndex = 173
        Me.TAPREPAIRWMI.Text = "Trigger Action - PowerShell"
        Me.TAPREPAIRWMI.UseCustomBackColor = True
        Me.TAPREPAIRWMI.UseCustomForeColor = True
        Me.TAPREPAIRWMI.UseSelectable = True
        '
        'TAPHRP
        '
        Me.TAPHRP.BackColor = System.Drawing.Color.Transparent
        Me.TAPHRP.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TAPHRP.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.TAPHRP.Location = New System.Drawing.Point(351, 341)
        Me.TAPHRP.Name = "TAPHRP"
        Me.TAPHRP.Size = New System.Drawing.Size(342, 177)
        Me.TAPHRP.TabIndex = 176
        Me.TAPHRP.Text = "Trigger Action - PowerShell"
        Me.TAPHRP.UseCustomBackColor = True
        Me.TAPHRP.UseCustomForeColor = True
        Me.TAPHRP.UseSelectable = True
        '
        'ClientFullLog
        '
        Me.ClientFullLog.Controls.Add(Me.SCCMfullClientLog)
        Me.ClientFullLog.Controls.Add(Me.GetFullCLientLogSCCM)
        Me.ClientFullLog.ImageKey = "Oxygen-Icons.org-Oxygen-Actions-view-list-details.ico"
        Me.ClientFullLog.Location = New System.Drawing.Point(4, 23)
        Me.ClientFullLog.Name = "ClientFullLog"
        Me.ClientFullLog.Padding = New System.Windows.Forms.Padding(3)
        Me.ClientFullLog.Size = New System.Drawing.Size(1048, 525)
        Me.ClientFullLog.TabIndex = 10
        Me.ClientFullLog.Text = "Client - StateMsg Log"
        Me.ClientFullLog.UseVisualStyleBackColor = True
        '
        'SCCMfullClientLog
        '
        Me.SCCMfullClientLog.AllowUserToResizeRows = False
        Me.SCCMfullClientLog.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.SCCMfullClientLog.BackgroundColor = System.Drawing.SystemColors.Window
        Me.SCCMfullClientLog.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.SCCMfullClientLog.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn40, Me.SCCMClientMessageSent, Me.SCCMClientMessageTime})
        Me.SCCMfullClientLog.Location = New System.Drawing.Point(8, 36)
        Me.SCCMfullClientLog.Name = "SCCMfullClientLog"
        Me.SCCMfullClientLog.RowHeadersVisible = False
        Me.SCCMfullClientLog.RowTemplate.Height = 21
        Me.SCCMfullClientLog.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.SCCMfullClientLog.Size = New System.Drawing.Size(1040, 483)
        Me.SCCMfullClientLog.TabIndex = 149
        '
        'DataGridViewTextBoxColumn40
        '
        Me.DataGridViewTextBoxColumn40.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn40.FillWeight = 68.65804!
        Me.DataGridViewTextBoxColumn40.HeaderText = "StateMsg"
        Me.DataGridViewTextBoxColumn40.Name = "DataGridViewTextBoxColumn40"
        Me.DataGridViewTextBoxColumn40.ReadOnly = True
        '
        'SCCMClientMessageSent
        '
        Me.SCCMClientMessageSent.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.SCCMClientMessageSent.FillWeight = 10.0!
        Me.SCCMClientMessageSent.HeaderText = "MessageSent"
        Me.SCCMClientMessageSent.Name = "SCCMClientMessageSent"
        '
        'SCCMClientMessageTime
        '
        Me.SCCMClientMessageTime.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.SCCMClientMessageTime.FillWeight = 50.0!
        Me.SCCMClientMessageTime.HeaderText = "MessageTime"
        Me.SCCMClientMessageTime.Name = "SCCMClientMessageTime"
        '
        'GetFullCLientLogSCCM
        '
        Me.GetFullCLientLogSCCM.BackColor = System.Drawing.Color.Transparent
        Me.GetFullCLientLogSCCM.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.GetFullCLientLogSCCM.Location = New System.Drawing.Point(8, 6)
        Me.GetFullCLientLogSCCM.Name = "GetFullCLientLogSCCM"
        Me.GetFullCLientLogSCCM.Size = New System.Drawing.Size(172, 25)
        Me.GetFullCLientLogSCCM.TabIndex = 148
        Me.GetFullCLientLogSCCM.Text = "Get Client - StateMsg Log"
        Me.GetFullCLientLogSCCM.UseCustomBackColor = True
        Me.GetFullCLientLogSCCM.UseCustomForeColor = True
        Me.GetFullCLientLogSCCM.UseSelectable = True
        '
        'CacheDirectoryChange
        '
        Me.CacheDirectoryChange.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.CacheDirectoryChange.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.CacheDirectoryChange.Location = New System.Drawing.Point(712, 56)
        Me.CacheDirectoryChange.Margin = New System.Windows.Forms.Padding(2)
        Me.CacheDirectoryChange.Name = "CacheDirectoryChange"
        Me.CacheDirectoryChange.Size = New System.Drawing.Size(250, 21)
        Me.CacheDirectoryChange.TabIndex = 126
        Me.CacheDirectoryChange.Text = "D:\SCCM\CCM\Cache"
        '
        'CacheChangeSize
        '
        Me.CacheChangeSize.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.CacheChangeSize.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.CacheChangeSize.Location = New System.Drawing.Point(857, 30)
        Me.CacheChangeSize.Margin = New System.Windows.Forms.Padding(2)
        Me.CacheChangeSize.MaxLength = 6
        Me.CacheChangeSize.Name = "CacheChangeSize"
        Me.CacheChangeSize.Size = New System.Drawing.Size(74, 21)
        Me.CacheChangeSize.TabIndex = 123
        Me.CacheChangeSize.Text = "500"
        '
        'Label166
        '
        Me.Label166.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label166.AutoSize = True
        Me.Label166.BackColor = System.Drawing.Color.Transparent
        Me.Label166.Location = New System.Drawing.Point(935, 33)
        Me.Label166.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label166.Name = "Label166"
        Me.Label166.Size = New System.Drawing.Size(21, 13)
        Me.Label166.TabIndex = 124
        Me.Label166.Text = "MB"
        '
        'SCCMCacheLabel
        '
        Me.SCCMCacheLabel.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.SCCMCacheLabel.BackColor = System.Drawing.Color.White
        Me.SCCMCacheLabel.Location = New System.Drawing.Point(566, 5)
        Me.SCCMCacheLabel.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.SCCMCacheLabel.Name = "SCCMCacheLabel"
        Me.SCCMCacheLabel.Size = New System.Drawing.Size(391, 19)
        Me.SCCMCacheLabel.TabIndex = 120
        Me.SCCMCacheLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label56
        '
        Me.Label56.AutoSize = True
        Me.Label56.BackColor = System.Drawing.Color.Transparent
        Me.Label56.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label56.Location = New System.Drawing.Point(58, 22)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(0, 16)
        Me.Label56.TabIndex = 118
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.BackColor = System.Drawing.Color.Transparent
        Me.Label34.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.Location = New System.Drawing.Point(58, 5)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(0, 16)
        Me.Label34.TabIndex = 116
        '
        'MetroTile11
        '
        Me.MetroTile11.ActiveControl = Nothing
        Me.MetroTile11.BackColor = System.Drawing.Color.Transparent
        Me.MetroTile11.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.MetroTile11.Location = New System.Drawing.Point(2, 3)
        Me.MetroTile11.Name = "MetroTile11"
        Me.MetroTile11.Size = New System.Drawing.Size(38, 43)
        Me.MetroTile11.TabIndex = 130
        Me.MetroTile11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MetroTile11.TileImage = CType(resources.GetObject("MetroTile11.TileImage"), System.Drawing.Image)
        Me.MetroTile11.TileImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MetroTile11.TileTextFontSize = MetroFramework.MetroTileTextSize.Small
        Me.MetroTile11.UseCustomBackColor = True
        Me.MetroTile11.UseCustomForeColor = True
        Me.MetroTile11.UseSelectable = True
        Me.MetroTile11.UseTileImage = True
        '
        'ServicesTab17
        '
        Me.ServicesTab17.BackColor = System.Drawing.Color.Transparent
        Me.ServicesTab17.Controls.Add(Me.ExportServices)
        Me.ServicesTab17.Controls.Add(Me.GetServices)
        Me.ServicesTab17.Controls.Add(Me.TableLayoutPanel18)
        Me.ServicesTab17.Controls.Add(Me.TableLayoutPanel12)
        Me.ServicesTab17.Controls.Add(Me.Label50)
        Me.ServicesTab17.Controls.Add(Me.Label38)
        Me.ServicesTab17.Controls.Add(Me.ServiceNameSelected)
        Me.ServicesTab17.Controls.Add(Me.Label35)
        Me.ServicesTab17.Controls.Add(Me.MetroTile12)
        Me.ServicesTab17.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.ServicesTab17.HorizontalScrollbarBarColor = True
        Me.ServicesTab17.HorizontalScrollbarHighlightOnWheel = False
        Me.ServicesTab17.HorizontalScrollbarSize = 10
        Me.ServicesTab17.Location = New System.Drawing.Point(4, 34)
        Me.ServicesTab17.Name = "ServicesTab17"
        Me.ServicesTab17.Size = New System.Drawing.Size(1075, 678)
        Me.ServicesTab17.TabIndex = 9
        Me.ServicesTab17.Text = "Services   "
        Me.ServicesTab17.VerticalScrollbarBarColor = True
        Me.ServicesTab17.VerticalScrollbarHighlightOnWheel = False
        Me.ServicesTab17.VerticalScrollbarSize = 10
        '
        'ExportServices
        '
        Me.ExportServices.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ExportServices.BackColor = System.Drawing.Color.AliceBlue
        Me.ExportServices.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.ExportServices.Location = New System.Drawing.Point(986, 18)
        Me.ExportServices.Name = "ExportServices"
        Me.ExportServices.Size = New System.Drawing.Size(86, 28)
        Me.ExportServices.TabIndex = 135
        Me.ExportServices.Text = "Export to CSV"
        Me.ExportServices.UseCustomBackColor = True
        Me.ExportServices.UseCustomForeColor = True
        Me.ExportServices.UseSelectable = True
        '
        'GetServices
        '
        Me.GetServices.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.GetServices.BackColor = System.Drawing.Color.AliceBlue
        Me.GetServices.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.GetServices.Location = New System.Drawing.Point(378, 18)
        Me.GetServices.Name = "GetServices"
        Me.GetServices.Size = New System.Drawing.Size(155, 28)
        Me.GetServices.TabIndex = 134
        Me.GetServices.Text = "List Services"
        Me.GetServices.UseCustomBackColor = True
        Me.GetServices.UseCustomForeColor = True
        Me.GetServices.UseSelectable = True
        '
        'TableLayoutPanel18
        '
        Me.TableLayoutPanel18.BackColor = System.Drawing.Color.Transparent
        Me.TableLayoutPanel18.ColumnCount = 8
        Me.TableLayoutPanel18.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.TableLayoutPanel18.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.TableLayoutPanel18.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.TableLayoutPanel18.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.TableLayoutPanel18.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.TableLayoutPanel18.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.TableLayoutPanel18.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.TableLayoutPanel18.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.TableLayoutPanel18.Controls.Add(Me.StartService, 0, 0)
        Me.TableLayoutPanel18.Controls.Add(Me.Label209, 4, 0)
        Me.TableLayoutPanel18.Controls.Add(Me.DeleteServiceButton, 7, 0)
        Me.TableLayoutPanel18.Controls.Add(Me.SetServiceStartDisabled, 5, 0)
        Me.TableLayoutPanel18.Controls.Add(Me.SetServiceStartManual, 3, 0)
        Me.TableLayoutPanel18.Controls.Add(Me.SetServiceStartAutomatic, 2, 0)
        Me.TableLayoutPanel18.Controls.Add(Me.StopService, 1, 0)
        Me.TableLayoutPanel18.Controls.Add(Me.Label37, 6, 0)
        Me.TableLayoutPanel18.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.TableLayoutPanel18.Location = New System.Drawing.Point(0, 647)
        Me.TableLayoutPanel18.Margin = New System.Windows.Forms.Padding(2)
        Me.TableLayoutPanel18.Name = "TableLayoutPanel18"
        Me.TableLayoutPanel18.RowCount = 1
        Me.TableLayoutPanel18.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel18.Size = New System.Drawing.Size(1075, 31)
        Me.TableLayoutPanel18.TabIndex = 120
        '
        'StartService
        '
        Me.StartService.BackColor = System.Drawing.Color.Transparent
        Me.StartService.Dock = System.Windows.Forms.DockStyle.Fill
        Me.StartService.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.StartService.Location = New System.Drawing.Point(3, 3)
        Me.StartService.Name = "StartService"
        Me.StartService.Size = New System.Drawing.Size(128, 25)
        Me.StartService.TabIndex = 141
        Me.StartService.Text = "Start Service"
        Me.StartService.UseCustomBackColor = True
        Me.StartService.UseCustomForeColor = True
        Me.StartService.UseSelectable = True
        '
        'Label209
        '
        Me.Label209.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.Label209.AutoSize = True
        Me.Label209.ForeColor = System.Drawing.Color.Red
        Me.Label209.Location = New System.Drawing.Point(566, 9)
        Me.Label209.Name = "Label209"
        Me.Label209.Size = New System.Drawing.Size(101, 13)
        Me.Label209.TabIndex = 109
        Me.Label209.Text = "Use With Caution >"
        '
        'DeleteServiceButton
        '
        Me.DeleteServiceButton.BackColor = System.Drawing.Color.Transparent
        Me.DeleteServiceButton.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DeleteServiceButton.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.DeleteServiceButton.Location = New System.Drawing.Point(941, 3)
        Me.DeleteServiceButton.Name = "DeleteServiceButton"
        Me.DeleteServiceButton.Size = New System.Drawing.Size(131, 25)
        Me.DeleteServiceButton.TabIndex = 136
        Me.DeleteServiceButton.Text = "Delete Service"
        Me.DeleteServiceButton.UseCustomBackColor = True
        Me.DeleteServiceButton.UseCustomForeColor = True
        Me.DeleteServiceButton.UseSelectable = True
        '
        'SetServiceStartDisabled
        '
        Me.SetServiceStartDisabled.BackColor = System.Drawing.Color.Transparent
        Me.SetServiceStartDisabled.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SetServiceStartDisabled.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.SetServiceStartDisabled.Location = New System.Drawing.Point(673, 3)
        Me.SetServiceStartDisabled.Name = "SetServiceStartDisabled"
        Me.SetServiceStartDisabled.Size = New System.Drawing.Size(128, 25)
        Me.SetServiceStartDisabled.TabIndex = 137
        Me.SetServiceStartDisabled.Text = "Set to ""Disabled"""
        Me.SetServiceStartDisabled.UseCustomBackColor = True
        Me.SetServiceStartDisabled.UseCustomForeColor = True
        Me.SetServiceStartDisabled.UseSelectable = True
        '
        'SetServiceStartManual
        '
        Me.SetServiceStartManual.BackColor = System.Drawing.Color.Transparent
        Me.SetServiceStartManual.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SetServiceStartManual.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.SetServiceStartManual.Location = New System.Drawing.Point(405, 3)
        Me.SetServiceStartManual.Name = "SetServiceStartManual"
        Me.SetServiceStartManual.Size = New System.Drawing.Size(128, 25)
        Me.SetServiceStartManual.TabIndex = 138
        Me.SetServiceStartManual.Text = "Set to ""Manual"""
        Me.SetServiceStartManual.UseCustomBackColor = True
        Me.SetServiceStartManual.UseCustomForeColor = True
        Me.SetServiceStartManual.UseSelectable = True
        '
        'SetServiceStartAutomatic
        '
        Me.SetServiceStartAutomatic.BackColor = System.Drawing.Color.Transparent
        Me.SetServiceStartAutomatic.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SetServiceStartAutomatic.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.SetServiceStartAutomatic.Location = New System.Drawing.Point(271, 3)
        Me.SetServiceStartAutomatic.Name = "SetServiceStartAutomatic"
        Me.SetServiceStartAutomatic.Size = New System.Drawing.Size(128, 25)
        Me.SetServiceStartAutomatic.TabIndex = 139
        Me.SetServiceStartAutomatic.Text = "Set to ""Automatic"""
        Me.SetServiceStartAutomatic.UseCustomBackColor = True
        Me.SetServiceStartAutomatic.UseCustomForeColor = True
        Me.SetServiceStartAutomatic.UseSelectable = True
        '
        'StopService
        '
        Me.StopService.BackColor = System.Drawing.Color.Transparent
        Me.StopService.Dock = System.Windows.Forms.DockStyle.Fill
        Me.StopService.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.StopService.Location = New System.Drawing.Point(137, 3)
        Me.StopService.Name = "StopService"
        Me.StopService.Size = New System.Drawing.Size(128, 25)
        Me.StopService.TabIndex = 140
        Me.StopService.Text = "Stop Service"
        Me.StopService.UseCustomBackColor = True
        Me.StopService.UseCustomForeColor = True
        Me.StopService.UseSelectable = True
        '
        'Label37
        '
        Me.Label37.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.Label37.AutoSize = True
        Me.Label37.ForeColor = System.Drawing.Color.Red
        Me.Label37.Location = New System.Drawing.Point(834, 9)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(101, 13)
        Me.Label37.TabIndex = 88
        Me.Label37.Text = "Use With Caution >"
        '
        'TableLayoutPanel12
        '
        Me.TableLayoutPanel12.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel12.BackColor = System.Drawing.Color.Transparent
        Me.TableLayoutPanel12.ColumnCount = 1
        Me.TableLayoutPanel12.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel12.Controls.Add(Me.DataGridView7, 0, 0)
        Me.TableLayoutPanel12.Location = New System.Drawing.Point(0, 51)
        Me.TableLayoutPanel12.Margin = New System.Windows.Forms.Padding(2)
        Me.TableLayoutPanel12.Name = "TableLayoutPanel12"
        Me.TableLayoutPanel12.RowCount = 1
        Me.TableLayoutPanel12.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel12.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 544.0!))
        Me.TableLayoutPanel12.Size = New System.Drawing.Size(1075, 544)
        Me.TableLayoutPanel12.TabIndex = 119
        '
        'DataGridView7
        '
        Me.DataGridView7.AllowUserToDeleteRows = False
        Me.DataGridView7.AllowUserToResizeRows = False
        Me.DataGridView7.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader
        Me.DataGridView7.BackgroundColor = System.Drawing.SystemColors.Window
        Me.DataGridView7.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView7.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.ServiceName, Me.ServiceDescription, Me.StartedYesNo, Me.Status})
        Me.DataGridView7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DataGridView7.Location = New System.Drawing.Point(3, 3)
        Me.DataGridView7.Name = "DataGridView7"
        Me.DataGridView7.RowHeadersVisible = False
        Me.DataGridView7.RowTemplate.Height = 24
        Me.DataGridView7.Size = New System.Drawing.Size(1069, 538)
        Me.DataGridView7.TabIndex = 84
        '
        'ServiceName
        '
        Me.ServiceName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.ServiceName.FillWeight = 25.0!
        Me.ServiceName.HeaderText = "Service Name"
        Me.ServiceName.Name = "ServiceName"
        Me.ServiceName.ReadOnly = True
        '
        'ServiceDescription
        '
        Me.ServiceDescription.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.ServiceDescription.FillWeight = 50.0!
        Me.ServiceDescription.HeaderText = "ServiceDescription"
        Me.ServiceDescription.Name = "ServiceDescription"
        Me.ServiceDescription.ReadOnly = True
        Me.ServiceDescription.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'StartedYesNo
        '
        Me.StartedYesNo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.StartedYesNo.FillWeight = 10.0!
        Me.StartedYesNo.HeaderText = "State"
        Me.StartedYesNo.Name = "StartedYesNo"
        Me.StartedYesNo.ReadOnly = True
        Me.StartedYesNo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'Status
        '
        Me.Status.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.Status.FillWeight = 10.0!
        Me.Status.HeaderText = "StartMode"
        Me.Status.Name = "Status"
        Me.Status.ReadOnly = True
        Me.Status.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.BackColor = System.Drawing.Color.Transparent
        Me.Label50.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label50.Location = New System.Drawing.Point(59, 20)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(0, 16)
        Me.Label50.TabIndex = 118
        '
        'Label38
        '
        Me.Label38.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label38.AutoSize = True
        Me.Label38.BackColor = System.Drawing.Color.Transparent
        Me.Label38.Location = New System.Drawing.Point(0, 597)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(374, 13)
        Me.Label38.TabIndex = 117
        Me.Label38.Text = "Select a ""Service Name""  from the above list before using the buttons below!"
        '
        'ServiceNameSelected
        '
        Me.ServiceNameSelected.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.ServiceNameSelected.Location = New System.Drawing.Point(0, 613)
        Me.ServiceNameSelected.Name = "ServiceNameSelected"
        Me.ServiceNameSelected.Size = New System.Drawing.Size(477, 21)
        Me.ServiceNameSelected.TabIndex = 116
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.BackColor = System.Drawing.Color.Transparent
        Me.Label35.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label35.Location = New System.Drawing.Point(59, 3)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(0, 16)
        Me.Label35.TabIndex = 115
        '
        'MetroTile12
        '
        Me.MetroTile12.ActiveControl = Nothing
        Me.MetroTile12.BackColor = System.Drawing.Color.Transparent
        Me.MetroTile12.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.MetroTile12.Location = New System.Drawing.Point(3, 3)
        Me.MetroTile12.Name = "MetroTile12"
        Me.MetroTile12.Size = New System.Drawing.Size(38, 43)
        Me.MetroTile12.TabIndex = 131
        Me.MetroTile12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MetroTile12.TileImage = CType(resources.GetObject("MetroTile12.TileImage"), System.Drawing.Image)
        Me.MetroTile12.TileImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MetroTile12.TileTextFontSize = MetroFramework.MetroTileTextSize.Small
        Me.MetroTile12.UseCustomBackColor = True
        Me.MetroTile12.UseCustomForeColor = True
        Me.MetroTile12.UseSelectable = True
        Me.MetroTile12.UseTileImage = True
        '
        'StoreApps18
        '
        Me.StoreApps18.BackColor = System.Drawing.Color.Transparent
        Me.StoreApps18.Controls.Add(Me.TableLayoutPanel31)
        Me.StoreApps18.Controls.Add(Me.ExportStoreApps)
        Me.StoreApps18.Controls.Add(Me.ListStoreApps)
        Me.StoreApps18.Controls.Add(Me.Labelstoreapps2)
        Me.StoreApps18.Controls.Add(Me.Labelstoreapps1)
        Me.StoreApps18.Controls.Add(Me.MetroTile16)
        Me.StoreApps18.Location = New System.Drawing.Point(4, 34)
        Me.StoreApps18.Name = "StoreApps18"
        Me.StoreApps18.Size = New System.Drawing.Size(1075, 678)
        Me.StoreApps18.TabIndex = 18
        Me.StoreApps18.Text = "StoreApps"
        '
        'TableLayoutPanel31
        '
        Me.TableLayoutPanel31.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel31.BackColor = System.Drawing.Color.Transparent
        Me.TableLayoutPanel31.ColumnCount = 1
        Me.TableLayoutPanel31.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel31.Controls.Add(Me.StoreAppsDataGridView, 0, 0)
        Me.TableLayoutPanel31.Location = New System.Drawing.Point(3, 51)
        Me.TableLayoutPanel31.Margin = New System.Windows.Forms.Padding(2)
        Me.TableLayoutPanel31.Name = "TableLayoutPanel31"
        Me.TableLayoutPanel31.RowCount = 1
        Me.TableLayoutPanel31.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel31.Size = New System.Drawing.Size(1069, 625)
        Me.TableLayoutPanel31.TabIndex = 146
        '
        'StoreAppsDataGridView
        '
        Me.StoreAppsDataGridView.BackgroundColor = System.Drawing.SystemColors.Window
        Me.StoreAppsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.StoreAppsDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn17, Me.DataGridViewTextBoxColumn18, Me.Architecture, Me.ProgramId, Me.Language, Me.Vendor})
        Me.StoreAppsDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.StoreAppsDataGridView.Location = New System.Drawing.Point(3, 3)
        Me.StoreAppsDataGridView.Name = "StoreAppsDataGridView"
        Me.StoreAppsDataGridView.RowHeadersVisible = False
        Me.StoreAppsDataGridView.RowTemplate.Height = 24
        Me.StoreAppsDataGridView.Size = New System.Drawing.Size(1063, 619)
        Me.StoreAppsDataGridView.TabIndex = 46
        '
        'DataGridViewTextBoxColumn17
        '
        Me.DataGridViewTextBoxColumn17.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn17.FillWeight = 13.0!
        Me.DataGridViewTextBoxColumn17.HeaderText = "Name"
        Me.DataGridViewTextBoxColumn17.Name = "DataGridViewTextBoxColumn17"
        Me.DataGridViewTextBoxColumn17.ReadOnly = True
        '
        'DataGridViewTextBoxColumn18
        '
        Me.DataGridViewTextBoxColumn18.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn18.FillWeight = 5.0!
        Me.DataGridViewTextBoxColumn18.HeaderText = "Version"
        Me.DataGridViewTextBoxColumn18.Name = "DataGridViewTextBoxColumn18"
        Me.DataGridViewTextBoxColumn18.ReadOnly = True
        '
        'Architecture
        '
        Me.Architecture.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.Architecture.FillWeight = 3.5!
        Me.Architecture.HeaderText = "Architecture"
        Me.Architecture.Name = "Architecture"
        '
        'ProgramId
        '
        Me.ProgramId.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.ProgramId.FillWeight = 10.0!
        Me.ProgramId.HeaderText = "ProgramId"
        Me.ProgramId.Name = "ProgramId"
        '
        'Language
        '
        Me.Language.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.Language.FillWeight = 3.2!
        Me.Language.HeaderText = "Language"
        Me.Language.Name = "Language"
        '
        'Vendor
        '
        Me.Vendor.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.Vendor.FillWeight = 20.0!
        Me.Vendor.HeaderText = "Vendor"
        Me.Vendor.Name = "Vendor"
        '
        'ExportStoreApps
        '
        Me.ExportStoreApps.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ExportStoreApps.BackColor = System.Drawing.Color.AliceBlue
        Me.ExportStoreApps.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.ExportStoreApps.Location = New System.Drawing.Point(982, 16)
        Me.ExportStoreApps.Name = "ExportStoreApps"
        Me.ExportStoreApps.Size = New System.Drawing.Size(86, 28)
        Me.ExportStoreApps.TabIndex = 145
        Me.ExportStoreApps.Text = "Export to CSV"
        Me.ExportStoreApps.UseCustomBackColor = True
        Me.ExportStoreApps.UseCustomForeColor = True
        Me.ExportStoreApps.UseSelectable = True
        '
        'ListStoreApps
        '
        Me.ListStoreApps.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.ListStoreApps.BackColor = System.Drawing.Color.AliceBlue
        Me.ListStoreApps.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.ListStoreApps.Location = New System.Drawing.Point(376, 16)
        Me.ListStoreApps.Name = "ListStoreApps"
        Me.ListStoreApps.Size = New System.Drawing.Size(174, 28)
        Me.ListStoreApps.TabIndex = 144
        Me.ListStoreApps.Text = "Display Store Apps"
        Me.ListStoreApps.UseCustomBackColor = True
        Me.ListStoreApps.UseCustomForeColor = True
        Me.ListStoreApps.UseSelectable = True
        '
        'Labelstoreapps2
        '
        Me.Labelstoreapps2.AutoSize = True
        Me.Labelstoreapps2.BackColor = System.Drawing.Color.Transparent
        Me.Labelstoreapps2.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Labelstoreapps2.Location = New System.Drawing.Point(55, 20)
        Me.Labelstoreapps2.Name = "Labelstoreapps2"
        Me.Labelstoreapps2.Size = New System.Drawing.Size(0, 16)
        Me.Labelstoreapps2.TabIndex = 142
        '
        'Labelstoreapps1
        '
        Me.Labelstoreapps1.AutoSize = True
        Me.Labelstoreapps1.BackColor = System.Drawing.Color.Transparent
        Me.Labelstoreapps1.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Labelstoreapps1.Location = New System.Drawing.Point(55, 3)
        Me.Labelstoreapps1.Name = "Labelstoreapps1"
        Me.Labelstoreapps1.Size = New System.Drawing.Size(0, 16)
        Me.Labelstoreapps1.TabIndex = 141
        '
        'MetroTile16
        '
        Me.MetroTile16.ActiveControl = Nothing
        Me.MetroTile16.BackColor = System.Drawing.Color.Transparent
        Me.MetroTile16.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.MetroTile16.Location = New System.Drawing.Point(0, 3)
        Me.MetroTile16.Name = "MetroTile16"
        Me.MetroTile16.Size = New System.Drawing.Size(38, 43)
        Me.MetroTile16.TabIndex = 143
        Me.MetroTile16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MetroTile16.TileImage = CType(resources.GetObject("MetroTile16.TileImage"), System.Drawing.Image)
        Me.MetroTile16.TileImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MetroTile16.TileTextFontSize = MetroFramework.MetroTileTextSize.Small
        Me.MetroTile16.UseCustomBackColor = True
        Me.MetroTile16.UseCustomForeColor = True
        Me.MetroTile16.UseSelectable = True
        Me.MetroTile16.UseTileImage = True
        '
        'TaskManTab19
        '
        Me.TaskManTab19.Controls.Add(Me.cmdRefresh)
        Me.TaskManTab19.Controls.Add(Me.Exporttaskmanager)
        Me.TaskManTab19.Controls.Add(Me.endprocessbutton)
        Me.TaskManTab19.Controls.Add(Me.TableLayoutPanel11)
        Me.TaskManTab19.Controls.Add(Me.Label52)
        Me.TaskManTab19.Controls.Add(Me.Label42)
        Me.TaskManTab19.Controls.Add(Me.MetroTile14)
        Me.TaskManTab19.HorizontalScrollbarBarColor = True
        Me.TaskManTab19.HorizontalScrollbarHighlightOnWheel = False
        Me.TaskManTab19.HorizontalScrollbarSize = 10
        Me.TaskManTab19.Location = New System.Drawing.Point(4, 34)
        Me.TaskManTab19.Name = "TaskManTab19"
        Me.TaskManTab19.Size = New System.Drawing.Size(1075, 678)
        Me.TaskManTab19.TabIndex = 13
        Me.TaskManTab19.Text = "Task Manager"
        Me.TaskManTab19.VerticalScrollbarBarColor = True
        Me.TaskManTab19.VerticalScrollbarHighlightOnWheel = False
        Me.TaskManTab19.VerticalScrollbarSize = 10
        '
        'cmdRefresh
        '
        Me.cmdRefresh.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.cmdRefresh.BackColor = System.Drawing.Color.AliceBlue
        Me.cmdRefresh.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.cmdRefresh.Location = New System.Drawing.Point(376, 18)
        Me.cmdRefresh.Name = "cmdRefresh"
        Me.cmdRefresh.Size = New System.Drawing.Size(158, 28)
        Me.cmdRefresh.TabIndex = 130
        Me.cmdRefresh.Text = "Display Full Process List"
        Me.cmdRefresh.UseCustomBackColor = True
        Me.cmdRefresh.UseCustomForeColor = True
        Me.cmdRefresh.UseSelectable = True
        '
        'Exporttaskmanager
        '
        Me.Exporttaskmanager.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Exporttaskmanager.BackColor = System.Drawing.Color.AliceBlue
        Me.Exporttaskmanager.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.Exporttaskmanager.Location = New System.Drawing.Point(986, 18)
        Me.Exporttaskmanager.Name = "Exporttaskmanager"
        Me.Exporttaskmanager.Size = New System.Drawing.Size(86, 28)
        Me.Exporttaskmanager.TabIndex = 129
        Me.Exporttaskmanager.Text = "Export to CSV"
        Me.Exporttaskmanager.UseCustomBackColor = True
        Me.Exporttaskmanager.UseCustomForeColor = True
        Me.Exporttaskmanager.UseSelectable = True
        '
        'endprocessbutton
        '
        Me.endprocessbutton.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.endprocessbutton.BackColor = System.Drawing.Color.AliceBlue
        Me.endprocessbutton.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.endprocessbutton.Location = New System.Drawing.Point(686, 18)
        Me.endprocessbutton.Name = "endprocessbutton"
        Me.endprocessbutton.Size = New System.Drawing.Size(158, 28)
        Me.endprocessbutton.TabIndex = 128
        Me.endprocessbutton.Text = "End selected process"
        Me.endprocessbutton.UseCustomBackColor = True
        Me.endprocessbutton.UseCustomForeColor = True
        Me.endprocessbutton.UseSelectable = True
        '
        'TableLayoutPanel11
        '
        Me.TableLayoutPanel11.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel11.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.TableLayoutPanel11.BackColor = System.Drawing.Color.Transparent
        Me.TableLayoutPanel11.ColumnCount = 1
        Me.TableLayoutPanel11.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel11.Controls.Add(Me.lvwProcesses, 0, 0)
        Me.TableLayoutPanel11.Location = New System.Drawing.Point(0, 51)
        Me.TableLayoutPanel11.Margin = New System.Windows.Forms.Padding(2)
        Me.TableLayoutPanel11.Name = "TableLayoutPanel11"
        Me.TableLayoutPanel11.RowCount = 1
        Me.TableLayoutPanel11.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel11.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 625.0!))
        Me.TableLayoutPanel11.Size = New System.Drawing.Size(1075, 625)
        Me.TableLayoutPanel11.TabIndex = 115
        '
        'lvwProcesses
        '
        Me.lvwProcesses.AllowColumnReorder = True
        Me.lvwProcesses.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lvwProcesses.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.lchImage, Me.lchID, Me.WhoRun, Me.exepath})
        Me.lvwProcesses.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lvwProcesses.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold)
        Me.lvwProcesses.FullRowSelect = True
        Me.lvwProcesses.GridLines = True
        Me.lvwProcesses.Location = New System.Drawing.Point(3, 3)
        Me.lvwProcesses.Name = "lvwProcesses"
        Me.lvwProcesses.Size = New System.Drawing.Size(1069, 619)
        Me.lvwProcesses.Sorting = System.Windows.Forms.SortOrder.Ascending
        Me.lvwProcesses.TabIndex = 4
        Me.lvwProcesses.UseCompatibleStateImageBehavior = False
        Me.lvwProcesses.View = System.Windows.Forms.View.Details
        '
        'lchImage
        '
        Me.lchImage.Text = "Process Name"
        Me.lchImage.Width = 206
        '
        'lchID
        '
        Me.lchID.Text = "Process ID"
        Me.lchID.Width = 80
        '
        'WhoRun
        '
        Me.WhoRun.Text = "WhoRun"
        Me.WhoRun.Width = 212
        '
        'exepath
        '
        Me.exepath.Text = "Exepath"
        Me.exepath.Width = 565
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.BackColor = System.Drawing.Color.Transparent
        Me.Label52.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label52.Location = New System.Drawing.Point(58, 20)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(0, 16)
        Me.Label52.TabIndex = 114
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.BackColor = System.Drawing.Color.Transparent
        Me.Label42.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label42.Location = New System.Drawing.Point(58, 3)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(0, 16)
        Me.Label42.TabIndex = 112
        '
        'MetroTile14
        '
        Me.MetroTile14.ActiveControl = Nothing
        Me.MetroTile14.BackColor = System.Drawing.Color.Transparent
        Me.MetroTile14.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.MetroTile14.Location = New System.Drawing.Point(3, 3)
        Me.MetroTile14.Name = "MetroTile14"
        Me.MetroTile14.Size = New System.Drawing.Size(38, 43)
        Me.MetroTile14.TabIndex = 133
        Me.MetroTile14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MetroTile14.TileImage = CType(resources.GetObject("MetroTile14.TileImage"), System.Drawing.Image)
        Me.MetroTile14.TileImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MetroTile14.TileTextFontSize = MetroFramework.MetroTileTextSize.Small
        Me.MetroTile14.UseCustomBackColor = True
        Me.MetroTile14.UseCustomForeColor = True
        Me.MetroTile14.UseSelectable = True
        Me.MetroTile14.UseTileImage = True
        '
        'UserTab20
        '
        Me.UserTab20.Controls.Add(Me.FlowLayoutPanel9)
        Me.UserTab20.Controls.Add(Me.FlowLayoutPanel10)
        Me.UserTab20.Controls.Add(Me.FlowLayoutPanel8)
        Me.UserTab20.Controls.Add(Me.FlowLayoutPanel1)
        Me.UserTab20.Controls.Add(Me.ExportUserDetails)
        Me.UserTab20.Controls.Add(Me.GetPrinters)
        Me.UserTab20.Controls.Add(Me.TableLayoutPanel36)
        Me.UserTab20.Controls.Add(Me.Label191)
        Me.UserTab20.Controls.Add(Me.Label193)
        Me.UserTab20.Controls.Add(Me.FlowLayoutPanel7)
        Me.UserTab20.Controls.Add(Me.FlowLayoutPanel6)
        Me.UserTab20.Controls.Add(Me.FlowLayoutPanel5)
        Me.UserTab20.Controls.Add(Me.FlowLayoutPanel4)
        Me.UserTab20.Controls.Add(Me.FlowLayoutPanel2)
        Me.UserTab20.Controls.Add(Me.FlowLayoutPanel3)
        Me.UserTab20.Controls.Add(Me.MetroTile15)
        Me.UserTab20.HorizontalScrollbarBarColor = True
        Me.UserTab20.HorizontalScrollbarHighlightOnWheel = False
        Me.UserTab20.HorizontalScrollbarSize = 10
        Me.UserTab20.ImageKey = "(none)"
        Me.UserTab20.Location = New System.Drawing.Point(4, 34)
        Me.UserTab20.Name = "UserTab20"
        Me.UserTab20.Size = New System.Drawing.Size(1075, 678)
        Me.UserTab20.TabIndex = 14
        Me.UserTab20.Text = "User    "
        Me.UserTab20.VerticalScrollbarBarColor = True
        Me.UserTab20.VerticalScrollbarHighlightOnWheel = False
        Me.UserTab20.VerticalScrollbarSize = 10
        '
        'FlowLayoutPanel9
        '
        Me.FlowLayoutPanel9.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.FlowLayoutPanel9.BackColor = System.Drawing.Color.Transparent
        Me.FlowLayoutPanel9.Controls.Add(Me.userlogonserver)
        Me.FlowLayoutPanel9.Location = New System.Drawing.Point(707, 64)
        Me.FlowLayoutPanel9.Name = "FlowLayoutPanel9"
        Me.FlowLayoutPanel9.Size = New System.Drawing.Size(353, 23)
        Me.FlowLayoutPanel9.TabIndex = 136
        '
        'userlogonserver
        '
        Me.userlogonserver.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.userlogonserver.AutoSize = True
        Me.userlogonserver.ForeColor = System.Drawing.Color.Blue
        Me.userlogonserver.Location = New System.Drawing.Point(3, 0)
        Me.userlogonserver.Name = "userlogonserver"
        Me.userlogonserver.Size = New System.Drawing.Size(27, 13)
        Me.userlogonserver.TabIndex = 1
        Me.userlogonserver.Text = "....."
        Me.userlogonserver.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'FlowLayoutPanel10
        '
        Me.FlowLayoutPanel10.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.FlowLayoutPanel10.BackColor = System.Drawing.Color.Transparent
        Me.FlowLayoutPanel10.Controls.Add(Me.Label6)
        Me.FlowLayoutPanel10.Location = New System.Drawing.Point(605, 63)
        Me.FlowLayoutPanel10.Name = "FlowLayoutPanel10"
        Me.FlowLayoutPanel10.Size = New System.Drawing.Size(96, 20)
        Me.FlowLayoutPanel10.TabIndex = 137
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(3, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(85, 13)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "Logon Server = "
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'FlowLayoutPanel8
        '
        Me.FlowLayoutPanel8.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.FlowLayoutPanel8.BackColor = System.Drawing.Color.Transparent
        Me.FlowLayoutPanel8.Controls.Add(Me.userbeingqueried)
        Me.FlowLayoutPanel8.Location = New System.Drawing.Point(172, 63)
        Me.FlowLayoutPanel8.Name = "FlowLayoutPanel8"
        Me.FlowLayoutPanel8.Size = New System.Drawing.Size(427, 24)
        Me.FlowLayoutPanel8.TabIndex = 122
        '
        'userbeingqueried
        '
        Me.userbeingqueried.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.userbeingqueried.AutoSize = True
        Me.userbeingqueried.ForeColor = System.Drawing.Color.Blue
        Me.userbeingqueried.Location = New System.Drawing.Point(3, 0)
        Me.userbeingqueried.Name = "userbeingqueried"
        Me.userbeingqueried.Size = New System.Drawing.Size(27, 13)
        Me.userbeingqueried.TabIndex = 1
        Me.userbeingqueried.Text = "....."
        Me.userbeingqueried.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'FlowLayoutPanel1
        '
        Me.FlowLayoutPanel1.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.FlowLayoutPanel1.BackColor = System.Drawing.Color.Transparent
        Me.FlowLayoutPanel1.Controls.Add(Me.Label4)
        Me.FlowLayoutPanel1.Location = New System.Drawing.Point(63, 63)
        Me.FlowLayoutPanel1.Name = "FlowLayoutPanel1"
        Me.FlowLayoutPanel1.Size = New System.Drawing.Size(96, 24)
        Me.FlowLayoutPanel1.TabIndex = 135
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(3, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(70, 13)
        Me.Label4.TabIndex = 0
        Me.Label4.Text = "User Name ="
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ExportUserDetails
        '
        Me.ExportUserDetails.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ExportUserDetails.BackColor = System.Drawing.Color.AliceBlue
        Me.ExportUserDetails.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.ExportUserDetails.Location = New System.Drawing.Point(974, 3)
        Me.ExportUserDetails.Name = "ExportUserDetails"
        Me.ExportUserDetails.Size = New System.Drawing.Size(86, 28)
        Me.ExportUserDetails.TabIndex = 133
        Me.ExportUserDetails.Text = "Export to CSV"
        Me.ExportUserDetails.UseCustomBackColor = True
        Me.ExportUserDetails.UseCustomForeColor = True
        Me.ExportUserDetails.UseSelectable = True
        '
        'GetPrinters
        '
        Me.GetPrinters.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.GetPrinters.BackColor = System.Drawing.Color.AliceBlue
        Me.GetPrinters.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.GetPrinters.Location = New System.Drawing.Point(376, 16)
        Me.GetPrinters.Name = "GetPrinters"
        Me.GetPrinters.Size = New System.Drawing.Size(168, 28)
        Me.GetPrinters.TabIndex = 132
        Me.GetPrinters.Text = "List selected users settings"
        Me.GetPrinters.UseCustomBackColor = True
        Me.GetPrinters.UseCustomForeColor = True
        Me.GetPrinters.UseSelectable = True
        '
        'TableLayoutPanel36
        '
        Me.TableLayoutPanel36.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel36.BackColor = System.Drawing.Color.Transparent
        Me.TableLayoutPanel36.ColumnCount = 1
        Me.TableLayoutPanel36.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel36.Controls.Add(Me.DataGridViewPrinters, 0, 0)
        Me.TableLayoutPanel36.Controls.Add(Me.DataGridViewODBC, 0, 2)
        Me.TableLayoutPanel36.Controls.Add(Me.DataGridViewNetwork, 0, 1)
        Me.TableLayoutPanel36.Location = New System.Drawing.Point(12, 118)
        Me.TableLayoutPanel36.Name = "TableLayoutPanel36"
        Me.TableLayoutPanel36.RowCount = 4
        Me.TableLayoutPanel36.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 43.13726!))
        Me.TableLayoutPanel36.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 56.86274!))
        Me.TableLayoutPanel36.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 182.0!))
        Me.TableLayoutPanel36.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 8.0!))
        Me.TableLayoutPanel36.Size = New System.Drawing.Size(1051, 548)
        Me.TableLayoutPanel36.TabIndex = 131
        '
        'DataGridViewPrinters
        '
        Me.DataGridViewPrinters.AllowUserToOrderColumns = True
        Me.DataGridViewPrinters.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridViewPrinters.BackgroundColor = System.Drawing.SystemColors.Window
        Me.DataGridViewPrinters.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewPrinters.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.PC_Name, Me.UsernamePrinters, Me.DataGridViewTextBoxColumn70})
        Me.DataGridViewPrinters.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DataGridViewPrinters.Location = New System.Drawing.Point(3, 3)
        Me.DataGridViewPrinters.Name = "DataGridViewPrinters"
        Me.DataGridViewPrinters.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken
        Me.DataGridViewPrinters.RowHeadersVisible = False
        Me.DataGridViewPrinters.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders
        Me.DataGridViewPrinters.RowTemplate.Height = 24
        Me.DataGridViewPrinters.Size = New System.Drawing.Size(1045, 148)
        Me.DataGridViewPrinters.TabIndex = 86
        '
        'PC_Name
        '
        Me.PC_Name.FillWeight = 15.0!
        Me.PC_Name.HeaderText = "PC Name"
        Me.PC_Name.Name = "PC_Name"
        '
        'UsernamePrinters
        '
        Me.UsernamePrinters.FillWeight = 35.0!
        Me.UsernamePrinters.HeaderText = "Username"
        Me.UsernamePrinters.Name = "UsernamePrinters"
        '
        'DataGridViewTextBoxColumn70
        '
        Me.DataGridViewTextBoxColumn70.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn70.FillWeight = 70.06329!
        Me.DataGridViewTextBoxColumn70.HeaderText = "Printer Connection Found"
        Me.DataGridViewTextBoxColumn70.Name = "DataGridViewTextBoxColumn70"
        '
        'DataGridViewODBC
        '
        Me.DataGridViewODBC.AllowUserToOrderColumns = True
        Me.DataGridViewODBC.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridViewODBC.BackgroundColor = System.Drawing.SystemColors.Window
        Me.DataGridViewODBC.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewODBC.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn75, Me.DataGridViewTextBoxColumn76, Me.DataGridViewTextBoxColumn77})
        Me.DataGridViewODBC.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DataGridViewODBC.Location = New System.Drawing.Point(3, 360)
        Me.DataGridViewODBC.Name = "DataGridViewODBC"
        Me.DataGridViewODBC.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken
        Me.DataGridViewODBC.RowHeadersVisible = False
        Me.DataGridViewODBC.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders
        Me.DataGridViewODBC.RowTemplate.Height = 24
        Me.DataGridViewODBC.Size = New System.Drawing.Size(1045, 176)
        Me.DataGridViewODBC.TabIndex = 90
        '
        'DataGridViewTextBoxColumn75
        '
        Me.DataGridViewTextBoxColumn75.FillWeight = 20.0!
        Me.DataGridViewTextBoxColumn75.HeaderText = "Database Connection by..."
        Me.DataGridViewTextBoxColumn75.Name = "DataGridViewTextBoxColumn75"
        '
        'DataGridViewTextBoxColumn76
        '
        Me.DataGridViewTextBoxColumn76.FillWeight = 25.0!
        Me.DataGridViewTextBoxColumn76.HeaderText = "Database Connection Name"
        Me.DataGridViewTextBoxColumn76.Name = "DataGridViewTextBoxColumn76"
        '
        'DataGridViewTextBoxColumn77
        '
        Me.DataGridViewTextBoxColumn77.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn77.FillWeight = 45.0!
        Me.DataGridViewTextBoxColumn77.HeaderText = "Driver Type"
        Me.DataGridViewTextBoxColumn77.Name = "DataGridViewTextBoxColumn77"
        '
        'DataGridViewNetwork
        '
        Me.DataGridViewNetwork.AllowUserToOrderColumns = True
        Me.DataGridViewNetwork.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridViewNetwork.BackgroundColor = System.Drawing.SystemColors.Window
        Me.DataGridViewNetwork.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewNetwork.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn68, Me.DataGridViewTextBoxColumn67, Me.DataGridViewTextBoxColumn69})
        Me.DataGridViewNetwork.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DataGridViewNetwork.Location = New System.Drawing.Point(3, 157)
        Me.DataGridViewNetwork.Name = "DataGridViewNetwork"
        Me.DataGridViewNetwork.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken
        Me.DataGridViewNetwork.RowHeadersVisible = False
        Me.DataGridViewNetwork.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders
        Me.DataGridViewNetwork.RowTemplate.Height = 24
        Me.DataGridViewNetwork.Size = New System.Drawing.Size(1045, 197)
        Me.DataGridViewNetwork.TabIndex = 89
        '
        'DataGridViewTextBoxColumn68
        '
        Me.DataGridViewTextBoxColumn68.FillWeight = 35.0!
        Me.DataGridViewTextBoxColumn68.HeaderText = "Network Connection by..."
        Me.DataGridViewTextBoxColumn68.Name = "DataGridViewTextBoxColumn68"
        '
        'DataGridViewTextBoxColumn67
        '
        Me.DataGridViewTextBoxColumn67.FillWeight = 13.0!
        Me.DataGridViewTextBoxColumn67.HeaderText = "Drive Letter"
        Me.DataGridViewTextBoxColumn67.Name = "DataGridViewTextBoxColumn67"
        '
        'DataGridViewTextBoxColumn69
        '
        Me.DataGridViewTextBoxColumn69.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn69.FillWeight = 70.06329!
        Me.DataGridViewTextBoxColumn69.HeaderText = "Network Path Connected to..."
        Me.DataGridViewTextBoxColumn69.Name = "DataGridViewTextBoxColumn69"
        '
        'Label191
        '
        Me.Label191.AutoSize = True
        Me.Label191.BackColor = System.Drawing.Color.Transparent
        Me.Label191.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label191.Location = New System.Drawing.Point(58, 18)
        Me.Label191.Name = "Label191"
        Me.Label191.Size = New System.Drawing.Size(0, 16)
        Me.Label191.TabIndex = 128
        '
        'Label193
        '
        Me.Label193.AutoSize = True
        Me.Label193.BackColor = System.Drawing.Color.Transparent
        Me.Label193.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label193.Location = New System.Drawing.Point(58, 1)
        Me.Label193.Name = "Label193"
        Me.Label193.Size = New System.Drawing.Size(0, 16)
        Me.Label193.TabIndex = 127
        '
        'FlowLayoutPanel7
        '
        Me.FlowLayoutPanel7.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.FlowLayoutPanel7.AutoSize = True
        Me.FlowLayoutPanel7.BackColor = System.Drawing.Color.Transparent
        Me.FlowLayoutPanel7.Controls.Add(Me.KeyboardLayout)
        Me.FlowLayoutPanel7.Location = New System.Drawing.Point(707, 33)
        Me.FlowLayoutPanel7.Name = "FlowLayoutPanel7"
        Me.FlowLayoutPanel7.Size = New System.Drawing.Size(254, 24)
        Me.FlowLayoutPanel7.TabIndex = 125
        '
        'KeyboardLayout
        '
        Me.KeyboardLayout.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.KeyboardLayout.AutoSize = True
        Me.KeyboardLayout.ForeColor = System.Drawing.Color.Blue
        Me.KeyboardLayout.Location = New System.Drawing.Point(3, 0)
        Me.KeyboardLayout.Name = "KeyboardLayout"
        Me.KeyboardLayout.Size = New System.Drawing.Size(27, 13)
        Me.KeyboardLayout.TabIndex = 0
        Me.KeyboardLayout.Text = "....."
        Me.KeyboardLayout.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'FlowLayoutPanel6
        '
        Me.FlowLayoutPanel6.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.FlowLayoutPanel6.BackColor = System.Drawing.Color.Transparent
        Me.FlowLayoutPanel6.Controls.Add(Me.Label5)
        Me.FlowLayoutPanel6.Location = New System.Drawing.Point(605, 33)
        Me.FlowLayoutPanel6.Name = "FlowLayoutPanel6"
        Me.FlowLayoutPanel6.Size = New System.Drawing.Size(99, 24)
        Me.FlowLayoutPanel6.TabIndex = 124
        '
        'Label5
        '
        Me.Label5.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label5.AutoSize = True
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(3, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(91, 13)
        Me.Label5.TabIndex = 1
        Me.Label5.Text = "Keyboard Type = "
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'FlowLayoutPanel5
        '
        Me.FlowLayoutPanel5.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.FlowLayoutPanel5.BackColor = System.Drawing.Color.Transparent
        Me.FlowLayoutPanel5.Controls.Add(Me.Label197)
        Me.FlowLayoutPanel5.Location = New System.Drawing.Point(605, 91)
        Me.FlowLayoutPanel5.Name = "FlowLayoutPanel5"
        Me.FlowLayoutPanel5.Size = New System.Drawing.Size(96, 24)
        Me.FlowLayoutPanel5.TabIndex = 123
        '
        'Label197
        '
        Me.Label197.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label197.AutoSize = True
        Me.Label197.ForeColor = System.Drawing.Color.Black
        Me.Label197.Location = New System.Drawing.Point(3, 0)
        Me.Label197.Name = "Label197"
        Me.Label197.Size = New System.Drawing.Size(79, 13)
        Me.Label197.TabIndex = 0
        Me.Label197.Text = "TNS_ADMIN = "
        Me.Label197.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'FlowLayoutPanel4
        '
        Me.FlowLayoutPanel4.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.FlowLayoutPanel4.AutoSize = True
        Me.FlowLayoutPanel4.BackColor = System.Drawing.Color.Transparent
        Me.FlowLayoutPanel4.Controls.Add(Me.tnsadmin)
        Me.FlowLayoutPanel4.Location = New System.Drawing.Point(707, 91)
        Me.FlowLayoutPanel4.Name = "FlowLayoutPanel4"
        Me.FlowLayoutPanel4.Size = New System.Drawing.Size(353, 24)
        Me.FlowLayoutPanel4.TabIndex = 122
        '
        'tnsadmin
        '
        Me.tnsadmin.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tnsadmin.AutoSize = True
        Me.tnsadmin.ForeColor = System.Drawing.Color.Blue
        Me.tnsadmin.Location = New System.Drawing.Point(3, 0)
        Me.tnsadmin.Name = "tnsadmin"
        Me.tnsadmin.Size = New System.Drawing.Size(27, 13)
        Me.tnsadmin.TabIndex = 0
        Me.tnsadmin.Text = "....."
        Me.tnsadmin.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'FlowLayoutPanel2
        '
        Me.FlowLayoutPanel2.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.FlowLayoutPanel2.BackColor = System.Drawing.Color.Transparent
        Me.FlowLayoutPanel2.Controls.Add(Me.Label177)
        Me.FlowLayoutPanel2.Location = New System.Drawing.Point(63, 93)
        Me.FlowLayoutPanel2.Name = "FlowLayoutPanel2"
        Me.FlowLayoutPanel2.Size = New System.Drawing.Size(96, 24)
        Me.FlowLayoutPanel2.TabIndex = 120
        '
        'Label177
        '
        Me.Label177.AutoSize = True
        Me.Label177.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label177.ForeColor = System.Drawing.Color.Black
        Me.Label177.Location = New System.Drawing.Point(3, 0)
        Me.Label177.Name = "Label177"
        Me.Label177.Size = New System.Drawing.Size(88, 13)
        Me.Label177.TabIndex = 0
        Me.Label177.Text = "Default Printer = "
        Me.Label177.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'FlowLayoutPanel3
        '
        Me.FlowLayoutPanel3.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.FlowLayoutPanel3.BackColor = System.Drawing.Color.Transparent
        Me.FlowLayoutPanel3.Controls.Add(Me.DefaultPrinter)
        Me.FlowLayoutPanel3.Location = New System.Drawing.Point(172, 91)
        Me.FlowLayoutPanel3.Name = "FlowLayoutPanel3"
        Me.FlowLayoutPanel3.Size = New System.Drawing.Size(427, 24)
        Me.FlowLayoutPanel3.TabIndex = 121
        '
        'DefaultPrinter
        '
        Me.DefaultPrinter.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DefaultPrinter.AutoSize = True
        Me.DefaultPrinter.ForeColor = System.Drawing.Color.Blue
        Me.DefaultPrinter.Location = New System.Drawing.Point(3, 0)
        Me.DefaultPrinter.Name = "DefaultPrinter"
        Me.DefaultPrinter.Size = New System.Drawing.Size(27, 13)
        Me.DefaultPrinter.TabIndex = 0
        Me.DefaultPrinter.Text = "....."
        Me.DefaultPrinter.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'MetroTile15
        '
        Me.MetroTile15.ActiveControl = Nothing
        Me.MetroTile15.BackColor = System.Drawing.Color.Transparent
        Me.MetroTile15.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.MetroTile15.Location = New System.Drawing.Point(3, 1)
        Me.MetroTile15.Name = "MetroTile15"
        Me.MetroTile15.Size = New System.Drawing.Size(38, 43)
        Me.MetroTile15.TabIndex = 134
        Me.MetroTile15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MetroTile15.TileImage = CType(resources.GetObject("MetroTile15.TileImage"), System.Drawing.Image)
        Me.MetroTile15.TileImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MetroTile15.TileTextFontSize = MetroFramework.MetroTileTextSize.Small
        Me.MetroTile15.UseCustomBackColor = True
        Me.MetroTile15.UseCustomForeColor = True
        Me.MetroTile15.UseSelectable = True
        Me.MetroTile15.UseTileImage = True
        '
        'WIM_PnPSignedDriver21
        '
        Me.WIM_PnPSignedDriver21.Controls.Add(Me.MetroTile17)
        Me.WIM_PnPSignedDriver21.Controls.Add(Me.PnPSignedDriverExportButton)
        Me.WIM_PnPSignedDriver21.Controls.Add(Me.PnPSignedDriverButton)
        Me.WIM_PnPSignedDriver21.Controls.Add(Me.PnPSignedDriverLabel2)
        Me.WIM_PnPSignedDriver21.Controls.Add(Me.PnPSignedDriverLabel1)
        Me.WIM_PnPSignedDriver21.Controls.Add(Me.TableLayoutPanel23)
        Me.WIM_PnPSignedDriver21.HorizontalScrollbarBarColor = True
        Me.WIM_PnPSignedDriver21.HorizontalScrollbarHighlightOnWheel = False
        Me.WIM_PnPSignedDriver21.HorizontalScrollbarSize = 10
        Me.WIM_PnPSignedDriver21.Location = New System.Drawing.Point(4, 34)
        Me.WIM_PnPSignedDriver21.Name = "WIM_PnPSignedDriver21"
        Me.WIM_PnPSignedDriver21.Size = New System.Drawing.Size(1075, 678)
        Me.WIM_PnPSignedDriver21.TabIndex = 17
        Me.WIM_PnPSignedDriver21.Text = "WIM_3rd_Party_Drivers"
        Me.WIM_PnPSignedDriver21.VerticalScrollbarBarColor = True
        Me.WIM_PnPSignedDriver21.VerticalScrollbarHighlightOnWheel = False
        Me.WIM_PnPSignedDriver21.VerticalScrollbarSize = 10
        '
        'MetroTile17
        '
        Me.MetroTile17.ActiveControl = Nothing
        Me.MetroTile17.BackColor = System.Drawing.Color.Transparent
        Me.MetroTile17.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.MetroTile17.Location = New System.Drawing.Point(0, 3)
        Me.MetroTile17.Name = "MetroTile17"
        Me.MetroTile17.Size = New System.Drawing.Size(38, 43)
        Me.MetroTile17.TabIndex = 132
        Me.MetroTile17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MetroTile17.TileImage = CType(resources.GetObject("MetroTile17.TileImage"), System.Drawing.Image)
        Me.MetroTile17.TileImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MetroTile17.TileTextFontSize = MetroFramework.MetroTileTextSize.Small
        Me.MetroTile17.UseCustomBackColor = True
        Me.MetroTile17.UseCustomForeColor = True
        Me.MetroTile17.UseSelectable = True
        Me.MetroTile17.UseTileImage = True
        '
        'PnPSignedDriverExportButton
        '
        Me.PnPSignedDriverExportButton.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PnPSignedDriverExportButton.BackColor = System.Drawing.Color.AliceBlue
        Me.PnPSignedDriverExportButton.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.PnPSignedDriverExportButton.Location = New System.Drawing.Point(982, 18)
        Me.PnPSignedDriverExportButton.Name = "PnPSignedDriverExportButton"
        Me.PnPSignedDriverExportButton.Size = New System.Drawing.Size(86, 28)
        Me.PnPSignedDriverExportButton.TabIndex = 134
        Me.PnPSignedDriverExportButton.Text = "Export to CSV"
        Me.PnPSignedDriverExportButton.UseCustomBackColor = True
        Me.PnPSignedDriverExportButton.UseCustomForeColor = True
        Me.PnPSignedDriverExportButton.UseSelectable = True
        '
        'PnPSignedDriverButton
        '
        Me.PnPSignedDriverButton.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.PnPSignedDriverButton.BackColor = System.Drawing.Color.AliceBlue
        Me.PnPSignedDriverButton.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.PnPSignedDriverButton.Location = New System.Drawing.Point(376, 18)
        Me.PnPSignedDriverButton.Name = "PnPSignedDriverButton"
        Me.PnPSignedDriverButton.Size = New System.Drawing.Size(158, 28)
        Me.PnPSignedDriverButton.TabIndex = 133
        Me.PnPSignedDriverButton.Text = "Display 3rd Party Drivers"
        Me.PnPSignedDriverButton.UseCustomBackColor = True
        Me.PnPSignedDriverButton.UseCustomForeColor = True
        Me.PnPSignedDriverButton.UseSelectable = True
        '
        'PnPSignedDriverLabel2
        '
        Me.PnPSignedDriverLabel2.AutoSize = True
        Me.PnPSignedDriverLabel2.BackColor = System.Drawing.Color.Transparent
        Me.PnPSignedDriverLabel2.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PnPSignedDriverLabel2.Location = New System.Drawing.Point(55, 20)
        Me.PnPSignedDriverLabel2.Name = "PnPSignedDriverLabel2"
        Me.PnPSignedDriverLabel2.Size = New System.Drawing.Size(0, 16)
        Me.PnPSignedDriverLabel2.TabIndex = 131
        '
        'PnPSignedDriverLabel1
        '
        Me.PnPSignedDriverLabel1.AutoSize = True
        Me.PnPSignedDriverLabel1.BackColor = System.Drawing.Color.Transparent
        Me.PnPSignedDriverLabel1.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PnPSignedDriverLabel1.Location = New System.Drawing.Point(55, 3)
        Me.PnPSignedDriverLabel1.Name = "PnPSignedDriverLabel1"
        Me.PnPSignedDriverLabel1.Size = New System.Drawing.Size(0, 16)
        Me.PnPSignedDriverLabel1.TabIndex = 130
        '
        'TableLayoutPanel23
        '
        Me.TableLayoutPanel23.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel23.BackColor = System.Drawing.Color.Transparent
        Me.TableLayoutPanel23.ColumnCount = 1
        Me.TableLayoutPanel23.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel23.Controls.Add(Me.PnPSignedDriverDataGrid, 0, 0)
        Me.TableLayoutPanel23.Location = New System.Drawing.Point(2, 51)
        Me.TableLayoutPanel23.Margin = New System.Windows.Forms.Padding(2)
        Me.TableLayoutPanel23.Name = "TableLayoutPanel23"
        Me.TableLayoutPanel23.RowCount = 1
        Me.TableLayoutPanel23.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel23.Size = New System.Drawing.Size(1069, 625)
        Me.TableLayoutPanel23.TabIndex = 121
        '
        'PnPSignedDriverDataGrid
        '
        Me.PnPSignedDriverDataGrid.BackgroundColor = System.Drawing.SystemColors.Window
        Me.PnPSignedDriverDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.PnPSignedDriverDataGrid.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DeviceClass, Me.DriverProviderName, Me.DataGridViewTextBoxColumn22, Me.DataGridViewTextBoxColumn20, Me.DataGridViewTextBoxColumn19, Me.DeviceID})
        Me.PnPSignedDriverDataGrid.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PnPSignedDriverDataGrid.Location = New System.Drawing.Point(3, 3)
        Me.PnPSignedDriverDataGrid.Name = "PnPSignedDriverDataGrid"
        Me.PnPSignedDriverDataGrid.RowHeadersVisible = False
        Me.PnPSignedDriverDataGrid.RowTemplate.Height = 24
        Me.PnPSignedDriverDataGrid.Size = New System.Drawing.Size(1063, 619)
        Me.PnPSignedDriverDataGrid.TabIndex = 46
        '
        'DeviceClass
        '
        Me.DeviceClass.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DeviceClass.FillWeight = 8.0!
        Me.DeviceClass.HeaderText = "Device Class"
        Me.DeviceClass.Name = "DeviceClass"
        Me.DeviceClass.ReadOnly = True
        '
        'DriverProviderName
        '
        Me.DriverProviderName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DriverProviderName.FillWeight = 10.0!
        Me.DriverProviderName.HeaderText = "Provider Name"
        Me.DriverProviderName.MinimumWidth = 15
        Me.DriverProviderName.Name = "DriverProviderName"
        Me.DriverProviderName.ReadOnly = True
        '
        'DataGridViewTextBoxColumn22
        '
        Me.DataGridViewTextBoxColumn22.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn22.FillWeight = 10.0!
        Me.DataGridViewTextBoxColumn22.HeaderText = "(dd/mm/yyyy) Driver Date"
        Me.DataGridViewTextBoxColumn22.Name = "DataGridViewTextBoxColumn22"
        Me.DataGridViewTextBoxColumn22.ReadOnly = True
        '
        'DataGridViewTextBoxColumn20
        '
        Me.DataGridViewTextBoxColumn20.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn20.FillWeight = 10.0!
        Me.DataGridViewTextBoxColumn20.HeaderText = "Driver Version"
        Me.DataGridViewTextBoxColumn20.Name = "DataGridViewTextBoxColumn20"
        Me.DataGridViewTextBoxColumn20.ReadOnly = True
        '
        'DataGridViewTextBoxColumn19
        '
        Me.DataGridViewTextBoxColumn19.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn19.FillWeight = 7.0!
        Me.DataGridViewTextBoxColumn19.HeaderText = "Published Name"
        Me.DataGridViewTextBoxColumn19.Name = "DataGridViewTextBoxColumn19"
        Me.DataGridViewTextBoxColumn19.ReadOnly = True
        '
        'DeviceID
        '
        Me.DeviceID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DeviceID.FillWeight = 15.0!
        Me.DeviceID.HeaderText = "Device ID"
        Me.DeviceID.MinimumWidth = 10
        Me.DeviceID.Name = "DeviceID"
        Me.DeviceID.ReadOnly = True
        '
        'WIM_OptionalFeatures22
        '
        Me.WIM_OptionalFeatures22.Controls.Add(Me.MetroTile18)
        Me.WIM_OptionalFeatures22.Controls.Add(Me.WIM_OptionalFeaturesExportButton)
        Me.WIM_OptionalFeatures22.Controls.Add(Me.WIM_OptionalFeaturesButton)
        Me.WIM_OptionalFeatures22.Controls.Add(Me.WIM_OptionalFeaturesLabel2)
        Me.WIM_OptionalFeatures22.Controls.Add(Me.WIM_OptionalFeaturesLabel1)
        Me.WIM_OptionalFeatures22.Controls.Add(Me.TableLayoutPanel21)
        Me.WIM_OptionalFeatures22.HorizontalScrollbarBarColor = True
        Me.WIM_OptionalFeatures22.HorizontalScrollbarHighlightOnWheel = False
        Me.WIM_OptionalFeatures22.HorizontalScrollbarSize = 10
        Me.WIM_OptionalFeatures22.Location = New System.Drawing.Point(4, 34)
        Me.WIM_OptionalFeatures22.Name = "WIM_OptionalFeatures22"
        Me.WIM_OptionalFeatures22.Size = New System.Drawing.Size(1075, 678)
        Me.WIM_OptionalFeatures22.TabIndex = 16
        Me.WIM_OptionalFeatures22.Text = "WIM_OptionalFeatures"
        Me.WIM_OptionalFeatures22.VerticalScrollbarBarColor = True
        Me.WIM_OptionalFeatures22.VerticalScrollbarHighlightOnWheel = False
        Me.WIM_OptionalFeatures22.VerticalScrollbarSize = 10
        '
        'MetroTile18
        '
        Me.MetroTile18.ActiveControl = Nothing
        Me.MetroTile18.BackColor = System.Drawing.Color.Transparent
        Me.MetroTile18.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.MetroTile18.Location = New System.Drawing.Point(0, 3)
        Me.MetroTile18.Name = "MetroTile18"
        Me.MetroTile18.Size = New System.Drawing.Size(38, 43)
        Me.MetroTile18.TabIndex = 137
        Me.MetroTile18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MetroTile18.TileImage = CType(resources.GetObject("MetroTile18.TileImage"), System.Drawing.Image)
        Me.MetroTile18.TileImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MetroTile18.TileTextFontSize = MetroFramework.MetroTileTextSize.Small
        Me.MetroTile18.UseCustomBackColor = True
        Me.MetroTile18.UseCustomForeColor = True
        Me.MetroTile18.UseSelectable = True
        Me.MetroTile18.UseTileImage = True
        '
        'WIM_OptionalFeaturesExportButton
        '
        Me.WIM_OptionalFeaturesExportButton.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.WIM_OptionalFeaturesExportButton.BackColor = System.Drawing.Color.AliceBlue
        Me.WIM_OptionalFeaturesExportButton.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.WIM_OptionalFeaturesExportButton.Location = New System.Drawing.Point(982, 16)
        Me.WIM_OptionalFeaturesExportButton.Name = "WIM_OptionalFeaturesExportButton"
        Me.WIM_OptionalFeaturesExportButton.Size = New System.Drawing.Size(86, 28)
        Me.WIM_OptionalFeaturesExportButton.TabIndex = 139
        Me.WIM_OptionalFeaturesExportButton.Text = "Export to CSV"
        Me.WIM_OptionalFeaturesExportButton.UseCustomBackColor = True
        Me.WIM_OptionalFeaturesExportButton.UseCustomForeColor = True
        Me.WIM_OptionalFeaturesExportButton.UseSelectable = True
        '
        'WIM_OptionalFeaturesButton
        '
        Me.WIM_OptionalFeaturesButton.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.WIM_OptionalFeaturesButton.BackColor = System.Drawing.Color.AliceBlue
        Me.WIM_OptionalFeaturesButton.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.WIM_OptionalFeaturesButton.Location = New System.Drawing.Point(376, 16)
        Me.WIM_OptionalFeaturesButton.Name = "WIM_OptionalFeaturesButton"
        Me.WIM_OptionalFeaturesButton.Size = New System.Drawing.Size(174, 28)
        Me.WIM_OptionalFeaturesButton.TabIndex = 138
        Me.WIM_OptionalFeaturesButton.Text = "Display WIM Features && State"
        Me.WIM_OptionalFeaturesButton.UseCustomBackColor = True
        Me.WIM_OptionalFeaturesButton.UseCustomForeColor = True
        Me.WIM_OptionalFeaturesButton.UseSelectable = True
        '
        'WIM_OptionalFeaturesLabel2
        '
        Me.WIM_OptionalFeaturesLabel2.AutoSize = True
        Me.WIM_OptionalFeaturesLabel2.BackColor = System.Drawing.Color.Transparent
        Me.WIM_OptionalFeaturesLabel2.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.WIM_OptionalFeaturesLabel2.Location = New System.Drawing.Point(55, 20)
        Me.WIM_OptionalFeaturesLabel2.Name = "WIM_OptionalFeaturesLabel2"
        Me.WIM_OptionalFeaturesLabel2.Size = New System.Drawing.Size(0, 16)
        Me.WIM_OptionalFeaturesLabel2.TabIndex = 136
        '
        'WIM_OptionalFeaturesLabel1
        '
        Me.WIM_OptionalFeaturesLabel1.AutoSize = True
        Me.WIM_OptionalFeaturesLabel1.BackColor = System.Drawing.Color.Transparent
        Me.WIM_OptionalFeaturesLabel1.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.WIM_OptionalFeaturesLabel1.Location = New System.Drawing.Point(55, 3)
        Me.WIM_OptionalFeaturesLabel1.Name = "WIM_OptionalFeaturesLabel1"
        Me.WIM_OptionalFeaturesLabel1.Size = New System.Drawing.Size(0, 16)
        Me.WIM_OptionalFeaturesLabel1.TabIndex = 135
        '
        'TableLayoutPanel21
        '
        Me.TableLayoutPanel21.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel21.BackColor = System.Drawing.Color.Transparent
        Me.TableLayoutPanel21.ColumnCount = 1
        Me.TableLayoutPanel21.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel21.Controls.Add(Me.OptionalFeaturesDataGrid, 0, 0)
        Me.TableLayoutPanel21.Location = New System.Drawing.Point(2, 49)
        Me.TableLayoutPanel21.Margin = New System.Windows.Forms.Padding(2)
        Me.TableLayoutPanel21.Name = "TableLayoutPanel21"
        Me.TableLayoutPanel21.RowCount = 1
        Me.TableLayoutPanel21.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel21.Size = New System.Drawing.Size(1069, 627)
        Me.TableLayoutPanel21.TabIndex = 121
        '
        'OptionalFeaturesDataGrid
        '
        Me.OptionalFeaturesDataGrid.BackgroundColor = System.Drawing.SystemColors.Window
        Me.OptionalFeaturesDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.OptionalFeaturesDataGrid.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn16})
        Me.OptionalFeaturesDataGrid.Dock = System.Windows.Forms.DockStyle.Fill
        Me.OptionalFeaturesDataGrid.Location = New System.Drawing.Point(3, 3)
        Me.OptionalFeaturesDataGrid.Name = "OptionalFeaturesDataGrid"
        Me.OptionalFeaturesDataGrid.RowHeadersVisible = False
        Me.OptionalFeaturesDataGrid.RowTemplate.Height = 24
        Me.OptionalFeaturesDataGrid.Size = New System.Drawing.Size(1063, 621)
        Me.OptionalFeaturesDataGrid.TabIndex = 46
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn3.FillWeight = 30.0!
        Me.DataGridViewTextBoxColumn3.HeaderText = "Feature Name"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.ReadOnly = True
        '
        'DataGridViewTextBoxColumn16
        '
        Me.DataGridViewTextBoxColumn16.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn16.FillWeight = 10.0!
        Me.DataGridViewTextBoxColumn16.HeaderText = "State"
        Me.DataGridViewTextBoxColumn16.Name = "DataGridViewTextBoxColumn16"
        Me.DataGridViewTextBoxColumn16.ReadOnly = True
        '
        'PXETab23
        '
        Me.PXETab23.Controls.Add(Me.MetroTile10)
        Me.PXETab23.Controls.Add(Me.Gather1EResults)
        Me.PXETab23.Controls.Add(Me.Label13)
        Me.PXETab23.Controls.Add(Me.Label15)
        Me.PXETab23.Controls.Add(Me.TableLayoutPanel40)
        Me.PXETab23.Controls.Add(Me.TableLayoutPanel38)
        Me.PXETab23.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.PXETab23.HorizontalScrollbarBarColor = True
        Me.PXETab23.HorizontalScrollbarHighlightOnWheel = False
        Me.PXETab23.HorizontalScrollbarSize = 10
        Me.PXETab23.Location = New System.Drawing.Point(4, 34)
        Me.PXETab23.Name = "PXETab23"
        Me.PXETab23.Size = New System.Drawing.Size(1075, 678)
        Me.PXETab23.TabIndex = 7
        Me.PXETab23.Text = "PXE       "
        Me.PXETab23.VerticalScrollbarBarColor = True
        Me.PXETab23.VerticalScrollbarHighlightOnWheel = False
        Me.PXETab23.VerticalScrollbarSize = 10
        '
        'MetroTile10
        '
        Me.MetroTile10.ActiveControl = Nothing
        Me.MetroTile10.BackColor = System.Drawing.Color.Transparent
        Me.MetroTile10.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.MetroTile10.Location = New System.Drawing.Point(3, 3)
        Me.MetroTile10.Name = "MetroTile10"
        Me.MetroTile10.Size = New System.Drawing.Size(38, 43)
        Me.MetroTile10.TabIndex = 129
        Me.MetroTile10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MetroTile10.TileImage = CType(resources.GetObject("MetroTile10.TileImage"), System.Drawing.Image)
        Me.MetroTile10.TileImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MetroTile10.TileTextFontSize = MetroFramework.MetroTileTextSize.Small
        Me.MetroTile10.UseCustomBackColor = True
        Me.MetroTile10.UseCustomForeColor = True
        Me.MetroTile10.UseSelectable = True
        Me.MetroTile10.UseTileImage = True
        '
        'Gather1EResults
        '
        Me.Gather1EResults.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Gather1EResults.BackColor = System.Drawing.Color.AliceBlue
        Me.Gather1EResults.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.Gather1EResults.Location = New System.Drawing.Point(416, 11)
        Me.Gather1EResults.Name = "Gather1EResults"
        Me.Gather1EResults.Size = New System.Drawing.Size(123, 28)
        Me.Gather1EResults.TabIndex = 123
        Me.Gather1EResults.Text = "Gather PXE Results"
        Me.Gather1EResults.UseCustomBackColor = True
        Me.Gather1EResults.UseCustomForeColor = True
        Me.Gather1EResults.UseSelectable = True
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.Transparent
        Me.Label13.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(58, 20)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(0, 13)
        Me.Label13.TabIndex = 113
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.Color.Transparent
        Me.Label15.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(58, 3)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(0, 13)
        Me.Label15.TabIndex = 111
        '
        'TableLayoutPanel40
        '
        Me.TableLayoutPanel40.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.TableLayoutPanel40.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.TableLayoutPanel40.BackColor = System.Drawing.Color.Transparent
        Me.TableLayoutPanel40.ColumnCount = 2
        Me.TableLayoutPanel40.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 37.57962!))
        Me.TableLayoutPanel40.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 62.42038!))
        Me.TableLayoutPanel40.Controls.Add(Me.MetroLabel9, 0, 3)
        Me.TableLayoutPanel40.Controls.Add(Me.PXElogOpen, 0, 6)
        Me.TableLayoutPanel40.Controls.Add(Me.MetroLabel8, 0, 2)
        Me.TableLayoutPanel40.Controls.Add(Me.OpenTftrootImages, 0, 7)
        Me.TableLayoutPanel40.Controls.Add(Me.PXEFolderOpen, 0, 5)
        Me.TableLayoutPanel40.Controls.Add(Me.PXEProductVersionValue, 1, 2)
        Me.TableLayoutPanel40.Controls.Add(Me.PXEServiceValue, 1, 3)
        Me.TableLayoutPanel40.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.TableLayoutPanel40.Location = New System.Drawing.Point(488, 64)
        Me.TableLayoutPanel40.Name = "TableLayoutPanel40"
        Me.TableLayoutPanel40.RowCount = 8
        Me.TableLayoutPanel40.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.633094!))
        Me.TableLayoutPanel40.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.87129!))
        Me.TableLayoutPanel40.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.87129!))
        Me.TableLayoutPanel40.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.38614!))
        Me.TableLayoutPanel40.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.39604!))
        Me.TableLayoutPanel40.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.35644!))
        Me.TableLayoutPanel40.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.85149!))
        Me.TableLayoutPanel40.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.35644!))
        Me.TableLayoutPanel40.Size = New System.Drawing.Size(471, 202)
        Me.TableLayoutPanel40.TabIndex = 110
        '
        'MetroLabel9
        '
        Me.MetroLabel9.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.MetroLabel9.AutoSize = True
        Me.MetroLabel9.Location = New System.Drawing.Point(50, 69)
        Me.MetroLabel9.Name = "MetroLabel9"
        Me.MetroLabel9.Size = New System.Drawing.Size(77, 23)
        Me.MetroLabel9.TabIndex = 130
        Me.MetroLabel9.Text = "PXE Service"
        Me.MetroLabel9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PXElogOpen
        '
        Me.PXElogOpen.BackColor = System.Drawing.Color.Transparent
        Me.PXElogOpen.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PXElogOpen.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.PXElogOpen.Location = New System.Drawing.Point(3, 145)
        Me.PXElogOpen.Name = "PXElogOpen"
        Me.PXElogOpen.Size = New System.Drawing.Size(171, 24)
        Me.PXElogOpen.TabIndex = 126
        Me.PXElogOpen.Text = "Open PXE log"
        Me.PXElogOpen.UseCustomBackColor = True
        Me.PXElogOpen.UseCustomForeColor = True
        Me.PXElogOpen.UseSelectable = True
        '
        'MetroLabel8
        '
        Me.MetroLabel8.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.MetroLabel8.AutoSize = True
        Me.MetroLabel8.Location = New System.Drawing.Point(27, 43)
        Me.MetroLabel8.Name = "MetroLabel8"
        Me.MetroLabel8.Size = New System.Drawing.Size(123, 26)
        Me.MetroLabel8.TabIndex = 129
        Me.MetroLabel8.Text = "PXE ProductVersion"
        Me.MetroLabel8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'OpenTftrootImages
        '
        Me.OpenTftrootImages.BackColor = System.Drawing.Color.Transparent
        Me.OpenTftrootImages.Dock = System.Windows.Forms.DockStyle.Fill
        Me.OpenTftrootImages.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.OpenTftrootImages.Location = New System.Drawing.Point(3, 175)
        Me.OpenTftrootImages.Name = "OpenTftrootImages"
        Me.OpenTftrootImages.Size = New System.Drawing.Size(171, 24)
        Me.OpenTftrootImages.TabIndex = 125
        Me.OpenTftrootImages.Text = "Open TftpRoot\Images"
        Me.OpenTftrootImages.UseCustomBackColor = True
        Me.OpenTftrootImages.UseCustomForeColor = True
        Me.OpenTftrootImages.UseSelectable = True
        '
        'PXEFolderOpen
        '
        Me.PXEFolderOpen.BackColor = System.Drawing.Color.Transparent
        Me.PXEFolderOpen.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PXEFolderOpen.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.PXEFolderOpen.Location = New System.Drawing.Point(3, 116)
        Me.PXEFolderOpen.Name = "PXEFolderOpen"
        Me.PXEFolderOpen.Size = New System.Drawing.Size(171, 23)
        Me.PXEFolderOpen.TabIndex = 127
        Me.PXEFolderOpen.Text = "Open PXE Folder"
        Me.PXEFolderOpen.UseCustomBackColor = True
        Me.PXEFolderOpen.UseCustomForeColor = True
        Me.PXEFolderOpen.UseSelectable = True
        '
        'PXEProductVersionValue
        '
        Me.PXEProductVersionValue.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PXEProductVersionValue.AutoSize = True
        Me.PXEProductVersionValue.Location = New System.Drawing.Point(180, 43)
        Me.PXEProductVersionValue.Name = "PXEProductVersionValue"
        Me.PXEProductVersionValue.Size = New System.Drawing.Size(288, 26)
        Me.PXEProductVersionValue.TabIndex = 9
        Me.PXEProductVersionValue.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PXEServiceValue
        '
        Me.PXEServiceValue.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PXEServiceValue.AutoSize = True
        Me.PXEServiceValue.Location = New System.Drawing.Point(180, 69)
        Me.PXEServiceValue.Name = "PXEServiceValue"
        Me.PXEServiceValue.Size = New System.Drawing.Size(288, 23)
        Me.PXEServiceValue.TabIndex = 11
        Me.PXEServiceValue.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TableLayoutPanel38
        '
        Me.TableLayoutPanel38.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.TableLayoutPanel38.BackColor = System.Drawing.Color.Transparent
        Me.TableLayoutPanel38.ColumnCount = 2
        Me.TableLayoutPanel38.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 37.57962!))
        Me.TableLayoutPanel38.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 62.42038!))
        Me.TableLayoutPanel38.Controls.Add(Me.MetroLabel3, 0, 0)
        Me.TableLayoutPanel38.Controls.Add(Me.IPsubnetValue, 1, 1)
        Me.TableLayoutPanel38.Controls.Add(Me.MetroLabel7, 0, 4)
        Me.TableLayoutPanel38.Controls.Add(Me.IPAddressValue, 1, 0)
        Me.TableLayoutPanel38.Controls.Add(Me.MetroLabel6, 0, 3)
        Me.TableLayoutPanel38.Controls.Add(Me.OpenNomadLogFile, 0, 6)
        Me.TableLayoutPanel38.Controls.Add(Me.OpenNomad, 0, 5)
        Me.TableLayoutPanel38.Controls.Add(Me.MetroLabel4, 0, 1)
        Me.TableLayoutPanel38.Controls.Add(Me.NomadProductVersionValue, 1, 2)
        Me.TableLayoutPanel38.Controls.Add(Me.NomadServiceValue, 1, 3)
        Me.TableLayoutPanel38.Controls.Add(Me.NomadFolderSizeValue, 1, 4)
        Me.TableLayoutPanel38.Controls.Add(Me.MetroLabel5, 0, 2)
        Me.TableLayoutPanel38.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.TableLayoutPanel38.Location = New System.Drawing.Point(14, 64)
        Me.TableLayoutPanel38.Name = "TableLayoutPanel38"
        Me.TableLayoutPanel38.RowCount = 8
        Me.TableLayoutPanel38.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.914173!))
        Me.TableLayoutPanel38.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.37624!))
        Me.TableLayoutPanel38.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 13.36634!))
        Me.TableLayoutPanel38.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.00453!))
        Me.TableLayoutPanel38.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.08111!))
        Me.TableLayoutPanel38.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 13.85138!))
        Me.TableLayoutPanel38.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15.34653!))
        Me.TableLayoutPanel38.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15.34653!))
        Me.TableLayoutPanel38.Size = New System.Drawing.Size(471, 202)
        Me.TableLayoutPanel38.TabIndex = 108
        '
        'MetroLabel3
        '
        Me.MetroLabel3.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.MetroLabel3.AutoSize = True
        Me.MetroLabel3.Location = New System.Drawing.Point(56, 0)
        Me.MetroLabel3.Name = "MetroLabel3"
        Me.MetroLabel3.Size = New System.Drawing.Size(65, 19)
        Me.MetroLabel3.TabIndex = 124
        Me.MetroLabel3.Text = "IPAddress"
        Me.MetroLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'IPsubnetValue
        '
        Me.IPsubnetValue.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.IPsubnetValue.AutoSize = True
        Me.IPsubnetValue.Location = New System.Drawing.Point(180, 19)
        Me.IPsubnetValue.Name = "IPsubnetValue"
        Me.IPsubnetValue.Size = New System.Drawing.Size(288, 24)
        Me.IPsubnetValue.TabIndex = 7
        Me.IPsubnetValue.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'MetroLabel7
        '
        Me.MetroLabel7.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.MetroLabel7.AutoSize = True
        Me.MetroLabel7.Location = New System.Drawing.Point(27, 92)
        Me.MetroLabel7.Name = "MetroLabel7"
        Me.MetroLabel7.Size = New System.Drawing.Size(123, 21)
        Me.MetroLabel7.TabIndex = 128
        Me.MetroLabel7.Text = "Nomad Folder Size"
        Me.MetroLabel7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'IPAddressValue
        '
        Me.IPAddressValue.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.IPAddressValue.AutoSize = True
        Me.IPAddressValue.Location = New System.Drawing.Point(180, 0)
        Me.IPAddressValue.Name = "IPAddressValue"
        Me.IPAddressValue.Size = New System.Drawing.Size(288, 19)
        Me.IPAddressValue.TabIndex = 6
        Me.IPAddressValue.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'MetroLabel6
        '
        Me.MetroLabel6.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.MetroLabel6.AutoSize = True
        Me.MetroLabel6.Location = New System.Drawing.Point(38, 69)
        Me.MetroLabel6.Name = "MetroLabel6"
        Me.MetroLabel6.Size = New System.Drawing.Size(100, 23)
        Me.MetroLabel6.TabIndex = 127
        Me.MetroLabel6.Text = "Nomad Service"
        Me.MetroLabel6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'OpenNomadLogFile
        '
        Me.OpenNomadLogFile.BackColor = System.Drawing.Color.Transparent
        Me.OpenNomadLogFile.Dock = System.Windows.Forms.DockStyle.Fill
        Me.OpenNomadLogFile.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.OpenNomadLogFile.Location = New System.Drawing.Point(3, 143)
        Me.OpenNomadLogFile.Name = "OpenNomadLogFile"
        Me.OpenNomadLogFile.Size = New System.Drawing.Size(171, 24)
        Me.OpenNomadLogFile.TabIndex = 128
        Me.OpenNomadLogFile.Text = "Open Nomad log"
        Me.OpenNomadLogFile.UseCustomBackColor = True
        Me.OpenNomadLogFile.UseCustomForeColor = True
        Me.OpenNomadLogFile.UseSelectable = True
        '
        'OpenNomad
        '
        Me.OpenNomad.BackColor = System.Drawing.Color.Transparent
        Me.OpenNomad.Dock = System.Windows.Forms.DockStyle.Fill
        Me.OpenNomad.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.OpenNomad.Location = New System.Drawing.Point(3, 116)
        Me.OpenNomad.Name = "OpenNomad"
        Me.OpenNomad.Size = New System.Drawing.Size(171, 21)
        Me.OpenNomad.TabIndex = 124
        Me.OpenNomad.Text = "Open Nomad Folder"
        Me.OpenNomad.UseCustomBackColor = True
        Me.OpenNomad.UseCustomForeColor = True
        Me.OpenNomad.UseSelectable = True
        '
        'MetroLabel4
        '
        Me.MetroLabel4.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.MetroLabel4.AutoSize = True
        Me.MetroLabel4.Location = New System.Drawing.Point(47, 19)
        Me.MetroLabel4.Name = "MetroLabel4"
        Me.MetroLabel4.Size = New System.Drawing.Size(83, 24)
        Me.MetroLabel4.TabIndex = 125
        Me.MetroLabel4.Text = "Subnet Mask"
        Me.MetroLabel4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'NomadProductVersionValue
        '
        Me.NomadProductVersionValue.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.NomadProductVersionValue.AutoSize = True
        Me.NomadProductVersionValue.Location = New System.Drawing.Point(180, 43)
        Me.NomadProductVersionValue.Name = "NomadProductVersionValue"
        Me.NomadProductVersionValue.Size = New System.Drawing.Size(288, 26)
        Me.NomadProductVersionValue.TabIndex = 9
        Me.NomadProductVersionValue.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'NomadServiceValue
        '
        Me.NomadServiceValue.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.NomadServiceValue.AutoSize = True
        Me.NomadServiceValue.Location = New System.Drawing.Point(180, 69)
        Me.NomadServiceValue.Name = "NomadServiceValue"
        Me.NomadServiceValue.Size = New System.Drawing.Size(288, 23)
        Me.NomadServiceValue.TabIndex = 11
        Me.NomadServiceValue.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'NomadFolderSizeValue
        '
        Me.NomadFolderSizeValue.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.NomadFolderSizeValue.AutoSize = True
        Me.NomadFolderSizeValue.Location = New System.Drawing.Point(180, 92)
        Me.NomadFolderSizeValue.Name = "NomadFolderSizeValue"
        Me.NomadFolderSizeValue.Size = New System.Drawing.Size(288, 21)
        Me.NomadFolderSizeValue.TabIndex = 91
        Me.NomadFolderSizeValue.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'MetroLabel5
        '
        Me.MetroLabel5.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.MetroLabel5.AutoSize = True
        Me.MetroLabel5.Location = New System.Drawing.Point(15, 43)
        Me.MetroLabel5.Name = "MetroLabel5"
        Me.MetroLabel5.Size = New System.Drawing.Size(146, 26)
        Me.MetroLabel5.TabIndex = 126
        Me.MetroLabel5.Text = "Nomad ProductVersion"
        Me.MetroLabel5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'MBSAtab11
        '
        Me.MBSAtab11.Controls.Add(Me.LabelMBSA2)
        Me.MBSAtab11.Controls.Add(Me.LabelMBSA1)
        Me.MBSAtab11.Controls.Add(Me.MetroTile22)
        Me.MBSAtab11.Controls.Add(Me.MetroLabel22)
        Me.MBSAtab11.Controls.Add(Me.MetroLabel21)
        Me.MBSAtab11.Controls.Add(Me.MetroLinkWSUSSCN2AB)
        Me.MBSAtab11.Controls.Add(Me.MetroLabel20)
        Me.MBSAtab11.Controls.Add(Me.MBSAlistBox)
        Me.MBSAtab11.Controls.Add(Me.MBSATextBox)
        Me.MBSAtab11.Controls.Add(Me.MetroLabel19)
        Me.MBSAtab11.Controls.Add(Me.MBSA_Run)
        Me.MBSAtab11.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MBSAtab11.HorizontalScrollbarBarColor = True
        Me.MBSAtab11.HorizontalScrollbarHighlightOnWheel = False
        Me.MBSAtab11.HorizontalScrollbarSize = 10
        Me.MBSAtab11.Location = New System.Drawing.Point(4, 34)
        Me.MBSAtab11.Name = "MBSAtab11"
        Me.MBSAtab11.Size = New System.Drawing.Size(1075, 678)
        Me.MBSAtab11.TabIndex = 22
        Me.MBSAtab11.Text = "MBSA"
        Me.MBSAtab11.VerticalScrollbarBarColor = True
        Me.MBSAtab11.VerticalScrollbarHighlightOnWheel = False
        Me.MBSAtab11.VerticalScrollbarSize = 10
        '
        'LabelMBSA2
        '
        Me.LabelMBSA2.AutoSize = True
        Me.LabelMBSA2.BackColor = System.Drawing.Color.Transparent
        Me.LabelMBSA2.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelMBSA2.Location = New System.Drawing.Point(58, 20)
        Me.LabelMBSA2.Name = "LabelMBSA2"
        Me.LabelMBSA2.Size = New System.Drawing.Size(0, 16)
        Me.LabelMBSA2.TabIndex = 136
        '
        'LabelMBSA1
        '
        Me.LabelMBSA1.AutoSize = True
        Me.LabelMBSA1.BackColor = System.Drawing.Color.Transparent
        Me.LabelMBSA1.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelMBSA1.Location = New System.Drawing.Point(58, 3)
        Me.LabelMBSA1.Name = "LabelMBSA1"
        Me.LabelMBSA1.Size = New System.Drawing.Size(0, 16)
        Me.LabelMBSA1.TabIndex = 135
        '
        'MetroTile22
        '
        Me.MetroTile22.ActiveControl = Nothing
        Me.MetroTile22.BackColor = System.Drawing.Color.Transparent
        Me.MetroTile22.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.MetroTile22.Location = New System.Drawing.Point(3, 3)
        Me.MetroTile22.Name = "MetroTile22"
        Me.MetroTile22.Size = New System.Drawing.Size(38, 43)
        Me.MetroTile22.TabIndex = 134
        Me.MetroTile22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MetroTile22.TileImage = CType(resources.GetObject("MetroTile22.TileImage"), System.Drawing.Image)
        Me.MetroTile22.TileImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MetroTile22.TileTextFontSize = MetroFramework.MetroTileTextSize.Small
        Me.MetroTile22.UseCustomBackColor = True
        Me.MetroTile22.UseCustomForeColor = True
        Me.MetroTile22.UseSelectable = True
        Me.MetroTile22.UseTileImage = True
        '
        'MetroLabel22
        '
        Me.MetroLabel22.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.MetroLabel22.AutoSize = True
        Me.MetroLabel22.Location = New System.Drawing.Point(280, 139)
        Me.MetroLabel22.Name = "MetroLabel22"
        Me.MetroLabel22.Size = New System.Drawing.Size(461, 19)
        Me.MetroLabel22.TabIndex = 133
        Me.MetroLabel22.Text = "3. Copy Scan-UpdatesOffline.zip to a network share in a new folder of its own"
        '
        'MetroLabel21
        '
        Me.MetroLabel21.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.MetroLabel21.AutoSize = True
        Me.MetroLabel21.Location = New System.Drawing.Point(307, 91)
        Me.MetroLabel21.Name = "MetroLabel21"
        Me.MetroLabel21.Size = New System.Drawing.Size(417, 19)
        Me.MetroLabel21.TabIndex = 132
        Me.MetroLabel21.Text = "2. Add wsusscn2.cab to the supplied zip file > Scan-UpdatesOffline.zip"
        '
        'MetroLinkWSUSSCN2AB
        '
        Me.MetroLinkWSUSSCN2AB.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.MetroLinkWSUSSCN2AB.BackColor = System.Drawing.Color.AliceBlue
        Me.MetroLinkWSUSSCN2AB.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.MetroLinkWSUSSCN2AB.Location = New System.Drawing.Point(433, 48)
        Me.MetroLinkWSUSSCN2AB.Name = "MetroLinkWSUSSCN2AB"
        Me.MetroLinkWSUSSCN2AB.Size = New System.Drawing.Size(171, 23)
        Me.MetroLinkWSUSSCN2AB.TabIndex = 131
        Me.MetroLinkWSUSSCN2AB.Text = "WSUSSCN2.CAB Download"
        Me.MetroLinkWSUSSCN2AB.UseCustomBackColor = True
        Me.MetroLinkWSUSSCN2AB.UseCustomForeColor = True
        Me.MetroLinkWSUSSCN2AB.UseSelectable = True
        '
        'MetroLabel20
        '
        Me.MetroLabel20.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.MetroLabel20.AutoSize = True
        Me.MetroLabel20.Location = New System.Drawing.Point(250, 17)
        Me.MetroLabel20.Name = "MetroLabel20"
        Me.MetroLabel20.Size = New System.Drawing.Size(555, 19)
        Me.MetroLabel20.TabIndex = 130
        Me.MetroLabel20.Text = "1. Download the latest Microsoft file ""wsusscn2.cab"" from Microsoft via this link" &
    " below (700MB)"
        '
        'MBSAlistBox
        '
        Me.MBSAlistBox.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.MBSAlistBox.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.MBSAlistBox.FormattingEnabled = True
        Me.MBSAlistBox.Location = New System.Drawing.Point(3, 307)
        Me.MBSAlistBox.Name = "MBSAlistBox"
        Me.MBSAlistBox.ScrollAlwaysVisible = True
        Me.MBSAlistBox.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple
        Me.MBSAlistBox.Size = New System.Drawing.Size(1069, 368)
        Me.MBSAlistBox.TabIndex = 129
        '
        'MBSATextBox
        '
        Me.MBSATextBox.Anchor = System.Windows.Forms.AnchorStyles.Top
        '
        '
        '
        Me.MBSATextBox.CustomButton.Image = Nothing
        Me.MBSATextBox.CustomButton.Location = New System.Drawing.Point(478, 1)
        Me.MBSATextBox.CustomButton.Name = ""
        Me.MBSATextBox.CustomButton.Size = New System.Drawing.Size(21, 21)
        Me.MBSATextBox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue
        Me.MBSATextBox.CustomButton.TabIndex = 1
        Me.MBSATextBox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light
        Me.MBSATextBox.CustomButton.UseSelectable = True
        Me.MBSATextBox.CustomButton.Visible = False
        Me.MBSATextBox.Lines = New String() {"\\Server\Share\FolderName"}
        Me.MBSATextBox.Location = New System.Drawing.Point(267, 227)
        Me.MBSATextBox.MaxLength = 32767
        Me.MBSATextBox.Name = "MBSATextBox"
        Me.MBSATextBox.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.MBSATextBox.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.MBSATextBox.SelectedText = ""
        Me.MBSATextBox.SelectionLength = 0
        Me.MBSATextBox.SelectionStart = 0
        Me.MBSATextBox.Size = New System.Drawing.Size(500, 23)
        Me.MBSATextBox.TabIndex = 128
        Me.MBSATextBox.Text = "\\Server\Share\FolderName"
        Me.MBSATextBox.UseSelectable = True
        Me.MBSATextBox.WaterMarkColor = System.Drawing.Color.FromArgb(CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.MBSATextBox.WaterMarkFont = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel)
        '
        'MetroLabel19
        '
        Me.MetroLabel19.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.MetroLabel19.AutoSize = True
        Me.MetroLabel19.Location = New System.Drawing.Point(267, 194)
        Me.MetroLabel19.Name = "MetroLabel19"
        Me.MetroLabel19.Size = New System.Drawing.Size(500, 19)
        Me.MetroLabel19.TabIndex = 127
        Me.MetroLabel19.Text = "4. Input the server and folder where you copied the file ""Scan-UpdatesOffline.zip" &
    """ to"
        '
        'MBSA_Run
        '
        Me.MBSA_Run.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.MBSA_Run.BackColor = System.Drawing.Color.AliceBlue
        Me.MBSA_Run.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.MBSA_Run.Location = New System.Drawing.Point(433, 273)
        Me.MBSA_Run.Name = "MBSA_Run"
        Me.MBSA_Run.Size = New System.Drawing.Size(184, 28)
        Me.MBSA_Run.TabIndex = 125
        Me.MBSA_Run.Text = "Run MBSA Scan on Remote PC"
        Me.MBSA_Run.UseCustomBackColor = True
        Me.MBSA_Run.UseCustomForeColor = True
        Me.MBSA_Run.UseSelectable = True
        '
        'ProcessorTab13
        '
        Me.ProcessorTab13.Controls.Add(Me.MetroTile13)
        Me.ProcessorTab13.Controls.Add(Me.ProcessorUsage)
        Me.ProcessorTab13.Controls.Add(Me.Label28)
        Me.ProcessorTab13.Controls.Add(Me.Label48)
        Me.ProcessorTab13.Controls.Add(Me.ListViewProcessorUsage)
        Me.ProcessorTab13.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.ProcessorTab13.HorizontalScrollbarBarColor = True
        Me.ProcessorTab13.HorizontalScrollbarHighlightOnWheel = False
        Me.ProcessorTab13.HorizontalScrollbarSize = 10
        Me.ProcessorTab13.Location = New System.Drawing.Point(4, 34)
        Me.ProcessorTab13.Name = "ProcessorTab13"
        Me.ProcessorTab13.Size = New System.Drawing.Size(1075, 678)
        Me.ProcessorTab13.TabIndex = 12
        Me.ProcessorTab13.Text = "Proc Usage"
        Me.ProcessorTab13.VerticalScrollbarBarColor = True
        Me.ProcessorTab13.VerticalScrollbarHighlightOnWheel = False
        Me.ProcessorTab13.VerticalScrollbarSize = 10
        '
        'MetroTile13
        '
        Me.MetroTile13.ActiveControl = Nothing
        Me.MetroTile13.BackColor = System.Drawing.Color.Transparent
        Me.MetroTile13.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.MetroTile13.Location = New System.Drawing.Point(3, 3)
        Me.MetroTile13.Name = "MetroTile13"
        Me.MetroTile13.Size = New System.Drawing.Size(38, 43)
        Me.MetroTile13.TabIndex = 132
        Me.MetroTile13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MetroTile13.TileImage = CType(resources.GetObject("MetroTile13.TileImage"), System.Drawing.Image)
        Me.MetroTile13.TileImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MetroTile13.TileTextFontSize = MetroFramework.MetroTileTextSize.Small
        Me.MetroTile13.UseCustomBackColor = True
        Me.MetroTile13.UseCustomForeColor = True
        Me.MetroTile13.UseSelectable = True
        Me.MetroTile13.UseTileImage = True
        '
        'ProcessorUsage
        '
        Me.ProcessorUsage.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.ProcessorUsage.BackColor = System.Drawing.Color.AliceBlue
        Me.ProcessorUsage.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.ProcessorUsage.Location = New System.Drawing.Point(451, 6)
        Me.ProcessorUsage.Name = "ProcessorUsage"
        Me.ProcessorUsage.Size = New System.Drawing.Size(123, 28)
        Me.ProcessorUsage.TabIndex = 124
        Me.ProcessorUsage.Text = "Display Process list"
        Me.ProcessorUsage.UseCustomBackColor = True
        Me.ProcessorUsage.UseCustomForeColor = True
        Me.ProcessorUsage.UseSelectable = True
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.BackColor = System.Drawing.Color.Transparent
        Me.Label28.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(59, 20)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(0, 13)
        Me.Label28.TabIndex = 112
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.BackColor = System.Drawing.Color.Transparent
        Me.Label48.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label48.Location = New System.Drawing.Point(59, 3)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(0, 13)
        Me.Label48.TabIndex = 110
        '
        'ListViewProcessorUsage
        '
        Me.ListViewProcessorUsage.AllowColumnReorder = True
        Me.ListViewProcessorUsage.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.ListViewProcessorUsage.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader5, Me.ColumnHeader6, Me.ColumnHeader8})
        Me.ListViewProcessorUsage.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold)
        Me.ListViewProcessorUsage.FullRowSelect = True
        Me.ListViewProcessorUsage.GridLines = True
        Me.ListViewProcessorUsage.Location = New System.Drawing.Point(172, 40)
        Me.ListViewProcessorUsage.Name = "ListViewProcessorUsage"
        Me.ListViewProcessorUsage.Size = New System.Drawing.Size(723, 607)
        Me.ListViewProcessorUsage.Sorting = System.Windows.Forms.SortOrder.Ascending
        Me.ListViewProcessorUsage.TabIndex = 109
        Me.ListViewProcessorUsage.UseCompatibleStateImageBehavior = False
        Me.ListViewProcessorUsage.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader5
        '
        Me.ColumnHeader5.Text = "Process Name"
        Me.ColumnHeader5.Width = 400
        '
        'ColumnHeader6
        '
        Me.ColumnHeader6.Text = "Process ID"
        Me.ColumnHeader6.Width = 100
        '
        'ColumnHeader8
        '
        Me.ColumnHeader8.Text = "Processor Percentage Used"
        Me.ColumnHeader8.Width = 200
        '
        'ContextMenu1
        '
        Me.ContextMenu1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AddPC, Me.ToolStripSeparator1, Me.AddPCFromFile, Me.ToolStripSeparator2, Me.CopyNameToClipBoardToolStripMenuItem, Me.ToolStripSeparator6, Me.DeletePC, Me.ToolStripSeparator3, Me.ClearAllComputers, Me.ToolStripSeparator4, Me.PINGSinglePC, Me.ToolStripSeparator5, Me.ConnectToolStripMenuItem})
        Me.ContextMenu1.Name = "ContextMenu1"
        Me.ContextMenu1.Size = New System.Drawing.Size(207, 194)
        '
        'AddPC
        '
        Me.AddPC.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.AddPC.Image = Global.RDT.My.Resources.Resources.Graphicloads_100_Flat_2_Check_1
        Me.AddPC.Name = "AddPC"
        Me.AddPC.Size = New System.Drawing.Size(206, 22)
        Me.AddPC.Text = "Add PC"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(203, 6)
        '
        'AddPCFromFile
        '
        Me.AddPCFromFile.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.AddPCFromFile.Image = Global.RDT.My.Resources.Resources.Graphicloads_100_Flat_2_Check_1
        Me.AddPCFromFile.Name = "AddPCFromFile"
        Me.AddPCFromFile.Size = New System.Drawing.Size(206, 22)
        Me.AddPCFromFile.Text = "Add PC's from File"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(203, 6)
        '
        'CopyNameToClipBoardToolStripMenuItem
        '
        Me.CopyNameToClipBoardToolStripMenuItem.Image = Global.RDT.My.Resources.Resources.Oxygen_Icons_org_Oxygen_Devices_printer_laser
        Me.CopyNameToClipBoardToolStripMenuItem.Name = "CopyNameToClipBoardToolStripMenuItem"
        Me.CopyNameToClipBoardToolStripMenuItem.Size = New System.Drawing.Size(206, 22)
        Me.CopyNameToClipBoardToolStripMenuItem.Text = "Copy Name to ClipBoard"
        '
        'ToolStripSeparator6
        '
        Me.ToolStripSeparator6.Name = "ToolStripSeparator6"
        Me.ToolStripSeparator6.Size = New System.Drawing.Size(203, 6)
        '
        'DeletePC
        '
        Me.DeletePC.ForeColor = System.Drawing.Color.DarkRed
        Me.DeletePC.Image = Global.RDT.My.Resources.Resources.Danrabbit_Elementary_Button_error
        Me.DeletePC.Name = "DeletePC"
        Me.DeletePC.ShowShortcutKeys = False
        Me.DeletePC.Size = New System.Drawing.Size(206, 22)
        Me.DeletePC.Text = "Remove PC"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(203, 6)
        '
        'ClearAllComputers
        '
        Me.ClearAllComputers.ForeColor = System.Drawing.Color.DarkRed
        Me.ClearAllComputers.Image = Global.RDT.My.Resources.Resources.Danrabbit_Elementary_Button_error
        Me.ClearAllComputers.Name = "ClearAllComputers"
        Me.ClearAllComputers.Size = New System.Drawing.Size(206, 22)
        Me.ClearAllComputers.Text = "Remove ALL - Clear List!"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(203, 6)
        '
        'PINGSinglePC
        '
        Me.PINGSinglePC.Image = Global.RDT.My.Resources.Resources.Danrabbit_Elementary_Window_remote_desktop
        Me.PINGSinglePC.Name = "PINGSinglePC"
        Me.PINGSinglePC.Size = New System.Drawing.Size(206, 22)
        Me.PINGSinglePC.Text = "Ping PC"
        '
        'ToolStripSeparator5
        '
        Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
        Me.ToolStripSeparator5.Size = New System.Drawing.Size(203, 6)
        '
        'ConnectToolStripMenuItem
        '
        Me.ConnectToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ConnectToolStripMenuItem.ForeColor = System.Drawing.Color.SeaGreen
        Me.ConnectToolStripMenuItem.Image = CType(resources.GetObject("ConnectToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ConnectToolStripMenuItem.Name = "ConnectToolStripMenuItem"
        Me.ConnectToolStripMenuItem.Size = New System.Drawing.Size(206, 22)
        Me.ConnectToolStripMenuItem.Text = "CONNECT to PC >"
        '
        'ImageList
        '
        Me.ImageList.ImageStream = CType(resources.GetObject("ImageList.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList.Images.SetKeyName(0, "Laptop-Green-12623.png")
        Me.ImageList.Images.SetKeyName(1, "pc-blank.png")
        Me.ImageList.Images.SetKeyName(2, "Laptop-Red-12624.png")
        Me.ImageList.Images.SetKeyName(3, "Laptop-Yellow-12622.png")
        Me.ImageList.Images.SetKeyName(4, "laptop-check-12460.png")
        Me.ImageList.Images.SetKeyName(5, "laptop-check-12463.png")
        '
        'BackgroundWorkerSpinner
        '
        Me.BackgroundWorkerSpinner.WorkerSupportsCancellation = True
        '
        'MetroProgressBar
        '
        Me.MetroProgressBar.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.MetroProgressBar.Location = New System.Drawing.Point(644, 26)
        Me.MetroProgressBar.MarqueeAnimationSpeed = 1
        Me.MetroProgressBar.Name = "MetroProgressBar"
        Me.MetroProgressBar.ProgressBarStyle = System.Windows.Forms.ProgressBarStyle.Blocks
        Me.MetroProgressBar.Size = New System.Drawing.Size(179, 13)
        Me.MetroProgressBar.Step = 1
        Me.MetroProgressBar.TabIndex = 119
        '
        'ImageList1
        '
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList1.Images.SetKeyName(0, "Everaldo-Crystal-Clear-App-hardware-info.ico")
        Me.ImageList1.Images.SetKeyName(1, "Graphicloads-100-Flat-2-Man-2.ico")
        Me.ImageList1.Images.SetKeyName(2, "Graphicloads-100-Flat-2-Man-1.ico")
        '
        'BackgroundWorkerEval
        '
        Me.BackgroundWorkerEval.WorkerSupportsCancellation = True
        '
        'MetroLabel12
        '
        Me.MetroLabel12.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.MetroLabel12.AutoSize = True
        Me.MetroLabel12.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel12.FontSize = MetroFramework.MetroLabelSize.Small
        Me.MetroLabel12.FontWeight = MetroFramework.MetroLabelWeight.Bold
        Me.MetroLabel12.ForeColor = System.Drawing.Color.LimeGreen
        Me.MetroLabel12.Location = New System.Drawing.Point(644, 8)
        Me.MetroLabel12.Name = "MetroLabel12"
        Me.MetroLabel12.Size = New System.Drawing.Size(179, 15)
        Me.MetroLabel12.TabIndex = 120
        Me.MetroLabel12.Text = "RDT - Remote Diagnostics Tool"
        Me.MetroLabel12.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.MetroLabel12.UseCustomForeColor = True
        '
        'TableLayoutPanel10
        '
        Me.TableLayoutPanel10.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel10.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.TableLayoutPanel10.ColumnCount = 1
        Me.TableLayoutPanel10.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel10.Controls.Add(Me.TreeView, 0, 0)
        Me.TableLayoutPanel10.Location = New System.Drawing.Point(5, 9)
        Me.TableLayoutPanel10.Name = "TableLayoutPanel10"
        Me.TableLayoutPanel10.RowCount = 1
        Me.TableLayoutPanel10.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel10.Size = New System.Drawing.Size(265, 755)
        Me.TableLayoutPanel10.TabIndex = 121
        '
        'TreeView
        '
        Me.TreeView.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TreeView.ContextMenuStrip = Me.ContextMenu1
        Me.TreeView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TreeView.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.TreeView.ImageIndex = 1
        Me.TreeView.ImageList = Me.ImageList
        Me.TreeView.Location = New System.Drawing.Point(3, 3)
        Me.TreeView.Name = "TreeView"
        TreeNode1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        TreeNode1.Checked = True
        TreeNode1.ForeColor = System.Drawing.Color.Black
        TreeNode1.Name = "          ROOT"
        TreeNode1.NodeFont = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        TreeNode1.Text = "          COMPUTER LIST          "
        Me.TreeView.Nodes.AddRange(New System.Windows.Forms.TreeNode() {TreeNode1})
        Me.TreeView.SelectedImageIndex = 1
        Me.TreeView.ShowLines = False
        Me.TreeView.Size = New System.Drawing.Size(259, 749)
        Me.TreeView.TabIndex = 3
        Me.ContextMenu1ToolTip.SetToolTip(Me.TreeView, "Right Click")
        '
        'TableLayoutPanel13
        '
        Me.TableLayoutPanel13.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel13.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.TableLayoutPanel13.ColumnCount = 1
        Me.TableLayoutPanel13.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel13.Controls.Add(Me.FormTabControl, 0, 0)
        Me.TableLayoutPanel13.Location = New System.Drawing.Point(273, 42)
        Me.TableLayoutPanel13.Name = "TableLayoutPanel13"
        Me.TableLayoutPanel13.RowCount = 1
        Me.TableLayoutPanel13.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel13.Size = New System.Drawing.Size(1089, 722)
        Me.TableLayoutPanel13.TabIndex = 122
        '
        'PrintScreenTip
        '
        Me.PrintScreenTip.Tag = ""
        '
        'Home
        '
        Me.Home.BackColor = System.Drawing.Color.AliceBlue
        Me.Home.BackgroundImage = CType(resources.GetObject("Home.BackgroundImage"), System.Drawing.Image)
        Me.Home.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Home.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.Home.Location = New System.Drawing.Point(276, 12)
        Me.Home.Name = "Home"
        Me.Home.Size = New System.Drawing.Size(34, 25)
        Me.Home.TabIndex = 123
        Me.Home.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.HelpTip.SetToolTip(Me.Home, "GOTO > Begin")
        Me.Home.UseCustomBackColor = True
        Me.Home.UseCustomForeColor = True
        Me.Home.UseSelectable = True
        '
        'MetroLabel15
        '
        Me.MetroLabel15.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.MetroLabel15.AutoSize = True
        Me.MetroLabel15.Location = New System.Drawing.Point(1120, 12)
        Me.MetroLabel15.Name = "MetroLabel15"
        Me.MetroLabel15.Size = New System.Drawing.Size(43, 19)
        Me.MetroLabel15.TabIndex = 124
        Me.MetroLabel15.Text = "4.0.40"
        '
        'ContextMenu1ToolTip
        '
        Me.ContextMenu1ToolTip.Style = MetroFramework.MetroColorStyle.Blue
        Me.ContextMenu1ToolTip.StyleManager = Nothing
        Me.ContextMenu1ToolTip.Tag = ""
        Me.ContextMenu1ToolTip.Theme = MetroFramework.MetroThemeStyle.Light
        '
        'MetroToolTip1
        '
        Me.MetroToolTip1.Style = MetroFramework.MetroColorStyle.Blue
        Me.MetroToolTip1.StyleManager = Nothing
        Me.MetroToolTip1.Theme = MetroFramework.MetroThemeStyle.Light
        '
        'Form5
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1366, 768)
        Me.Controls.Add(Me.MetroLabel15)
        Me.Controls.Add(Me.Home)
        Me.Controls.Add(Me.TableLayoutPanel13)
        Me.Controls.Add(Me.TableLayoutPanel10)
        Me.Controls.Add(Me.MetroLabel12)
        Me.Controls.Add(Me.MetroProgressBar)
        Me.Controls.Add(Me.Purchase)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Helpme)
        Me.DisplayHeader = False
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form5"
        Me.Padding = New System.Windows.Forms.Padding(20, 30, 20, 20)
        Me.Resizable = False
        Me.RightToLeftLayout = True
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
        Me.FormTabControl.ResumeLayout(False)
        Me.HomeTab1.ResumeLayout(False)
        Me.TableLayoutPanel24.ResumeLayout(False)
        Me.TableLayoutPanel24.PerformLayout()
        Me.TableLayoutPanel43.ResumeLayout(False)
        Me.TableLayoutPanel43.PerformLayout()
        Me.TableLayoutPanel34.ResumeLayout(False)
        Me.TableLayoutPanel34.PerformLayout()
        Me.TableLayoutPanel33.ResumeLayout(False)
        Me.TableLayoutPanel33.PerformLayout()
        Me.TableLayoutPanel9.ResumeLayout(False)
        Me.TableLayoutPanel9.PerformLayout()
        Me.ContextMenuCopyHOST2Clipboard.ResumeLayout(False)
        Me.TableLayoutPanel5.ResumeLayout(False)
        Me.TableLayoutPanel5.PerformLayout()
        Me.ContextMenuCopyIPAddress2Clipboard.ResumeLayout(False)
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.ADtab2.ResumeLayout(False)
        Me.MetroPanel1.ResumeLayout(False)
        Me.INFOTab3.ResumeLayout(False)
        Me.INFOTab3.PerformLayout()
        Me.TableLayoutPanel6.ResumeLayout(False)
        CType(Me.DataGridViewDetails, System.ComponentModel.ISupportInitialize).EndInit()
        Me.DiskTab4.ResumeLayout(False)
        Me.DiskTab4.PerformLayout()
        CType(Me.DataGridViewDisk2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridViewDisk, System.ComponentModel.ISupportInitialize).EndInit()
        Me.NetTab5.ResumeLayout(False)
        Me.NetTab5.PerformLayout()
        Me.TableLayoutPanel42.ResumeLayout(False)
        CType(Me.DataGridViewNetCore, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel41.ResumeLayout(False)
        CType(Me.DataGridViewNet64, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel39.ResumeLayout(False)
        CType(Me.DataGridViewNet32, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ExecuteTab6.ResumeLayout(False)
        Me.ExecuteTab6.PerformLayout()
        Me.TableLayoutPanel30.ResumeLayout(False)
        Me.TableLayoutPanel30.PerformLayout()
        Me.TableLayoutPanel28.ResumeLayout(False)
        Me.TableLayoutPanel22.ResumeLayout(False)
        Me.TableLayoutPanel22.PerformLayout()
        Me.TableLayoutPanel32.ResumeLayout(False)
        Me.TableLayoutPanel32.PerformLayout()
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        Me.TableLayoutPanel8.ResumeLayout(False)
        Me.TableLayoutPanel4.ResumeLayout(False)
        Me.TableLayoutPanel3.ResumeLayout(False)
        Me.TableLayoutPanel3.PerformLayout()
        Me.FtypeTab7.ResumeLayout(False)
        Me.FtypeTab7.PerformLayout()
        Me.TableLayoutPanel14.ResumeLayout(False)
        Me.GroupsTab8.ResumeLayout(False)
        Me.GroupsTab8.PerformLayout()
        Me.TableLayoutPanel27.ResumeLayout(False)
        Me.TableLayoutPanel26.ResumeLayout(False)
        Me.TableLayoutPanel26.PerformLayout()
        Me.TableLayoutPanel25.ResumeLayout(False)
        Me.instSoftwareTab9.ResumeLayout(False)
        Me.instSoftwareTab9.PerformLayout()
        Me.TableLayoutPanel16.ResumeLayout(False)
        Me.TableLayoutPanel15.ResumeLayout(False)
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.WUtab10.ResumeLayout(False)
        Me.WUtab10.PerformLayout()
        Me.TableLayoutPanel20.ResumeLayout(False)
        Me.TableLayoutPanel37.ResumeLayout(False)
        CType(Me.DataGridView10, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MSITab12.ResumeLayout(False)
        Me.MSITab12.PerformLayout()
        Me.TableLayoutPanel19.ResumeLayout(False)
        Me.TableLayoutPanel17.ResumeLayout(False)
        CType(Me.DataGridView6, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Profiles14.ResumeLayout(False)
        Me.Profiles14.PerformLayout()
        Me.TableLayoutPanel35.ResumeLayout(False)
        CType(Me.DataGridViewProfiles, System.ComponentModel.ISupportInitialize).EndInit()
        Me.RebootChecker15.ResumeLayout(False)
        Me.RebootChecker15.PerformLayout()
        Me.TableLayoutPanel44.ResumeLayout(False)
        Me.TableLayoutPanel44.PerformLayout()
        Me.SCCMtab16.ResumeLayout(False)
        Me.SCCMtab16.PerformLayout()
        Me.TableLayoutPanel47.ResumeLayout(False)
        Me.TableLayoutPanel7.ResumeLayout(False)
        Me.TableLayoutPanel7.PerformLayout()
        Me.SCCMTabControl.ResumeLayout(False)
        Me.ExecutionHistory.ResumeLayout(False)
        CType(Me.DataGridView9, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ADVMachine.ResumeLayout(False)
        Me.ADVMachine.PerformLayout()
        CType(Me.DataGridView8, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ADVLoggedOnUser.ResumeLayout(False)
        CType(Me.DataGridView25, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ADVTaskSeq.ResumeLayout(False)
        CType(Me.DataGridView11, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PKGInstallStats.ResumeLayout(False)
        CType(Me.DataGridViewSCCMRunning, System.ComponentModel.ISupportInitialize).EndInit()
        Me.KB_EvaluationState.ResumeLayout(False)
        CType(Me.DataGridViewKBStatus, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SCCMmissUpdates.ResumeLayout(False)
        CType(Me.ListMissingUpdatesSCCMDatagrid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PatchesIn.ResumeLayout(False)
        CType(Me.SCCMPatchesInstalledDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SCCMcomplianceTab.ResumeLayout(False)
        Me.TableLayoutPanel46.ResumeLayout(False)
        Me.TableLayoutPanel46.PerformLayout()
        Me.TableLayoutPanel45.ResumeLayout(False)
        CType(Me.SCCMcomplianceDataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SCCMcomplianceDataGridView2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.RemoteCommandsSCCM.ResumeLayout(False)
        Me.RemoteCommandsSCCM.PerformLayout()
        Me.TableLayoutPanel29.ResumeLayout(False)
        Me.TableLayoutPanel29.PerformLayout()
        Me.ClientFullLog.ResumeLayout(False)
        CType(Me.SCCMfullClientLog, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ServicesTab17.ResumeLayout(False)
        Me.ServicesTab17.PerformLayout()
        Me.TableLayoutPanel18.ResumeLayout(False)
        Me.TableLayoutPanel18.PerformLayout()
        Me.TableLayoutPanel12.ResumeLayout(False)
        CType(Me.DataGridView7, System.ComponentModel.ISupportInitialize).EndInit()
        Me.StoreApps18.ResumeLayout(False)
        Me.StoreApps18.PerformLayout()
        Me.TableLayoutPanel31.ResumeLayout(False)
        CType(Me.StoreAppsDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TaskManTab19.ResumeLayout(False)
        Me.TaskManTab19.PerformLayout()
        Me.TableLayoutPanel11.ResumeLayout(False)
        Me.UserTab20.ResumeLayout(False)
        Me.UserTab20.PerformLayout()
        Me.FlowLayoutPanel9.ResumeLayout(False)
        Me.FlowLayoutPanel9.PerformLayout()
        Me.FlowLayoutPanel10.ResumeLayout(False)
        Me.FlowLayoutPanel10.PerformLayout()
        Me.FlowLayoutPanel8.ResumeLayout(False)
        Me.FlowLayoutPanel8.PerformLayout()
        Me.FlowLayoutPanel1.ResumeLayout(False)
        Me.FlowLayoutPanel1.PerformLayout()
        Me.TableLayoutPanel36.ResumeLayout(False)
        CType(Me.DataGridViewPrinters, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridViewODBC, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridViewNetwork, System.ComponentModel.ISupportInitialize).EndInit()
        Me.FlowLayoutPanel7.ResumeLayout(False)
        Me.FlowLayoutPanel7.PerformLayout()
        Me.FlowLayoutPanel6.ResumeLayout(False)
        Me.FlowLayoutPanel6.PerformLayout()
        Me.FlowLayoutPanel5.ResumeLayout(False)
        Me.FlowLayoutPanel5.PerformLayout()
        Me.FlowLayoutPanel4.ResumeLayout(False)
        Me.FlowLayoutPanel4.PerformLayout()
        Me.FlowLayoutPanel2.ResumeLayout(False)
        Me.FlowLayoutPanel2.PerformLayout()
        Me.FlowLayoutPanel3.ResumeLayout(False)
        Me.FlowLayoutPanel3.PerformLayout()
        Me.WIM_PnPSignedDriver21.ResumeLayout(False)
        Me.WIM_PnPSignedDriver21.PerformLayout()
        Me.TableLayoutPanel23.ResumeLayout(False)
        CType(Me.PnPSignedDriverDataGrid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.WIM_OptionalFeatures22.ResumeLayout(False)
        Me.WIM_OptionalFeatures22.PerformLayout()
        Me.TableLayoutPanel21.ResumeLayout(False)
        CType(Me.OptionalFeaturesDataGrid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PXETab23.ResumeLayout(False)
        Me.PXETab23.PerformLayout()
        Me.TableLayoutPanel40.ResumeLayout(False)
        Me.TableLayoutPanel40.PerformLayout()
        Me.TableLayoutPanel38.ResumeLayout(False)
        Me.TableLayoutPanel38.PerformLayout()
        Me.MBSAtab11.ResumeLayout(False)
        Me.MBSAtab11.PerformLayout()
        Me.ProcessorTab13.ResumeLayout(False)
        Me.ProcessorTab13.PerformLayout()
        Me.ContextMenu1.ResumeLayout(False)
        Me.TableLayoutPanel10.ResumeLayout(False)
        Me.TableLayoutPanel13.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ImageListSCCM As System.Windows.Forms.ImageList
    Friend WithEvents BackgroundWorker3 As System.ComponentModel.BackgroundWorker
    Friend WithEvents Purchase As MetroFramework.Controls.MetroTile
    Friend WithEvents Button2 As MetroFramework.Controls.MetroTile
    Friend WithEvents Helpme As MetroFramework.Controls.MetroTile
    Friend WithEvents FormTabControl As MetroFramework.Controls.MetroTabControl
    Friend WithEvents INFOTab3 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents PCnameFordetails As System.Windows.Forms.Label
    Friend WithEvents TableLayoutPanel6 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents DataGridViewDetails As System.Windows.Forms.DataGridView
    Friend WithEvents Column8 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column9 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DiskTab4 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents Label206 As System.Windows.Forms.Label
    Friend WithEvents DataGridViewDisk2 As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Model As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents SerialNumber As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Label65 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label69 As System.Windows.Forms.Label
    Friend WithEvents Label67 As System.Windows.Forms.Label
    Friend WithEvents TotalPhysicalMemoryDetails As System.Windows.Forms.Label
    Friend WithEvents PagefileDetails As System.Windows.Forms.Label
    Friend WithEvents DataGridViewDisk As System.Windows.Forms.DataGridView
    Friend WithEvents Drive As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Drivetype As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents SizeDiskOut As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents FreeSpace As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Used As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PercentFree As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PercentUsed As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Label62 As System.Windows.Forms.Label
    Friend WithEvents Label63 As System.Windows.Forms.Label
    Friend WithEvents Label68 As System.Windows.Forms.Label
    Friend WithEvents FtypeTab7 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents TableLayoutPanel14 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents FileTypes As System.Windows.Forms.ListBox
    Friend WithEvents Label53 As System.Windows.Forms.Label
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents GroupsTab8 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents TableLayoutPanel27 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents groupview1 As System.Windows.Forms.ListBox
    Friend WithEvents userview1 As System.Windows.Forms.ListBox
    Friend WithEvents Userlist As System.Windows.Forms.ListBox
    Friend WithEvents TableLayoutPanel26 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Label175 As System.Windows.Forms.Label
    Friend WithEvents Label174 As System.Windows.Forms.Label
    Friend WithEvents TableLayoutPanel25 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Label59 As System.Windows.Forms.Label
    Friend WithEvents Label60 As System.Windows.Forms.Label
    Friend WithEvents ExecuteTab6 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents Label221 As System.Windows.Forms.Label
    Friend WithEvents Label220 As System.Windows.Forms.Label
    Friend WithEvents Label219 As System.Windows.Forms.Label
    Friend WithEvents Label218 As System.Windows.Forms.Label
    Friend WithEvents Label214 As System.Windows.Forms.Label
    Friend WithEvents Label213 As System.Windows.Forms.Label
    Friend WithEvents Label212 As System.Windows.Forms.Label
    Friend WithEvents Label211 As System.Windows.Forms.Label
    Friend WithEvents TableLayoutPanel32 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Inst_RemDriveLetter As System.Windows.Forms.ComboBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents REMCOMPackageText As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents TableLayoutPanel8 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents SDListDirectory As System.Windows.Forms.ComboBox
    Friend WithEvents TableLayoutPanel4 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents SDList1 As System.Windows.Forms.ListBox
    Friend WithEvents TableLayoutPanel3 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Label215 As System.Windows.Forms.Label
    Friend WithEvents WUtab10 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents TableLayoutPanel37 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Label55 As System.Windows.Forms.Label
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents PXETab23 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents TableLayoutPanel40 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents PXEProductVersionValue As System.Windows.Forms.Label
    Friend WithEvents PXEServiceValue As System.Windows.Forms.Label
    Friend WithEvents TableLayoutPanel38 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents IPsubnetValue As System.Windows.Forms.Label
    Friend WithEvents IPAddressValue As System.Windows.Forms.Label
    Friend WithEvents NomadProductVersionValue As System.Windows.Forms.Label
    Friend WithEvents NomadServiceValue As System.Windows.Forms.Label
    Friend WithEvents NomadFolderSizeValue As System.Windows.Forms.Label
    Friend WithEvents ServicesTab17 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents TableLayoutPanel18 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Label209 As System.Windows.Forms.Label
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents TableLayoutPanel12 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents DataGridView7 As System.Windows.Forms.DataGridView
    Friend WithEvents ServiceName As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ServiceDescription As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StartedYesNo As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Status As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents ServiceNameSelected As System.Windows.Forms.TextBox
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents instSoftwareTab9 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents TableLayoutPanel16 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents TableLayoutPanel15 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents SoftwareName As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents SoftwareVersion As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents InstallDate As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents KeyName As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Label54 As System.Windows.Forms.Label
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents MSITab12 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents TableLayoutPanel19 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents TableLayoutPanel17 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents DataGridView6 As System.Windows.Forms.DataGridView
    Friend WithEvents Column1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StrKey As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents InstallTime As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents ProcessorTab13 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents ListViewProcessorUsage As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader5 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader6 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader8 As System.Windows.Forms.ColumnHeader
    Friend WithEvents TaskManTab19 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents TableLayoutPanel11 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents lvwProcesses As System.Windows.Forms.ListView
    Friend WithEvents lchImage As System.Windows.Forms.ColumnHeader
    Friend WithEvents lchID As System.Windows.Forms.ColumnHeader
    Friend WithEvents WhoRun As System.Windows.Forms.ColumnHeader
    Friend WithEvents exepath As System.Windows.Forms.ColumnHeader
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents UserTab20 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents TableLayoutPanel36 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents DataGridViewPrinters As System.Windows.Forms.DataGridView
    Friend WithEvents PC_Name As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents UsernamePrinters As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn70 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewODBC As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewNetwork As System.Windows.Forms.DataGridView
    Friend WithEvents Label191 As System.Windows.Forms.Label
    Friend WithEvents Label193 As System.Windows.Forms.Label
    Friend WithEvents FlowLayoutPanel7 As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents KeyboardLayout As System.Windows.Forms.Label
    Friend WithEvents FlowLayoutPanel6 As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents FlowLayoutPanel5 As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents Label197 As System.Windows.Forms.Label
    Friend WithEvents FlowLayoutPanel4 As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents tnsadmin As System.Windows.Forms.Label
    Friend WithEvents FlowLayoutPanel2 As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents Label177 As System.Windows.Forms.Label
    Friend WithEvents FlowLayoutPanel3 As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents DefaultPrinter As System.Windows.Forms.Label
    Friend WithEvents GETpcDETAILSnow As MetroFramework.Controls.MetroButton
    Friend WithEvents GatherVideoInfo As MetroFramework.Controls.MetroButton
    Friend WithEvents GatherBIOSInfo As MetroFramework.Controls.MetroButton
    Friend WithEvents GatherNetworkInfo As MetroFramework.Controls.MetroButton
    Friend WithEvents ExportDataGridViewDetails As MetroFramework.Controls.MetroButton
    Friend WithEvents Button66 As MetroFramework.Controls.MetroButton
    Friend WithEvents Button3 As MetroFramework.Controls.MetroButton
    Friend WithEvents ExportFileTypes As MetroFramework.Controls.MetroButton
    Friend WithEvents Groups As MetroFramework.Controls.MetroButton
    Friend WithEvents Button5 As MetroFramework.Controls.MetroButton
    Friend WithEvents userlistbutton As MetroFramework.Controls.MetroButton
    Friend WithEvents Addlocalgroup As MetroFramework.Controls.MetroButton
    Friend WithEvents adddomaintolocal As MetroFramework.Controls.MetroButton
    Friend WithEvents addlocalusertolocalgroup As MetroFramework.Controls.MetroButton
    Friend WithEvents removeuser As MetroFramework.Controls.MetroButton
    Friend WithEvents removelocaluser As MetroFramework.Controls.MetroButton
    Friend WithEvents addlocaluser As MetroFramework.Controls.MetroButton
    Friend WithEvents removedomainfromlocal As MetroFramework.Controls.MetroButton
    Friend WithEvents removelocalgroup As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroLabel2 As MetroFramework.Controls.MetroLabel
    Friend WithEvents MetroLabel1 As MetroFramework.Controls.MetroLabel
    Friend WithEvents SDlistpackages As MetroFramework.Controls.MetroButton
    Friend WithEvents REMCOMPackageFromDOMAIN As MetroFramework.Controls.MetroButton
    Friend WithEvents SecurityPatchesBUT As MetroFramework.Controls.MetroButton
    Friend WithEvents ExportPatches As MetroFramework.Controls.MetroButton
    Friend WithEvents OtherUpdates As MetroFramework.Controls.MetroButton
    Friend WithEvents Gather1EResults As MetroFramework.Controls.MetroButton
    Friend WithEvents OpenNomadLogFile As MetroFramework.Controls.MetroButton
    Friend WithEvents PXEFolderOpen As MetroFramework.Controls.MetroButton
    Friend WithEvents PXElogOpen As MetroFramework.Controls.MetroButton
    Friend WithEvents OpenTftrootImages As MetroFramework.Controls.MetroButton
    Friend WithEvents OpenNomad As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroLabel9 As MetroFramework.Controls.MetroLabel
    Friend WithEvents MetroLabel8 As MetroFramework.Controls.MetroLabel
    Friend WithEvents MetroLabel3 As MetroFramework.Controls.MetroLabel
    Friend WithEvents MetroLabel7 As MetroFramework.Controls.MetroLabel
    Friend WithEvents MetroLabel6 As MetroFramework.Controls.MetroLabel
    Friend WithEvents MetroLabel4 As MetroFramework.Controls.MetroLabel
    Friend WithEvents MetroLabel5 As MetroFramework.Controls.MetroLabel
    Friend WithEvents ExportDISK_DETAILS As MetroFramework.Controls.MetroButton
    Friend WithEvents DISK_DETAILS As MetroFramework.Controls.MetroButton
    Friend WithEvents Button14 As MetroFramework.Controls.MetroButton
    Friend WithEvents Button13 As MetroFramework.Controls.MetroButton
    Friend WithEvents ProcessorUsage As MetroFramework.Controls.MetroButton
    Friend WithEvents SCCMtab16 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents Button8 As MetroFramework.Controls.MetroButton
    Friend WithEvents GetSCCMCacheSettings As MetroFramework.Controls.MetroButton
    Friend WithEvents TableLayoutPanel7 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents SCCMTabControl As System.Windows.Forms.TabControl
    Friend WithEvents ExecutionHistory As System.Windows.Forms.TabPage
    Friend WithEvents DataGridView9 As System.Windows.Forms.DataGridView
    Friend WithEvents ADVMachine As System.Windows.Forms.TabPage
    Friend WithEvents AdvertNameMachine As System.Windows.Forms.Label
    Friend WithEvents PkgIDMachine As System.Windows.Forms.Label
    Friend WithEvents AdvIDMachine As System.Windows.Forms.Label
    Friend WithEvents DataGridView8 As System.Windows.Forms.DataGridView
    Friend WithEvents AdvID As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ContentSize As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column6 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column7 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ADVLoggedOnUser As System.Windows.Forms.TabPage
    Friend WithEvents DataGridView25 As System.Windows.Forms.DataGridView
    Friend WithEvents PKGInstallStats As System.Windows.Forms.TabPage
    Friend WithEvents DataGridViewSCCMRunning As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn71 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn72 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn73 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn74 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Runningstate As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ADVTaskSeq As System.Windows.Forms.TabPage
    Friend WithEvents DataGridView11 As System.Windows.Forms.DataGridView
    Friend WithEvents ADV_TS As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn14 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn15 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Live As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents RemoteCommandsSCCM As System.Windows.Forms.TabPage
    Friend WithEvents CacheDirectoryChange As System.Windows.Forms.TextBox
    Friend WithEvents CacheChangeSize As System.Windows.Forms.TextBox
    Friend WithEvents Label166 As System.Windows.Forms.Label
    Friend WithEvents SCCMCacheLabel As System.Windows.Forms.Label
    Friend WithEvents Label56 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents GetSCCMinfo As MetroFramework.Controls.MetroButton
    Friend WithEvents SCCMMODE As MetroFramework.Controls.MetroButton
    Friend WithEvents SCCMProvisioningMode As MetroFramework.Controls.MetroLabel
    Friend WithEvents openSCCMCache As MetroFramework.Controls.MetroButton
    Friend WithEvents ChangeCacheSizeButton As MetroFramework.Controls.MetroButton
    Friend WithEvents ChangeCacheDirectory As MetroFramework.Controls.MetroButton
    Friend WithEvents ExportSCCMhistory As MetroFramework.Controls.MetroButton
    Friend WithEvents GetSCCM2 As MetroFramework.Controls.MetroButton
    Friend WithEvents GETSCCM As MetroFramework.Controls.MetroButton
    Friend WithEvents ReRunAdvertMachine As MetroFramework.Controls.MetroButton
    Friend WithEvents AdvertisementsUser As MetroFramework.Controls.MetroButton
    Friend WithEvents SCCMRunningJobs As MetroFramework.Controls.MetroButton
    Friend WithEvents GetSCCMTaskSequences As MetroFramework.Controls.MetroButton
    Friend WithEvents ExportServices As MetroFramework.Controls.MetroButton
    Friend WithEvents GetServices As MetroFramework.Controls.MetroButton
    Friend WithEvents StopService As MetroFramework.Controls.MetroButton
    Friend WithEvents SetServiceStartAutomatic As MetroFramework.Controls.MetroButton
    Friend WithEvents SetServiceStartManual As MetroFramework.Controls.MetroButton
    Friend WithEvents SetServiceStartDisabled As MetroFramework.Controls.MetroButton
    Friend WithEvents DeleteServiceButton As MetroFramework.Controls.MetroButton
    Friend WithEvents StartService As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroLabel10 As MetroFramework.Controls.MetroLabel
    Friend WithEvents ExportFullSoftwareList As MetroFramework.Controls.MetroButton
    Friend WithEvents GetSoftwareList As MetroFramework.Controls.MetroButton
    Friend WithEvents MSIUNINSTALL As MetroFramework.Controls.MetroButton
    Friend WithEvents TextBox1 As MetroFramework.Controls.MetroTextBox
    Friend WithEvents ExportSoftwareListMSI As MetroFramework.Controls.MetroButton
    Friend WithEvents GetMSIList As MetroFramework.Controls.MetroButton
    Friend WithEvents MSIZAPbutton As MetroFramework.Controls.MetroButton
    Friend WithEvents TextBoxMSIZAP As MetroFramework.Controls.MetroTextBox
    Friend WithEvents Exporttaskmanager As MetroFramework.Controls.MetroButton
    Friend WithEvents endprocessbutton As MetroFramework.Controls.MetroButton
    Friend WithEvents cmdRefresh As MetroFramework.Controls.MetroButton
    Friend WithEvents ExportUserDetails As MetroFramework.Controls.MetroButton
    Friend WithEvents GetPrinters As MetroFramework.Controls.MetroButton
    Friend WithEvents GROUPSVALUE2 As MetroFramework.Controls.MetroTextBox
    Friend WithEvents GROUPSVALUE1 As MetroFramework.Controls.MetroTextBox
    Friend WithEvents BackgroundWorkerSpinner As System.ComponentModel.BackgroundWorker
    Friend WithEvents MetroProgressBar As MetroFramework.Controls.MetroProgressBar
    Friend WithEvents UpdatesLabel As MetroFramework.Controls.MetroLabel
    Friend WithEvents MetroTile2 As MetroFramework.Controls.MetroTile
    Friend WithEvents MetroTile3 As MetroFramework.Controls.MetroTile
    Friend WithEvents MetroTile4 As MetroFramework.Controls.MetroTile
    Friend WithEvents MetroTile5 As MetroFramework.Controls.MetroTile
    Friend WithEvents MetroTile6 As MetroFramework.Controls.MetroTile
    Friend WithEvents MetroTile7 As MetroFramework.Controls.MetroTile
    Friend WithEvents MetroTile8 As MetroFramework.Controls.MetroTile
    Friend WithEvents MetroTile9 As MetroFramework.Controls.MetroTile
    Friend WithEvents MetroTile10 As MetroFramework.Controls.MetroTile
    Friend WithEvents MetroTile11 As MetroFramework.Controls.MetroTile
    Friend WithEvents MetroTile12 As MetroFramework.Controls.MetroTile
    Friend WithEvents MetroTile13 As MetroFramework.Controls.MetroTile
    Friend WithEvents MetroTile14 As MetroFramework.Controls.MetroTile
    Friend WithEvents MetroTile15 As MetroFramework.Controls.MetroTile
    Friend WithEvents ImageList1 As ImageList
    Friend WithEvents BackgroundWorkerEval As System.ComponentModel.BackgroundWorker
    Friend WithEvents MetroLabel12 As MetroFramework.Controls.MetroLabel
    Friend WithEvents FlowLayoutPanel8 As FlowLayoutPanel
    Friend WithEvents FlowLayoutPanel1 As FlowLayoutPanel
    Friend WithEvents Label4 As Label
    Friend WithEvents FlowLayoutPanel9 As FlowLayoutPanel
    Friend WithEvents userlogonserver As Label
    Friend WithEvents FlowLayoutPanel10 As FlowLayoutPanel
    Friend WithEvents Label6 As Label
    Friend WithEvents userbeingqueried As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents DataGridViewTextBoxColumn75 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn76 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn77 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn68 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn67 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn69 As DataGridViewTextBoxColumn
    Friend WithEvents TableLayoutPanel10 As TableLayoutPanel
    Friend WithEvents TreeView As TreeView
    Friend WithEvents ContextMenu1 As ContextMenuStrip
    Friend WithEvents AddPC As ToolStripMenuItem
    Friend WithEvents DeletePC As ToolStripMenuItem
    Friend WithEvents PINGSinglePC As ToolStripMenuItem
    Friend WithEvents ImageList As ImageList
    Friend WithEvents TableLayoutPanel13 As TableLayoutPanel
    Friend WithEvents ConnectToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PrintScreenTip As ToolTip
    Friend WithEvents PaypalTip As ToolTip
    Friend WithEvents HelpTip As ToolTip
    Friend WithEvents TableLayoutPanel20 As TableLayoutPanel
    Friend WithEvents KBTextBox As MetroFramework.Controls.MetroTextBox
    Friend WithEvents KBRemoveButton As MetroFramework.Controls.MetroButton
    Friend WithEvents WIM_OptionalFeatures22 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents TableLayoutPanel21 As TableLayoutPanel
    Friend WithEvents OptionalFeaturesDataGrid As DataGridView
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn16 As DataGridViewTextBoxColumn
    Friend WithEvents WIM_PnPSignedDriver21 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents MetroTile17 As MetroFramework.Controls.MetroTile
    Friend WithEvents PnPSignedDriverExportButton As MetroFramework.Controls.MetroButton
    Friend WithEvents PnPSignedDriverButton As MetroFramework.Controls.MetroButton
    Friend WithEvents PnPSignedDriverLabel2 As Label
    Friend WithEvents PnPSignedDriverLabel1 As Label
    Friend WithEvents TableLayoutPanel23 As TableLayoutPanel
    Friend WithEvents PnPSignedDriverDataGrid As DataGridView
    Friend WithEvents MetroTile18 As MetroFramework.Controls.MetroTile
    Friend WithEvents WIM_OptionalFeaturesExportButton As MetroFramework.Controls.MetroButton
    Friend WithEvents WIM_OptionalFeaturesButton As MetroFramework.Controls.MetroButton
    Friend WithEvents WIM_OptionalFeaturesLabel2 As Label
    Friend WithEvents WIM_OptionalFeaturesLabel1 As Label
    Friend WithEvents Home As MetroFramework.Controls.MetroButton
    Friend WithEvents DeviceClass As DataGridViewTextBoxColumn
    Friend WithEvents DriverProviderName As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn22 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn20 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn19 As DataGridViewTextBoxColumn
    Friend WithEvents DeviceID As DataGridViewTextBoxColumn
    Friend WithEvents Label7 As Label
    Friend WithEvents TableLayoutPanel22 As TableLayoutPanel
    Friend WithEvents PowershellCopyLocalExecuteButton As MetroFramework.Controls.MetroButton
    Friend WithEvents Label8 As Label
    Friend WithEvents PSEXECUTEPackageText As TextBox
    Friend WithEvents TableLayoutPanel28 As TableLayoutPanel
    Friend WithEvents SDList1Files As ListBox
    Friend WithEvents TableLayoutPanel30 As TableLayoutPanel
    Friend WithEvents Label10 As Label
    Friend WithEvents SDBoxFile As MetroFramework.Controls.MetroTextBox
    Friend WithEvents SDBOXFolder As MetroFramework.Controls.MetroTextBox
    Friend WithEvents MetroLabel13 As MetroFramework.Controls.MetroLabel
    Friend WithEvents MetroLabel11 As MetroFramework.Controls.MetroLabel
    Friend WithEvents MetroLabel14 As MetroFramework.Controls.MetroLabel
    Friend WithEvents Label12 As Label
    Friend WithEvents MetroLabel15 As MetroFramework.Controls.MetroLabel
    Friend WithEvents HomeTab1 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents TableLayoutPanel24 As TableLayoutPanel
    Friend WithEvents RunPSCommandButton As MetroFramework.Controls.MetroTile
    Friend WithEvents Label9 As Label
    Friend WithEvents RunPSCommandTextBox As MetroFramework.Controls.MetroTextBox
    Friend WithEvents TableLayoutPanel43 As TableLayoutPanel
    Friend WithEvents Runcommandonly As MetroFramework.Controls.MetroTile
    Friend WithEvents Label217 As Label
    Friend WithEvents runcommandonlytext As MetroFramework.Controls.MetroTextBox
    Friend WithEvents TableLayoutPanel34 As TableLayoutPanel
    Friend WithEvents SaveEMAdetails As MetroFramework.Controls.MetroTextBox
    Friend WithEvents Label208 As Label
    Friend WithEvents DeleteEMAnumber As MetroFramework.Controls.MetroTile
    Friend WithEvents TableLayoutPanel33 As TableLayoutPanel
    Friend WithEvents SaveEMAnumber As MetroFramework.Controls.MetroTile
    Friend WithEvents Label179 As Label
    Friend WithEvents Helpdesknumber As MetroFramework.Controls.MetroTextBox
    Friend WithEvents TableLayoutPanel9 As TableLayoutPanel
    Friend WithEvents userdomainComboBox As ComboBox
    Friend WithEvents GetMobileNumber As MetroFramework.Controls.MetroTile
    Friend WithEvents GetPhoneNumber As MetroFramework.Controls.MetroTile
    Friend WithEvents Reboot As Label
    Friend WithEvents GetEmailAddress As MetroFramework.Controls.MetroTile
    Friend WithEvents PhoneNumber1 As Label
    Friend WithEvents EmailAddress As Label
    Friend WithEvents Host As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents PhoneNumber2 As Label
    Friend WithEvents MobileNumber As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents uptime1 As Label
    Friend WithEvents GetUptime As MetroFramework.Controls.MetroTile
    Friend WithEvents TableLayoutPanel5 As TableLayoutPanel
    Friend WithEvents StatusOfConnection As Label
    Friend WithEvents Button1 As MetroFramework.Controls.MetroTile
    Friend WithEvents MetroTile1 As MetroFramework.Controls.MetroTile
    Friend WithEvents ProgressBar2 As ProgressBar
    Friend WithEvents AliveButton As Button
    Friend WithEvents Alive As Label
    Friend WithEvents ForceReboot As MetroFramework.Controls.MetroTile
    Friend WithEvents PCNAME As Label
    Friend WithEvents TableLayoutPanel2 As TableLayoutPanel
    Friend WithEvents Eventlog As MetroFramework.Controls.MetroTile
    Friend WithEvents StartupItemsList As MetroFramework.Controls.MetroTile
    Friend WithEvents TaskSched As MetroFramework.Controls.MetroTile
    Friend WithEvents PowershellCMD As MetroFramework.Controls.MetroTile
    Friend WithEvents RDP As MetroFramework.Controls.MetroTile
    Friend WithEvents RDTReadWriteRegistry As MetroFramework.Controls.MetroTile
    Friend WithEvents NSlookup As MetroFramework.Controls.MetroTile
    Friend WithEvents NLTEST As MetroFramework.Controls.MetroTile
    Friend WithEvents btnOpenReg As MetroFramework.Controls.MetroTile
    Friend WithEvents CompMgmt As MetroFramework.Controls.MetroTile
    Friend WithEvents DetectAPPV As MetroFramework.Controls.MetroTile
    Friend WithEvents DefragC As MetroFramework.Controls.MetroTile
    Friend WithEvents CheckAntivirus As MetroFramework.Controls.MetroTile
    Friend WithEvents BrowseAppslogs As MetroFramework.Controls.MetroTile
    Friend WithEvents StoreApps18 As TabPage
    Friend WithEvents MetroTile16 As MetroFramework.Controls.MetroTile
    Friend WithEvents ExportStoreApps As MetroFramework.Controls.MetroButton
    Friend WithEvents ListStoreApps As MetroFramework.Controls.MetroButton
    Friend WithEvents Labelstoreapps2 As Label
    Friend WithEvents Labelstoreapps1 As Label
    Friend WithEvents TableLayoutPanel31 As TableLayoutPanel
    Friend WithEvents StoreAppsDataGridView As DataGridView
    Friend WithEvents DataGridViewTextBoxColumn17 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn18 As DataGridViewTextBoxColumn
    Friend WithEvents Architecture As DataGridViewTextBoxColumn
    Friend WithEvents ProgramId As DataGridViewTextBoxColumn
    Friend WithEvents Language As DataGridViewTextBoxColumn
    Friend WithEvents Vendor As DataGridViewTextBoxColumn
    Friend WithEvents ToolStripSeparator1 As ToolStripSeparator
    Friend WithEvents ToolStripSeparator2 As ToolStripSeparator
    Friend WithEvents ToolStripSeparator3 As ToolStripSeparator
    Friend WithEvents ClearAllComputers As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator4 As ToolStripSeparator
    Friend WithEvents Profiles14 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents MetroTile19 As MetroFramework.Controls.MetroTile
    Friend WithEvents LabelProfiles2 As Label
    Friend WithEvents LabelProfiles1 As Label
    Friend WithEvents TableLayoutPanel35 As TableLayoutPanel
    Friend WithEvents DataGridViewProfiles As DataGridView
    Friend WithEvents DeleteProfile As MetroFramework.Controls.MetroButton
    Friend WithEvents DetectProfiles As MetroFramework.Controls.MetroButton
    Friend WithEvents ADtab2 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents ListViewAD As ListView
    Friend WithEvents MetroPanel1 As MetroFramework.Controls.MetroPanel
    Friend WithEvents ListADUsers_Computers As MetroFramework.Controls.MetroButton
    Friend WithEvents ListUsersInGroupBox As MetroFramework.Controls.MetroTextBox
    Friend WithEvents ListUsersInGroupButton As MetroFramework.Controls.MetroButton
    Friend WithEvents ListADGroups As MetroFramework.Controls.MetroButton
    Friend WithEvents AddPCFromFile As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator5 As ToolStripSeparator
    Friend WithEvents ContextMenu1ToolTip As MetroFramework.Components.MetroToolTip
    Friend WithEvents SearchProgramBox As MetroFramework.Controls.MetroTextBox
    Friend WithEvents SearchProgramButton As MetroFramework.Controls.MetroButton
    Friend WithEvents ShaddowUserSession As MetroFramework.Controls.MetroTile
    Friend WithEvents NetTab5 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents MetroTile20 As MetroFramework.Controls.MetroTile
    Friend WithEvents ExportDOTNETlist As MetroFramework.Controls.MetroButton
    Friend WithEvents DotNetDetect As MetroFramework.Controls.MetroButton
    Friend WithEvents Label14a As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents MetroLabel18 As MetroFramework.Controls.MetroLabel
    Friend WithEvents MetroLabel17 As MetroFramework.Controls.MetroLabel
    Friend WithEvents MetroLabel16 As MetroFramework.Controls.MetroLabel
    Friend WithEvents TableLayoutPanel42 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel41 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel39 As TableLayoutPanel
    Friend WithEvents DataGridViewNet32 As DataGridView
    Friend WithEvents DataGridViewNetCore As DataGridView
    Friend WithEvents DataGridViewNet64 As DataGridView
    Friend WithEvents DataGridViewTextBoxColumn27 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn28 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn29 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn30 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn21 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn24 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn25 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn26 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn31 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn32 As DataGridViewTextBoxColumn
    Friend WithEvents ContextMenuCopyHOST2Clipboard As ContextMenuStrip
    Friend WithEvents ToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents ContextMenuCopyIPAddress2Clipboard As ContextMenuStrip
    Friend WithEvents ToolStripMenuItem2 As ToolStripMenuItem
    Friend WithEvents MetroToolTip1 As MetroFramework.Components.MetroToolTip
    Friend WithEvents Column16 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn23 As DataGridViewTextBoxColumn
    Friend WithEvents Column13 As DataGridViewTextBoxColumn
    Friend WithEvents Column14 As DataGridViewTextBoxColumn
    Friend WithEvents Column15 As DataGridViewTextBoxColumn
    Friend WithEvents CopyNameToClipBoardToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator6 As ToolStripSeparator
    Friend WithEvents FileVersionFinder As MetroFramework.Controls.MetroTile
    Friend WithEvents MBSAtab11 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents MBSA_Run As MetroFramework.Controls.MetroButton
    Friend WithEvents MBSATextBox As MetroFramework.Controls.MetroTextBox
    Friend WithEvents MetroLabel19 As MetroFramework.Controls.MetroLabel
    Friend WithEvents MBSAlistBox As ListBox
    Friend WithEvents MetroLinkWSUSSCN2AB As MetroFramework.Controls.MetroLink
    Friend WithEvents MetroLabel20 As MetroFramework.Controls.MetroLabel
    Friend WithEvents MetroLabel22 As MetroFramework.Controls.MetroLabel
    Friend WithEvents MetroLabel21 As MetroFramework.Controls.MetroLabel
    Friend WithEvents LabelMBSA2 As Label
    Friend WithEvents LabelMBSA1 As Label
    Friend WithEvents MetroTile22 As MetroFramework.Controls.MetroTile
    Friend WithEvents DataGridView10 As DataGridView
    Friend WithEvents DataGridViewTextBoxColumn7 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn11 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn12 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn13 As DataGridViewTextBoxColumn
    Friend WithEvents SCCMmissUpdates As TabPage
    Friend WithEvents SCCMPatchesMissing As MetroFramework.Controls.MetroButton
    Friend WithEvents ListMissingUpdatesSCCMDatagrid As DataGridView
    Friend WithEvents PatchesIn As TabPage
    Friend WithEvents SCCMPatchesInstalled As MetroFramework.Controls.MetroButton
    Friend WithEvents SCCMPatchesInstalledDataGridView As DataGridView
    Friend WithEvents DataGridViewTextBoxColumn35 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn33 As DataGridViewTextBoxColumn
    Friend WithEvents RebootChecker15 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents MetroTile21 As MetroFramework.Controls.MetroTile
    Friend WithEvents Label1 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents RebootButton1 As MetroFramework.Controls.MetroButton
    Friend WithEvents TableLayoutPanel44 As TableLayoutPanel
    Friend WithEvents MetroLabel26 As MetroFramework.Controls.MetroLabel
    Friend WithEvents MetroLabel25 As MetroFramework.Controls.MetroLabel
    Friend WithEvents MetroLabel24 As MetroFramework.Controls.MetroLabel
    Friend WithEvents MetroLabel23 As MetroFramework.Controls.MetroLabel
    Friend WithEvents RebootRequiredCheck1 As MetroFramework.Controls.MetroLabel
    Friend WithEvents RebootRequiredCheck2 As MetroFramework.Controls.MetroLabel
    Friend WithEvents RebootRequiredCheck3 As MetroFramework.Controls.MetroLabel
    Friend WithEvents RebootRequiredCheck4 As MetroFramework.Controls.MetroLabel
    Friend WithEvents SCCMcomplianceTab As TabPage
    Friend WithEvents MetroLabel28 As MetroFramework.Controls.MetroLabel
    Friend WithEvents MetroLabel27 As MetroFramework.Controls.MetroLabel
    Friend WithEvents SCCMcomplianceDataGridView2 As DataGridView
    Friend WithEvents SCCMcomplianceDataGridView1 As DataGridView
    Friend WithEvents DataGridViewTextBoxColumn34 As DataGridViewTextBoxColumn
    Friend WithEvents AssignmentID As DataGridViewTextBoxColumn
    Friend WithEvents SCCMcomplianceButton As MetroFramework.Controls.MetroButton
    Friend WithEvents DataGridViewTextBoxColumn36 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn37 As DataGridViewTextBoxColumn
    Friend WithEvents TableLayoutPanel45 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel46 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel29 As TableLayoutPanel
    Friend WithEvents Button9 As MetroFramework.Controls.MetroButton
    Friend WithEvents SCCMREPAIRWMI As MetroFramework.Controls.MetroButton
    Friend WithEvents Button173 As MetroFramework.Controls.MetroButton
    Friend WithEvents Label226 As Label
    Friend WithEvents Label173 As Label
    Friend WithEvents Label194 As Label
    Friend WithEvents TAPREPAIRWMI As MetroFramework.Controls.MetroButton
    Friend WithEvents TAPHRP As MetroFramework.Controls.MetroButton
    Friend WithEvents GatherAudioInfo As MetroFramework.Controls.MetroButton
    Friend WithEvents GetHPBiosSettings As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroLabel29 As MetroFramework.Controls.MetroLabel
    Friend WithEvents RebootRequiredCheck5 As MetroFramework.Controls.MetroLabel
    Friend WithEvents DataGridViewTextBoxColumn78 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn79 As DataGridViewTextBoxColumn
    Friend WithEvents KB_EvaluationState As TabPage
    Friend WithEvents KBStatus As MetroFramework.Controls.MetroButton
    Friend WithEvents DataGridViewKBStatus As DataGridView
    Friend WithEvents DataGridViewTextBoxColumn6 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn9 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn8 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn10 As DataGridViewTextBoxColumn
    Friend WithEvents EvaluationStateReason As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn38 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn39 As DataGridViewTextBoxColumn
    Friend WithEvents PercentComplete As DataGridViewTextBoxColumn
    Friend WithEvents ErrorCode As DataGridViewTextBoxColumn
    Friend WithEvents ClientFullLog As TabPage
    Friend WithEvents SCCMfullClientLog As DataGridView
    Friend WithEvents GetFullCLientLogSCCM As MetroFramework.Controls.MetroButton
    Friend WithEvents DataGridViewTextBoxColumn40 As DataGridViewTextBoxColumn
    Friend WithEvents SCCMClientMessageSent As DataGridViewTextBoxColumn
    Friend WithEvents SCCMClientMessageTime As DataGridViewTextBoxColumn
    Friend WithEvents TableLayoutPanel47 As TableLayoutPanel
    Friend WithEvents TriggerScheduleSCCM_WMIC As MetroFramework.Controls.MetroButton
    Friend WithEvents TriggerScheduleSCCM_Powershell As MetroFramework.Controls.MetroButton
    Friend WithEvents TriggerScheduleSCCM_ComboBox As MetroFramework.Controls.MetroComboBox
    Friend WithEvents TAPREPAIRSCCMCLIENT As MetroFramework.Controls.MetroButton
End Class
