﻿Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Management
Imports System.Runtime.InteropServices
Imports System.Diagnostics.Process
Imports System.IO
Imports System.Net
Imports System.Text.RegularExpressions
Imports System.DirectoryServices
Imports System.Threading
Imports System.Text
Imports System.Security.AccessControl
Imports System.Security.Principal

Public Class AppV
    Inherits MetroFramework.Forms.MetroForm

    Public Declare Function WNetAddConnection2 Lib "mpr.dll" Alias "WNetAddConnection2A" (ByRef lpNetResource As NETRESOURCE, ByVal lpPassword As String, ByVal lpUserName As String, ByVal dwFlags As Integer) As Integer
    Public Declare Function WNetCancelConnection2 Lib "mpr" Alias "WNetCancelConnection2A" (ByVal lpName As String, ByVal dwFlags As Integer, ByVal fForce As Integer) As Integer

    <Runtime.InteropServices.StructLayout(LayoutKind.Sequential)> Public Structure NETRESOURCE
        Public dwScope As Integer
        Public dwType As Integer
        Public dwDisplayType As Integer
        Public dwUsage As Integer
        Public lpLocalName As String
        Public lpRemoteName As String
        Public lpComment As String
        Public lpProvider As String
    End Structure

    Public Const RESOURCETYPE_DISK As Long = &H1

    Private Sub AppV_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Text = "App-V Version : " & DetectedAPPVVersion & " on : " & MachineName
        DataGridView1.Rows.Clear()
        DataGridView2.Rows.Clear()
        GETAPPVCACHE()
        PopulateAPPV()
        PopulateAPPVShortcuts()
    End Sub

    Private Sub PopulateAPPV()
        Dim PkgGUID1 As String = Nothing
        Dim Name1 As String = Nothing
        Dim version1 As String = Nothing
        Dim InUse1 As String = Nothing
        Dim TotalSize1 As String = Nothing
        Dim SftPath1 As String = Nothing
        Dim Locked1 As String = Nothing

        Cursor = Cursors.WaitCursor

        Dim QueryOptions = New Management.EnumerationOptions
        QueryOptions.Timeout = New TimeSpan(0, 0, 10)

        Dim objManagementScope As Management.ManagementScope
        Dim options As Management.ConnectionOptions
        options = New Management.ConnectionOptions()
        Dim computerconnect As String = "\\" & txtpcname & "\root\microsoft\appvirt\client"
        options.Username = username
        options.Password = password
        options.Timeout = TimeSpan.FromSeconds(30)
        options.Authority = "NTLMDOMAIN:" & domain
        options.Authentication = Management.AuthenticationLevel.PacketPrivacy
        objManagementScope = New Management.ManagementScope(computerconnect, options)

        If objManagementScope.IsConnected = True Then
        Else
            Try
                objManagementScope.Connect()
            Catch ex As Exception
                MessageBox.Show("Couldn't connect: " + ex.Message, "Error , Please check PC online and APPV Agent is installed!")
                Cursor = Cursors.Default
                Me.Close()
                Exit Sub
            End Try
        End If
        Try
            Dim query As New Management.SelectQuery("SELECT * FROM Package")
            Dim searcher As New Management.ManagementObjectSearcher(objManagementScope, query, QueryOptions)
            For Each mo As Management.ManagementObject In searcher.[Get]()
                Name1 = mo("Name")
                version1 = mo("Version")
                PkgGUID1 = mo("PackageGUID")
                InUse1 = mo("InUse")
                Locked1 = mo("Locked")
                TotalSize1 = mo("TotalSize")
                SftPath1 = mo("SftPath")

                DataGridView1.RowTemplate.DefaultCellStyle.ForeColor = Color.Black
                DataGridView1.Rows.Add(Name1, version1, PkgGUID1, InUse1, Locked1, TotalSize1, SftPath1)
            Next

        Catch ex As Exception
            MessageBox.Show("Unable to connect to APPV Agent, Please check Agent is Installed!")
            Cursor = Cursors.Default
            Me.Close()
            Form5.Show()
            Exit Sub
        End Try

        Try
            DataGridView1.Sort(DataGridView1.Columns(0), System.ComponentModel.ListSortDirection.Ascending)
        Catch
        End Try

        Cursor = Cursors.Default
    End Sub

    Private Sub PopulateAPPVShortcuts()
        Dim PkgGUID2 As String = Nothing
        Dim Name2 As String = Nothing
        Dim version2 As String = Nothing
        Dim LastLaunchOnSystem2 As String = Nothing
        Dim OriginalOsdPath2 As String = Nothing
        Dim Loading2 As String = Nothing
        Dim LastLaunchOnSystem2converted As Date = Nothing

        Cursor = Cursors.WaitCursor

        Dim QueryOptions = New Management.EnumerationOptions
        QueryOptions.Timeout = New TimeSpan(0, 0, 10)

        Dim objManagementScope As Management.ManagementScope
        Dim options As Management.ConnectionOptions
        options = New Management.ConnectionOptions()
        Dim computerconnect As String = "\\" & txtpcname & "\root\microsoft\appvirt\client"
        options.Username = username
        options.Password = password
        options.Timeout = TimeSpan.FromSeconds(30)
        options.Authority = "NTLMDOMAIN:" & domain
        options.Authentication = Management.AuthenticationLevel.PacketPrivacy
        objManagementScope = New Management.ManagementScope(computerconnect, options)

        If objManagementScope.IsConnected = True Then
        Else
            Try
                objManagementScope.Connect()
            Catch ex As Exception
                MessageBox.Show("Couldn't connect: " + ex.Message, "Error , Please check PC online and APPV Agent is installed!")
                Cursor = Cursors.Default
                Me.Close()
                Exit Sub
            End Try
        End If
        Try
            Dim query As New Management.SelectQuery("SELECT * FROM Application")
            Dim searcher As New Management.ManagementObjectSearcher(objManagementScope, query, QueryOptions)
            For Each mo As Management.ManagementObject In searcher.[Get]()
                Name2 = mo("Name")
                version2 = mo("Version")
                PkgGUID2 = mo("PackageGUID")
                LastLaunchOnSystem2 = mo("LastLaunchOnSystem")
                Loading2 = mo("Loading")
                OriginalOsdPath2 = mo("OriginalOsdPath")

                Dim s1 As String = Microsoft.VisualBasic.Left(LastLaunchOnSystem2, 14)
                LastLaunchOnSystem2converted = Date.ParseExact(s1, "yyyyMMddHHmmss", System.Globalization.DateTimeFormatInfo.InvariantInfo)

                DataGridView2.RowTemplate.DefaultCellStyle.ForeColor = Color.Black
                DataGridView2.Rows.Add(Name2, version2, LastLaunchOnSystem2converted.ToString, PkgGUID2, Loading2, OriginalOsdPath2)
            Next

        Catch ex As Exception
            MessageBox.Show("Unable to connect to APPV Agent, Please check Agent is Installed!")
        End Try

        Try
            DataGridView2.Sort(DataGridView2.Columns(0), System.ComponentModel.ListSortDirection.Ascending)
        Catch
        End Try
        Cursor = Cursors.Default
    End Sub

    Private Sub GETAPPVCACHE()
        On Error Resume Next

        Cursor = Cursors.WaitCursor
        ProgressBar_APPVCACHE.Value = 0
        APPVCACHEsize.Text = ""
        APPVCACHEfree.Text = ""
        PUAPPVCache.Text = ""
        APPVCACHElocation.Text = ""
        APPV4mindiskspace.Text = ""
        Dim CACHESIZE
        Dim CACHEFileSize As Long
        Dim CACHEpercentFree As Long
        Dim CACHElocation
        Dim APPVCACHElocationRemote

        Dim objManagementScope As Management.ManagementScope = Nothing
        Dim objManagementClass As Management.ManagementClass = Nothing
        Dim objManagementBaseObject As Management.ManagementBaseObject = Nothing
        Dim intRegistryHive As Microsoft.Win32.RegistryHive

        intRegistryHive = Microsoft.Win32.RegistryHive.LocalMachine

        Dim options As Management.ConnectionOptions
        options = New Management.ConnectionOptions()
        Dim computerconnect As String = "\\" & txtpcname & "\root\DEFAULT"
        options.Username = username
        options.Password = password
        options.Timeout = TimeSpan.FromSeconds(30)
        options.Authority = "NTLMDOMAIN:" & domain
        options.Authentication = Management.AuthenticationLevel.PacketPrivacy
        objManagementScope = New Management.ManagementScope(computerconnect, options)

        If objManagementScope.IsConnected = True Then
        Else
            objManagementScope.Connect()
        End If

        objManagementClass = New Management.ManagementClass("StdRegProv")

        With objManagementClass
            .Scope = objManagementScope
            objManagementBaseObject = .GetMethodParameters("GetStringValue")

            With objManagementBaseObject
                .SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                .SetPropertyValue("sSubKeyName", "SOFTWARE\Microsoft\SoftGrid\4.5\Client\AppFS")
                .SetPropertyValue("sValueName", "FileSize")
            End With
            Dim OutParams As Management.ManagementBaseObject = .InvokeMethod("GetDWORDValue", objManagementBaseObject, Nothing)
            CACHESIZE = CType(OutParams("uValue"), String)
            APPVCACHEsize.Text = CACHESIZE

            With objManagementBaseObject
                .SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                .SetPropertyValue("sSubKeyName", "SOFTWARE\Microsoft\SoftGrid\4.5\Client\AppFS")
                .SetPropertyValue("sValueName", "FileName")
            End With
            OutParams = .InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
            CACHElocation = CType(OutParams("sValue"), String)
            APPVCACHElocation.Text = CACHElocation
        End With

        If CACHElocation = Nothing Then
            objManagementClass = New Management.ManagementClass("StdRegProv")

            With objManagementClass
                .Scope = objManagementScope
                objManagementBaseObject = .GetMethodParameters("GetStringValue")

                With objManagementBaseObject
                    .SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                    .SetPropertyValue("sSubKeyName", "SOFTWARE\Wow6432Node\Microsoft\SoftGrid\4.5\Client\AppFS")
                    .SetPropertyValue("sValueName", "FileSize")
                End With
                Dim OutParams As Management.ManagementBaseObject = .InvokeMethod("GetDWORDValue", objManagementBaseObject, Nothing)
                CACHESIZE = CType(OutParams("uValue"), String)
                APPVCACHEsize.Text = CACHESIZE

                With objManagementBaseObject
                    .SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                    .SetPropertyValue("sSubKeyName", "SOFTWARE\Wow6432Node\Microsoft\SoftGrid\4.5\Client\AppFS")
                    .SetPropertyValue("sValueName", "FileName")
                End With
                OutParams = .InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                CACHElocation = CType(OutParams("sValue"), String)
                APPVCACHElocation.Text = CACHElocation
            End With

            objManagementBaseObject.Dispose()
            objManagementClass.Dispose()
            computerconnect = Nothing
            Cursor = Cursors.Default
        End If

        Cursor = Cursors.WaitCursor
        APPVCACHElocationRemote = APPVCACHElocation.Text.Replace(":", "$")

        Dim info As New IO.FileInfo("\\" & txtpcname & "\" & APPVCACHElocationRemote)
        CACHEFileSize = info.Length
        CACHEFileSize = (CACHEFileSize / 1024) / 1024
        APPVCACHEfree.Text = CACHEFileSize.ToString

        CACHEpercentFree = CLng((APPVCACHEfree.Text / APPVCACHEsize.Text) * 100)
        ProgressBar_APPVCACHE.Value = CACHEpercentFree
        PUAPPVCache.Text = (100 - CACHEpercentFree).ToString & "% Free."

        Dim objReg
        Dim objSWbemServices
        Dim objSWbemLocator
        Dim strKeyPath As String = "SOFTWARE\Wow6432Node\Microsoft\SoftGrid\4.5\Client\AppFS"
        Dim i As Integer = Nothing
        Dim strValueName = "MinFreeSpaceMB"
        Dim intValue As String = Nothing
        objSWbemLocator = CreateObject("wbemScripting.SwbemLocator")
        objSWbemServices = objSWbemLocator.ConnectServer(txtpcname, "root\default", domain & "\" & username, password)
        objReg = objSWbemServices.Get("StdRegProv")
        objReg.GetDWORDValue(intRegistryHive, strKeyPath, strValueName, intValue)
        Dim p As Long = intValue
        Dim hex2 As String = Conversion.Hex(p)
        APPV4mindiskspace.Text = hex2 & " (" & intValue & ")"

        If APPV4mindiskspace.Text = "" Then
            strKeyPath = "SOFTWARE\Microsoft\SoftGrid\4.5\Client\AppFS"
            objReg.GetDWORDValue(intRegistryHive, strKeyPath, strValueName, intValue)
            p = intValue
            hex2 = Conversion.Hex(p)
            APPV4mindiskspace.Text = hex2 & " (" & intValue & ")"
        End If

        Cursor = Cursors.Default

    End Sub


    Public Function MapDrive(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String) As Boolean
        Dim nr As NETRESOURCE
        Dim strUsername As String
        Dim strPassword As String
        strUsername = domain & "\" & username
        strPassword = password

        Cursor = Cursors.WaitCursor

        Try
            Dim oNet = CreateObject("WScript.Network")
            Try
                oNet.RemoveNetworkDrive("\\" & txtpcname & "\ipc$", True, False)
                oNet.RemoveNetworkDrive("\\" & txtpcname & "\admin$", True, False)
            Catch
            End Try
            nr = New NETRESOURCE
            nr.lpRemoteName = "\\" & txtpcname & "\Admin$"
            nr.lpLocalName = Nothing
            nr.dwType = RESOURCETYPE_DISK

            Dim result As Integer
            result = WNetAddConnection2(nr, strPassword, strUsername, 0)

            If result = 0 Then
                Cursor = Cursors.Default
                Return True
            Else
                Cursor = Cursors.Default
                Return False
            End If
        Catch ex As Exception
        End Try

        Cursor = Cursors.Default

    End Function

    Private Sub PaExec_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PaExec.Click
        If MachineName = "" Then
            Exit Sub
        End If
        Dim psresult As Boolean = False
        Dim powersetup As Boolean = False
        powersetup = SETUPPowerShellonRemote()
        If powersetup = False Then
            MsgBox("Unable to configure Powershell for connection on computer : " & txtpcname)
            Exit Sub
        End If


        MapDrive(username, password, domain, txtpcname)
        Try

            Dim securepass As New Security.SecureString
            Dim c As Char
            For Each c In password
                securepass.AppendChar(c)
            Next
            Process.Start(New ProcessStartInfo() With {.UseShellExecute = False, .FileName = "powershell.exe", .UserName = username, .Password = securepass, .Domain = domain, .Arguments = "-Noexit enter-pssession " & MachineName, .WorkingDirectory = "C:\Windows\Temp"})

        Catch ex As Exception
        End Try
        psresult = MapDriveAdminRemove(username, password, domain, txtpcname)

    End Sub

    Public Function MapDriveAdminRemove(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String) As Boolean
        Dim strUsername As String
        Dim strPassword As String
        strUsername = domain & "\" & username
        strPassword = password

        Dim result As Integer
        result = WNetCancelConnection2("\\" & txtpcname & "\Ipc$", 0, True)
        result = WNetCancelConnection2("\\" & txtpcname & "\Admin$", 0, True)

        If result = 0 Then
            Return True
        Else
            Return False
        End If

    End Function

    Private Function IsPortOpen(ByVal Host As String, ByVal PortNumber As Integer) As Boolean
        Dim Client As Sockets.TcpClient = Nothing
        Try
            Client = New Sockets.TcpClient(Host, PortNumber)
            Return True
        Catch ex As Sockets.SocketException
            Return False
        Finally
            If Not Client Is Nothing Then
                Client.Close()
            End If
        End Try
    End Function

    Private Function SETUPPowerShellonRemote() As Boolean

        Dim Port As Integer = 5985
        Dim Hostname As String = IP4Address
        Dim PortOpen As Boolean = IsPortOpen(Hostname, Port)
        If PortOpen = True Then
            Return True
            Exit Function
        End If
        If PortOpen = False Then

            Try
                Dim wmi_out As Management.ManagementBaseObject
                Dim objManagementScope As Management.ManagementScope
                Dim objManagementClass As Management.ManagementClass = Nothing
                Dim objManagementBaseObject As Management.ManagementBaseObject = Nothing
                Dim retValue As Integer
                Dim Command As String = "CMD /C winrm quickconfig -quiet"

                Try
                    Dim options As Management.ConnectionOptions
                    options = New Management.ConnectionOptions()
                    Dim computerconnect As String = "\\" & txtpcname & "\root\cimv2:Win32_Process"

                    options.Username = username
                    options.Password = password
                    options.Timeout = TimeSpan.FromSeconds(30)
                    options.Authority = "NTLMDOMAIN:" & domain
                    options.Authentication = Management.AuthenticationLevel.PacketPrivacy
                    objManagementScope = New Management.ManagementScope(computerconnect, options)

                    If objManagementScope.IsConnected = True Then
                    Else
                        Try
                            objManagementScope.Connect()
                        Catch ex As Exception
                            'MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                            Return False
                            Exit Function
                        End Try
                    End If

                    objManagementClass = New Management.ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
                    objManagementClass.Scope = objManagementScope

                    objManagementBaseObject = objManagementClass.GetMethodParameters("Create")
                    objManagementBaseObject.SetPropertyValue("CommandLine", Command)
                    wmi_out = objManagementClass.InvokeMethod("Create", objManagementBaseObject, Nothing)

                    retValue = Convert.ToInt32(wmi_out("returnValue"))
                    Select Case retValue
                        Case 0
                        ' success!
                        Case 2
                            Throw New ApplicationException("Access denied")
                        Case 3
                            Throw New ApplicationException("Insufficient privilege")
                        Case 8
                            Throw New ApplicationException("Unknown failure")
                        Case 9
                            Throw New ApplicationException("Path not found")
                        Case 21
                            Throw New ApplicationException("Invalid parameter")
                        Case Else
                            Throw New ApplicationException("Unknown return code " & retValue)
                    End Select
                Catch ex As Exception
                    'MsgBox(txtpcname & ": Can't create the process. " & ex.Message)
                End Try
                objManagementBaseObject.Dispose()
                objManagementClass.Dispose()
            Catch
                'MessageBox.Show("Could not run process, " & Err.Description, "Error:", MessageBoxButtons.OK, MessageBoxIcon.Stop)
            End Try

            Try
                Dim connOptions As New Management.ConnectionOptions()
                connOptions.Username = username
                connOptions.Password = password
                connOptions.Timeout = TimeSpan.FromSeconds(30)
                connOptions.Authority = "NTLMDOMAIN:" & domain
                connOptions.EnablePrivileges = True
                connOptions.Authentication = AuthenticationLevel.PacketPrivacy
                connOptions.Impersonation = ImpersonationLevel.Impersonate
                connOptions.EnablePrivileges = True
                Dim manScope As New Management.ManagementScope([String].Format("\\{0}\ROOT\CIMV2", txtpcname), connOptions)

                Try
                    manScope.Connect()
                Catch
                    'MsgBox("Couldn't connect to remote PC.")
                    Return False
                    Exit Function
                End Try

                Dim objectGetOptions As New Management.ObjectGetOptions()
                Dim managementPath As New Management.ManagementPath("Win32_Process")
                Using processClass As New Management.ManagementClass(manScope, managementPath, objectGetOptions)
                    Using inParams As Management.ManagementBaseObject = processClass.GetMethodParameters("Create")
                        inParams("CommandLine") = Chr(34) & "winrm create winrm/config/listener?Address=*+Transport=HTTP" & Chr(34)
                        Using outParams As Management.ManagementBaseObject = processClass.InvokeMethod("Create", inParams, Nothing)
                            If CUInt(outParams("returnValue")) <> 0 Then
                                'MsgBox("Unsuccessfully Configured Powershell")
                                Return False
                                Exit Function
                            Else
                                'MsgBox("Configured Transport=HTTP for Powershell")
                                'processID = CUInt(outParams("processId"))
                                Return True
                                Exit Function
                            End If
                        End Using
                    End Using
                End Using
            Catch
            End Try
        End If

    End Function

End Class