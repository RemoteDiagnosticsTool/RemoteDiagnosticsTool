﻿Option Explicit On

Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Management
Imports System.Runtime.InteropServices
Imports System.Diagnostics.Process
Imports System.IO
Imports System.Net
Imports System.Text.RegularExpressions
Imports System.DirectoryServices
Imports System.Threading
Imports System.Text
Imports System.Security.AccessControl
Imports System.Security.Principal
Imports Microsoft.Win32
Imports System.Management.Automation
Imports System.Management.Automation.Runspaces
Imports System.Net.Sockets
Imports System.Security
Imports System.Threading.Tasks
Imports System.Net.NetworkInformation

Public Class Form5
    Inherits MetroFramework.Forms.MetroForm

    Private Shared deDomainRoot As DirectoryEntry
    Private Shared strDomainPath As String
    Private Declare Auto Function ConvertSidToStringSid Lib "advapi32.dll" (ByVal bSID As IntPtr, <System.Runtime.InteropServices.In(), System.Runtime.InteropServices.Out(), System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.LPTStr)> ByRef SIDString As String) As Integer

    <DllImportAttribute("mpr.dll",
      EntryPoint:="WNetAddConnection2W")>
    Public Shared Function WNetAddConnection2(ByRef lpNetResource _
      As NETRESOURCE, <InAttribute(),
      MarshalAsAttribute(UnmanagedType.LPWStr)> ByVal _
      lpPassword As String, <InAttribute(),
      MarshalAsAttribute(UnmanagedType.LPWStr)> ByVal _
      lpUserName As String, ByVal dwFlags As UInteger) As UInteger
    End Function

    <DllImportAttribute("mpr.dll",
      EntryPoint:="WNetCancelConnectionW")>
    Public Shared Function WNetCancelConnection(<InAttribute(),
      MarshalAsAttribute(UnmanagedType.LPWStr)> ByVal _
      lpName As String, ByVal dwFlags As UInteger,
      <MarshalAsAttribute(UnmanagedType.Bool)> ByVal _
      fForce As Boolean) As UInteger
    End Function

    Public Const NO_ERROR As UInteger = 0
    Public Const RESOURCETYPE_DISK As UInteger = 1
    Public Const CONNECT_UPDATE_PROFILE As UInteger = 1

    <StructLayoutAttribute(LayoutKind.Sequential)>
    Public Structure NETRESOURCE

        Public dwScope As UInteger
        Public dwType As UInteger
        Public dwDisplayType As UInteger
        Public dwUsage As UInteger

        <MarshalAsAttribute(UnmanagedType.LPWStr)>
        Public lpLocalName As String

        <MarshalAsAttribute(UnmanagedType.LPWStr)>
        Public lpRemoteName As String

        <MarshalAsAttribute(UnmanagedType.LPWStr)>
        Public lpComment As String

        <MarshalAsAttribute(UnmanagedType.LPWStr)>
        Public lpProvider As String

    End Structure



    Private Declare Sub keybd_event Lib "user32" (ByVal bVk As Byte, ByVal bScan As Byte, ByVal dwFlags As Long, ByVal dwExtraInfo As Long)
    Private Const KEYEVENTF_KEYUP = &H2

    <DllImport("user32.dll", CallingConvention:=CallingConvention.StdCall,
               CharSet:=CharSet.Unicode, EntryPoint:="keybd_event",
               ExactSpelling:=True, SetLastError:=True)>
    Public Shared Sub keybd_event(ByVal bVk As Byte, ByVal bScan As Byte,
                                   ByVal dwFlags As IntPtr, ByVal dwExtraInfo As IntPtr)
    End Sub

    ' Function to terminate a process
    Private Declare Function TerminateProcess Lib "kernel32" Alias "TerminateProcess" (ByVal hProcess As Long, ByVal uExitCode As Long) As Long

    Const VK_MENU = &H12    ' ALT
    Const VK_F = &H46       ' F
    Const VK_C = &H43       ' C
    Const VK_Enter = &HD    ' ENTER
    Const VK_Left = &H25    ' LEFT arrow
    Const VK_Right = &H27   ' RIGHT arrow
    Const VK_Home = &H24    ' HOME
    Const VK_ESCAPE = &H1B  ' ESCAPE
    Const wbemFlagReturnImmediately = &H10
    Const wbemFlagForwardOnly = &H20


    Dim lv1 As New ListView
    Dim ProcessorPerformanceCounters As ArrayList = New ArrayList
    Dim MemoryPerformanceCounters As ArrayList = New ArrayList
    Dim sortColumn As Integer = -1
    Public Property OpenFileDialog1 As Object

    Public Function Crypt(ByVal Text As String) As String
        ' Encrypts/decrypts the passed string using 
        ' a simple ASCII value-swapping algorithm
        Dim strTempChar As String = ""
        Dim i As Integer
        For i = 1 To Len(Text)
            If Asc(Mid$(Text, i, 1)) < 128 Then
                strTempChar = CType(Asc(Mid$(Text, i, 1)) + 128, String)
            ElseIf Asc(Mid$(Text, i, 1)) > 128 Then
                strTempChar = CType(Asc(Mid$(Text, i, 1)) - 128, String)
            End If
            Mid$(Text, i, 1) = Chr(CType(strTempChar, Integer))
        Next i
        Return Text
    End Function

    Public Class ListViewItemComparer
        Implements IComparer
        Private col As Integer
        Private order As SortOrder

        Public Sub New()
            col = 0
            order = SortOrder.Ascending
        End Sub

        Public Sub New(column As Integer, order As SortOrder)
            col = column
            Me.order = order
        End Sub

        Public Function Compare(x As Object, y As Object) As Integer Implements IComparer.Compare
            Dim returnVal As Integer
            Try
                If IsDate(CType(x, ListViewItem).SubItems(col).Text) And IsDate(CType(y, ListViewItem).SubItems(col).Text) Then
                    returnVal = 1
                Else
                    If IsNumeric(CType(x, ListViewItem).SubItems(col).Text) And IsNumeric(CType(y, ListViewItem).SubItems(col).Text) Then
                        'compare as numeric
                        returnVal = Val(CType(x, ListViewItem).SubItems(col).Text).CompareTo(Val(CType(y, ListViewItem).SubItems(col).Text))
                    Else
                        'Not numeric, so compare as string
                        returnVal = [String].Compare(CType(x, ListViewItem).SubItems(col).Text, CType(y, ListViewItem).SubItems(col).Text)
                    End If
                End If

            Catch ex As Exception
                Return 1
                'to avoid an error, probably caused by user interaction with the listview during re-population and sorting at same time
                'or if the column contains an object which is not a date, not numeric and not a string
            End Try

            'if order is descending then invert value
            If order = SortOrder.Descending Then
                returnVal *= -1
                'return the REVERSE value of the current value by multiplying it by "-1"
            End If

            Return returnVal
        End Function
    End Class


    Private Sub ListViewProcessorUsage_ColumnClick(sender As Object, e As ColumnClickEventArgs) Handles ListViewProcessorUsage.ColumnClick
        'if current column is not the previously clicked column
        If e.Column <> sortColumn Then
            'set the sort column to the new column
            sortColumn = e.Column
            'default to ascending sort order
            Me.ListViewProcessorUsage.Sorting = SortOrder.Descending
        Else
            'flip the sort order
            If ListViewProcessorUsage.Sorting = SortOrder.Descending Then
                Me.ListViewProcessorUsage.Sorting = SortOrder.Ascending
            Else
                Me.ListViewProcessorUsage.Sorting = SortOrder.Descending
            End If
        End If

        'set ListViewItemSorter property to a new ListViewItemComparer object
        Me.ListViewProcessorUsage.ListViewItemSorter = New ListViewItemComparer(e.Column, ListViewProcessorUsage.Sorting)
        'call the sort method to manually sort

        ListViewProcessorUsage.Sort()
    End Sub

    Private Sub Form5_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Dim Serial1Read As String = ""
        Dim Serial2Read As String = ""
        Dim REnableTRead As String = ""
        Dim SecurityResult As String = ""
        Dim xdays As Integer = 0

        MetroProgressBar.Hide()
        PCNAME.Text = txtpcname
        Form1.Hide()
        FormTabControl.Size = New Size(MyBase.Width, MyBase.Height)
        Inst_RemDriveLetter.Text = "A"
        FormTabControl.SelectTab(0)
        CreateRDTRegistryKeys()

        Dim CommandtoRun As String = ""
        CommandtoRun = "CMD.EXE /C DEL /F /Q RemComSvc.exe"
        Try
            Dim objShell = CreateObject("Wscript.Shell")
            objShell.run(CommandtoRun, 0, False)
        Catch ex As Exception
        End Try
        CommandtoRun = "CMD.EXE /C DEL /F /Q RemCom.exe"
        Try
            Dim objShell = CreateObject("Wscript.Shell")
            objShell.run(CommandtoRun, 0, False)
        Catch ex As Exception
        End Try
        CommandtoRun = "CMD.EXE /C DEL /F /Q options.vnc"
        Try
            Dim objShell = CreateObject("Wscript.Shell")
            objShell.run(CommandtoRun, 0, False)
        Catch ex As Exception
        End Try
        CommandtoRun = "CMD.EXE /C DEL /F /Q paexec.exe"
        Try
            Dim objShell = CreateObject("Wscript.Shell")
            objShell.run(CommandtoRun, 0, False)
        Catch ex As Exception
        End Try
        CommandtoRun = "CMD.EXE /C DEL /F /Q Remote_Assistance.exe"
        Try
            Dim objShell = CreateObject("Wscript.Shell")
            objShell.run(CommandtoRun, 0, False)
        Catch ex As Exception
        End Try
        CommandtoRun = "CMD.EXE /C DEL /F /Q RemoteAssistanceA.exe"
        Try
            Dim objShell = CreateObject("Wscript.Shell")
            objShell.run(CommandtoRun, 0, False)
        Catch ex As Exception
        End Try
        CommandtoRun = "CMD.EXE /C DEL /F /Q SecureVNCPlugin.dsm"
        Try
            Dim objShell = CreateObject("Wscript.Shell")
            objShell.run(CommandtoRun, 0, False)
        Catch ex As Exception
        End Try
        CommandtoRun = "CMD.EXE /C DEL /F /Q ultravnc.ini"
        Try
            Dim objShell = CreateObject("Wscript.Shell")
            objShell.run(CommandtoRun, 0, False)
        Catch ex As Exception
        End Try

        LoadTree()


    End Sub

    Private Sub CreateRDTRegistryKeys()
        Try
            Dim regKey As Microsoft.Win32.RegistryKey
            regKey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey("Software", True)
            regKey.CreateSubKey("RDT")
            regKey.Close()
        Catch ex As Exception
        End Try
        Try
            Dim regKey As Microsoft.Win32.RegistryKey
            regKey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey("Software\RDT", True)
            regKey.CreateSubKey("Computers")
            regKey.Close()
        Catch ex As Exception
        End Try
    End Sub

    Private Sub LoadTree()
        Try
            Dim rk As RegistryKey
            Dim skName As String
            Dim sublist As New ArrayList
            Dim serverinlist = 0

            rk = Registry.CurrentUser.OpenSubKey("Software\RDT\Computers", True)

            For Each skName In rk.GetSubKeyNames()
                Dim TopLevelAD As TreeNode
                TopLevelAD = TreeView.SelectedNode
                If TreeView.Nodes.Count > 0 Then
                    TopLevelAD = AddTreeViewNode(TreeView.Nodes, skName, 1)
                End If
            Next skName

        Catch ex As Exception
        End Try

        TreeView.Sort()

    End Sub

    Private Function AddTreeViewNode(ByVal parent_nodes As TreeNodeCollection, ByVal text As String, ByVal image_index As Integer, Optional ByVal tag_object As Object = Nothing) As TreeNode
        Dim new_node As TreeNode = parent_nodes.Add(text)
        new_node.ImageIndex = image_index
        new_node.SelectedImageIndex = image_index
        new_node.Tag = tag_object
        Return new_node
    End Function

    Private Sub Explorer1_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles TreeView.MouseDown
        ' See if this is the right button.
        If e.Button = Windows.Forms.MouseButtons.Right Then
            ' Select this node.
            Dim node_here As TreeNode = TreeView.GetNodeAt(e.X, e.Y)
            TreeView.SelectedNode = node_here
            ' See if we got a node.
            If node_here Is Nothing Then Exit Sub
        End If
    End Sub



    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Hide() 'or form.ShowDialog() for Modal forms
        Form1.Show() 'or form.ShowDialog() for Modal forms
    End Sub

    Public Function PassParam(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String)
        username = txtusername
        password = txtpassword
        domain = txtdomain
        Return (username)
        Return (password)
        Return (domain)
    End Function

    Public Sub GETSTRVALUES(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)

        On Error Resume Next

        Dim strRead2 As String = Nothing
        Dim strRead3 As String = Nothing
        Dim strRead5 As String = Nothing
        Dim strRead6 As String = Nothing
        Dim Lumensions As String = Nothing
        Dim strread18 As String = Nothing
        Dim strread18_64 As String = Nothing
        Dim strread20 As String = Nothing
        Dim strread20_64 As String = Nothing
        Dim OSArchitecture As String = Nothing
        Dim OSLanguage As String = Nothing
        Dim PCdomain As String = Nothing
        Dim PCname As String = Nothing
        Dim PCPartOfDomain As String = Nothing
        Dim PCManufacturer As String = Nothing
        Dim PCModel As String = Nothing
        Dim PCSystemType As String = Nothing
        Dim PCTotalPhysicalMemory As String = Nothing
        Dim PCUsername As String = Nothing
        Dim PCWorkgroup As String = Nothing
        Dim sActiveName As String = Nothing
        Dim KeyboardLayout As String = Nothing
        Dim dtmInstallDate As DateTime = Nothing
        Dim OSname As String = Nothing
        Dim EncryptionLevel As String = Nothing
        Dim ChassisType As String = Nothing
        Dim ProcessorName As String = Nothing


        DataGridViewDetails.Rows.Clear()


        If PCnameFordetails.Text <> "" Then

            Dim objManagementScope2 As ManagementScope
            Dim options2 As ConnectionOptions
            options2 = New ConnectionOptions()
            Dim computerconnect2 As String = "\\" & txtpcname & "\root\cimv2"
            options2.Username = username
            options2.Password = password
            options2.Timeout = TimeSpan.FromSeconds(30)
            options2.Authority = "NTLMDOMAIN:" & domain
            options2.Authentication = AuthenticationLevel.PacketPrivacy
            objManagementScope2 = New ManagementScope(computerconnect2, options2)
            If objManagementScope2.IsConnected = True Then
            Else
                objManagementScope2.Connect()
            End If

            Dim QueryOptions = New EnumerationOptions
            QueryOptions.Timeout = New TimeSpan(0, 0, 10)
            Dim query2 As New SelectQuery("SELECT * FROM Win32_OperatingSystem")
            Dim searcher2 As New ManagementObjectSearcher(objManagementScope2, query2, QueryOptions)
            For Each mo As ManagementObject In searcher2.[Get]()
                dtmInstallDate = ManagementDateTimeConverter.ToDateTime(CStr(mo("InstallDate")))
                OSArchitecture = mo("OSArchitecture")
                OSLanguage = mo("OSLanguage")
                OSname = mo("Name")
                EncryptionLevel = mo("EncryptionLevel")
            Next

            Dim QueryOptions4 = New EnumerationOptions
            QueryOptions4.Timeout = New TimeSpan(0, 0, 10)
            Dim query4 As New SelectQuery("SELECT * FROM Win32_SystemEnclosure")
            Dim searcher4 As New ManagementObjectSearcher(objManagementScope2, query4, QueryOptions4)
            For Each mo As ManagementObject In searcher4.[Get]()
                ChassisType = mo("ChassisTypes")
            Next

            Dim QueryOptions5 = New EnumerationOptions
            QueryOptions5.Timeout = New TimeSpan(0, 0, 10)
            Dim query5 As New SelectQuery("SELECT * FROM Win32_Processor")
            Dim searcher5 As New ManagementObjectSearcher(objManagementScope2, query5, QueryOptions5)
            For Each mo As ManagementObject In searcher5.[Get]()
                ProcessorName = mo("Name")
            Next

            Dim array1 As Array = Nothing
            array1 = Split(OSname, "|")
            OSname = array1(0).ToString

            Dim QueryOptions3 = New EnumerationOptions
            QueryOptions3.Timeout = New TimeSpan(0, 0, 10)
            Dim query3 As New SelectQuery("SELECT * FROM Win32_ComputerSystem")
            Dim searcher3 As New ManagementObjectSearcher(objManagementScope2, query3, QueryOptions3)
            For Each mo As ManagementObject In searcher3.[Get]()
                PCdomain = mo("Domain").ToString
                PCname = mo("Name").ToString
                PCPartOfDomain = mo("PartOfDomain").ToString
                If PCPartOfDomain = "True" Then
                    PCPartOfDomain = "Yes"
                Else
                    PCPartOfDomain = "No"
                End If
                PCManufacturer = mo("Manufacturer").ToString
                PCModel = mo("Model").ToString
                PCSystemType = mo("SystemType").ToString
                PCTotalPhysicalMemory = mo("TotalPhysicalMemory").ToString
                PCUsername = mo("Username").ToString
                PCWorkgroup = mo("Workgroup").ToString
            Next

            Dim strStringValue As String = ""
            Dim strSubKeyName As String
            Dim objManagementScope As ManagementScope = Nothing
            Dim objManagementClass As ManagementClass = Nothing
            Dim objManagementBaseObject As ManagementBaseObject = Nothing
            Dim intRegistryHive As Microsoft.Win32.RegistryHive
            intRegistryHive = Microsoft.Win32.RegistryHive.LocalMachine
            Dim options As ConnectionOptions
            options = New ConnectionOptions()
            Dim computerconnect As String = "\\" & txtpcname & "\root\DEFAULT"
            options.Username = txtusername
            options.Password = txtpassword
            options.Timeout = TimeSpan.FromSeconds(30)
            options.Authority = "NTLMDOMAIN:" & txtdomain
            options.Authentication = AuthenticationLevel.PacketPrivacy
            objManagementScope = New ManagementScope(computerconnect, options)
            If objManagementScope.IsConnected = True Then
            Else
                objManagementScope.Connect()
            End If

            objManagementClass = New ManagementClass("StdRegProv")

            With objManagementClass
                .Scope = objManagementScope
                objManagementBaseObject = .GetMethodParameters("GetStringValue")
                Dim OutParams As ManagementBaseObject

                With objManagementBaseObject
                    .SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                    .SetPropertyValue("sSubKeyName", "SOFTWARE\Microsoft\Windows NT\CurrentVersion")
                    .SetPropertyValue("sValueName", "CSDVersion")
                End With
                OutParams = .InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                strRead2 = CType(OutParams("sValue"), String)

                If strRead2 = Nothing Then
                    With objManagementBaseObject
                        .SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                        .SetPropertyValue("sSubKeyName", "SOFTWARE\Microsoft\Windows NT\CurrentVersion\Update\TargetingInfo\Installed\Client.OS.rs2.amd64")
                        .SetPropertyValue("sValueName", "Version")
                    End With
                    OutParams = .InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                    strRead2 = CType(OutParams("sValue"), String)
                End If

                If strRead2 = Nothing Then
                    With objManagementBaseObject
                        .SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                        .SetPropertyValue("sSubKeyName", "SOFTWARE\Microsoft\Windows NT\CurrentVersion\Update\TargetingInfo\Installed\Server.OS.amd64")
                        .SetPropertyValue("sValueName", "Version")
                    End With
                    OutParams = .InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                    strRead2 = CType(OutParams("sValue"), String)
                End If

                With objManagementBaseObject
                    .SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                    .SetPropertyValue("sSubKeyName", "SYSTEM\CurrentControlSet\Control\Session Manager\Environment")
                    .SetPropertyValue("sValueName", "PROCESSOR_ARCHITECTURE")
                End With
                OutParams = .InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                strRead3 = CType(OutParams("sValue"), String)

                With objManagementBaseObject
                    .SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                    .SetPropertyValue("sSubKeyName", "SOFTWARE\Microsoft\Windows\CurrentVersion\Group Policy\State\Machine")
                    .SetPropertyValue("sValueName", "Site-Name")
                End With
                OutParams = .InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                strRead5 = CType(OutParams("sValue"), String)

                With objManagementBaseObject
                    .SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                    .SetPropertyValue("sSubKeyName", "SYSTEM\CurrentControlSet\Services\Netlogon\Parameters")
                    .SetPropertyValue("sValueName", "DynamicSiteName")
                End With
                OutParams = .InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                strRead6 = CType(OutParams("sValue"), String)

                With objManagementBaseObject
                    .SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                    .SetPropertyValue("sSubKeyName", "SOFTWARE\Microsoft\Internet Explorer")
                    .SetPropertyValue("sValueName", "svcVersion")
                End With
                OutParams = .InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                strread18 = CType(OutParams("sValue"), String)
                If strread18 = Nothing Then
                    With objManagementBaseObject
                        .SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                        .SetPropertyValue("sSubKeyName", "SOFTWARE\Microsoft\Internet Explorer")
                        .SetPropertyValue("sValueName", "Version")
                    End With
                    OutParams = .InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                    strread18 = CType(OutParams("sValue"), String)
                End If

                With objManagementBaseObject
                    .SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                    .SetPropertyValue("sSubKeyName", "SOFTWARE\Wow6432Node\Microsoft\Internet Explorer")
                    .SetPropertyValue("sValueName", "svcVersion")
                End With
                OutParams = .InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                strread18_64 = CType(OutParams("sValue"), String)
                If strread18_64 = Nothing Then
                    With objManagementBaseObject
                        .SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                        .SetPropertyValue("sSubKeyName", "SOFTWARE\Wow6432Node\Microsoft\Internet Explorer")
                        .SetPropertyValue("sValueName", "Version")
                    End With
                    OutParams = .InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                    strread18_64 = CType(OutParams("sValue"), String)
                End If

                With objManagementBaseObject
                    .SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                    .SetPropertyValue("sSubKeyName", "SOFTWARE\Classes\CLSID\{08B0E5C0-4FCB-11CF-AAA5-00401C608501}\TreatAs")
                    .SetPropertyValue("sValueName", "")
                End With
                OutParams = .InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                strread20 = CType(OutParams("sValue"), String)
                If strread20 = "{8AD9C840-044E-11D1-B3E9-00805F499D93}" Then
                    With objManagementBaseObject
                        .SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                        .SetPropertyValue("sSubKeyName", "SOFTWARE\Classes\CLSID\{8AD9C840-044E-11D1-B3E9-00805F499D93}")
                        .SetPropertyValue("sValueName", "")
                    End With
                    OutParams = .InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                    strread20 = CType(OutParams("sValue"), String)
                Else
                    strread20 = strread20.Replace("{CAFEEFAC-", "")
                    strread20 = strread20.Replace("-ABCDEFFEDCBB}", "")
                End If

                With objManagementBaseObject
                    .SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                    .SetPropertyValue("sSubKeyName", "SOFTWARE\Wow6432Node\Classes\CLSID\{08B0E5C0-4FCB-11CF-AAA5-00401C608501}\TreatAs")
                    .SetPropertyValue("sValueName", "")
                End With
                OutParams = .InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                strread20_64 = CType(OutParams("sValue"), String)
                If strread20_64 = "{8AD9C840-044E-11D1-B3E9-00805F499D93}" Then
                    With objManagementBaseObject
                        .SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                        .SetPropertyValue("sSubKeyName", "SOFTWARE\Wow6432Node\Classes\CLSID\{8AD9C840-044E-11D1-B3E9-00805F499D93}")
                        .SetPropertyValue("sValueName", "")
                    End With
                    OutParams = .InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                    strread20_64 = CType(OutParams("sValue"), String)
                Else
                    strread20_64 = strread20_64.Replace("{CAFEEFAC-", "")
                    strread20_64 = strread20_64.Replace("-ABCDEFFEDCBB}", "")
                End If

                With objManagementBaseObject
                    .SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                    .SetPropertyValue("sSubKeyName", "SYSTEM\CurrentControlSet\Services\scomc\Parameters")
                    .SetPropertyValue("sValueName", "Servers")
                End With
                OutParams = .InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                Lumensions = CType(OutParams("sValue"), String)

            End With

            DataGridViewDetails.Rows.Add("Name", PCname)
            DataGridViewDetails.Rows.Add("Part of a Domain", PCPartOfDomain)
            DataGridViewDetails.Rows.Add("Domain", PCdomain)
            DataGridViewDetails.Rows.Add("Workgroup", PCWorkgroup)
            DataGridViewDetails.Rows.Add("GPO Site Name", strRead5)
            DataGridViewDetails.Rows.Add("Netlogon Site Name", strRead6)
            DataGridViewDetails.Rows.Add("", "")
            DataGridViewDetails.Rows.Add("Product Name", OSname)
            DataGridViewDetails.Rows.Add("Version", strRead2)
            DataGridViewDetails.Rows.Add("System Type", PCSystemType)
            DataGridViewDetails.Rows.Add("EncryptionLevel", EncryptionLevel)
            DataGridViewDetails.Rows.Add("Model", PCModel)
            DataGridViewDetails.Rows.Add("Processor Name", ProcessorName)
            DataGridViewDetails.Rows.Add("Processor Architecture", strRead3)
            DataGridViewDetails.Rows.Add("OS Architecture", OSArchitecture)
            DataGridViewDetails.Rows.Add("OS Language", OSLanguage)
            DataGridViewDetails.Rows.Add("TotalPhysicalMemory", PCTotalPhysicalMemory)
            DataGridViewDetails.Rows.Add("Manufacturer", PCManufacturer)
            DataGridViewDetails.Rows.Add("", "")
            DataGridViewDetails.Rows.Add("Install Date", dtmInstallDate)
            DataGridViewDetails.Rows.Add("", "")

            If strread18_64 = Nothing Then
                DataGridViewDetails.Rows.Add("Internet Explorer version", strread18)
                DataGridViewDetails.Rows.Add("", "")
            Else
                DataGridViewDetails.Rows.Add("Internet Explorer version", strread18_64)
                DataGridViewDetails.Rows.Add("", "")
            End If
            If strRead3 = "AMD64" Then
                If strread20_64 <> Nothing Then
                    DataGridViewDetails.Rows.Add("32-bit Java version plugged into IE", strread20_64)
                End If
                If strread20 <> Nothing Then
                    DataGridViewDetails.Rows.Add("64-bit Java version plugged into IE", strread20)
                End If
                DataGridViewDetails.Rows.Add("", "")
            Else
                If strread20 <> Nothing Then
                    DataGridViewDetails.Rows.Add("32-bit Java version plugged into IE", strread20)
                    DataGridViewDetails.Rows.Add("", "")
                End If
            End If

            If Lumensions <> Nothing Then
                DataGridViewDetails.Rows.Add("Lumensions Server Properties", Lumensions)
                DataGridViewDetails.Rows.Add("", "")
            End If

            objManagementScope = Nothing
            objManagementScope2 = Nothing
            objManagementBaseObject.Dispose()
            objManagementClass.Dispose()

        End If

    End Sub

    Private Sub Form5_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        Dim response As MsgBoxResult
        response = MsgBox("Do you want to close this application down?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "Confirm")
        If response = MsgBoxResult.Yes Then
            Form1.Dispose()
            Dim pProcess() As Process = System.Diagnostics.Process.GetProcessesByName("RDT.exe")
            For Each p As Process In pProcess
                p.Kill()
            Next
            Dispose()
        ElseIf response = MsgBoxResult.No Then
            e.Cancel = True
            Exit Sub
        End If
    End Sub

    Private Sub Form5_HelpButtonClicked(ByVal sender As Object, ByVal e As CancelEventArgs) Handles MyBase.HelpButtonClicked
        Dim sResult As String
        Dim objShell = CreateObject("Wscript.Shell")
        Dim path2 As String = Directory.GetCurrentDirectory()
        Try
            sResult = objShell.run("help.pdf", 1, False)
        Catch ex As Exception
        End Try
    End Sub


    Private Sub GETADDREMOVE(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)

        Dim strComputerName As String = txtpcname
        Dim strStringValue As String = ""
        Dim strKeyPath As String = "SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\"
        Dim strKeyPath2 As String = "SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\"
        Dim objManagementScope As ManagementScope = Nothing
        Dim objManagementClass As ManagementClass = Nothing
        Dim objManagementBaseObject As ManagementBaseObject = Nothing
        Dim strkey As String
        Dim myKey As String
        Dim myValue As String
        Dim myValue1 As String
        Dim myValue2 As String
        Dim aSubKeys() As String
        Dim intRegistryHive As Microsoft.Win32.RegistryHive
        intRegistryHive = Microsoft.Win32.RegistryHive.LocalMachine

        Dim options As ConnectionOptions
        options = New ConnectionOptions()
        Dim computerconnect As String = "\\" & txtpcname & "\root\DEFAULT"

        options.Username = txtusername
        options.Password = txtpassword
        options.Timeout = TimeSpan.FromSeconds(30)
        options.Authority = "NTLMDOMAIN:" & txtdomain
        options.Authentication = AuthenticationLevel.PacketPrivacy
        objManagementScope = New ManagementScope(computerconnect, options)

        If objManagementScope.IsConnected = True Then
        Else
            Try
                objManagementScope.Connect()
            Catch ex As Exception
                BackgroundWorkerSpinner.CancelAsync()
                MetroProgressBar.Hide()
                PCNAME.Focus()
                MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                Exit Sub
            End Try
        End If

        Try
            objManagementClass = New ManagementClass("stdRegProv")
            objManagementClass.Scope = objManagementScope
            objManagementBaseObject = objManagementClass.GetMethodParameters("EnumKey")
            objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
            objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath)
            aSubKeys = CType(objManagementClass.InvokeMethod("EnumKey", objManagementBaseObject, Nothing).Properties.Item("sNames").Value, String())

            For Each strkey In aSubKeys
                myKey = strkey
                objManagementBaseObject = objManagementClass.GetMethodParameters("GetStringValue")
                objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath & strkey)
                objManagementBaseObject.SetPropertyValue("sValueName", "DisplayName")
                objManagementBaseObject = objManagementClass.InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                myValue = objManagementBaseObject("sValue")

                objManagementBaseObject = objManagementClass.GetMethodParameters("GetStringValue")
                objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath & strkey)
                objManagementBaseObject.SetPropertyValue("sValueName", "DisplayVersion")
                objManagementBaseObject = objManagementClass.InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                myValue1 = objManagementBaseObject("sValue")

                objManagementBaseObject = objManagementClass.GetMethodParameters("GetStringValue")
                objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath & strkey)
                objManagementBaseObject.SetPropertyValue("sValueName", "InstallDate")
                objManagementBaseObject = objManagementClass.InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                myValue2 = objManagementBaseObject("sValue")
                If myValue2 <> "" Then
                    Try
                        myValue2 = DateTime.ParseExact(myValue2, "yyyyMMdd", System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat)
                    Catch ex As Exception
                        'MessageBox.Show(ex.Message)
                    End Try
                End If

                If Not myValue = "" Then
                    Dim MyvalueCompare As Integer = 0
                    Dim MyvalueCompare2 As Integer = 0
                    MyvalueCompare = InStr(myValue, "Security Update", vbTextCompare)
                    MyvalueCompare2 = InStr(myValue, "Update for", vbTextCompare)
                    If MyvalueCompare = 0 Then
                        If MyvalueCompare2 = 0 Then
                            DataGridView1.Rows.Add(myValue, myValue1, myValue2, strkey)
                        End If
                    End If
                End If
            Next
        Catch ex As Exception
            'MessageBox.Show(ex.Message)
        End Try
        Try
            objManagementClass = New ManagementClass("stdRegProv")
            objManagementClass.Scope = objManagementScope
            objManagementBaseObject = objManagementClass.GetMethodParameters("EnumKey")
            objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
            objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath2)
            aSubKeys = CType(objManagementClass.InvokeMethod("EnumKey", objManagementBaseObject, Nothing).Properties.Item("sNames").Value, String())

            For Each strkey In aSubKeys
                myKey = strkey
                objManagementBaseObject = objManagementClass.GetMethodParameters("GetStringValue")
                objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath2 & strkey)
                objManagementBaseObject.SetPropertyValue("sValueName", "DisplayName")
                objManagementBaseObject = objManagementClass.InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                myValue = objManagementBaseObject("sValue")

                objManagementBaseObject = objManagementClass.GetMethodParameters("GetStringValue")
                objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath2 & strkey)
                objManagementBaseObject.SetPropertyValue("sValueName", "DisplayVersion")
                objManagementBaseObject = objManagementClass.InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                myValue1 = objManagementBaseObject("sValue")

                objManagementBaseObject = objManagementClass.GetMethodParameters("GetStringValue")
                objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath2 & strkey)
                objManagementBaseObject.SetPropertyValue("sValueName", "InstallDate")
                objManagementBaseObject = objManagementClass.InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                myValue2 = objManagementBaseObject("sValue")
                If myValue2 <> "" Then
                    Try
                        myValue2 = DateTime.ParseExact(myValue2, "yyyyMMdd", System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat)
                    Catch ex As Exception
                        'MessageBox.Show(ex.Message)
                    End Try
                End If

                If Not myValue = "" Then
                    Dim MyvalueCompare As Integer = 0
                    Dim MyvalueCompare2 As Integer = 0
                    MyvalueCompare = InStr(myValue, "Security Update", vbTextCompare)
                    MyvalueCompare2 = InStr(myValue, "Update for", vbTextCompare)
                    If MyvalueCompare = 0 Then
                        If MyvalueCompare2 = 0 Then
                            DataGridView1.Rows.Add(myValue, myValue1, myValue2, strkey)
                        End If
                    End If
                End If
            Next
        Catch ex As Exception
            'MessageBox.Show(ex.Message)
        End Try

        Try
            DataGridView1.Sort(DataGridView1.Columns(0), System.ComponentModel.ListSortDirection.Ascending)
        Catch ex As Exception
        End Try

        objManagementBaseObject.Dispose()
        objManagementClass.Dispose()

        PCNAME.Focus()

    End Sub

    Public Shared Function StrToByteArray(ByVal str As String) As Byte()
        Dim encoding As New System.Text.UTF8Encoding()
        Return encoding.GetBytes(str)
    End Function 'StrToByteArray

    Private Sub GETADDREMOVEPATCHES(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)
        BackgroundWorkerSpinnerStopWorker()

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        UpdatesLabel.Text = Nothing
        UpdatesLabel.Text = "Displaying Windows Updates"
        Try
            Dim options2 As ConnectionOptions
            options2 = New ConnectionOptions()
            Dim computerconnect2 As String = "\\" & txtpcname & "\root\cimv2"
            options2.Username = username
            options2.Password = password
            options2.Timeout = TimeSpan.FromSeconds(30)
            options2.Authority = "NTLMDOMAIN:" & domain
            options2.Authentication = AuthenticationLevel.PacketPrivacy
            Dim msc As ManagementScope = New ManagementScope(computerconnect2, options2)

            Dim QueryOptions = New EnumerationOptions
            QueryOptions.Timeout = New TimeSpan(0, 0, 60)
            Dim query_command As String = "Select * from Win32_QuickFixEngineering"
            Dim select_query As SelectQuery = New SelectQuery(query_command)
            Dim Srch As New ManagementObjectSearcher(msc, select_query, QueryOptions)
            Dim objMgmt As ManagementObject
            Dim HOTFIXID As String = Nothing
            Dim Caption As String = Nothing

            For Each objMgmt In Srch.Get
                Dim s(1) As String
                'ServicePackInEffect = objMgmt.GetPropertyValue("ServicePackInEffect").ToString
                HOTFIXID = objMgmt.GetPropertyValue("HotFixID").ToString
                Caption = objMgmt.GetPropertyValue("Caption")
                If Caption = "" Then
                    Caption = objMgmt.GetPropertyValue("ServicePackInEffect")
                End If
                Dim InstalledOn2 As String = objMgmt.GetPropertyValue("InstalledOn")
                If InstalledOn2 <> "" Then

                    Dim array1 As Array = Nothing
                    array1 = Split(InstalledOn2, "/")


                    'InstalledOn2 = String.Join(" / ", array1)
                    InstalledOn2 = array1(1).ToString & " / " & array1(0).ToString & " / " & array1(2).ToString

                End If


                If HOTFIXID <> "File 1" Then
                    DataGridView10.Rows.Add(objMgmt.GetPropertyValue("HotFixID"), InstalledOn2, objMgmt.GetPropertyValue("Description"), Caption)
                End If

            Next

            msc = Nothing

        Catch ex As Exception
        End Try

        Try
            DataGridView10.Sort(DataGridView10.Columns(0), System.ComponentModel.ListSortDirection.Ascending)
        Catch ex As Exception
        End Try

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
        PCNAME.Focus()

    End Sub

    Private Sub BrowseAppslogs_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BrowseAppslogs.Click
        If MachineName = "" Then
            Exit Sub
        End If

        Dim strUsername As String
        Dim strPassword As String
        strUsername = domain & "\" & username
        strPassword = password


        Dim oNet = CreateObject("WScript.Network")
        Try
            oNet.RemoveNetworkDrive("\\" & txtpcname & "\ipc$", True, False)
            oNet.RemoveNetworkDrive("\\" & txtpcname & "\admin$", True, False)
        Catch
        End Try
        oNet.MapNetworkDrive("", "\\" & txtpcname & "\ipc$", False, strUsername, strPassword)

        Try
            Dim path As String
            path = "\\" & txtpcname & "\C$"
            Dim objShell = CreateObject("Wscript.Shell")
            Dim Process = 0
            Process = objShell.run(path)
            Dim LoopCount = 0
            Dim timeout = 1
            Do 'control loop
                Thread.Sleep(1000)
                LoopCount = LoopCount + 1
            Loop Until (Process.Status <> 0) Or (LoopCount > timeout * 10)
        Catch ex As Exception
        End Try
        Try
            ' dismount the previously mounted secure channel
            oNet.RemoveNetworkDrive("\\" & txtpcname & "\ipc$", True, False)
        Catch ex As Exception
        End Try

    End Sub

    Public Function MapDriveAdmin(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String) As Boolean
        Dim nr As NETRESOURCE
        Dim strUsername As String
        Dim strPassword As String
        strUsername = domain & "\" & username
        strPassword = password

        Try
            nr = New NETRESOURCE
            nr.lpRemoteName = "\\" & txtpcname & "\Admin$"
            nr.lpLocalName = Nothing
            nr.dwType = RESOURCETYPE_DISK

            Dim result As Integer
            result = WNetAddConnection2(nr, strPassword, strUsername, 0)

            If result = 0 Then
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
        End Try
    End Function

    Public Function MapDriveAdminRemove(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String) As Boolean
        Dim strUsername As String
        Dim strPassword As String
        strUsername = domain & "\" & username
        strPassword = password

        Dim result As Integer
        result = WNetCancelConnection("\\" & txtpcname & "\Ipc$", 0, True)
        result = WNetCancelConnection("\\" & txtpcname & "\Admin$", 0, True)

        If result = 0 Then
            Return True
        Else
            Return False
        End If

    End Function

    Private Sub DataGridView1_CellClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        Dim x As String
        x = DataGridView1.CurrentRow.Cells.Item(3).Value
        TextBox1.Text = "MSIEXEC.EXE /x " & x & " REBOOT=REALLYSUPPRESS /qn /l*v c:\windows\installer\" & x & "_Remove.log"
    End Sub

    Private Sub SDList1_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles SDList1.SelectedIndexChanged
        Dim x As String
        x = SDList1.SelectedItem.ToString
        SDBOXFolder.Text = x

        SDList1Files.Items.Clear()

        Try
            MapDriveAdmin(username, password, domain, txtpcname)

            Dim Array() As String = Nothing
            Dim fileout As String = ""
            Dim files() As String = IO.Directory.GetFiles(SDListDirectory.Text & "\" & SDList1.SelectedItem.ToString)
            For Each file As String In files
                Try
                    Array = Split(file, SDListDirectory.Text & "\" & SDList1.SelectedItem.ToString & "\")
                Catch ex As Exception
                End Try
                fileout = Array.GetValue(1)
                SDList1Files.Items.Add(fileout)
            Next

            MapDriveAdminRemove(username, password, domain, txtpcname)

        Catch ex As Exception
        End Try
    End Sub

    Private Sub SDList1Files_SelectedIndexChanged(sender As Object, e As EventArgs) Handles SDList1Files.SelectedIndexChanged
        Dim x As String
        x = SDList1Files.SelectedItem.ToString
        SDBoxFile.Text = x
        REMCOMPackageText.Text = x
        PSEXECUTEPackageText.Text = x
    End Sub


    Private Sub GETpcDETAILSnow_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GETpcDETAILSnow.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Try
            GETSTRVALUES(username, password, domain, txtpcname)
        Catch
        End Try

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
        PCNAME.Focus()
        'TabControl1.SelectTab(1)
    End Sub



    Private Sub RDP_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RDP.Click
        If MachineName = "" Then
            Exit Sub
        End If

        Dim strUsername As String
        Dim strPassword As String
        strUsername = domain & "\" & username
        strPassword = password

        Dim oNet = CreateObject("WScript.Network")
        Try
            oNet.RemoveNetworkDrive("\\" & txtpcname & "\ipc$", True, False)
            oNet.RemoveNetworkDrive("\\" & txtpcname & "\admin$", True, False)
        Catch
        End Try
        oNet.MapNetworkDrive("", "\\" & txtpcname & "\ipc$", False, strUsername, strPassword)

        Try
            Dim path As String
            path = "mstsc /v:" & txtpcname & " /prompt /admin"
            Dim objShell = CreateObject("Wscript.Shell")
            objShell.run(path)
        Catch ex As Exception
        End Try
        Try
            ' dismount the previously mounted secure channel
            oNet.RemoveNetworkDrive("\\" & txtpcname & "\ipc$", True, False)
        Catch ex As Exception
        End Try

        PCNAME.Focus()

    End Sub


    Public Sub Registry_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOpenReg.Click
        If MachineName = "" Then
            Exit Sub
        End If

        Dim strUsername As String
        Dim strPassword As String
        strUsername = domain & "\" & username
        strPassword = password

        Dim oNet = CreateObject("WScript.Network")
        Try
            oNet.RemoveNetworkDrive("\\" & txtpcname & "\ipc$", True, False)
            oNet.RemoveNetworkDrive("\\" & txtpcname & "\admin$", True, False)
        Catch
        End Try
        oNet.MapNetworkDrive("", "\\" & txtpcname & "\ipc$", False, strUsername, strPassword)

        Try
            Dim path As String
            path = "Regedit.exe"
            Dim objShell = CreateObject("Wscript.Shell")
            objShell.run(path)
        Catch ex As Exception
        End Try
        Try
            ' dismount the previously mounted secure channel
            oNet.RemoveNetworkDrive("\\" & txtpcname & "\ipc$", True, False)
        Catch ex As Exception
        End Try

        PCNAME.Focus()

    End Sub


    Private Sub SCCMJOBCHECK(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)
        Dim wmi_out As ManagementBaseObject
        Dim objManagementScope As ManagementScope
        Dim objManagementClass As ManagementClass = Nothing
        Dim objManagementBaseObject As ManagementBaseObject = Nothing
        Dim retValue As Integer
        Dim Command As String = "WMIC /node:" & txtpcname & " /namespace:\\root\ccm path sms_client CALL TriggerSchedule " & Chr(34) & "{00000000-0000-0000-0000-000000000001}" & Chr(34)
        Try

            Dim options As ConnectionOptions
            options = New ConnectionOptions()
            Dim computerconnect As String = "\\" & txtpcname & "\root\cimv2:Win32_Process"

            options.Username = txtusername
            options.Password = txtpassword
            options.Timeout = TimeSpan.FromSeconds(30)
            options.Authority = "NTLMDOMAIN:" & txtdomain
            options.Authentication = AuthenticationLevel.PacketPrivacy
            objManagementScope = New ManagementScope(computerconnect, options)

            If objManagementScope.IsConnected = True Then
            Else
                Try
                    objManagementScope.Connect()
                Catch ex As Exception
                    MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                    PCNAME.Focus()
                    Exit Sub
                End Try
            End If

            objManagementClass = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
            objManagementClass.Scope = objManagementScope

            objManagementBaseObject = objManagementClass.GetMethodParameters("Create")
            objManagementBaseObject.SetPropertyValue("CommandLine", Command)
            wmi_out = objManagementClass.InvokeMethod("Create", objManagementBaseObject, Nothing)

            'wmi = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
            'wmi_in = wmi.GetMethodParameters("Create")
            'wmi_in("CommandLine") = "cmd /c md c:\temp\temptd"
            'wmi_out = wmi.InvokeMethod("Create", wmi_in, Nothing)

            retValue = Convert.ToInt32(wmi_out("returnValue"))
            Select Case retValue
                Case 0
                    ' Msgbox success!
                Case 2
                    Throw New ApplicationException("Access denied")
                Case 3
                    Throw New ApplicationException("Insufficient privilege")
                Case 8
                    Throw New ApplicationException("Unknown failure")
                Case 9
                    Throw New ApplicationException("Path not found")
                Case 21
                    Throw New ApplicationException("Invalid parameter")
                Case Else
                    Throw New ApplicationException("Unknown return code " & retValue)
            End Select
        Catch ex As Exception
            MsgBox(txtpcname & ": Can't create the process. " & ex.Message)
        End Try
        objManagementScope = Nothing
        objManagementBaseObject.Dispose()
        objManagementClass.Dispose()
    End Sub


    Private Sub GETAPPVASSOC(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        MapDriveAdmin(username, password, domain, txtpcname)

        Dim fullPath As String = "\\" & txtpcname & "\c$\Program Files\RDT"
        Directory.CreateDirectory(fullPath)
        Dim fullPath2 As String = "\\" & txtpcname & "\c$\Program Files\RDT\RDT"
        Directory.CreateDirectory(fullPath2)

        Dim wmi_out As ManagementBaseObject
        Dim objManagementScope As ManagementScope
        Dim objManagementClass As ManagementClass = Nothing
        Dim objManagementBaseObject As ManagementBaseObject = Nothing
        Dim retValue As Integer

        Dim options As ConnectionOptions
        options = New ConnectionOptions()
        Dim computerconnect As String = "\\" & txtpcname & "\root\cimv2:Win32_Process"

        options.Username = username
        options.Password = password
        options.Timeout = TimeSpan.FromSeconds(30)
        options.Authority = "NTLMDOMAIN:" & domain
        options.Authentication = AuthenticationLevel.PacketPrivacy
        objManagementScope = New ManagementScope(computerconnect, options)

        If objManagementScope.IsConnected = True Then
        Else
            Try
                objManagementScope.Connect()
            Catch ex As Exception
                MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                BackgroundWorkerSpinner.CancelAsync()
                MetroProgressBar.Hide()
                PCNAME.Focus()
                Exit Sub
            End Try
        End If

        Try
            objManagementClass = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
            objManagementClass.Scope = objManagementScope
            objManagementBaseObject = objManagementClass.GetMethodParameters("Create")
            objManagementBaseObject.SetPropertyValue("CommandLine", "cmd /c assoc > c:\progra~1\RDT\RDT\ftype.log")
            wmi_out = objManagementClass.InvokeMethod("Create", objManagementBaseObject, Nothing)

            'wmi = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
            'wmi_in = wmi.GetMethodParameters("Create")
            'wmi_in("CommandLine") = "cmd /c md c:\temp\temptd"
            'wmi_out = wmi.InvokeMethod("Create", wmi_in, Nothing)

            retValue = Convert.ToInt32(wmi_out("returnValue"))
            Select Case retValue
                Case 0
                    ' success!
                    Thread.Sleep(3000)
                    Dim sr As New IO.StreamReader("\\" & txtpcname & "\c$\Program Files\RDT\RDT\ftype.log")
                    FileTypes.Items.AddRange(Strings.Split(sr.ReadToEnd(), Constants.vbCrLf))
                    sr.Close()
                Case 2
                    Throw New ApplicationException("Access denied")
                Case 3
                    Throw New ApplicationException("Insufficient privilege")
                Case 8
                    Throw New ApplicationException("Unknown failure")
                Case 9
                    Throw New ApplicationException("Path not found")
                Case 21
                    Throw New ApplicationException("Invalid parameter")
                Case Else
                    Throw New ApplicationException("Unknown return code " & retValue)
            End Select
        Catch ex As Exception
            MsgBox(txtpcname & ": Can't create the process. " & ex.Message)
        End Try

        Dim commandtorun As String = "CMD.EXE /C RD /S /Q " & Chr(34) & "\\" & MachineName & "\c$\Progra~1\RDT" & Chr(34)
        Try
            Dim objShell = CreateObject("Wscript.Shell")
            objShell.run(commandtorun, 0, False)
        Catch ex As Exception
        End Try

        objManagementScope = Nothing
        objManagementBaseObject.Dispose()
        objManagementClass.Dispose()

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()

        MapDriveAdminRemove(username, password, domain, txtpcname)

        PCNAME.Focus()
    End Sub

    Private Sub GETAPPVFTYPE(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        MapDriveAdmin(username, password, domain, txtpcname)

        Dim fullPath As String = "\\" & txtpcname & "\c$\Program Files\RDT"
        Directory.CreateDirectory(fullPath)
        Dim fullPath2 As String = "\\" & txtpcname & "\c$\Program Files\RDT\RDT"
        Directory.CreateDirectory(fullPath2)

        Dim wmi_out As ManagementBaseObject
        Dim objManagementScope As ManagementScope
        Dim objManagementClass As ManagementClass = Nothing
        Dim objManagementBaseObject As ManagementBaseObject = Nothing
        Dim retValue As Integer

        Dim options As ConnectionOptions
        options = New ConnectionOptions()
        Dim computerconnect As String = "\\" & txtpcname & "\root\cimv2:Win32_Process"

        options.Username = username
        options.Password = password
        options.Timeout = TimeSpan.FromSeconds(30)
        options.Authority = "NTLMDOMAIN:" & domain
        options.Authentication = AuthenticationLevel.PacketPrivacy
        objManagementScope = New ManagementScope(computerconnect, options)

        If objManagementScope.IsConnected = True Then
        Else
            Try
                objManagementScope.Connect()
            Catch ex As Exception
                MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                BackgroundWorkerSpinner.CancelAsync()
                MetroProgressBar.Hide()
                PCNAME.Focus()
                Exit Sub
            End Try
        End If

        Try
            objManagementClass = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
            objManagementClass.Scope = objManagementScope
            objManagementBaseObject = objManagementClass.GetMethodParameters("Create")
            objManagementBaseObject.SetPropertyValue("CommandLine", "cmd /c ftype > c:\progra~1\RDT\RDT\ftype.log")
            wmi_out = objManagementClass.InvokeMethod("Create", objManagementBaseObject, Nothing)

            'wmi = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
            'wmi_in = wmi.GetMethodParameters("Create")
            'wmi_in("CommandLine") = "cmd /c md c:\temp\temptd"
            'wmi_out = wmi.InvokeMethod("Create", wmi_in, Nothing)

            retValue = Convert.ToInt32(wmi_out("returnValue"))
            Select Case retValue
                Case 0
                    ' success!
                    Thread.Sleep(3000)
                    Dim sr As New IO.StreamReader("\\" & txtpcname & "\c$\Program Files\RDT\RDT\ftype.log")
                    FileTypes.Items.AddRange(Strings.Split(sr.ReadToEnd(), Constants.vbCrLf))
                    sr.Close()
                Case 2
                    Throw New ApplicationException("Access denied")
                Case 3
                    Throw New ApplicationException("Insufficient privilege")
                Case 8
                    Throw New ApplicationException("Unknown failure")
                Case 9
                    Throw New ApplicationException("Path not found")
                Case 21
                    Throw New ApplicationException("Invalid parameter")
                Case Else
                    Throw New ApplicationException("Unknown return code " & retValue)
            End Select
        Catch ex As Exception
            MsgBox(txtpcname & ": Can't create the process. " & ex.Message)
        End Try

        Dim commandtorun As String = "CMD.EXE /C RD /S /Q " & Chr(34) & "\\" & MachineName & "\c$\Progra~1\RDT" & Chr(34)
        Try
            Dim objShell = CreateObject("Wscript.Shell")
            objShell.run(commandtorun, 0, False)
        Catch ex As Exception
        End Try

        objManagementScope = Nothing
        objManagementBaseObject.Dispose()
        objManagementClass.Dispose()

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()

        MapDriveAdminRemove(username, password, domain, txtpcname)

        PCNAME.Focus()
    End Sub

    Private Sub GroupsTab8_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupsTab8.Enter
        Label60.Text = Host.Text
    End Sub
    Private Sub TabPage31_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PXETab23.Enter
        Label15.Text = Host.Text
    End Sub
    Private Sub SCCMtab16_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SCCMtab16.Enter
        Label34.Text = Host.Text
    End Sub
    Private Sub ServicesTab17_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ServicesTab17.Enter
        Label35.Text = Host.Text
    End Sub
    Private Sub MSITab12_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MSITab12.Enter
        Label23.Text = Host.Text
    End Sub
    Private Sub FtypeTab7_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FtypeTab7.Enter
        Label40.Text = Host.Text
    End Sub
    Private Sub TaskManTab19_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TaskManTab19.Enter
        Label42.Text = Host.Text
    End Sub
    Private Sub instSoftwareTab9_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles instSoftwareTab9.Enter
        Label44.Text = Host.Text
    End Sub
    Private Sub WUtab10_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles WUtab10.Enter
        Label46.Text = Host.Text
    End Sub
    Private Sub DiskTab4_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DiskTab4.Enter
        Label63.Text = Host.Text
    End Sub
    Private Sub NetTab5_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NetTab5.Enter
        Label14.Text = Host.Text
    End Sub
    Private Sub MBSAtab11_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MBSAtab11.Enter
        LabelMBSA1.Text = Host.Text
    End Sub
    Private Sub ExecuteTab6_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExecuteTab6.Enter
        Label19.Text = Host.Text

        Try
            Dim rk As RegistryKey
            Dim skName As String
            Dim sublist As New ArrayList
            Dim serverinlist = 0
            Dim Replacementstring As String

            rk = Registry.CurrentUser.OpenSubKey("Software\RDT\RDTExecuteDirShare", True)

            For Each skName In rk.GetSubKeyNames()

                Replacementstring = skName.Replace("*", "\")

                If SDListDirectory.Items.Contains(Replacementstring) Then

                Else
                    SDListDirectory.Items.Add(Replacementstring)
                End If

            Next skName

        Catch ex As Exception
        End Try

        SDlistpackages.Focus()
    End Sub
    Private Sub ProcessorTab13_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ProcessorTab13.Enter
        Label48.Text = Host.Text
    End Sub
    Private Sub UserTab20_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UserTab20.Enter
        Label193.Text = Host.Text
    End Sub
    Private Sub WIM_OptionalFeatures22_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles WIM_OptionalFeatures22.Enter
        WIM_OptionalFeaturesLabel1.Text = Host.Text
    End Sub
    Private Sub WIM_PnPSignedDriver21_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles WIM_PnPSignedDriver21.Enter
        PnPSignedDriverLabel1.Text = Host.Text
    End Sub
    Private Sub StoreApps18_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StoreApps18.Enter
        Labelstoreapps1.Text = Host.Text
    End Sub
    Private Sub RebootChecker15_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RebootChecker15.Enter
        Label16.Text = Host.Text
    End Sub
    Private Sub Profiles14_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Profiles14.Enter
        LabelProfiles1.Text = Host.Text
    End Sub

    Private Sub GetMSIList_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GetMSIList.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        GETADDREMOVEMSI(username, password, domain, txtpcname)

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
        PCNAME.Focus()
    End Sub
    Private Sub GETADDREMOVEMSI(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)

        Dim strComputerName As String = txtpcname
        Dim strStringValue As String = ""
        Dim strKeyPath As String = "SOFTWARE\Microsoft\Windows\CurrentVersion\Installer\UserData\S-1-5-18\Products\"
        Dim strKeyPath2 As String = "SOFTWARE\WOW6432node\Microsoft\Windows\CurrentVersion\Installer\UserData\S-1-5-18\Products\"
        Dim objManagementScope As ManagementScope = Nothing
        Dim objManagementClass As ManagementClass = Nothing
        Dim objManagementBaseObject As ManagementBaseObject = Nothing
        Dim strkey As String = Nothing
        Dim myKey As String = Nothing
        Dim myValue As String = Nothing
        Dim myValue1 As String = Nothing
        Dim myValueMSI As String = Nothing
        Dim myVersionValue As String = Nothing
        Dim fileName As String
        Dim aSubKeys() As String
        Dim dtCreationDate As DateTime = Nothing
        Dim dtFileVersion As String = Nothing
        Dim intRegistryHive As Microsoft.Win32.RegistryHive
        intRegistryHive = Microsoft.Win32.RegistryHive.LocalMachine

        DataGridView6.Rows.Clear()

        Dim options As ConnectionOptions
        options = New ConnectionOptions()
        Dim computerconnect As String = "\\" & txtpcname & "\root\DEFAULT"

        options.Username = txtusername
        options.Password = txtpassword
        options.Timeout = TimeSpan.FromSeconds(30)
        options.Authority = "NTLMDOMAIN:" & txtdomain
        options.Authentication = AuthenticationLevel.PacketPrivacy
        objManagementScope = New ManagementScope(computerconnect, options)

        If objManagementScope.IsConnected = True Then
        Else
            Try
                objManagementScope.Connect()
            Catch ex As Exception
                MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                Exit Sub
            End Try
        End If
        Try
            objManagementClass = New ManagementClass("stdRegProv")
            objManagementClass.Scope = objManagementScope
            objManagementBaseObject = objManagementClass.GetMethodParameters("EnumKey")
            objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
            objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath)
            aSubKeys = CType(objManagementClass.InvokeMethod("EnumKey", objManagementBaseObject, Nothing).Properties.Item("sNames").Value, String())

            For Each strkey In aSubKeys
                myKey = strkey
                myValue = Nothing
                myVersionValue = Nothing
                myValue1 = Nothing
                dtCreationDate = Nothing

                Try
                    objManagementBaseObject = objManagementClass.GetMethodParameters("GetStringValue")
                    objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                    objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath & strkey & "\InstallProperties")
                    objManagementBaseObject.SetPropertyValue("sValueName", "DisplayName")
                    objManagementBaseObject = objManagementClass.InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                    myValue = objManagementBaseObject("sValue")
                Catch ex As Exception
                    'MessageBox.Show(ex.Message)
                End Try

                Try
                    objManagementBaseObject = objManagementClass.GetMethodParameters("GetStringValue")
                    objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                    objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath & strkey & "\InstallProperties")
                    objManagementBaseObject.SetPropertyValue("sValueName", "DisplayVersion")
                    objManagementBaseObject = objManagementClass.InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                    myVersionValue = objManagementBaseObject("sValue")
                Catch ex As Exception
                    'MessageBox.Show(ex.Message)
                End Try

                Try
                    objManagementBaseObject = objManagementClass.GetMethodParameters("GetStringValue")
                    objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                    objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath & strkey & "\InstallProperties")
                    objManagementBaseObject.SetPropertyValue("sValueName", "LocalPackage")
                    objManagementBaseObject = objManagementClass.InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                    myValue1 = objManagementBaseObject("sValue")
                    myValueMSI = myValue1
                    myValueMSI = myValueMSI.Replace("C:", "C$")

                    fileName = "\\" & txtpcname & "\" & myValueMSI

                    If Dir(fileName) <> "" Then
                        dtCreationDate = File.GetCreationTime(fileName)
                        dtFileVersion = FileVersionInfo.GetVersionInfo(fileName).FileVersion
                    End If

                Catch ex As Exception
                    'MessageBox.Show(ex.Message)
                End Try

                Try
                    If myValue <> "" Then
                        DataGridView6.Rows.Add(myValue, myVersionValue, myValue1, dtCreationDate)
                    End If
                Catch ex As Exception
                    'MessageBox.Show(ex.Message)
                End Try
            Next

        Catch ex As Exception
            'MessageBox.Show(ex.Message)
        End Try


        Try
            objManagementClass = New ManagementClass("stdRegProv")
            objManagementClass.Scope = objManagementScope
            objManagementBaseObject = objManagementClass.GetMethodParameters("EnumKey")
            objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
            objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath2)
            aSubKeys = CType(objManagementClass.InvokeMethod("EnumKey", objManagementBaseObject, Nothing).Properties.Item("sNames").Value, String())

            For Each strkey In aSubKeys
                myKey = strkey
                myValue = Nothing
                myVersionValue = Nothing
                myValue1 = Nothing
                dtCreationDate = Nothing

                Try
                    objManagementBaseObject = objManagementClass.GetMethodParameters("GetStringValue")
                    objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                    objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath2 & strkey & "\InstallProperties")
                    objManagementBaseObject.SetPropertyValue("sValueName", "DisplayName")
                    objManagementBaseObject = objManagementClass.InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                    myValue = objManagementBaseObject("sValue")
                Catch ex As Exception
                    'MessageBox.Show(ex.Message)
                End Try

                Try
                    objManagementBaseObject = objManagementClass.GetMethodParameters("GetStringValue")
                    objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                    objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath2 & strkey & "\InstallProperties")
                    objManagementBaseObject.SetPropertyValue("sValueName", "DisplayVersion")
                    objManagementBaseObject = objManagementClass.InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                    myVersionValue = objManagementBaseObject("sValue")
                Catch ex As Exception
                    'MessageBox.Show(ex.Message)
                End Try

                Try
                    objManagementBaseObject = objManagementClass.GetMethodParameters("GetStringValue")
                    objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                    objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath2 & strkey & "\InstallProperties")
                    objManagementBaseObject.SetPropertyValue("sValueName", "LocalPackage")
                    objManagementBaseObject = objManagementClass.InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                    myValue1 = objManagementBaseObject("sValue")
                    myValueMSI = myValue1
                    myValueMSI = myValueMSI.Replace("C:", "C$")
                    fileName = "\\" & txtpcname & "\" & myValueMSI

                    If Dir(fileName) <> "" Then
                        dtCreationDate = File.GetCreationTime(fileName)
                    End If
                Catch ex As Exception
                    'MessageBox.Show(ex.Message)
                End Try

                Try
                    If myValue <> "" Then
                        DataGridView6.Rows.Add(myValue, myVersionValue, myValue1, dtCreationDate)
                    End If
                Catch ex As Exception
                    'MessageBox.Show(ex.Message)
                End Try
            Next

        Catch ex As Exception
            'MessageBox.Show(ex.Message)
        End Try

        Try
            DataGridView6.Sort(DataGridView6.Columns(0), System.ComponentModel.ListSortDirection.Ascending)
        Catch ex As Exception
        End Try
        objManagementScope = Nothing
        objManagementBaseObject.Dispose()
        objManagementClass.Dispose()

    End Sub

    Private Sub MSIZAPbutton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MSIZAPbutton.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        Dim response As MsgBoxResult
        response = MsgBox("Are you sure you want to run the command: " & TextBoxMSIZAP.Text & " ?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "Confirm")
        If response = MsgBoxResult.Yes Then
            Dim wmi_out As ManagementBaseObject
            Dim objManagementScope As ManagementScope
            Dim objManagementClass As ManagementClass = Nothing
            Dim objManagementBaseObject As ManagementBaseObject = Nothing
            Dim retValue As Integer
            Dim Command As String = TextBoxMSIZAP.Text
            Try
                If TextBoxMSIZAP.Text = "" Then
                    Exit Sub
                End If
                Dim options As ConnectionOptions
                options = New ConnectionOptions()
                Dim computerconnect As String = "\\" & txtpcname & "\root\cimv2:Win32_Process"

                options.Username = username
                options.Password = password
                options.Timeout = TimeSpan.FromSeconds(30)
                options.Authority = "NTLMDOMAIN:" & domain
                options.Authentication = AuthenticationLevel.PacketPrivacy
                objManagementScope = New ManagementScope(computerconnect, options)

                If objManagementScope.IsConnected = True Then
                Else
                    Try
                        objManagementScope.Connect()
                    Catch ex As Exception
                        MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                        Exit Sub
                    End Try
                End If

                objManagementClass = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
                objManagementClass.Scope = objManagementScope

                objManagementBaseObject = objManagementClass.GetMethodParameters("Create")
                objManagementBaseObject.SetPropertyValue("CommandLine", Command)
                wmi_out = objManagementClass.InvokeMethod("Create", objManagementBaseObject, Nothing)

                'wmi = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
                'wmi_in = wmi.GetMethodParameters("Create")
                'wmi_in("CommandLine") = "cmd /c md c:\temp\temptd"
                'wmi_out = wmi.InvokeMethod("Create", wmi_in, Nothing)

                retValue = Convert.ToInt32(wmi_out("returnValue"))
                Select Case retValue
                    Case 0
                        ' success!
                        MsgBox(TextBoxMSIZAP.Text & " has run on pc " & txtpcname & " Successfully!")
                    Case 2
                        Throw New ApplicationException("Access denied")
                    Case 3
                        Throw New ApplicationException("Insufficient privilege")
                    Case 8
                        Throw New ApplicationException("Unknown failure")
                    Case 9
                        Throw New ApplicationException("Path not found")
                    Case 21
                        Throw New ApplicationException("Invalid parameter")
                    Case Else
                        Throw New ApplicationException("Unknown return code " & retValue)
                End Select
            Catch ex As Exception
                MsgBox(txtpcname & ": Can't create the process. " & ex.Message)
            End Try
            objManagementScope = Nothing
            objManagementBaseObject.Dispose()
            objManagementClass.Dispose()

        ElseIf response = MsgBoxResult.No Then
            Exit Sub
        End If

    End Sub
    Private Sub DataGridView6_CellClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView6.CellClick
        Dim x As String
        x = DataGridView6.CurrentRow.Cells.Item(2).Value
        TextBoxMSIZAP.Text = "Msiexec /x " & x & " /L*V C:\Windows\Installer\MSI_Removal.log /qn REBOOT=REALLYSUPPRESS"
    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        MapDriveAdmin(username, password, domain, txtpcname)

        Try
            Dim path As String
            path = "\\" & txtpcname & "\Admin$\system32\CCM\logs"
            Dim objShell = CreateObject("Wscript.Shell")
            objShell.run(path)
        Catch ex As Exception
        End Try
        Try
            Dim path As String
            path = "\\" & txtpcname & "\Admin$\SYSWOW64\CCM\logs"
            Dim objShell = CreateObject("Wscript.Shell")
            objShell.run(path)
        Catch ex1 As Exception
        End Try
        Try
            Dim path As String
            path = "\\" & txtpcname & "\Admin$\CCM\logs"
            Dim objShell = CreateObject("Wscript.Shell")
            objShell.run(path)
        Catch ex As Exception
        End Try

        MapDriveAdminRemove(username, password, domain, txtpcname)

        PCNAME.Focus()

    End Sub

    Private Sub GetServices_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GetServices.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Dim ServiceDisplayName As String = Nothing
        Dim ServiceName As String = Nothing
        Dim ServiceState As String = Nothing
        Dim ServiceStartMode As String = Nothing

        DataGridView7.Rows.Clear()

        Dim objManagementScope As ManagementScope
        Dim options As ConnectionOptions
        options = New ConnectionOptions()
        Dim computerconnect As String = "\\" & txtpcname & "\root\cimv2"

        options.Username = username
        options.Password = password
        options.Timeout = TimeSpan.FromSeconds(30)
        options.Authority = "NTLMDOMAIN:" & domain
        options.Authentication = AuthenticationLevel.PacketPrivacy
        objManagementScope = New ManagementScope(computerconnect, options)

        If objManagementScope.IsConnected = True Then
        Else
            Try
                objManagementScope.Connect()
            Catch ex As Exception
                MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                BackgroundWorkerSpinner.CancelAsync()
                MetroProgressBar.Hide()
                PCNAME.Focus()
                Exit Sub
            End Try
        End If

        Try
            Dim QueryOptions = New EnumerationOptions
            QueryOptions.Timeout = New TimeSpan(0, 0, 10)
            Dim query As New SelectQuery("SELECT * FROM Win32_Service")
            Dim searcher As New ManagementObjectSearcher(objManagementScope, query, QueryOptions)
            For Each mo As ManagementObject In searcher.[Get]()
                ServiceDisplayName = mo("DisplayName")
                ServiceName = mo("Name")
                ServiceState = mo("State")
                ServiceStartMode = mo("StartMode")
                DataGridView7.Rows.Add(ServiceName, ServiceDisplayName, ServiceState, ServiceStartMode)
            Next
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

        objManagementScope = Nothing

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
        PCNAME.Focus()
    End Sub

    Private Sub StartService_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StartService.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Try
            Dim objManagementScope As ManagementScope
            Dim options As ConnectionOptions
            options = New ConnectionOptions()
            Dim computerconnect As String = "\\" & txtpcname & "\root\cimv2"

            options.Username = username
            options.Password = password
            options.Timeout = TimeSpan.FromSeconds(30)
            options.Authority = "NTLMDOMAIN:" & domain
            options.Authentication = AuthenticationLevel.PacketPrivacy
            objManagementScope = New ManagementScope(computerconnect, options)

            If objManagementScope.IsConnected = True Then
            Else
                Try
                    objManagementScope.Connect()
                Catch ex As Exception
                    BackgroundWorkerSpinner.CancelAsync()
                    MetroProgressBar.Hide()
                    PCNAME.Focus()
                    MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                    Exit Sub
                End Try
            End If

            Dim QueryOptions = New EnumerationOptions
            QueryOptions.Timeout = New TimeSpan(0, 0, 10)
            Dim query As New SelectQuery("SELECT * FROM Win32_Service Where Name = " & Chr(34) & ServiceNameSelected.Text & Chr(34) & " ")
            Dim searcher As New ManagementObjectSearcher(objManagementScope, query, QueryOptions)
            Dim args As Object = Nothing
            Try
                For Each mo As ManagementObject In searcher.[Get]()
                    mo.InvokeMethod("StartService", args)
                Next
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
            objManagementScope = Nothing
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        GetServices2()

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
        PCNAME.Focus()

    End Sub

    Private Sub StopService_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StopService.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Try
            Dim objManagementScope As ManagementScope

            Dim options As ConnectionOptions
            options = New ConnectionOptions()
            Dim computerconnect As String = "\\" & txtpcname & "\root\cimv2"

            options.Username = username
            options.Password = password
            options.Timeout = TimeSpan.FromSeconds(30)
            options.Authority = "NTLMDOMAIN:" & domain
            options.Authentication = AuthenticationLevel.PacketPrivacy
            objManagementScope = New ManagementScope(computerconnect, options)

            If objManagementScope.IsConnected = True Then
            Else
                Try
                    objManagementScope.Connect()
                Catch ex As Exception
                    BackgroundWorkerSpinner.CancelAsync()
                    MetroProgressBar.Hide()
                    PCNAME.Focus()
                    MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                    Exit Sub
                End Try
            End If

            Dim QueryOptions = New EnumerationOptions
            QueryOptions.Timeout = New TimeSpan(0, 0, 10)
            Dim query As New SelectQuery("SELECT * FROM Win32_Service Where Name = " & Chr(34) & ServiceNameSelected.Text & Chr(34) & " ")
            Dim searcher As New ManagementObjectSearcher(objManagementScope, query, QueryOptions)
            Dim args As Object = Nothing
            Try
                For Each mo As ManagementObject In searcher.[Get]()
                    mo.InvokeMethod("StopService", args)
                Next
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
            objManagementScope = Nothing
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

        GetServices2()

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
        PCNAME.Focus()
    End Sub

    Private Sub DeleteServiceButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeleteServiceButton.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Try

            Dim objManagementScope As ManagementScope

            Dim options As ConnectionOptions
            options = New ConnectionOptions()
            Dim computerconnect As String = "\\" & txtpcname & "\root\cimv2"

            options.Username = username
            options.Password = password
            options.Timeout = TimeSpan.FromSeconds(30)
            options.Authority = "NTLMDOMAIN:" & domain
            options.Authentication = AuthenticationLevel.PacketPrivacy
            objManagementScope = New ManagementScope(computerconnect, options)

            If objManagementScope.IsConnected = True Then
            Else
                Try
                    objManagementScope.Connect()
                Catch ex As Exception
                    BackgroundWorkerSpinner.CancelAsync()
                    MetroProgressBar.Hide()
                    PCNAME.Focus()
                    MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                    Exit Sub
                End Try
            End If

            Dim QueryOptions = New EnumerationOptions
            QueryOptions.Timeout = New TimeSpan(0, 0, 10)
            Dim query As New SelectQuery("SELECT * FROM Win32_Service Where Name = " & Chr(34) & ServiceNameSelected.Text & Chr(34) & " ")
            Dim searcher As New ManagementObjectSearcher(objManagementScope, query, QueryOptions)
            Dim args As Object = Nothing
            Try
                For Each mo As ManagementObject In searcher.[Get]()
                    mo.InvokeMethod("StopService", args)
                Next
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

        Try
            Dim objManagementScope As ManagementScope
            Dim options As ConnectionOptions
            options = New ConnectionOptions()
            Dim computerconnect As String = "\\" & txtpcname & "\root\cimv2"

            options.Username = username
            options.Password = password
            options.Timeout = TimeSpan.FromSeconds(30)
            options.Authority = "NTLMDOMAIN:" & domain
            options.Authentication = AuthenticationLevel.PacketPrivacy
            objManagementScope = New ManagementScope(computerconnect, options)

            If objManagementScope.IsConnected = True Then
            Else
                Try
                    objManagementScope.Connect()
                Catch ex As Exception
                    MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                    BackgroundWorkerSpinner.CancelAsync()
                    MetroProgressBar.Hide()
                    PCNAME.Focus()
                    Exit Sub
                End Try
            End If

            Dim QueryOptions = New EnumerationOptions
            QueryOptions.Timeout = New TimeSpan(0, 0, 10)
            Dim query As New SelectQuery("SELECT * FROM Win32_Service Where Name = " & Chr(34) & ServiceNameSelected.Text & Chr(34) & " ")
            Dim searcher As New ManagementObjectSearcher(objManagementScope, query, QueryOptions)
            Dim args As Object = Nothing
            Try
                For Each mo As ManagementObject In searcher.[Get]()
                    mo.InvokeMethod("Delete", args)
                Next
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
            objManagementScope = Nothing
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        GetServices2()

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
        PCNAME.Focus()
    End Sub

    Private Sub SetServiceStartAutomatic_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SetServiceStartAutomatic.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Try
            Dim objManagementScope As ManagementScope
            Dim objManagementClass As ManagementClass = Nothing
            Dim objManagementBaseObject As ManagementBaseObject = Nothing

            Dim options As ConnectionOptions
            options = New ConnectionOptions()
            Dim computerconnect As String = "\\" & txtpcname & "\root\cimv2"

            options.Username = username
            options.Password = password
            options.Timeout = TimeSpan.FromSeconds(30)
            options.Authority = "NTLMDOMAIN:" & domain
            options.Authentication = AuthenticationLevel.PacketPrivacy
            objManagementScope = New ManagementScope(computerconnect, options)

            If objManagementScope.IsConnected = True Then
            Else
                Try
                    objManagementScope.Connect()
                Catch ex As Exception
                    BackgroundWorkerSpinner.CancelAsync()
                    MetroProgressBar.Hide()
                    PCNAME.Focus()
                    MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                    Exit Sub
                End Try
            End If

            Dim QueryOptions = New EnumerationOptions
            QueryOptions.Timeout = New TimeSpan(0, 0, 10)
            Dim query As New SelectQuery("SELECT * FROM Win32_Service Where Name = " & Chr(34) & ServiceNameSelected.Text & Chr(34) & " ")
            Dim searcher As New ManagementObjectSearcher(objManagementScope, query, QueryOptions)
            Dim args As Object = Nothing
            Try
                For Each mo As ManagementObject In searcher.[Get]()
                    Dim inParams As ManagementBaseObject
                    inParams = mo.GetMethodParameters("ChangeStartMode")
                    inParams("StartMode") = "Automatic"
                    mo.InvokeMethod("ChangeStartMode", inParams, Nothing)
                Next
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
            objManagementScope = Nothing
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        GetServices2()

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
        PCNAME.Focus()
    End Sub

    Private Sub SetServiceStartManual_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SetServiceStartManual.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Try
            Dim objManagementScope As ManagementScope
            Dim objManagementClass As ManagementClass = Nothing
            Dim objManagementBaseObject As ManagementBaseObject = Nothing

            Dim options As ConnectionOptions
            options = New ConnectionOptions()
            Dim computerconnect As String = "\\" & txtpcname & "\root\cimv2"

            options.Username = username
            options.Password = password
            options.Timeout = TimeSpan.FromSeconds(30)
            options.Authority = "NTLMDOMAIN:" & domain
            options.Authentication = AuthenticationLevel.PacketPrivacy
            objManagementScope = New ManagementScope(computerconnect, options)

            If objManagementScope.IsConnected = True Then
            Else
                Try
                    objManagementScope.Connect()
                Catch ex As Exception
                    BackgroundWorkerSpinner.CancelAsync()
                    MetroProgressBar.Hide()
                    PCNAME.Focus()
                    MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                    Exit Sub
                End Try
            End If

            Dim QueryOptions = New EnumerationOptions
            QueryOptions.Timeout = New TimeSpan(0, 0, 10)
            Dim query As New SelectQuery("SELECT * FROM Win32_Service Where Name = " & Chr(34) & ServiceNameSelected.Text & Chr(34) & " ")
            Dim searcher As New ManagementObjectSearcher(objManagementScope, query, QueryOptions)
            Dim args As Object = Nothing
            Try
                For Each mo As ManagementObject In searcher.[Get]()
                    Dim inParams As ManagementBaseObject
                    inParams = mo.GetMethodParameters("ChangeStartMode")
                    inParams("StartMode") = "Manual"
                    mo.InvokeMethod("ChangeStartMode", inParams, Nothing)
                Next
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
            objManagementScope = Nothing
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        GetServices2()

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
        PCNAME.Focus()
    End Sub
    Private Sub DataGridView7_CellClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView7.CellClick
        Dim x As String = Nothing
        x = DataGridView7.CurrentRow.Cells.Item(0).Value
        ServiceNameSelected.Text = x
    End Sub
    Private Sub GetServices2()
        If MachineName = "" Then
            Exit Sub
        End If

        Dim ServiceDisplayName As String = Nothing
        Dim ServiceName As String = Nothing
        Dim ServiceState As String = Nothing
        Dim ServiceStartMode As String = Nothing

        DataGridView7.Rows.Clear()

        Dim objManagementScope As ManagementScope

        Dim options As ConnectionOptions
        options = New ConnectionOptions()
        Dim computerconnect As String = "\\" & txtpcname & "\root\cimv2"

        options.Username = username
        options.Password = password
        options.Timeout = TimeSpan.FromSeconds(30)
        options.Authority = "NTLMDOMAIN:" & domain
        options.Authentication = AuthenticationLevel.PacketPrivacy
        objManagementScope = New ManagementScope(computerconnect, options)

        If objManagementScope.IsConnected = True Then
        Else
            Try
                objManagementScope.Connect()
            Catch ex As Exception
                MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                PCNAME.Focus()
                Exit Sub
            End Try
        End If

        Dim query As New SelectQuery("SELECT * FROM Win32_Service")
        Dim QueryOptions = New EnumerationOptions
        QueryOptions.Timeout = New TimeSpan(0, 0, 10)
        Dim searcher As New ManagementObjectSearcher(objManagementScope, query, QueryOptions)

        ' get the datetime value and set the local boot
        ' time variable to contain that value
        For Each mo As ManagementObject In searcher.[Get]()
            ServiceDisplayName = mo("DisplayName")
            ServiceName = mo("Name")
            ServiceState = mo("State")
            ServiceStartMode = mo("StartMode")
            DataGridView7.Rows.Add(ServiceName, ServiceDisplayName, ServiceState, ServiceStartMode)
        Next
        PCNAME.Focus()
        objManagementScope = Nothing
    End Sub

    Private Sub GETSCCM_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GETSCCM.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If
        DataGridView8.Rows.Clear()
        AdvIDMachine.Text = "AdvID"
        PkgIDMachine.Text = "PkgID"
        AdvertNameMachine.Text = "AdvertName"

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        SCCMADV()

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
        PCNAME.Focus()
    End Sub
    Private Sub SCCMADV()
        Dim AdvID As String = Nothing
        Dim PkgID As String = Nothing
        Dim Name As String = Nothing
        Dim SoftwareVersion As String = Nothing
        Dim Program As String = Nothing
        Dim Command As String = Nothing
        Dim ContentSize As String = Nothing

        Dim objManagementScope As ManagementScope

        Dim options As ConnectionOptions
        options = New ConnectionOptions()
        Dim computerconnect As String = "\\" & txtpcname & "\root\ccm\policy\machine"

        options.Username = username
        options.Password = password
        options.Timeout = TimeSpan.FromSeconds(30)
        options.Authority = "NTLMDOMAIN:" & domain
        options.Authentication = AuthenticationLevel.PacketPrivacy
        objManagementScope = New ManagementScope(computerconnect, options)

        If objManagementScope.IsConnected = True Then
        Else
            Try
                objManagementScope.Connect()
            Catch ex As Exception
                MessageBox.Show("Couldn't connect: " + ex.Message, "Error , Please check pc online and SCCM Agent is installed!")
                PCNAME.Focus()
                Exit Sub
            End Try
        End If
        Try
            Dim QueryOptions = New EnumerationOptions
            QueryOptions.Timeout = New TimeSpan(0, 0, 10)
            Dim query As New SelectQuery("SELECT * FROM CCM_SoftwareDistribution")
            Dim searcher As New ManagementObjectSearcher(objManagementScope, query, QueryOptions)
            For Each mo As ManagementObject In searcher.[Get]()
                AdvID = mo("ADV_AdvertisementID")
                PkgID = mo("PKG_PackageID")
                Name = mo("PKG_Name")
                SoftwareVersion = mo("PKG_SourceVersion")
                Program = mo("PRG_ProgramName")
                Command = mo("PRG_CommandLine")
                ContentSize = mo("PKG_ContentSize")

                If Program = "*" Then
                    DataGridView8.RowTemplate.DefaultCellStyle.ForeColor = Color.Orange
                    Program = "* (TASK SEQUENCE/TASK SEQUENCE ACTION!)"
                    Command = mo("PRG_Comment")
                End If

                DataGridView8.Rows.Add(AdvID, PkgID, Name, ContentSize, SoftwareVersion, Program, Command)

                DataGridView8.RowTemplate.DefaultCellStyle.ForeColor = Color.Black
            Next

            Try
                DataGridView8.Sort(DataGridView8.Columns(2), System.ComponentModel.ListSortDirection.Ascending)
            Catch ex As Exception
            End Try

        Catch ex As Exception
            MessageBox.Show("Unable to connect to SCCM Agent, Please check AGent is Installed!")
        End Try
        objManagementScope = Nothing
    End Sub

    Private Sub SCCMHIS(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)
        If MachineName = "" Then
            Exit Sub
        End If

        Dim strComputerName As String = txtpcname
        Dim strStringValue As String = ""
        Dim strKeyPath As String = "SOFTWARE\Microsoft\SMS\Mobile Client\Software Distribution\Execution History\System\"
        Dim strKeyPath64 As String = "SOFTWARE\WOW6432node\Microsoft\SMS\Mobile Client\Software Distribution\Execution History\System\"
        Dim objManagementScope As ManagementScope = Nothing
        Dim objManagementClass As ManagementClass = Nothing
        Dim objManagementBaseObject As ManagementBaseObject = Nothing
        Dim strkey As String = ""
        Dim strkey2 As String = ""
        Dim myValue1 As String = ""
        Dim myValue2 As String = ""
        Dim myValue3 As Date
        Dim myValue4 As String = ""
        Dim myValue5 As String = ""
        Dim myValue6 As String = ""
        Dim aSubKeys() As String = Nothing
        Dim aSubKeys2() As String = Nothing
        Dim intRegistryHive As Microsoft.Win32.RegistryHive
        intRegistryHive = Microsoft.Win32.RegistryHive.LocalMachine

        Dim options As ConnectionOptions
        options = New ConnectionOptions()
        Dim computerconnect As String = "\\" & txtpcname & "\root\DEFAULT"

        options.Username = username
        options.Password = password
        options.Timeout = TimeSpan.FromSeconds(30)
        options.Authority = "NTLMDOMAIN:" & domain
        options.Authentication = AuthenticationLevel.PacketPrivacy
        objManagementScope = New ManagementScope(computerconnect, options)

        If objManagementScope.IsConnected = True Then
        Else
            Try
                objManagementScope.Connect()
            Catch ex As Exception
                MessageBox.Show("Couldn't connect: " + ex.Message, "Error , Please check pc online and SCCM Agent is installed!")
                Exit Sub
            End Try
        End If
        Try
            objManagementClass = New ManagementClass("stdRegProv")
            objManagementClass.Scope = objManagementScope
            objManagementBaseObject = objManagementClass.GetMethodParameters("EnumKey")
            objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
            objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath)
            aSubKeys = CType(objManagementClass.InvokeMethod("EnumKey", objManagementBaseObject, Nothing).Properties.Item("sNames").Value, String())

            For Each strkey In aSubKeys
                myValue1 = strkey
                objManagementClass = New ManagementClass("stdRegProv")
                objManagementClass.Scope = objManagementScope
                objManagementBaseObject = objManagementClass.GetMethodParameters("EnumKey")
                objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath & strkey)
                aSubKeys2 = CType(objManagementClass.InvokeMethod("EnumKey", objManagementBaseObject, Nothing).Properties.Item("sNames").Value, String())
                Try
                    For Each strkey2 In aSubKeys2
                        objManagementBaseObject = objManagementClass.GetMethodParameters("GetStringValue")
                        objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                        objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath & strkey & "\" & strkey2)
                        objManagementBaseObject.SetPropertyValue("sValueName", "_ProgramID")
                        objManagementBaseObject = objManagementClass.InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                        myValue2 = objManagementBaseObject("sValue")
                        If myValue2 = Nothing Then
                            myValue2 = ""
                        End If
                        If myValue2 = "*" Then
                            myValue2 = "* (TASK SEQUENCE/TASK SEQUENCE ACTION!)"
                        End If
                        objManagementBaseObject = objManagementClass.GetMethodParameters("GetStringValue")
                        objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                        objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath & strkey & "\" & strkey2)
                        objManagementBaseObject.SetPropertyValue("sValueName", "_RunStartTime")
                        objManagementBaseObject = objManagementClass.InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                        myValue3 = objManagementBaseObject("sValue")
                        If myValue3 = Nothing Then
                            myValue3 = ""
                        End If

                        objManagementBaseObject = objManagementClass.GetMethodParameters("GetStringValue")
                        objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                        objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath & strkey & "\" & strkey2)
                        objManagementBaseObject.SetPropertyValue("sValueName", "_State")
                        objManagementBaseObject = objManagementClass.InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                        myValue4 = objManagementBaseObject("sValue")
                        If myValue4 = Nothing Then
                            myValue4 = ""
                        End If
                        objManagementBaseObject = objManagementClass.GetMethodParameters("GetStringValue")
                        objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                        objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath & strkey & "\" & strkey2)
                        objManagementBaseObject.SetPropertyValue("sValueName", "SuccessOrFailureCode")
                        objManagementBaseObject = objManagementClass.InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                        myValue5 = objManagementBaseObject("sValue")
                        If myValue5 = Nothing Then
                            myValue5 = ""
                        End If
                        objManagementBaseObject = objManagementClass.GetMethodParameters("GetStringValue")
                        objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                        objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath & strkey & "\" & strkey2)
                        objManagementBaseObject.SetPropertyValue("sValueName", "SuccessOrFailureReason")
                        objManagementBaseObject = objManagementClass.InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                        myValue6 = objManagementBaseObject("sValue")
                        If myValue6 = Nothing Then
                            myValue6 = ""
                        End If

                        If myValue4 = "Failure" Then
                            DataGridView9.RowTemplate.DefaultCellStyle.ForeColor = Color.Red
                        End If

                        DataGridView9.Rows.Add(myValue1, myValue2, myValue3, myValue4, myValue5, myValue6)

                        DataGridView9.RowTemplate.DefaultCellStyle.ForeColor = Color.Black
                    Next
                Catch
                End Try
            Next
        Catch
            ' MessageBox.Show("You have a DUFF registry entry in SCCM Execution History... Please check Registry here: HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\SMS\Mobile Client\Software Distribution\Execution History\System for any Keys without a Subkey!")
        End Try

        Try
            objManagementClass = New ManagementClass("stdRegProv")
            objManagementClass.Scope = objManagementScope
            objManagementBaseObject = objManagementClass.GetMethodParameters("EnumKey")
            objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
            objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath64)
            aSubKeys = CType(objManagementClass.InvokeMethod("EnumKey", objManagementBaseObject, Nothing).Properties.Item("sNames").Value, String())

            For Each strkey In aSubKeys
                myValue1 = strkey
                objManagementClass = New ManagementClass("stdRegProv")
                objManagementClass.Scope = objManagementScope
                objManagementBaseObject = objManagementClass.GetMethodParameters("EnumKey")
                objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath64 & strkey)
                aSubKeys2 = CType(objManagementClass.InvokeMethod("EnumKey", objManagementBaseObject, Nothing).Properties.Item("sNames").Value, String())
                Try
                    For Each strkey2 In aSubKeys2
                        objManagementBaseObject = objManagementClass.GetMethodParameters("GetStringValue")
                        objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                        objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath64 & strkey & "\" & strkey2)
                        objManagementBaseObject.SetPropertyValue("sValueName", "_ProgramID")
                        objManagementBaseObject = objManagementClass.InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                        myValue2 = objManagementBaseObject("sValue")
                        If myValue2 = Nothing Then
                            myValue2 = ""
                        End If
                        If myValue2 = "*" Then
                            myValue2 = "* (TASK SEQUENCE/TASK SEQUENCE ACTION!)"
                        End If
                        objManagementBaseObject = objManagementClass.GetMethodParameters("GetStringValue")
                        objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                        objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath64 & strkey & "\" & strkey2)
                        objManagementBaseObject.SetPropertyValue("sValueName", "_RunStartTime")
                        objManagementBaseObject = objManagementClass.InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                        myValue3 = objManagementBaseObject("sValue")
                        If myValue3 = Nothing Then
                            myValue3 = ""
                        End If
                        objManagementBaseObject = objManagementClass.GetMethodParameters("GetStringValue")
                        objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                        objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath64 & strkey & "\" & strkey2)
                        objManagementBaseObject.SetPropertyValue("sValueName", "_State")
                        objManagementBaseObject = objManagementClass.InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                        myValue4 = objManagementBaseObject("sValue")
                        If myValue4 = Nothing Then
                            myValue4 = ""
                        End If
                        objManagementBaseObject = objManagementClass.GetMethodParameters("GetStringValue")
                        objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                        objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath64 & strkey & "\" & strkey2)
                        objManagementBaseObject.SetPropertyValue("sValueName", "SuccessOrFailureCode")
                        objManagementBaseObject = objManagementClass.InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                        myValue5 = objManagementBaseObject("sValue")
                        If myValue5 = Nothing Then
                            myValue5 = ""
                        End If
                        objManagementBaseObject = objManagementClass.GetMethodParameters("GetStringValue")
                        objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                        objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath64 & strkey & "\" & strkey2)
                        objManagementBaseObject.SetPropertyValue("sValueName", "SuccessOrFailureReason")
                        objManagementBaseObject = objManagementClass.InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                        myValue6 = objManagementBaseObject("sValue")
                        If myValue6 = Nothing Then
                            myValue6 = ""
                        End If

                        If myValue4 = "Failure" Then
                            DataGridView9.RowTemplate.DefaultCellStyle.ForeColor = Color.Red
                        End If

                        DataGridView9.Rows.Add(myValue1, myValue2, myValue3, myValue4, myValue5, myValue6)
                        DataGridView9.RowTemplate.DefaultCellStyle.ForeColor = Color.Black
                    Next
                Catch
                End Try
            Next
        Catch
            'MessageBox.Show("You have a DUFF registry entry in SCCM Execution History... Please check Registry here: HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\SMS\Mobile Client\Software Distribution\Execution History\System for any Keys without a Subkey!")
        End Try

        Try
            DataGridView9.Sort(DataGridView9.Columns(2), System.ComponentModel.ListSortDirection.Descending)
        Catch
        End Try

        objManagementScope = Nothing
        objManagementBaseObject.Dispose()
        objManagementClass.Dispose()
    End Sub

    Private Sub GetSCCM2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GetSCCM2.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If
        DataGridView9.Rows.Clear()

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        SCCMHIS(username, password, domain, txtpcname)

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
        PCNAME.Focus()
    End Sub


    Private Sub fillproclist()
        On Error Resume Next
        Dim n1
        Dim d1
        Dim n2
        Dim d2
        Dim nd
        Dim dd
        Dim PercentProcessorTime
        Dim CPUUSage
        Dim handleresult As String
        Dim nameresult As String
        Dim lvwP As New ListViewItem
        Dim options2 As ConnectionOptions
        Dim UserDomain As String
        options2 = New ConnectionOptions()
        Dim computerconnect2 As String = "\\" & txtpcname & "\root\cimv2"
        options2.Username = username
        options2.Password = password
        options2.Timeout = TimeSpan.FromSeconds(30)
        options2.Authority = "NTLMDOMAIN:" & domain
        options2.Authentication = AuthenticationLevel.PacketPrivacy
        Dim msc As ManagementScope = New ManagementScope(computerconnect2, options2)
        Dim query_command As String = "SELECT * FROM Win32_Process"
        Dim select_query As SelectQuery = New SelectQuery(query_command)
        Dim QueryOptions = New EnumerationOptions
        QueryOptions.Timeout = New TimeSpan(0, 0, 10)
        Dim Srch As New ManagementObjectSearcher(msc, select_query, QueryOptions)
        Dim objMgmt As ManagementObject

        For Each objMgmt In Srch.Get
            lvwP.UseItemStyleForSubItems = False
            lvwP.Font = New Font(lvwProcesses.Font, FontStyle.Regular)

            lvwP = lvwProcesses.Items.Add(objMgmt("Name"))
            lvwP.SubItems.Add(objMgmt("ProcessId")).Font = New Font(lvwProcesses.Font, FontStyle.Regular)
            Dim s(1) As String
            objMgmt.InvokeMethod("GetOwner", s)
            UserDomain = (s(1) + ("\" + s(0)))
            lvwP.SubItems.Add(UserDomain).Font = New Font(lvwProcesses.Font, FontStyle.Regular)
            lvwP.SubItems.Add(objMgmt("ExecutablePath")).Font = New Font(lvwProcesses.Font, FontStyle.Regular)
        Next

        msc = Nothing

    End Sub

    Private Sub cmdRefresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdRefresh.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        lvwProcesses.Items.Clear()

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Call fillproclist()

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
        PCNAME.Focus()
    End Sub

    Private Sub SecurityPatchesBUT_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SecurityPatchesBUT.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        DataGridView10.Rows.Clear()
        KBTextBox.Text = ""

        GETADDREMOVEPATCHES(username, password, domain, txtpcname)

        PCNAME.Focus()
    End Sub

    Private Sub GetSoftwareList_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GetSoftwareList.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        DataGridView1.Rows.Clear()

        GETADDREMOVE(username, password, domain, txtpcname)

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
        PCNAME.Focus()
    End Sub

    Private Sub Groups_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Groups.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        groupview1.Items.Clear()

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Try
            Dim options2 As ConnectionOptions
            options2 = New ConnectionOptions()
            Dim computerconnect2 As String = "\\" & txtpcname & "\root\cimv2"
            options2.Username = username
            options2.Password = password
            options2.Timeout = TimeSpan.FromSeconds(30)
            options2.Authority = "NTLMDOMAIN:" & domain
            options2.Authentication = AuthenticationLevel.PacketPrivacy
            Dim msc As ManagementScope = New ManagementScope(computerconnect2, options2)
            Dim query_command As String = "Select * from Win32_Group Where LocalAccount='True'"
            Dim select_query As SelectQuery = New SelectQuery(query_command)
            Dim Srch As New ManagementObjectSearcher(msc, select_query)
            Dim objMgmt As ManagementObject
            For Each objMgmt In Srch.Get
                Dim s(1) As String
                groupview1.Items.Add(objMgmt.GetPropertyValue("Name"))
            Next
            msc = Nothing
        Catch ex As Exception
        End Try

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
        PCNAME.Focus()
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        If GROUPSVALUE2.Text = "" Then
            PCNAME.Focus()
            Exit Sub
        End If

        userview1.Items.Clear()

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Try
            Dim options2 As ConnectionOptions
            options2 = New ConnectionOptions()
            Dim computerconnect2 As String = "\\" & txtpcname & "\root\cimv2"
            options2.Username = username
            options2.Password = password
            options2.Timeout = TimeSpan.FromSeconds(30)
            options2.Authority = "NTLMDOMAIN:" & domain
            options2.Authentication = AuthenticationLevel.PacketPrivacy
            Dim msc As ManagementScope = New ManagementScope(computerconnect2, options2)
            'Dim query_command As String = "Select * from Win32_Group Where LocalAccount='True'"
            Dim query_command As String = "select * from Win32_GroupUser where GroupComponent = " &
                                 Chr(34) & "Win32_Group.Domain='" & Host.Text & "',Name='" & GROUPSVALUE2.Text & "'" & Chr(34)

            Dim select_query As SelectQuery = New SelectQuery(query_command)
            Dim Srch As New ManagementObjectSearcher(msc, select_query)
            Dim objMgmt As ManagementObject
            For Each objMgmt In Srch.Get
                Dim NamesArray = Split(objMgmt.GetPropertyValue("PartComponent"), ",")
                'MsgBox(Replace(Replace(NamesArray(1), Chr(34), ""), "Name=", ""))
                userview1.Items.Add(Replace(Replace(NamesArray(1), Chr(34), ""), "Name=", ""))
            Next
            msc = Nothing
        Catch ex As Exception
        End Try

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
        PCNAME.Focus()
    End Sub

    Private Sub addlocaluser_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles addlocaluser.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Dim commandtorun As String = "CMD.EXE /c net user " & GROUPSVALUE1.Text & " Password12345! /add"


        'MsgBox(commandtorun)
        Dim sResult As Boolean = False
        Try
            sResult = WMI_RUN_Impersonate(commandtorun)
            'RunRemotePSScript(MachineName, username, password, commandtorun)
            Refreshuserslist()
        Catch ex As Exception
        End Try

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
        PCNAME.Focus()

    End Sub

    Private Sub removeuser_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles removeuser.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Dim commandtorun As String = "C:\Windows\System32\CMD.EXE /c net user " & GROUPSVALUE1.Text & " /delete"
        'MsgBox(commandtorun)
        Dim sResult As Boolean = False
        Try
            sResult = WMI_RUN_Impersonate(commandtorun)
            'RunRemotePSScript(MachineName, username, password, commandtorun)
            Refreshuserslist()
        Catch ex As Exception
        End Try

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
        PCNAME.Focus()
    End Sub

    Private Sub removelocaluser_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles removelocaluser.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Dim commandtorun As String = "C:\Windows\System32\CMD.EXE /c net localgroup " & GROUPSVALUE2.Text & " " & GROUPSVALUE1.Text & " /delete"
        'MsgBox(commandtorun)
        Dim sResult As Boolean = False
        Try
            sResult = WMI_RUN_Impersonate(commandtorun)
            'RunRemotePSScript(MachineName, username, password, commandtorun)
            refreshusers()
        Catch ex As Exception
        End Try

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
        PCNAME.Focus()
    End Sub

    Private Sub adddomaintolocal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles adddomaintolocal.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Dim commandtorun As String = "C:\Windows\System32\CMD.EXE /c net localgroup " & GROUPSVALUE2.Text & " """ & domain & "\" & GROUPSVALUE1.Text & """ /add"
        'MsgBox(commandtorun)
        Dim sResult As Boolean = False
        Try
            sResult = WMI_RUN_Impersonate(commandtorun)
            'RunRemotePSScript(MachineName, username, password, commandtorun)
            refreshusers()
        Catch ex As Exception
        End Try

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
        PCNAME.Focus()
    End Sub

    Private Sub removedomainfromlocal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles removedomainfromlocal.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Dim commandtorun As String = "C:\Windows\System32\CMD.EXE /c net localgroup " & GROUPSVALUE2.Text & " """ & domain & "\" & GROUPSVALUE1.Text & """ /delete"
        'MsgBox(commandtorun)
        Dim sResult As Boolean = False
        Try
            sResult = WMI_RUN_Impersonate(commandtorun)
            'RunRemotePSScript(MachineName, username, password, commandtorun)
            refreshusers()
        Catch ex As Exception
        End Try

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
        PCNAME.Focus()
    End Sub

    Private Sub adduser_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles addlocalusertolocalgroup.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Dim commandtorun As String = "C:\Windows\System32\CMD.EXE /c net localgroup " & GROUPSVALUE2.Text & " " & GROUPSVALUE1.Text & " /add"
        'MsgBox(commandtorun)
        Dim sResult As Boolean = False
        Try
            sResult = WMI_RUN_Impersonate(commandtorun)
            'RunRemotePSScript(MachineName, username, password, commandtorun)
            refreshusers()
        Catch ex As Exception
        End Try

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
        PCNAME.Focus()
    End Sub


    Private Sub Addlocalgroup_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Addlocalgroup.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Dim commandtorun As String = "C:\Windows\System32\CMD.EXE /c net localgroup " & GROUPSVALUE1.Text & " /add"
        'MsgBox(commandtorun)
        Dim sResult As Boolean = False
        Try
            sResult = WMI_RUN_Impersonate(commandtorun)
            'RunRemotePSScript(MachineName, username, password, commandtorun)
            refreshgroups()
        Catch ex As Exception
        End Try

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
        PCNAME.Focus()
    End Sub

    Private Sub removelocalgroup_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles removelocalgroup.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Dim commandtorun As String = "C:\Windows\System32\CMD.EXE /c net localgroup " & GROUPSVALUE2.Text & " /delete"
        'MsgBox(commandtorun)
        Dim sResult As Boolean = False
        Try
            sResult = WMI_RUN_Impersonate(commandtorun)
            'RunRemotePSScript(MachineName, username, password, commandtorun)
            refreshgroups()
        Catch ex As Exception
        End Try

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
        PCNAME.Focus()
    End Sub

    Private Sub groupview1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles groupview1.SelectedIndexChanged
        Try
            Dim x As String
            x = groupview1.SelectedItem.ToString
            GROUPSVALUE2.Text = x
        Catch ex As Exception
        End Try
    End Sub
    Private Sub userview1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles userview1.SelectedIndexChanged
        Try
            Dim x As String
            x = userview1.SelectedItem.ToString
            GROUPSVALUE1.Text = x
        Catch ex As Exception
        End Try
    End Sub

    Private Sub userlist_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Userlist.SelectedIndexChanged
        Try
            Dim x As String
            x = Userlist.SelectedItem.ToString
            GROUPSVALUE1.Text = x
        Catch ex As Exception
        End Try
    End Sub
    Private Sub refreshusers()

        If GROUPSVALUE2.Text = "" Then
            PCNAME.Focus()
            Exit Sub
        End If

        userview1.Items.Clear()
        Try
            Dim options2 As ConnectionOptions
            options2 = New ConnectionOptions()
            Dim computerconnect2 As String = "\\" & txtpcname & "\root\cimv2"
            options2.Username = username
            options2.Password = password
            options2.Timeout = TimeSpan.FromSeconds(30)
            options2.Authority = "NTLMDOMAIN:" & domain
            options2.Authentication = AuthenticationLevel.PacketPrivacy
            Dim msc As ManagementScope = New ManagementScope(computerconnect2, options2)
            'Dim query_command As String = "Select * from Win32_Group Where LocalAccount='True'"
            Dim query_command As String = "select * from Win32_GroupUser where GroupComponent = " &
                                 Chr(34) & "Win32_Group.Domain='" & Host.Text & "',Name='" & GROUPSVALUE2.Text & "'" & Chr(34)

            Dim select_query As SelectQuery = New SelectQuery(query_command)
            Dim Srch As New ManagementObjectSearcher(msc, select_query)
            Dim objMgmt As ManagementObject
            For Each objMgmt In Srch.Get
                Dim NamesArray = Split(objMgmt.GetPropertyValue("PartComponent"), ",")
                'MsgBox(Replace(Replace(NamesArray(1), Chr(34), ""), "Name=", ""))
                userview1.Items.Add(Replace(Replace(NamesArray(1), Chr(34), ""), "Name=", ""))
            Next
            msc = Nothing
        Catch ex As Exception
        End Try

        PCNAME.Focus()
    End Sub

    Private Sub refreshgroups()

        If GROUPSVALUE2.Text = "" Then
            PCNAME.Focus()
            Exit Sub
        End If

        groupview1.Items.Clear()
        Try
            Dim options2 As ConnectionOptions
            options2 = New ConnectionOptions()
            Dim computerconnect2 As String = "\\" & txtpcname & "\root\cimv2"
            options2.Username = username
            options2.Password = password
            options2.Timeout = TimeSpan.FromSeconds(30)
            options2.Authority = "NTLMDOMAIN:" & domain
            options2.Authentication = AuthenticationLevel.PacketPrivacy
            Dim msc As ManagementScope = New ManagementScope(computerconnect2, options2)
            Dim query_command As String = "Select * from Win32_Group Where LocalAccount='True'"
            Dim select_query As SelectQuery = New SelectQuery(query_command)
            Dim Srch As New ManagementObjectSearcher(msc, select_query)
            Dim objMgmt As ManagementObject
            For Each objMgmt In Srch.Get
                Dim s(1) As String
                groupview1.Items.Add(objMgmt.GetPropertyValue("Name"))
            Next
            msc = Nothing
        Catch ex As Exception
        End Try

        PCNAME.Focus()
    End Sub


    Private Sub MSIUNINSTALL_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MSIUNINSTALL.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If
        Dim wmi_out As ManagementBaseObject
        Dim objManagementScope As ManagementScope = Nothing
        Dim objManagementClass As ManagementClass = Nothing
        Dim objManagementBaseObject As ManagementBaseObject = Nothing
        Dim retValue As Integer

        Dim response As MsgBoxResult
        response = MsgBox("Are you sure you want to Remove the software using this command:" & TextBox1.Text & " ?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "Confirm")
        If response = MsgBoxResult.Yes Then
            Dim Command As String = TextBox1.Text
            Try
                If TextBox1.Text = "" Then
                    Exit Sub
                End If

                Dim options As ConnectionOptions
                options = New ConnectionOptions()
                Dim computerconnect As String = "\\" & txtpcname & "\root\cimv2:Win32_Process"

                options.Username = username
                options.Password = password
                options.Timeout = TimeSpan.FromSeconds(30)
                options.Authority = "NTLMDOMAIN:" & domain
                options.Authentication = AuthenticationLevel.PacketPrivacy
                objManagementScope = New ManagementScope(computerconnect, options)

                If objManagementScope.IsConnected = True Then
                Else
                    Try
                        objManagementScope.Connect()
                    Catch ex As Exception
                        MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                        PCNAME.Focus()
                        Exit Sub
                    End Try
                End If

                objManagementClass = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
                objManagementClass.Scope = objManagementScope

                objManagementBaseObject = objManagementClass.GetMethodParameters("Create")
                objManagementBaseObject.SetPropertyValue("CommandLine", Command)
                wmi_out = objManagementClass.InvokeMethod("Create", objManagementBaseObject, Nothing)

                'wmi = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
                'wmi_in = wmi.GetMethodParameters("Create")
                'wmi_in("CommandLine") = "cmd /c md c:\temp\temptd"
                'wmi_out = wmi.InvokeMethod("Create", wmi_in, Nothing)

                retValue = Convert.ToInt32(wmi_out("returnValue"))
                Select Case retValue
                    Case 0
                        ' success!
                        MsgBox(txtpcname & ": MSI Uninstall started at : " & Now)
                    Case 2
                        Throw New ApplicationException("Access denied")
                    Case 3
                        Throw New ApplicationException("Insufficient privilege")
                    Case 8
                        Throw New ApplicationException("Unknown failure")
                    Case 9
                        Throw New ApplicationException("Path not found")
                    Case 21
                        Throw New ApplicationException("Invalid parameter")
                    Case Else
                        Throw New ApplicationException("Unknown return code " & retValue)
                End Select
            Catch ex As Exception
                MsgBox(txtpcname & ": Can't create the process. " & ex.Message)
            End Try

            PCNAME.Focus()

        ElseIf response = MsgBoxResult.No Then
            PCNAME.Focus()
            Exit Sub
        End If

        objManagementScope = Nothing
        objManagementBaseObject.Dispose()
        objManagementClass.Dispose()
    End Sub

    Private Sub CopyToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim x As String
        x = DataGridView1.CurrentCell.Value
        If x <> String.Empty Then
            Clipboard.SetText(x)
        End If
    End Sub

    Private Sub CopySDList1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim x As String
        x = SDList1.SelectedItem.ToString
        If x <> String.Empty Then
            Clipboard.SetText(x)
        End If
    End Sub

    Private Sub Button12_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        BackgroundWorkerSpinnerStopWorker()

        System.Windows.Forms.Application.DoEvents()

        ' Take a screenshot of the application that has 
        ' focus. The screenshot is on the clipboard.
        System.Windows.Forms.SendKeys.Send("%{PRTSC}")

        Dim iData As System.Windows.Forms.IDataObject = System.Windows.Forms.Clipboard.GetDataObject()

        System.Windows.Forms.Application.DoEvents()
    End Sub

    Public Sub DISK_DETAILS_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DISK_DETAILS.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        On Error Resume Next

        DataGridViewDisk.Rows.Clear()
        DataGridViewDisk2.Rows.Clear()

        PagefileDetails.Text = ""
        TotalPhysicalMemoryDetails.Text = "Total Physical Memory : "

        Dim options2 As ConnectionOptions
        options2 = New ConnectionOptions()
        Dim computerconnect2 As String = "\\" & txtpcname & "\root\cimv2"
        options2.Username = username
        options2.Password = password
        options2.Timeout = TimeSpan.FromSeconds(30)
        options2.Authority = "NTLMDOMAIN:" & domain
        options2.Authentication = AuthenticationLevel.PacketPrivacy
        Dim msc As ManagementScope = New ManagementScope(computerconnect2, options2)

        If msc.IsConnected = True Then
        Else
            msc.Connect()
        End If

        If msc.IsConnected = False Then
            BackgroundWorkerSpinner.CancelAsync()
            MetroProgressBar.Hide()
            PCNAME.Focus()
            Exit Sub
        End If

        Dim QueryOptions = New EnumerationOptions
        QueryOptions.Timeout = New TimeSpan(0, 0, 10)

        Dim query_command As String = "select FreeSpace,Size,Name,DriveType from Win32_LogicalDisk"
        Dim select_query As SelectQuery = New SelectQuery(query_command)
        Dim Srch As New ManagementObjectSearcher(msc, select_query, QueryOptions)
        Dim objMgmt As ManagementObject

        Dim query_command2 As String = "select Size,Name,partitions,Model,SerialNumber from Win32_DiskDrive"
        Dim select_query2 As SelectQuery = New SelectQuery(query_command2)
        Dim Srch2 As New ManagementObjectSearcher(msc, select_query2, QueryOptions)
        For Each objMgmt In Srch2.Get
            Dim DiskDriveSize As Long = CLng((objMgmt("Size").ToString()) / (1073741824))
            Dim DiskDriveName As String = UCase(objMgmt("Name").ToString())
            Dim DiskDrivePartitions As String = UCase(objMgmt("Partitions").ToString())
            Dim DiskDriveModel As String = UCase(objMgmt("Model").ToString())
            Dim DiskDriveSerialNumber As String = UCase(objMgmt("SerialNumber").ToString())
            DataGridViewDisk2.Rows.Add(DiskDriveName, DiskDriveModel, DiskDriveSerialNumber, DiskDriveSize, DiskDrivePartitions)
        Next

        For Each objMgmt In Srch.Get
            Dim llFreeSpaceC As Long = 0
            Dim lsDriveName As String = UCase(objMgmt("Name").ToString())
            Dim lsDriveType As String = UCase(objMgmt("DriveType").ToString())
            Dim lsDriveSzeC As Long = 0
            Dim DriveUsedC As Long = 0
            Dim DriveUsedPercentC As Long = 0
            Dim DriveFreePercentC As Long = 0
            lsDriveSzeC = CLng((((objMgmt("Size").ToString()) / 1024) / 1024) / 1024)
            llFreeSpaceC = CLng((((objMgmt("FreeSpace").ToString()) / 1024) / 1024) / 1024)
            DriveUsedC = lsDriveSzeC - llFreeSpaceC
            DriveUsedPercentC = (DriveUsedC / lsDriveSzeC) * 100%
            DriveFreePercentC = (llFreeSpaceC / lsDriveSzeC) * 100%
            If lsDriveType = "3" Then
                If lsDriveSzeC = 0 Then
                    If llFreeSpaceC = 0 Then
                        lsDriveType = "AppV-4"
                    End If
                End If
            End If
            If lsDriveType = "5" Then
                lsDriveType = "CD/DVD"
            End If
            If lsDriveType = "2" Then
                lsDriveType = "Floppy"
            End If
            DataGridViewDisk.Rows.Add(lsDriveName, lsDriveType, lsDriveSzeC, llFreeSpaceC, DriveUsedC, DriveFreePercentC, DriveUsedPercentC)
        Next

        Dim query_command3 As String = "select * from Win32_PageFileSetting"
        Dim select_query3 As SelectQuery = New SelectQuery(query_command3)
        Dim Srch3 As New ManagementObjectSearcher(msc, select_query3, QueryOptions)
        Dim PagefileDetailsOUT As String = ""

        For Each objMgmt In Srch3.Get
            Dim PagefileMinSize As Long = CLng(objMgmt("InitialSize").ToString())
            Dim PagefileName As String = UCase(objMgmt("Name").ToString())
            Dim PagefileMaxSize As Long = CLng(objMgmt("MaximumSize").ToString())
            PagefileDetailsOUT = PagefileDetailsOUT & PagefileName & " " & PagefileMinSize & " " & PagefileMaxSize & vbCrLf
        Next
        If PagefileDetailsOUT = "" Then
            PagefileDetailsOUT = "Managed by System."
        End If
        PagefileDetails.Text = PagefileDetailsOUT

        Dim query_command4 As String = "select * from Win32_ComputerSystem"
        Dim select_query4 As SelectQuery = New SelectQuery(query_command4)
        Dim Srch4 As New ManagementObjectSearcher(msc, select_query4, QueryOptions)

        For Each objMgmt In Srch4.Get
            TotalPhysicalMemory = CLng(objMgmt("TotalPhysicalMemory").ToString() / 1024 / 1024)
            TotalPhysicalMemoryDetails.Text = "Total Physical Memory : " & TotalPhysicalMemory & " (MB)"
        Next

        msc = Nothing

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
        PCNAME.Focus()

    End Sub

    Private Sub Button13_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button13.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        Dim Pagemin As Long = TotalPhysicalMemory * 1.5
        Dim Pagemax As Long = TotalPhysicalMemory * 1.5

        Dim wmi_out As ManagementBaseObject
        Dim objManagementScope As ManagementScope
        Dim objManagementClass As ManagementClass = Nothing
        Dim objManagementBaseObject As ManagementBaseObject = Nothing
        Dim retValue As Integer
        Dim Command As String = "cmd /c reg add ""HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management"" /v PagingFiles /t REG_MULTI_SZ /d ""C:\pagefile.sys 64 64\0D:\pagefile.sys " & Pagemin & " " & Pagemax & """ /f"

        Try
            Dim options As ConnectionOptions
            options = New ConnectionOptions()
            Dim computerconnect As String = "\\" & txtpcname & "\root\cimv2:Win32_Process"

            options.Username = username
            options.Password = password
            options.Timeout = TimeSpan.FromSeconds(30)
            options.Authority = "NTLMDOMAIN:" & domain
            options.Authentication = AuthenticationLevel.PacketPrivacy
            objManagementScope = New ManagementScope(computerconnect, options)

            If objManagementScope.IsConnected = True Then
            Else
                Try
                    objManagementScope.Connect()
                Catch ex As Exception
                    MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                    Exit Sub
                End Try
            End If

            objManagementClass = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
            objManagementClass.Scope = objManagementScope

            objManagementBaseObject = objManagementClass.GetMethodParameters("Create")
            objManagementBaseObject.SetPropertyValue("CommandLine", Command)
            wmi_out = objManagementClass.InvokeMethod("Create", objManagementBaseObject, Nothing)

            retValue = Convert.ToInt32(wmi_out("returnValue"))
            Select Case retValue
                Case 0
                    ' success!
                Case 2
                    Throw New ApplicationException("Access denied")
                Case 3
                    Throw New ApplicationException("Insufficient privilege")
                Case 8
                    Throw New ApplicationException("Unknown failure")
                Case 9
                    Throw New ApplicationException("Path not found")
                Case 21
                    Throw New ApplicationException("Invalid parameter")
                Case Else
                    Throw New ApplicationException("Unknown return code " & retValue)
            End Select
        Catch ex As Exception
            MsgBox(txtpcname & ": Can't create the process. " & ex.Message)
        End Try

        objManagementScope = Nothing
        objManagementBaseObject.Dispose()
        objManagementClass.Dispose()

        PCNAME.Focus()
    End Sub

    Private Sub Button14_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button14.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        Dim Pagemin As Long = TotalPhysicalMemory * 1.5
        Dim Pagemax As Long = TotalPhysicalMemory * 1.5

        Dim wmi_out As ManagementBaseObject
        Dim objManagementScope As ManagementScope
        Dim objManagementClass As ManagementClass = Nothing
        Dim objManagementBaseObject As ManagementBaseObject = Nothing
        Dim retValue As Integer
        Dim Command As String = "cmd /c reg add ""HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management"" /v PagingFiles /t REG_MULTI_SZ /d ""C:\pagefile.sys 64 64\0E:\pagefile.sys " & Pagemin & " " & Pagemax & """ /f"

        Try
            Dim options As ConnectionOptions
            options = New ConnectionOptions()
            Dim computerconnect As String = "\\" & txtpcname & "\root\cimv2:Win32_Process"

            options.Username = username
            options.Password = password
            options.Timeout = TimeSpan.FromSeconds(30)
            options.Authority = "NTLMDOMAIN:" & domain
            options.Authentication = AuthenticationLevel.PacketPrivacy
            objManagementScope = New ManagementScope(computerconnect, options)

            If objManagementScope.IsConnected = True Then
            Else
                Try
                    objManagementScope.Connect()
                Catch ex As Exception
                    MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                    Exit Sub
                End Try
            End If

            objManagementClass = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
            objManagementClass.Scope = objManagementScope

            objManagementBaseObject = objManagementClass.GetMethodParameters("Create")
            objManagementBaseObject.SetPropertyValue("CommandLine", Command)
            wmi_out = objManagementClass.InvokeMethod("Create", objManagementBaseObject, Nothing)

            retValue = Convert.ToInt32(wmi_out("returnValue"))
            Select Case retValue
                Case 0
                    ' success!
                Case 2
                    Throw New ApplicationException("Access denied")
                Case 3
                    Throw New ApplicationException("Insufficient privilege")
                Case 8
                    Throw New ApplicationException("Unknown failure")
                Case 9
                    Throw New ApplicationException("Path not found")
                Case 21
                    Throw New ApplicationException("Invalid parameter")
                Case Else
                    Throw New ApplicationException("Unknown return code " & retValue)
            End Select
        Catch ex As Exception
            MsgBox(txtpcname & ": Can't create the process. " & ex.Message)
        End Try

        objManagementScope = Nothing
        objManagementBaseObject.Dispose()
        objManagementClass.Dispose()

        PCNAME.Focus()
    End Sub

    Private Sub Minimise_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        WindowState = System.Windows.Forms.FormWindowState.Minimized
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        BackgroundWorkerSpinnerStopWorker()

        System.Windows.Forms.Application.DoEvents()

        ' Take a screenshot of the application that has 
        ' focus. The screenshot is on the clipboard.
        System.Windows.Forms.SendKeys.Send("%{PRTSC}")

        Dim iData As System.Windows.Forms.IDataObject = System.Windows.Forms.Clipboard.GetDataObject()

        System.Windows.Forms.Application.DoEvents()
    End Sub

    Private Sub GetSCCMTaskSequences_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GetSCCMTaskSequences.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If
        DataGridView11.Rows.Clear()

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        SCCMTASKLIST(username, password, domain, txtpcname)

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
        PCNAME.Focus()
    End Sub

    Private Sub SCCMTASKLIST(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)
        Dim Adv_TS As String = Nothing
        Dim PkgID As String = Nothing
        Dim Name As String = Nothing
        Dim SoftwarePublished As String = Nothing

        Dim objManagementScope As ManagementScope

        Dim options As ConnectionOptions
        options = New ConnectionOptions()
        Dim computerconnect As String = "\\" & txtpcname & "\root\ccm\policy\machine"

        options.Username = username
        options.Password = password
        options.Timeout = TimeSpan.FromSeconds(30)
        options.Authority = "NTLMDOMAIN:" & domain
        options.Authentication = AuthenticationLevel.PacketPrivacy
        objManagementScope = New ManagementScope(computerconnect, options)

        If objManagementScope.IsConnected = True Then
        Else
            Try
                objManagementScope.Connect()
            Catch ex As Exception
                MessageBox.Show("Couldn't connect: " + ex.Message, "Error , Please check pc online and SCCM Agent is installed!")
                PCNAME.Focus()
                Exit Sub
            End Try
        End If

        Try
            Dim QueryOptions = New EnumerationOptions
            QueryOptions.Timeout = New TimeSpan(0, 0, 10)
            Dim query As New SelectQuery("SELECT * FROM CCM_TaskSequence")
            Dim searcher As New ManagementObjectSearcher(objManagementScope, query, QueryOptions)
            For Each mo As ManagementObject In searcher.[Get]()
                Adv_TS = mo("ADV_AdvertisementID")
                PkgID = mo("PKG_PackageID")
                Name = mo("PKG_Name")
                SoftwarePublished = mo("ADV_ADF_Published")

                If SoftwarePublished = "True" Then
                    DataGridView11.RowTemplate.DefaultCellStyle.ForeColor = Color.Orange
                End If

                DataGridView11.Rows.Add(Adv_TS, PkgID, Name, SoftwarePublished)
                DataGridView11.RowTemplate.DefaultCellStyle.ForeColor = Color.Black
            Next

        Catch ex As Exception
            MessageBox.Show("Unable to connect to SCCM Agent, Please check AGent is Installed!")
        End Try

        Try
            DataGridView11.Sort(DataGridView11.Columns(2), System.ComponentModel.ListSortDirection.Ascending)
        Catch
        End Try

        objManagementScope = Nothing

        PCNAME.Focus()
    End Sub

    Private Sub GetSCCMCacheSettings_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GetSCCMCacheSettings.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        Dim CacheSize As String = Nothing
        Dim CacheLocation As String = Nothing

        Dim objManagementScope As ManagementScope
        Dim options As ConnectionOptions
        options = New ConnectionOptions()
        Dim computerconnect As String = "\\" & txtpcname & "\root\ccm\SoftMgmtAgent"

        options.Username = username
        options.Password = password
        options.Timeout = TimeSpan.FromSeconds(30)
        options.Authority = "NTLMDOMAIN:" & domain
        options.Authentication = AuthenticationLevel.PacketPrivacy
        objManagementScope = New ManagementScope(computerconnect, options)

        If objManagementScope.IsConnected = True Then
        Else
            Try
                objManagementScope.Connect()
            Catch ex As Exception
                MessageBox.Show("Couldn't connect: " + ex.Message, "Error , Please check pc online and SCCM Agent is installed!")
                PCNAME.Focus()
                Exit Sub
            End Try
        End If
        Try
            Dim QueryOptions = New EnumerationOptions
            QueryOptions.Timeout = New TimeSpan(0, 0, 10)
            Dim query As New SelectQuery("SELECT * FROM CacheConfig")
            Dim searcher As New ManagementObjectSearcher(objManagementScope, query, QueryOptions)
            For Each mo As ManagementObject In searcher.[Get]()
                CacheLocation = mo("Location")
                CacheSize = mo("Size")

                SCCMCacheLabel.Text = CacheLocation & " = " & CacheSize & " MB"
            Next
        Catch ex As Exception
            MessageBox.Show("Unable to connect to SCCM Agent, Please check AGent is Installed!")
        End Try

        objManagementScope = Nothing

        PCNAME.Focus()

    End Sub

    Private Sub openSCCMCache_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles openSCCMCache.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        Dim CacheSize As String = Nothing
        Dim CacheLocation As String = Nothing
        Dim CacheLocationUNC As String = Nothing

        Dim objManagementScope As ManagementScope
        Dim options As ConnectionOptions
        options = New ConnectionOptions()
        Dim computerconnect As String = "\\" & txtpcname & "\root\ccm\SoftMgmtAgent"

        options.Username = username
        options.Password = password
        options.Timeout = TimeSpan.FromSeconds(30)
        options.Authority = "NTLMDOMAIN:" & domain
        options.Authentication = AuthenticationLevel.PacketPrivacy
        objManagementScope = New ManagementScope(computerconnect, options)

        If objManagementScope.IsConnected = True Then
        Else
            Try
                objManagementScope.Connect()
            Catch ex As Exception
                MessageBox.Show("Couldn't connect: " + ex.Message, "Error , Please check pc online and SCCM Agent is installed!")
                PCNAME.Focus()
                Exit Sub
            End Try
        End If
        Try
            Dim QueryOptions = New EnumerationOptions
            QueryOptions.Timeout = New TimeSpan(0, 0, 10)
            Dim query As New SelectQuery("SELECT * FROM CacheConfig")
            Dim searcher As New ManagementObjectSearcher(objManagementScope, query, QueryOptions)
            For Each mo As ManagementObject In searcher.[Get]()
                CacheLocation = mo("Location")
            Next
        Catch ex As Exception
            MessageBox.Show("Unable to connect to SCCM Agent, Please check AGent is Installed!")
        End Try

        MapDriveAdmin(username, password, domain, txtpcname)

        Try
            CacheLocation = CacheLocation.ToUpper
            CacheLocation = CacheLocation.Replace(":", "$")
            CacheLocationUNC = "\\" & txtpcname & "\" & CacheLocation
            Dim objShell = CreateObject("Wscript.Shell")
            objShell.run(CacheLocationUNC)
        Catch ex As Exception
            MessageBox.Show(ex.Message & ", If a laptop then please use IP Address to connect!")
        End Try

        MapDriveAdminRemove(username, password, domain, txtpcname)

        objManagementScope = Nothing

        PCNAME.Focus()

    End Sub

    Private Sub endprocessbutton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles endprocessbutton.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Dim Prc As String
        Try
            Prc = lvwProcesses.SelectedItems(0).SubItems(1).Text
            Dim wmi_out As ManagementBaseObject
            Dim objManagementScope As ManagementScope
            Dim objManagementClass As ManagementClass = Nothing
            Dim objManagementBaseObject As ManagementBaseObject = Nothing
            Dim retValue As Integer
            Dim Command As String = "Taskkill /PID " & Prc & " /F"

            Try
                Dim options As ConnectionOptions
                options = New ConnectionOptions()
                Dim computerconnect As String = "\\" & txtpcname & "\root\cimv2:Win32_Process"

                options.Username = username
                options.Password = password
                options.Timeout = TimeSpan.FromSeconds(30)
                options.Authority = "NTLMDOMAIN:" & domain
                options.Authentication = AuthenticationLevel.PacketPrivacy
                objManagementScope = New ManagementScope(computerconnect, options)

                If objManagementScope.IsConnected = True Then
                Else
                    Try
                        objManagementScope.Connect()
                    Catch ex As Exception
                        MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                        Exit Sub
                    End Try
                End If

                objManagementClass = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
                objManagementClass.Scope = objManagementScope

                objManagementBaseObject = objManagementClass.GetMethodParameters("Create")
                objManagementBaseObject.SetPropertyValue("CommandLine", Command)
                wmi_out = objManagementClass.InvokeMethod("Create", objManagementBaseObject, Nothing)

                retValue = Convert.ToInt32(wmi_out("returnValue"))
                Select Case retValue
                    Case 0
                        ' success!
                        lvwProcesses.Items.Clear()
                        Call fillproclist()
                    Case 2
                        Throw New ApplicationException("Access denied")
                    Case 3
                        Throw New ApplicationException("Insufficient privilege")
                    Case 8
                        Throw New ApplicationException("Unknown failure")
                    Case 9
                        Throw New ApplicationException("Path not found")
                    Case 21
                        Throw New ApplicationException("Invalid parameter")
                    Case Else
                        Throw New ApplicationException("Unknown return code " & retValue)
                End Select
            Catch ex As Exception
                MsgBox(txtpcname & ": Can't create the kill process. " & ex.Message)
            End Try
            objManagementScope = Nothing
            objManagementBaseObject.Dispose()
            objManagementClass.Dispose()
        Catch
            MessageBox.Show("Could not close process, " & Err.Description, "Error:", MessageBoxButtons.OK, MessageBoxIcon.Stop)
        End Try

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
        PCNAME.Focus()
    End Sub

    Private Sub Button162_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button162.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If
        SCCMButton162(username, password, domain, txtpcname)
    End Sub


    Private Sub SCCMButton162(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)
        Dim wmi_out As ManagementBaseObject
        Dim objManagementScope As ManagementScope
        Dim objManagementClass As ManagementClass = Nothing
        Dim objManagementBaseObject As ManagementBaseObject = Nothing

        Dim retValue As Integer
        Dim Command As String = "WMIC /node:" & txtpcname & " /namespace:\\root\ccm path sms_client CALL TriggerSchedule " & Chr(34) & "{00000000-0000-0000-0000-000000000001}" & Chr(34) & " /NOINTERACTIVE"

        Try

            Dim options As ConnectionOptions
            options = New ConnectionOptions()
            Dim computerconnect As String = "\\" & txtpcname & "\root\cimv2:Win32_Process"

            options.Username = txtusername
            options.Password = txtpassword
            options.Timeout = TimeSpan.FromSeconds(30)
            options.Authority = "NTLMDOMAIN:" & txtdomain
            options.Authentication = AuthenticationLevel.PacketPrivacy
            objManagementScope = New ManagementScope(computerconnect, options)

            If objManagementScope.IsConnected = True Then
            Else
                Try
                    objManagementScope.Connect()
                Catch ex As Exception
                    MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                    Exit Sub
                End Try
            End If

            objManagementClass = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
            objManagementClass.Scope = objManagementScope

            objManagementBaseObject = objManagementClass.GetMethodParameters("Create")
            objManagementBaseObject.SetPropertyValue("CommandLine", Command)
            wmi_out = objManagementClass.InvokeMethod("Create", objManagementBaseObject, Nothing)

            'wmi = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
            'wmi_in = wmi.GetMethodParameters("Create")
            'wmi_in("CommandLine") = "cmd /c md c:\temp\temptd"
            'wmi_out = wmi.InvokeMethod("Create", wmi_in, Nothing)

            retValue = Convert.ToInt32(wmi_out("returnValue"))
            Select Case retValue
                Case 0

                Case 2
                    Throw New ApplicationException("Access denied")
                Case 3
                    Throw New ApplicationException("Insufficient privilege")
                Case 8
                    Throw New ApplicationException("Unknown failure")
                Case 9
                    Throw New ApplicationException("Path not found")
                Case 21
                    Throw New ApplicationException("Invalid parameter")
                Case Else
                    Throw New ApplicationException("Unknown return code " & retValue)
            End Select
        Catch ex As Exception
            MsgBox(txtpcname & ": Can't create the process. " & ex.Message)
        End Try
        Try
            objManagementScope = Nothing
            objManagementBaseObject.Dispose()
            objManagementClass.Dispose()
        Catch
        End Try
    End Sub

    Private Sub Button163_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button163.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If
        SCCMButton163(username, password, domain, txtpcname)
    End Sub

    Private Sub SCCMButton163(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)
        Dim wmi_out As ManagementBaseObject
        Dim objManagementScope As ManagementScope
        Dim objManagementClass As ManagementClass = Nothing
        Dim objManagementBaseObject As ManagementBaseObject = Nothing
        Dim retValue As Integer

        Dim Command As String = "WMIC /node:" & txtpcname & " /namespace:\\root\ccm path sms_client CALL TriggerSchedule " & Chr(34) & "{00000000-0000-0000-0000-000000000002}" & Chr(34) & " /NOINTERACTIVE"

        Try

            Dim options As ConnectionOptions
            options = New ConnectionOptions()
            Dim computerconnect As String = "\\" & txtpcname & "\root\cimv2:Win32_Process"

            options.Username = txtusername
            options.Password = txtpassword
            options.Timeout = TimeSpan.FromSeconds(30)
            options.Authority = "NTLMDOMAIN:" & txtdomain
            options.Authentication = AuthenticationLevel.PacketPrivacy
            objManagementScope = New ManagementScope(computerconnect, options)

            If objManagementScope.IsConnected = True Then
            Else
                Try
                    objManagementScope.Connect()
                Catch ex As Exception
                    MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                    Exit Sub
                End Try
            End If

            objManagementClass = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
            objManagementClass.Scope = objManagementScope

            objManagementBaseObject = objManagementClass.GetMethodParameters("Create")
            objManagementBaseObject.SetPropertyValue("CommandLine", Command)
            wmi_out = objManagementClass.InvokeMethod("Create", objManagementBaseObject, Nothing)

            'wmi = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
            'wmi_in = wmi.GetMethodParameters("Create")
            'wmi_in("CommandLine") = "cmd /c md c:\temp\temptd"
            'wmi_out = wmi.InvokeMethod("Create", wmi_in, Nothing)

            retValue = Convert.ToInt32(wmi_out("returnValue"))
            Select Case retValue
                Case 0

                Case 2
                    Throw New ApplicationException("Access denied")
                Case 3
                    Throw New ApplicationException("Insufficient privilege")
                Case 8
                    Throw New ApplicationException("Unknown failure")
                Case 9
                    Throw New ApplicationException("Path not found")
                Case 21
                    Throw New ApplicationException("Invalid parameter")
                Case Else
                    Throw New ApplicationException("Unknown return code " & retValue)
            End Select
        Catch ex As Exception
            MsgBox(txtpcname & ": Can't create the process. " & ex.Message)
        End Try
        objManagementScope = Nothing
        objManagementBaseObject.Dispose()
        objManagementClass.Dispose()
    End Sub

    Private Sub Button164_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button164.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If
        SCCMButton164(username, password, domain, txtpcname)
    End Sub

    Private Sub SCCMButton164(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)
        Dim wmi_out As ManagementBaseObject
        Dim objManagementScope As ManagementScope
        Dim objManagementClass As ManagementClass = Nothing
        Dim objManagementBaseObject As ManagementBaseObject = Nothing
        Dim retValue As Integer

        Dim Command As String = "WMIC /node:" & txtpcname & " /namespace:\\root\ccm path sms_client CALL TriggerSchedule " & Chr(34) & "{00000000-0000-0000-0000-000000000003}" & Chr(34) & " /NOINTERACTIVE"

        Try

            Dim options As ConnectionOptions
            options = New ConnectionOptions()
            Dim computerconnect As String = "\\" & txtpcname & "\root\cimv2:Win32_Process"

            options.Username = txtusername
            options.Password = txtpassword
            options.Timeout = TimeSpan.FromSeconds(30)
            options.Authority = "NTLMDOMAIN:" & txtdomain
            options.Authentication = AuthenticationLevel.PacketPrivacy
            objManagementScope = New ManagementScope(computerconnect, options)

            If objManagementScope.IsConnected = True Then
            Else
                Try
                    objManagementScope.Connect()
                Catch ex As Exception
                    MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                    Exit Sub
                End Try
            End If

            objManagementClass = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
            objManagementClass.Scope = objManagementScope

            objManagementBaseObject = objManagementClass.GetMethodParameters("Create")
            objManagementBaseObject.SetPropertyValue("CommandLine", Command)
            wmi_out = objManagementClass.InvokeMethod("Create", objManagementBaseObject, Nothing)

            'wmi = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
            'wmi_in = wmi.GetMethodParameters("Create")
            'wmi_in("CommandLine") = "cmd /c md c:\temp\temptd"
            'wmi_out = wmi.InvokeMethod("Create", wmi_in, Nothing)

            retValue = Convert.ToInt32(wmi_out("returnValue"))
            Select Case retValue
                Case 0

                Case 2
                    Throw New ApplicationException("Access denied")
                Case 3
                    Throw New ApplicationException("Insufficient privilege")
                Case 8
                    Throw New ApplicationException("Unknown failure")
                Case 9
                    Throw New ApplicationException("Path not found")
                Case 21
                    Throw New ApplicationException("Invalid parameter")
                Case Else
                    Throw New ApplicationException("Unknown return code " & retValue)
            End Select
        Catch ex As Exception
            MsgBox(txtpcname & ": Can't create the process. " & ex.Message)
        End Try
        objManagementScope = Nothing
        objManagementBaseObject.Dispose()
        objManagementClass.Dispose()
    End Sub

    Private Sub Button165_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button165.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If
        SCCMButton165(username, password, domain, txtpcname)
    End Sub

    Private Sub SCCMButton165(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)
        Dim wmi_out As ManagementBaseObject
        Dim objManagementScope As ManagementScope
        Dim objManagementClass As ManagementClass = Nothing
        Dim objManagementBaseObject As ManagementBaseObject = Nothing
        Dim retValue As Integer

        Dim Command As String = "WMIC /node:" & txtpcname & " /namespace:\\root\ccm path sms_client CALL TriggerSchedule " & Chr(34) & "{00000000-0000-0000-0000-000000000021}" & Chr(34) & " /NOINTERACTIVE"

        Try

            Dim options As ConnectionOptions
            options = New ConnectionOptions()
            Dim computerconnect As String = "\\" & txtpcname & "\root\cimv2:Win32_Process"

            options.Username = txtusername
            options.Password = txtpassword
            options.Timeout = TimeSpan.FromSeconds(30)
            options.Authority = "NTLMDOMAIN:" & txtdomain
            options.Authentication = AuthenticationLevel.PacketPrivacy
            objManagementScope = New ManagementScope(computerconnect, options)

            If objManagementScope.IsConnected = True Then
            Else
                Try
                    objManagementScope.Connect()
                Catch ex As Exception
                    MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                    Exit Sub
                End Try
            End If

            objManagementClass = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
            objManagementClass.Scope = objManagementScope

            objManagementBaseObject = objManagementClass.GetMethodParameters("Create")
            objManagementBaseObject.SetPropertyValue("CommandLine", Command)
            wmi_out = objManagementClass.InvokeMethod("Create", objManagementBaseObject, Nothing)

            'wmi = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
            'wmi_in = wmi.GetMethodParameters("Create")
            'wmi_in("CommandLine") = "cmd /c md c:\temp\temptd"
            'wmi_out = wmi.InvokeMethod("Create", wmi_in, Nothing)

            retValue = Convert.ToInt32(wmi_out("returnValue"))
            Select Case retValue
                Case 0

                Case 2
                    Throw New ApplicationException("Access denied")
                Case 3
                    Throw New ApplicationException("Insufficient privilege")
                Case 8
                    Throw New ApplicationException("Unknown failure")
                Case 9
                    Throw New ApplicationException("Path not found")
                Case 21
                    Throw New ApplicationException("Invalid parameter")
                Case Else
                    Throw New ApplicationException("Unknown return code " & retValue)
            End Select
        Catch ex As Exception
            MsgBox(txtpcname & ": Can't create the process. " & ex.Message)
        End Try
        objManagementScope = Nothing
        objManagementBaseObject.Dispose()
        objManagementClass.Dispose()
    End Sub

    Private Sub Button167_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button167.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If
        SCCMButton167(username, password, domain, txtpcname)
    End Sub

    Private Sub SCCMButton167(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)

        Dim wmi_out As ManagementBaseObject
        Dim objManagementScope As ManagementScope
        Dim objManagementClass As ManagementClass = Nothing
        Dim objManagementBaseObject As ManagementBaseObject = Nothing
        Dim retValue As Integer

        Dim Command As String = "WMIC /node:" & txtpcname & " /namespace:\\root\ccm path sms_client CALL TriggerSchedule " & Chr(34) & "{00000000-0000-0000-0000-000000000108}" & Chr(34) & " /NOINTERACTIVE"

        Try

            Dim options As ConnectionOptions
            options = New ConnectionOptions()
            Dim computerconnect As String = "\\" & txtpcname & "\root\cimv2:Win32_Process"

            options.Username = txtusername
            options.Password = txtpassword
            options.Timeout = TimeSpan.FromSeconds(30)
            options.Authority = "NTLMDOMAIN:" & txtdomain
            options.Authentication = AuthenticationLevel.PacketPrivacy
            objManagementScope = New ManagementScope(computerconnect, options)

            If objManagementScope.IsConnected = True Then
            Else
                Try
                    objManagementScope.Connect()
                Catch ex As Exception
                    MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                    Exit Sub
                End Try
            End If

            objManagementClass = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
            objManagementClass.Scope = objManagementScope

            objManagementBaseObject = objManagementClass.GetMethodParameters("Create")
            objManagementBaseObject.SetPropertyValue("CommandLine", Command)
            wmi_out = objManagementClass.InvokeMethod("Create", objManagementBaseObject, Nothing)

            'wmi = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
            'wmi_in = wmi.GetMethodParameters("Create")
            'wmi_in("CommandLine") = "cmd /c md c:\temp\temptd"
            'wmi_out = wmi.InvokeMethod("Create", wmi_in, Nothing)

            retValue = Convert.ToInt32(wmi_out("returnValue"))
            Select Case retValue
                Case 0

                Case 2
                    Throw New ApplicationException("Access denied")
                Case 3
                    Throw New ApplicationException("Insufficient privilege")
                Case 8
                    Throw New ApplicationException("Unknown failure")
                Case 9
                    Throw New ApplicationException("Path not found")
                Case 21
                    Throw New ApplicationException("Invalid parameter")
                Case Else
                    Throw New ApplicationException("Unknown return code " & retValue)
            End Select
        Catch ex As Exception
            MsgBox(txtpcname & ": Can't create the process. " & ex.Message)
        End Try
        objManagementScope = Nothing
        objManagementBaseObject.Dispose()
        objManagementClass.Dispose()
    End Sub

    Private Sub Button9162_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GLRT001.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If
        Label001.Text = "00:00:00"

        Dim LastHWDate As DateTime

        Dim objManagementScope As ManagementScope
        Dim options As ConnectionOptions
        options = New ConnectionOptions()
        Dim computerconnect As String = "\\" & txtpcname & "\root\ccm\invagt"

        options.Username = username
        options.Password = password
        options.Timeout = TimeSpan.FromSeconds(30)
        options.Authority = "NTLMDOMAIN:" & domain
        options.Authentication = AuthenticationLevel.PacketPrivacy
        objManagementScope = New ManagementScope(computerconnect, options)

        If objManagementScope.IsConnected = True Then
        Else
            Try
                objManagementScope.Connect()
            Catch ex As Exception
                MessageBox.Show("Couldn't connect: " + ex.Message, "Error , Please check pc online and SCCM Agent is installed!")
                PCNAME.Focus()
                Exit Sub
            End Try
        End If
        Try
            Dim query As New SelectQuery("Select * From InventoryActionStatus where InventoryActionID = '{00000000-0000-0000-0000-000000000001}'")
            Dim searcher As New ManagementObjectSearcher(objManagementScope, query)
            For Each mo As ManagementObject In searcher.[Get]()
                LastHWDate = System.Management.ManagementDateTimeConverter.ToDateTime(mo("LastCycleStartedDate").ToString)
                Label001.Text = LastHWDate
            Next
        Catch ex As Exception
            MessageBox.Show("Unable to connect to SCCM Agent, Please check AGent is Installed!")
        End Try

        objManagementScope = Nothing

    End Sub

    Private Sub GLRT002_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GLRT002.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        Label002.Text = "00:00:00"

        Dim LastHWDate As DateTime

        Dim objManagementScope As ManagementScope
        Dim options As ConnectionOptions
        options = New ConnectionOptions()
        Dim computerconnect As String = "\\" & txtpcname & "\root\ccm\invagt"

        options.Username = username
        options.Password = password
        options.Timeout = TimeSpan.FromSeconds(30)
        options.Authority = "NTLMDOMAIN:" & domain
        options.Authentication = AuthenticationLevel.PacketPrivacy
        objManagementScope = New ManagementScope(computerconnect, options)

        If objManagementScope.IsConnected = True Then
        Else
            Try
                objManagementScope.Connect()
            Catch ex As Exception
                MessageBox.Show("Couldn't connect: " + ex.Message, "Error , Please check pc online and SCCM Agent is installed!")
                PCNAME.Focus()
                Exit Sub
            End Try
        End If
        Try
            Dim query As New SelectQuery("Select * From InventoryActionStatus where InventoryActionID = '{00000000-0000-0000-0000-000000000002}'")
            Dim searcher As New ManagementObjectSearcher(objManagementScope, query)
            For Each mo As ManagementObject In searcher.[Get]()
                LastHWDate = System.Management.ManagementDateTimeConverter.ToDateTime(mo("LastCycleStartedDate").ToString)
                Label002.Text = LastHWDate
            Next
        Catch ex As Exception
            MessageBox.Show("Unable to connect to SCCM Agent, Please check AGent is Installed!")
        End Try

        objManagementScope = Nothing

    End Sub

    Private Sub GLRT003_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GLRT003.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If
        Label003.Text = "00:00:00"

        Dim LastHWDate As DateTime

        Dim objManagementScope As ManagementScope
        Dim options As ConnectionOptions
        options = New ConnectionOptions()
        Dim computerconnect As String = "\\" & txtpcname & "\root\ccm\invagt"

        options.Username = username
        options.Password = password
        options.Timeout = TimeSpan.FromSeconds(30)
        options.Authority = "NTLMDOMAIN:" & domain
        options.Authentication = AuthenticationLevel.PacketPrivacy
        objManagementScope = New ManagementScope(computerconnect, options)

        If objManagementScope.IsConnected = True Then
        Else
            Try
                objManagementScope.Connect()
            Catch ex As Exception
                MessageBox.Show("Couldn't connect: " + ex.Message, "Error , Please check pc online and SCCM Agent is installed!")
                PCNAME.Focus()
                Exit Sub
            End Try
        End If
        Try
            Dim query As New SelectQuery("Select * From InventoryActionStatus where InventoryActionID = '{00000000-0000-0000-0000-000000000003}'")
            Dim searcher As New ManagementObjectSearcher(objManagementScope, query)
            For Each mo As ManagementObject In searcher.[Get]()
                LastHWDate = System.Management.ManagementDateTimeConverter.ToDateTime(mo("LastCycleStartedDate").ToString)
                Label003.Text = LastHWDate
            Next
        Catch ex As Exception
            MessageBox.Show("Unable to connect to SCCM Agent, Please check AGent is Installed!")
        End Try

        objManagementScope = Nothing
    End Sub

    Private Sub Button168_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button168.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If
        SCCMButton168(username, password, domain, txtpcname)
    End Sub

    Private Sub SCCMButton168(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)
        Dim wmi_out As ManagementBaseObject
        Dim objManagementScope As ManagementScope
        Dim objManagementClass As ManagementClass = Nothing
        Dim objManagementBaseObject As ManagementBaseObject = Nothing
        Dim retValue As Integer

        Dim Command As String = "WMIC /node:" & txtpcname & " /namespace:\\root\ccm path sms_client CALL TriggerSchedule " & Chr(34) & "{00000000-0000-0000-0000-000000000113}" & Chr(34) & " /NOINTERACTIVE"

        Try

            Dim options As ConnectionOptions
            options = New ConnectionOptions()
            Dim computerconnect As String = "\\" & txtpcname & "\root\cimv2:Win32_Process"

            options.Username = txtusername
            options.Password = txtpassword
            options.Timeout = TimeSpan.FromSeconds(30)
            options.Authority = "NTLMDOMAIN:" & txtdomain
            options.Authentication = AuthenticationLevel.PacketPrivacy
            objManagementScope = New ManagementScope(computerconnect, options)

            If objManagementScope.IsConnected = True Then
            Else
                Try
                    objManagementScope.Connect()
                Catch ex As Exception
                    MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                    Exit Sub
                End Try
            End If

            objManagementClass = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
            objManagementClass.Scope = objManagementScope

            objManagementBaseObject = objManagementClass.GetMethodParameters("Create")
            objManagementBaseObject.SetPropertyValue("CommandLine", Command)
            wmi_out = objManagementClass.InvokeMethod("Create", objManagementBaseObject, Nothing)

            'wmi = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
            'wmi_in = wmi.GetMethodParameters("Create")
            'wmi_in("CommandLine") = "cmd /c md c:\temp\temptd"
            'wmi_out = wmi.InvokeMethod("Create", wmi_in, Nothing)

            retValue = Convert.ToInt32(wmi_out("returnValue"))
            Select Case retValue
                Case 0

                Case 2
                    Throw New ApplicationException("Access denied")
                Case 3
                    Throw New ApplicationException("Insufficient privilege")
                Case 8
                    Throw New ApplicationException("Unknown failure")
                Case 9
                    Throw New ApplicationException("Path not found")
                Case 21
                    Throw New ApplicationException("Invalid parameter")
                Case Else
                    Throw New ApplicationException("Unknown return code " & retValue)
            End Select
        Catch ex As Exception
            MsgBox(txtpcname & ": Can't create the process. " & ex.Message)
        End Try
        Try
            objManagementScope = Nothing
            objManagementBaseObject.Dispose()
            objManagementClass.Dispose()
        Catch
        End Try

    End Sub

    Private Sub Button169_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button169.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If
        SCCMButton169(username, password, domain, txtpcname)
    End Sub

    Private Sub SCCMButton169(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)
        Dim wmi_out As ManagementBaseObject
        Dim objManagementScope As ManagementScope
        Dim objManagementClass As ManagementClass = Nothing
        Dim objManagementBaseObject As ManagementBaseObject = Nothing
        Dim retValue As Integer

        Dim Command As String = "WMIC /node:" & txtpcname & " /namespace:\\root\ccm path sms_client CALL TriggerSchedule " & Chr(34) & "{00000000-0000-0000-0000-000000000010}" & Chr(34) & " /NOINTERACTIVE"

        Try

            Dim options As ConnectionOptions
            options = New ConnectionOptions()
            Dim computerconnect As String = "\\" & txtpcname & "\root\cimv2:Win32_Process"

            options.Username = txtusername
            options.Password = txtpassword
            options.Timeout = TimeSpan.FromSeconds(30)
            options.Authority = "NTLMDOMAIN:" & txtdomain
            options.Authentication = AuthenticationLevel.PacketPrivacy
            objManagementScope = New ManagementScope(computerconnect, options)

            If objManagementScope.IsConnected = True Then
            Else
                Try
                    objManagementScope.Connect()
                Catch ex As Exception
                    MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                    Exit Sub
                End Try
            End If

            objManagementClass = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
            objManagementClass.Scope = objManagementScope

            objManagementBaseObject = objManagementClass.GetMethodParameters("Create")
            objManagementBaseObject.SetPropertyValue("CommandLine", Command)
            wmi_out = objManagementClass.InvokeMethod("Create", objManagementBaseObject, Nothing)

            'wmi = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
            'wmi_in = wmi.GetMethodParameters("Create")
            'wmi_in("CommandLine") = "cmd /c md c:\temp\temptd"
            'wmi_out = wmi.InvokeMethod("Create", wmi_in, Nothing)

            retValue = Convert.ToInt32(wmi_out("returnValue"))
            Select Case retValue
                Case 0

                Case 2
                    Throw New ApplicationException("Access denied")
                Case 3
                    Throw New ApplicationException("Insufficient privilege")
                Case 8
                    Throw New ApplicationException("Unknown failure")
                Case 9
                    Throw New ApplicationException("Path not found")
                Case 21
                    Throw New ApplicationException("Invalid parameter")
                Case Else
                    Throw New ApplicationException("Unknown return code " & retValue)
            End Select
        Catch ex As Exception
            MsgBox(txtpcname & ": Can't create the process. " & ex.Message)
        End Try
        Try
            objManagementScope = Nothing
            objManagementBaseObject.Dispose()
            objManagementClass.Dispose()
        Catch
        End Try

    End Sub

    Private Sub Button170_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button170.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If
        SCCMButton170(username, password, domain, txtpcname)
    End Sub

    Private Sub SCCMButton170(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)
        Dim wmi_out As ManagementBaseObject
        Dim objManagementScope As ManagementScope
        Dim objManagementClass As ManagementClass = Nothing
        Dim objManagementBaseObject As ManagementBaseObject = Nothing
        Dim retValue As Integer

        Dim Command As String = "WMIC /node:" & txtpcname & " /namespace:\\root\ccm path sms_client CALL TriggerSchedule " & Chr(34) & "{00000000-0000-0000-0000-000000000032}" & Chr(34) & " /NOINTERACTIVE"

        Try

            Dim options As ConnectionOptions
            options = New ConnectionOptions()
            Dim computerconnect As String = "\\" & txtpcname & "\root\cimv2:Win32_Process"

            options.Username = txtusername
            options.Password = txtpassword
            options.Timeout = TimeSpan.FromSeconds(30)
            options.Authority = "NTLMDOMAIN:" & txtdomain
            options.Authentication = AuthenticationLevel.PacketPrivacy
            objManagementScope = New ManagementScope(computerconnect, options)

            If objManagementScope.IsConnected = True Then
            Else
                Try
                    objManagementScope.Connect()
                Catch ex As Exception
                    MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                    Exit Sub
                End Try
            End If

            objManagementClass = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
            objManagementClass.Scope = objManagementScope

            objManagementBaseObject = objManagementClass.GetMethodParameters("Create")
            objManagementBaseObject.SetPropertyValue("CommandLine", Command)
            wmi_out = objManagementClass.InvokeMethod("Create", objManagementBaseObject, Nothing)

            'wmi = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
            'wmi_in = wmi.GetMethodParameters("Create")
            'wmi_in("CommandLine") = "cmd /c md c:\temp\temptd"
            'wmi_out = wmi.InvokeMethod("Create", wmi_in, Nothing)

            retValue = Convert.ToInt32(wmi_out("returnValue"))
            Select Case retValue
                Case 0

                Case 2
                    Throw New ApplicationException("Access denied")
                Case 3
                    Throw New ApplicationException("Insufficient privilege")
                Case 8
                    Throw New ApplicationException("Unknown failure")
                Case 9
                    Throw New ApplicationException("Path not found")
                Case 21
                    Throw New ApplicationException("Invalid parameter")
                Case Else
                    Throw New ApplicationException("Unknown return code " & retValue)
            End Select
        Catch ex As Exception
            MsgBox(txtpcname & ": Can't create the process. " & ex.Message)
        End Try

        Try
            objManagementScope = Nothing
            objManagementBaseObject.Dispose()
            objManagementClass.Dispose()
        Catch
        End Try

    End Sub

    Private Sub Button171_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button171.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If
        SCCMButton171(username, password, domain, txtpcname)
    End Sub

    Private Sub SCCMButton171(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)
        Dim wmi_out As ManagementBaseObject
        Dim objManagementScope As ManagementScope
        Dim objManagementClass As ManagementClass = Nothing
        Dim objManagementBaseObject As ManagementBaseObject = Nothing
        Dim retValue As Integer

        Dim Command As String = "WMIC /node:" & txtpcname & " /namespace:\\root\ccm path sms_client CALL TriggerSchedule " & Chr(34) & "{00000000-0000-0000-0000-000000000031}" & Chr(34) & " /NOINTERACTIVE"

        Try

            Dim options As ConnectionOptions
            options = New ConnectionOptions()
            Dim computerconnect As String = "\\" & txtpcname & "\root\cimv2:Win32_Process"

            options.Username = txtusername
            options.Password = txtpassword
            options.Timeout = TimeSpan.FromSeconds(30)
            options.Authority = "NTLMDOMAIN:" & txtdomain
            options.Authentication = AuthenticationLevel.PacketPrivacy
            objManagementScope = New ManagementScope(computerconnect, options)

            If objManagementScope.IsConnected = True Then
            Else
                Try
                    objManagementScope.Connect()
                Catch ex As Exception
                    MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                    Exit Sub
                End Try
            End If

            objManagementClass = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
            objManagementClass.Scope = objManagementScope

            objManagementBaseObject = objManagementClass.GetMethodParameters("Create")
            objManagementBaseObject.SetPropertyValue("CommandLine", Command)
            wmi_out = objManagementClass.InvokeMethod("Create", objManagementBaseObject, Nothing)

            'wmi = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
            'wmi_in = wmi.GetMethodParameters("Create")
            'wmi_in("CommandLine") = "cmd /c md c:\temp\temptd"
            'wmi_out = wmi.InvokeMethod("Create", wmi_in, Nothing)

            retValue = Convert.ToInt32(wmi_out("returnValue"))
            Select Case retValue
                Case 0

                Case 2
                    Throw New ApplicationException("Access denied")
                Case 3
                    Throw New ApplicationException("Insufficient privilege")
                Case 8
                    Throw New ApplicationException("Unknown failure")
                Case 9
                    Throw New ApplicationException("Path not found")
                Case 21
                    Throw New ApplicationException("Invalid parameter")
                Case Else
                    Throw New ApplicationException("Unknown return code " & retValue)
            End Select
        Catch ex As Exception
            MsgBox(txtpcname & ": Can't create the process. " & ex.Message)
        End Try

        Try
            objManagementScope = Nothing
            objManagementBaseObject.Dispose()
            objManagementClass.Dispose()
        Catch
        End Try

    End Sub

    Private Sub Button172_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button172.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If
        SCCMButton172(username, password, domain, txtpcname)
    End Sub

    Private Sub SCCMButton172(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)
        Dim wmi_out As ManagementBaseObject
        Dim objManagementScope As ManagementScope
        Dim objManagementClass As ManagementClass = Nothing
        Dim objManagementBaseObject As ManagementBaseObject = Nothing
        Dim retValue As Integer

        Dim Command As String = "WMIC /node:" & txtpcname & " /namespace:\\root\ccm path sms_client CALL TriggerSchedule " & Chr(34) & "{00000000-0000-0000-0000-000000000061}" & Chr(34) & " /NOINTERACTIVE"

        Try

            Dim options As ConnectionOptions
            options = New ConnectionOptions()
            Dim computerconnect As String = "\\" & txtpcname & "\root\cimv2:Win32_Process"

            options.Username = txtusername
            options.Password = txtpassword
            options.Timeout = TimeSpan.FromSeconds(30)
            options.Authority = "NTLMDOMAIN:" & txtdomain
            options.Authentication = AuthenticationLevel.PacketPrivacy
            objManagementScope = New ManagementScope(computerconnect, options)

            If objManagementScope.IsConnected = True Then
            Else
                Try
                    objManagementScope.Connect()
                Catch ex As Exception
                    MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                    Exit Sub
                End Try
            End If

            objManagementClass = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
            objManagementClass.Scope = objManagementScope

            objManagementBaseObject = objManagementClass.GetMethodParameters("Create")
            objManagementBaseObject.SetPropertyValue("CommandLine", Command)
            wmi_out = objManagementClass.InvokeMethod("Create", objManagementBaseObject, Nothing)

            'wmi = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
            'wmi_in = wmi.GetMethodParameters("Create")
            'wmi_in("CommandLine") = "cmd /c md c:\temp\temptd"
            'wmi_out = wmi.InvokeMethod("Create", wmi_in, Nothing)

            retValue = Convert.ToInt32(wmi_out("returnValue"))
            Select Case retValue
                Case 0

                Case 2
                    Throw New ApplicationException("Access denied")
                Case 3
                    Throw New ApplicationException("Insufficient privilege")
                Case 8
                    Throw New ApplicationException("Unknown failure")
                Case 9
                    Throw New ApplicationException("Path not found")
                Case 21
                    Throw New ApplicationException("Invalid parameter")
                Case Else
                    Throw New ApplicationException("Unknown return code " & retValue)
            End Select
        Catch ex As Exception
            MsgBox(txtpcname & ": Can't create the process. " & ex.Message)
        End Try

        Try
            objManagementScope = Nothing
            objManagementBaseObject.Dispose()
            objManagementClass.Dispose()
        Catch
        End Try

    End Sub

    Private Sub Button173_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button173.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If
        SCCMButton173(username, password, domain, txtpcname)
    End Sub

    Private Sub SCCMButton173(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)
        Dim wmi_out As ManagementBaseObject
        Dim objManagementScope As ManagementScope
        Dim objManagementClass As ManagementClass = Nothing
        Dim objManagementBaseObject As ManagementBaseObject = Nothing
        Dim retValue As Integer

        Dim Command As String = "WMIC /node:" & txtpcname & " /namespace:\\root\ccm path sms_client CALL RepairClient"

        Try

            Dim options As ConnectionOptions
            options = New ConnectionOptions()
            Dim computerconnect As String = "\\" & txtpcname & "\root\cimv2:Win32_Process"

            options.Username = txtusername
            options.Password = txtpassword
            options.Timeout = TimeSpan.FromSeconds(30)
            options.Authority = "NTLMDOMAIN:" & txtdomain
            options.Authentication = AuthenticationLevel.PacketPrivacy
            objManagementScope = New ManagementScope(computerconnect, options)

            If objManagementScope.IsConnected = True Then
            Else
                Try
                    objManagementScope.Connect()
                Catch ex As Exception
                    MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                    Exit Sub
                End Try
            End If

            objManagementClass = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
            objManagementClass.Scope = objManagementScope

            objManagementBaseObject = objManagementClass.GetMethodParameters("Create")
            objManagementBaseObject.SetPropertyValue("CommandLine", Command)
            wmi_out = objManagementClass.InvokeMethod("Create", objManagementBaseObject, Nothing)

            'wmi = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
            'wmi_in = wmi.GetMethodParameters("Create")
            'wmi_in("CommandLine") = "cmd /c md c:\temp\temptd"
            'wmi_out = wmi.InvokeMethod("Create", wmi_in, Nothing)

            retValue = Convert.ToInt32(wmi_out("returnValue"))
            Select Case retValue
                Case 0

                Case 2
                    Throw New ApplicationException("Access denied")
                Case 3
                    Throw New ApplicationException("Insufficient privilege")
                Case 8
                    Throw New ApplicationException("Unknown failure")
                Case 9
                    Throw New ApplicationException("Path not found")
                Case 21
                    Throw New ApplicationException("Invalid parameter")
                Case Else
                    Throw New ApplicationException("Unknown return code " & retValue)
            End Select
        Catch ex As Exception
            MsgBox(txtpcname & ": Can't create the process. " & ex.Message)
        End Try

        Try
            objManagementScope = Nothing
            objManagementBaseObject.Dispose()
            objManagementClass.Dispose()
        Catch
        End Try

    End Sub

    Private Sub ChangeCacheSizeButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ChangeCacheSizeButton.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        Dim CacheSize As String = Nothing

        Dim objManagementScope As ManagementScope
        Dim options As ConnectionOptions
        options = New ConnectionOptions()
        Dim computerconnect As String = "\\" & txtpcname & "\root\ccm\SoftMgmtAgent"

        options.Username = username
        options.Password = password
        options.Timeout = TimeSpan.FromSeconds(30)
        options.Authority = "NTLMDOMAIN:" & domain
        options.Authentication = AuthenticationLevel.PacketPrivacy
        objManagementScope = New ManagementScope(computerconnect, options)

        If objManagementScope.IsConnected = True Then
        Else
            Try
                objManagementScope.Connect()
            Catch ex As Exception
                MessageBox.Show("Couldn't connect: " + ex.Message, "Error , Please check pc online and SCCM Agent is installed!")
                PCNAME.Focus()
                Exit Sub
            End Try
        End If

        CacheSize = CacheChangeSize.Text
        CacheSize = CDbl(CacheSize)
        'MsgBox(CacheSize)
        If CacheSize < 5000 Then
            MessageBox.Show("You cannot set the cache size < 5000MB")
            PCNAME.Focus()
            Exit Sub
        Else
            Dim response As MsgBoxResult
            response = MsgBox("Please check you have enough free disk space on the drive before you force the cache size to : " & CacheSize & "MB. Please click 'YES' if you have checked the disk space available and wish to continue. The SCCM Client Service will be restarted taking approx 15 secs, Please wait for it to restart! Continue at your own risk!", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "Confirm")
            If response = MsgBoxResult.Yes Then
                Try
                    Dim QueryOptions = New EnumerationOptions
                    QueryOptions.Timeout = New TimeSpan(0, 0, 10)
                    Dim query As New SelectQuery("SELECT * FROM CacheConfig")
                    Dim searcher As New ManagementObjectSearcher(objManagementScope, query, QueryOptions)
                    For Each mo As ManagementObject In searcher.[Get]()
                        mo("Size") = CacheSize
                        mo.Put()

                        Try
                            Dim objManagementScope2 As ManagementScope
                            Dim options2 As ConnectionOptions
                            options2 = New ConnectionOptions()
                            Dim computerconnect2 As String = "\\" & txtpcname & "\root\cimv2"

                            options2.Username = username
                            options2.Password = password
                            options2.Timeout = TimeSpan.FromSeconds(30)
                            options2.Authority = "NTLMDOMAIN:" & domain
                            options2.Authentication = AuthenticationLevel.PacketPrivacy
                            objManagementScope2 = New ManagementScope(computerconnect2, options2)

                            If objManagementScope2.IsConnected = True Then
                            Else
                                Try
                                    objManagementScope2.Connect()
                                Catch ex As Exception
                                    MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                                    PCNAME.Focus()
                                    Exit Sub
                                End Try
                            End If

                            ' define a select query
                            Dim query2 As New SelectQuery("SELECT * FROM Win32_Service Where Name='CcmExec'")
                            Dim searcher2 As New ManagementObjectSearcher(objManagementScope2, query2, QueryOptions)
                            Dim args As Object = Nothing
                            Try
                                For Each mo2 As ManagementObject In searcher2.[Get]()
                                    mo2.InvokeMethod("StopService", args)
                                    System.Threading.Thread.Sleep(10000)
                                    mo2.InvokeMethod("StartService", args)
                                    System.Threading.Thread.Sleep(3000)
                                Next
                            Catch ex As Exception
                                MsgBox(ex.Message)
                                PCNAME.Focus()
                            End Try

                        Catch ex As Exception
                            MsgBox(ex.Message)
                            PCNAME.Focus()
                        End Try
                    Next

                Catch ex As Exception
                    MessageBox.Show("Unable to connect to SCCM Agent, Please check AGent is Installed!")
                    PCNAME.Focus()
                End Try
                PCNAME.Focus()

            ElseIf response = MsgBoxResult.No Then
                PCNAME.Focus()
                Exit Sub
            End If
        End If

        Try
            objManagementScope = Nothing
        Catch
        End Try

    End Sub

    Private Sub ChangeCacheDirectory_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ChangeCacheDirectory.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        Dim CacheLocation As String = Nothing

        Dim objManagementScope As ManagementScope
        Dim options As ConnectionOptions
        options = New ConnectionOptions()
        Dim computerconnect As String = "\\" & txtpcname & "\root\ccm\SoftMgmtAgent"

        options.Username = username
        options.Password = password
        options.Timeout = TimeSpan.FromSeconds(30)
        options.Authority = "NTLMDOMAIN:" & domain
        options.Authentication = AuthenticationLevel.PacketPrivacy
        objManagementScope = New ManagementScope(computerconnect, options)

        If objManagementScope.IsConnected = True Then
        Else
            Try
                objManagementScope.Connect()
            Catch ex As Exception
                MessageBox.Show("Couldn't connect: " + ex.Message, "Error , Please check pc online and SCCM Agent is installed!")
                PCNAME.Focus()
                Exit Sub
            End Try
        End If

        CacheLocation = CacheDirectoryChange.Text

        Dim response As MsgBoxResult
        response = MsgBox("Please check you have a valid drive selected before you force the cache location change to : " & CacheLocation & " , Please click 'YES' if you have checked the drive letter is available and has enough space! The SCCM Client Service will be restarted taking approx 15 secs, Please wait for it to restart! Continue at your own risk!", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "Confirm")
        If response = MsgBoxResult.Yes Then
            Try
                Dim QueryOptions = New EnumerationOptions
                QueryOptions.Timeout = New TimeSpan(0, 0, 10)
                Dim query As New SelectQuery("SELECT * FROM CacheConfig")
                Dim searcher As New ManagementObjectSearcher(objManagementScope, query, QueryOptions)
                For Each mo As ManagementObject In searcher.[Get]()
                    mo("Location") = CacheLocation
                    mo.Put()

                    Try
                        Dim objManagementScope2 As ManagementScope
                        Dim options2 As ConnectionOptions
                        options2 = New ConnectionOptions()
                        Dim computerconnect2 As String = "\\" & txtpcname & "\root\cimv2"

                        options2.Username = username
                        options2.Password = password
                        options2.Timeout = TimeSpan.FromSeconds(30)
                        options2.Authority = "NTLMDOMAIN:" & domain
                        options2.Authentication = AuthenticationLevel.PacketPrivacy
                        objManagementScope2 = New ManagementScope(computerconnect2, options2)

                        If objManagementScope2.IsConnected = True Then
                        Else
                            Try
                                objManagementScope2.Connect()
                            Catch ex As Exception
                                MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                                PCNAME.Focus()
                                Exit Sub
                            End Try
                        End If

                        ' define a select query
                        Dim query2 As New SelectQuery("SELECT * FROM Win32_Service Where Name='CcmExec'")
                        Dim searcher2 As New ManagementObjectSearcher(objManagementScope2, query2, QueryOptions)
                        Dim args As Object = Nothing
                        Try
                            For Each mo2 As ManagementObject In searcher2.[Get]()
                                mo2.InvokeMethod("StopService", args)
                                System.Threading.Thread.Sleep(10000)
                                mo2.InvokeMethod("StartService", args)
                                System.Threading.Thread.Sleep(3000)
                            Next
                        Catch ex As Exception
                            MsgBox(ex.Message)
                            PCNAME.Focus()
                        End Try

                    Catch ex As Exception
                        MsgBox(ex.Message)
                        PCNAME.Focus()
                    End Try
                Next

            Catch ex As Exception
                MessageBox.Show("Unable to connect to SCCM Agent, Please check AGent is Installed!")
                PCNAME.Focus()
            End Try
            PCNAME.Focus()

        ElseIf response = MsgBoxResult.No Then
            PCNAME.Focus()
            Exit Sub
        End If

        Try
            objManagementScope = Nothing
        Catch
        End Try

    End Sub

    Private Sub Button66_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button66.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        FileTypes.Items.Clear()
        GETAPPVASSOC(username, password, domain, txtpcname)
        PCNAME.Focus()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        FileTypes.Items.Clear()
        GETAPPVFTYPE(username, password, domain, txtpcname)
        PCNAME.Focus()
    End Sub

    Private Sub OpenAPPVlog_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        Try
            MapDriveAdmin(username, password, domain, txtpcname)

            Dim myValue As String = Nothing
            Dim OpenAPPVlogfileName As String = Nothing
            Dim objShell = CreateObject("Wscript.Shell")
            myValue = OpenAPPVlogfile(username, password, domain, txtpcname)
            myValue = myValue.Replace("C:", "C$")

            OpenAPPVlogfileName = "\\" & txtpcname & "\" & myValue
            objShell.run("""" & OpenAPPVlogfileName & """")

            MapDriveAdminRemove(username, password, domain, txtpcname)
        Catch ex As Exception
        End Try

        PCNAME.Focus()

    End Sub

    Function OpenAPPVlogfile(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)

        Dim strComputerName As String = txtpcname
        Dim strStringValue As String = ""
        Dim strKeyPath As String = "SOFTWARE\Microsoft\SoftGrid\4.5\Client\Configuration"
        Dim strKeyPath64 As String = "SOFTWARE\WOW6432node\Microsoft\SoftGrid\4.5\Client\Configuration"
        Dim objManagementScope As ManagementScope
        Dim objManagementClass As ManagementClass = Nothing
        Dim objManagementBaseObject As ManagementBaseObject = Nothing
        Dim myValue As String = Nothing
        Dim intRegistryHive As Microsoft.Win32.RegistryHive
        intRegistryHive = Microsoft.Win32.RegistryHive.LocalMachine

        Dim options As ConnectionOptions
        options = New ConnectionOptions()
        Dim computerconnect As String = "\\" & txtpcname & "\root\DEFAULT"

        options.Username = txtusername
        options.Password = txtpassword
        options.Timeout = TimeSpan.FromSeconds(30)
        options.Authority = "NTLMDOMAIN:" & txtdomain
        options.Authentication = AuthenticationLevel.PacketPrivacy
        objManagementScope = New ManagementScope(computerconnect, options)

        If objManagementScope.IsConnected = True Then
        Else
            Try
                objManagementScope.Connect()
            Catch ex As Exception
                Return "Error connecting to machine!"
                Exit Function
            End Try
        End If

        Try
            objManagementClass = New ManagementClass("stdRegProv")
            objManagementClass.Scope = objManagementScope
            objManagementBaseObject = objManagementClass.GetMethodParameters("GetStringValue")
            objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
            objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath)
            objManagementBaseObject.SetPropertyValue("sValueName", "LogFileName")
            objManagementBaseObject = objManagementClass.InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
            myValue = objManagementBaseObject("sValue")
        Catch
        End Try

        If myValue = "" Then
            Try
                objManagementClass = New ManagementClass("stdRegProv")
                objManagementClass.Scope = objManagementScope
                objManagementBaseObject = objManagementClass.GetMethodParameters("GetStringValue")
                objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath64)
                objManagementBaseObject.SetPropertyValue("sValueName", "LogFileName")
                objManagementBaseObject = objManagementClass.InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                myValue = objManagementBaseObject("sValue")
            Catch
            End Try
        End If

        Try
            objManagementScope = Nothing
            objManagementBaseObject.Dispose()
            objManagementClass.Dispose()
        Catch
        End Try

        Return myValue
    End Function

    Private Sub Purchase_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Purchase.Click
        BackgroundWorkerSpinnerStopWorker()

        Process.Start("https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=4RQRKFB2CP3MA")

    End Sub

    Private Sub CompMgmt_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CompMgmt.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Dim strUsername As String
        Dim strPassword As String
        strUsername = domain & "\" & username
        strPassword = password

        Dim oNet = CreateObject("WScript.Network")
        Try
            oNet.RemoveNetworkDrive("\\" & txtpcname & "\ipc$", True, False)
            oNet.RemoveNetworkDrive("\\" & txtpcname & "\admin$", True, False)
        Catch
        End Try
        oNet.MapNetworkDrive("", "\\" & txtpcname & "\ipc$", False, strUsername, strPassword)

        PCNAME.Focus()

        Dim sResult As String
        Dim objShell = CreateObject("Wscript.Shell")
        Dim path2 As String = Directory.GetCurrentDirectory()
        Try
            sResult = objShell.run("c:\windows\system32\Compmgmt.msc /Computer:" & txtpcname, 1, False)
        Catch ex As Exception
        End Try
        Try
            ' dismount the previously mounted secure channel
            oNet.RemoveNetworkDrive("\\" & txtpcname & "\ipc$", True, False)
        Catch ex As Exception
        End Try

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()

    End Sub

    Private Sub userlistbutton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles userlistbutton.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        Userlist.Items.Clear()

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Try
            Dim options2 As ConnectionOptions
            options2 = New ConnectionOptions()
            Dim computerconnect2 As String = "\\" & txtpcname & "\root\cimv2"
            options2.Username = username
            options2.Password = password
            options2.Timeout = TimeSpan.FromSeconds(30)
            options2.Authority = "NTLMDOMAIN:" & domain
            options2.Authentication = AuthenticationLevel.PacketPrivacy
            Dim msc As ManagementScope = New ManagementScope(computerconnect2, options2)
            Dim query_command As String = "Select * from Win32_UserAccount Where LocalAccount='True'"
            Dim select_query As SelectQuery = New SelectQuery(query_command)
            Dim Srch As New ManagementObjectSearcher(msc, select_query)
            Dim objMgmt As ManagementObject
            For Each objMgmt In Srch.Get
                Dim s(1) As String
                Userlist.Items.Add(objMgmt.GetPropertyValue("Name"))
            Next

            Try
                objMgmt = Nothing
            Catch
            End Try

        Catch ex As Exception
        End Try

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()

        PCNAME.Focus()

    End Sub

    Private Sub Refreshuserslist()

        Userlist.Items.Clear()
        Try
            Dim options2 As ConnectionOptions
            options2 = New ConnectionOptions()
            Dim computerconnect2 As String = "\\" & txtpcname & "\root\cimv2"
            options2.Username = username
            options2.Password = password
            options2.Timeout = TimeSpan.FromSeconds(30)
            options2.Authority = "NTLMDOMAIN:" & domain
            options2.Authentication = AuthenticationLevel.PacketPrivacy
            Dim msc As ManagementScope = New ManagementScope(computerconnect2, options2)
            Dim query_command As String = "Select * from Win32_UserAccount Where LocalAccount='True'"
            Dim select_query As SelectQuery = New SelectQuery(query_command)
            Dim Srch As New ManagementObjectSearcher(msc, select_query)
            Dim objMgmt As ManagementObject
            For Each objMgmt In Srch.Get
                Dim s(1) As String
                Userlist.Items.Add(objMgmt.GetPropertyValue("Name"))
            Next
        Catch ex As Exception
        End Try

        PCNAME.Focus()
    End Sub

    Private Sub OtherUpdates_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OtherUpdates.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Dim strComputerName As String = txtpcname
        Dim strStringValue As String = ""
        Dim strKeyPath As String = "SOFTWARE\Microsoft\Windows\CurrentVersion\Installer\UserData\S-1-5-18\Products\"
        Dim objManagementScope As ManagementScope = Nothing
        Dim objManagementClass As ManagementClass = Nothing
        Dim objManagementBaseObject As ManagementBaseObject = Nothing
        Dim strkey As String
        Dim strkey2 As String
        Dim myKey2 As String
        Dim myValue As String
        Dim myValue1 As String
        Dim myValue2 As String
        Dim aSubKeys() As String
        Dim aSubKeys2() As String
        Dim intRegistryHive As Microsoft.Win32.RegistryHive
        intRegistryHive = Microsoft.Win32.RegistryHive.LocalMachine

        UpdatesLabel.Text = Nothing
        UpdatesLabel.Text = "Displaying Other Updates"

        DataGridView10.Rows.Clear()
        KBTextBox.Text = ""

        Dim options As ConnectionOptions
        options = New ConnectionOptions()
        Dim computerconnect As String = "\\" & txtpcname & "\root\DEFAULT"

        options.Username = username
        options.Password = password
        options.Timeout = TimeSpan.FromSeconds(30)
        options.Authority = "NTLMDOMAIN:" & domain
        options.Authentication = AuthenticationLevel.PacketPrivacy
        objManagementScope = New ManagementScope(computerconnect, options)

        If objManagementScope.IsConnected = True Then
        Else
            Try
                objManagementScope.Connect()
            Catch ex As Exception
                MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                BackgroundWorkerSpinner.CancelAsync()
                MetroProgressBar.Hide()
                PCNAME.Focus()
                Exit Sub
            End Try
        End If

        Try
            objManagementClass = New ManagementClass("stdRegProv")
            objManagementClass.Scope = objManagementScope
            objManagementBaseObject = objManagementClass.GetMethodParameters("EnumKey")
            objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
            objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath)
            aSubKeys = CType(objManagementClass.InvokeMethod("EnumKey", objManagementBaseObject, Nothing).Properties.Item("sNames").Value, String())
            Try
                For Each strkey In aSubKeys
                    objManagementClass = New ManagementClass("stdRegProv")
                    objManagementClass.Scope = objManagementScope
                    objManagementBaseObject = objManagementClass.GetMethodParameters("EnumKey")
                    objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                    objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath & strkey & "\Patches")
                    aSubKeys2 = CType(objManagementClass.InvokeMethod("EnumKey", objManagementBaseObject, Nothing).Properties.Item("sNames").Value, String())
                    Try
                        For Each strkey2 In aSubKeys2
                            myKey2 = strkey2
                            objManagementBaseObject = objManagementClass.GetMethodParameters("GetStringValue")
                            objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                            objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath & strkey & "\Patches\" & strkey2)
                            objManagementBaseObject.SetPropertyValue("sValueName", "DisplayName")
                            objManagementBaseObject = objManagementClass.InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                            myValue = objManagementBaseObject("sValue")

                            objManagementBaseObject = objManagementClass.GetMethodParameters("GetStringValue")
                            objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                            objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath & strkey & "\InstallProperties")
                            objManagementBaseObject.SetPropertyValue("sValueName", "DisplayName")
                            objManagementBaseObject = objManagementClass.InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                            myValue2 = objManagementBaseObject("sValue")

                            objManagementBaseObject = objManagementClass.GetMethodParameters("GetStringValue")
                            objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                            objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath & strkey & "\Patches\" & strkey2)
                            objManagementBaseObject.SetPropertyValue("sValueName", "Installed")
                            objManagementBaseObject = objManagementClass.InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                            myValue1 = objManagementBaseObject("sValue")
                            If myValue1 <> "" Then
                                Try
                                    myValue1 = DateTime.ParseExact(myValue1, "yyyyMMdd", System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat)
                                Catch ex As Exception
                                End Try
                            End If

                            If Not myValue = "" Then
                                DataGridView10.Rows.Add(myValue, myValue1, myValue2, strkey2)
                            End If
                        Next
                    Catch ex As Exception
                    End Try
                Next
            Catch ex As Exception
            End Try
        Catch ex As Exception
        End Try

        Try
            DataGridView10.Sort(DataGridView10.Columns(0), System.ComponentModel.ListSortDirection.Ascending)
        Catch ex As Exception
        End Try

        Try
            objManagementScope = Nothing
            objManagementBaseObject.Dispose()
            objManagementClass.Dispose()
        Catch
        End Try

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
        PCNAME.Focus()
    End Sub

    Private Sub GetPrinters_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GetPrinters.Click
        BackgroundWorkerSpinnerStopWorker()

        If userdomainComboBox.Text = "" Then
            Exit Sub
        End If

        If MachineName = "" Then
            Exit Sub
        End If

        DefaultPrinter.Text = "....."
        tnsadmin.Text = "....."
        KeyboardLayout.Text = "....."
        userlogonserver.Text = "....."
        userbeingqueried.Text = "....."

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Dim lookforbackslash As Integer = InStr(userdomainComboBox.Text, "\")
        If lookforbackslash <> 0 Then
            Dim wordArr As String() = userdomainComboBox.Text.Split(" ")
            Dim result As String = wordArr(0)
            LoggedOnUserNameOnly = result
            wordArr = LoggedOnUserNameOnly.Split("\")
            result = wordArr(1)
            LoggedOnUserNameOnly = result
            userbeingqueried.Text = LoggedOnUserNameOnly
            SIDKEY = GetSIDUsingADSearch(LoggedOnUserNameOnly)
        Else
            Exit Sub
        End If

        Dim DriveLetter = ""
        Dim wordArr1 As String() = userdomainComboBox.Text.Split(" ")
        Dim strUsers As String = wordArr1(0)
        Dim strComputerName As String = txtpcname
        Dim strStringValue As String = ""
        Dim strKeyPath As String = ""
        Dim objManagementScope As ManagementScope = Nothing
        Dim objManagementClass As ManagementClass = Nothing
        Dim objManagementBaseObject As ManagementBaseObject = Nothing
        Dim strkey2 As String
        Dim myValue As String = "....."
        Dim aSubKeys2() As String
        Dim intRegistryHive As Microsoft.Win32.RegistryHive
        intRegistryHive = Microsoft.Win32.RegistryHive.Users

        DataGridViewPrinters.Rows.Clear()
        DataGridViewNetwork.Rows.Clear()
        DataGridViewODBC.Rows.Clear()

        Dim options As ConnectionOptions
        options = New ConnectionOptions()
        Dim computerconnect As String = "\\" & txtpcname & "\root\DEFAULT"

        options.Username = username
        options.Password = password
        options.Timeout = TimeSpan.FromSeconds(30)
        options.Authority = "NTLMDOMAIN:" & domain
        options.Authentication = AuthenticationLevel.PacketPrivacy
        objManagementScope = New ManagementScope(computerconnect, options)

        If objManagementScope.IsConnected = True Then
        Else
            Try
                objManagementScope.Connect()
            Catch ex As Exception
                BackgroundWorkerSpinner.CancelAsync()
                MetroProgressBar.Hide()
                PCNAME.Focus()
                MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                Exit Sub
            End Try
        End If

        strKeyPath = SIDKEY & "\Software\Microsoft\Windows NT\CurrentVersion\Devices\"
        Try
            objManagementClass = New ManagementClass("stdRegProv")
            objManagementClass.Scope = objManagementScope
            objManagementBaseObject = objManagementClass.GetMethodParameters("EnumValues")
            objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
            objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath)
            aSubKeys2 = CType(objManagementClass.InvokeMethod("EnumValues", objManagementBaseObject, Nothing).Properties.Item("sNames").Value, String())

            Try
                For Each strkey2 In aSubKeys2
                    DataGridViewPrinters.Rows.Add(Host.Text, strUsers, strkey2)
                Next
            Catch EX As Exception
            End Try
        Catch EX As Exception
        End Try

        Try
            For i As Integer = 1 To DataGridViewPrinters.Rows.Count
                DataGridViewPrinters.Rows(i - 1).HeaderCell.Value = i.ToString()
            Next i
        Catch ex As Exception
        End Try

        Dim strKeyPath2 As String = SIDKEY & "\Software\Microsoft\Windows NT\CurrentVersion\Windows\"
        Try
            objManagementClass = New ManagementClass("stdRegProv")
            objManagementClass.Scope = objManagementScope
            objManagementBaseObject = objManagementClass.GetMethodParameters("GetStringValue")
            objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
            objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath2)
            objManagementBaseObject.SetPropertyValue("sValueName", "Device")
            objManagementBaseObject = objManagementClass.InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
            myValue = objManagementBaseObject("sValue")
            DefaultPrinter.Text = myValue
        Catch ex As Exception
        End Try


        strKeyPath = ""
        strKeyPath = SIDKEY & "\Network\"
        Try
            objManagementClass = New ManagementClass("stdRegProv")
            objManagementClass.Scope = objManagementScope
            objManagementBaseObject = objManagementClass.GetMethodParameters("EnumKey")
            objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
            objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath)
            aSubKeys2 = CType(objManagementClass.InvokeMethod("EnumKey", objManagementBaseObject, Nothing).Properties.Item("sNames").Value, String())
            Try
                For Each strkey2 In aSubKeys2
                    DriveLetter = strkey2
                    Dim strKeyPath3 As String = SIDKEY & "\Network\" & DriveLetter & "\"
                    Try
                        objManagementBaseObject = objManagementClass.GetMethodParameters("GetStringValue")
                        objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                        objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath3)
                        objManagementBaseObject.SetPropertyValue("sValueName", "RemotePath")
                        objManagementBaseObject = objManagementClass.InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                        myValue = objManagementBaseObject("sValue")
                        DataGridViewNetwork.Rows.Add(strUsers, DriveLetter, myValue)
                    Catch ex As Exception
                    End Try
                Next
            Catch EX As Exception
            End Try
        Catch EX As Exception
        End Try

        strKeyPath = ""
        strKeyPath = SIDKEY & "\Software\ODBC\ODBC.INI\"
        Try
            objManagementClass = New ManagementClass("stdRegProv")
            objManagementClass.Scope = objManagementScope
            objManagementBaseObject = objManagementClass.GetMethodParameters("EnumKey")
            objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
            objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath)
            aSubKeys2 = CType(objManagementClass.InvokeMethod("EnumKey", objManagementBaseObject, Nothing).Properties.Item("sNames").Value, String())
            Try
                For Each strkey2 In aSubKeys2
                    DriveLetter = strkey2
                    Dim strKeyPath3 As String = SIDKEY & "\Software\ODBC\ODBC.INI\" & DriveLetter & "\"
                    Try
                        objManagementBaseObject = objManagementClass.GetMethodParameters("GetStringValue")
                        objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                        objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath3)
                        objManagementBaseObject.SetPropertyValue("sValueName", "Driver")
                        objManagementBaseObject = objManagementClass.InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                        myValue = objManagementBaseObject("sValue")
                        DataGridViewODBC.Rows.Add(strUsers, DriveLetter, myValue)
                    Catch ex As Exception
                    End Try
                Next
            Catch EX As Exception
            End Try
        Catch EX As Exception
        End Try

        strKeyPath = ""
        strKeyPath = SIDKEY & "\Environment\"
        Try
            objManagementBaseObject = objManagementClass.GetMethodParameters("GetStringValue")
            objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
            objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath)
            objManagementBaseObject.SetPropertyValue("sValueName", "TNS_ADMIN")
            objManagementBaseObject = objManagementClass.InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
            myValue = objManagementBaseObject("sValue")
            tnsadmin.Text = myValue
        Catch EX As Exception
        End Try

        strKeyPath = ""
        strKeyPath = SIDKEY & "\Volatile Environment\"
        Try
            objManagementBaseObject = objManagementClass.GetMethodParameters("GetStringValue")
            objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
            objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath)
            objManagementBaseObject.SetPropertyValue("sValueName", "LOGONSERVER")
            objManagementBaseObject = objManagementClass.InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
            myValue = objManagementBaseObject("sValue")
            userlogonserver.Text = myValue
        Catch EX As Exception
        End Try

        strKeyPath = ""
        strKeyPath = SIDKEY & "\Keyboard Layout\Preload\"
        Try
            objManagementBaseObject = objManagementClass.GetMethodParameters("GetStringValue")
            objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
            objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath)
            objManagementBaseObject.SetPropertyValue("sValueName", "1")
            objManagementBaseObject = objManagementClass.InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
            myValue = objManagementBaseObject("sValue")
            KeyboardLayout.Text = myValue
        Catch EX As Exception
        End Try

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
        PCNAME.Focus()

        Try
            objManagementScope = Nothing
            objManagementBaseObject.Dispose()
            objManagementClass.Dispose()
        Catch
        End Try

    End Sub

    Private Sub SCCMRunningJobs_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SCCMRunningJobs.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If
        Dim AdvertID As String = Nothing
        Dim ProgramID As String = Nothing
        Dim ProgramName As String = Nothing
        Dim AdvertisementID As String = Nothing
        Dim State As String = Nothing
        Dim Runningstatus As String = Nothing

        DataGridViewSCCMRunning.Rows.Clear()

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Dim objManagementScope As ManagementScope
        Dim options As ConnectionOptions
        options = New ConnectionOptions()
        Dim computerconnect As String = "\\" & txtpcname & "\root\ccm\SoftMgmtAgent"

        options.Username = username
        options.Password = password
        options.Timeout = TimeSpan.FromSeconds(30)
        options.Authority = "NTLMDOMAIN:" & domain
        options.Authentication = AuthenticationLevel.PacketPrivacy
        objManagementScope = New ManagementScope(computerconnect, options)

        If objManagementScope.IsConnected = True Then
        Else
            Try
                objManagementScope.Connect()
            Catch ex As Exception
                MessageBox.Show("Couldn't connect: " + ex.Message, "Error , Please check pc online and SCCM Agent is installed!")
                PCNAME.Focus()
                Exit Sub
            End Try
        End If


        Try
            Dim QueryOptions = New EnumerationOptions
            QueryOptions.Timeout = New TimeSpan(0, 0, 10)
            Dim query As New SelectQuery("SELECT * FROM CCM_ExecutionRequestEx")
            Dim searcher As New ManagementObjectSearcher(objManagementScope, query, QueryOptions)
            For Each mo As ManagementObject In searcher.[Get]()
                If Not mo Is Nothing Then
                    AdvertisementID = ""
                    AdvertID = mo("AdvertID")
                    ProgramID = mo("ContentID")
                    ProgramName = mo("ProgramID")
                    State = mo("State")
                    Runningstatus = mo("Runningstate")

                    If AdvertID = "" Then
                        If IsArray(mo("OptionalAdvertisements")) Then
                            AdvertisementID = mo("OptionalAdvertisements(0)")
                        End If
                    End If
                    DataGridViewSCCMRunning.Rows.Add(AdvertID, ProgramID, ProgramName, State, Runningstatus)
                End If
            Next
        Catch ex As Exception
            MessageBox.Show("Unable to connect to SCCM Agent, Please check AGent is Installed!")
        End Try

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
        PCNAME.Focus()

        Try
            objManagementScope = Nothing
        Catch
        End Try

    End Sub

    Private Sub ProcessorUsage_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ProcessorUsage.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        ListViewProcessorUsage.Items.Clear()


        Dim lvwP As New ListViewItem
        Dim options2 As ConnectionOptions
        options2 = New ConnectionOptions()
        Dim computerconnect2 As String = "\\" & txtpcname & "\root\cimv2"
        options2.Username = username
        options2.Password = password
        options2.Timeout = TimeSpan.FromSeconds(30)
        options2.Authority = "NTLMDOMAIN:" & domain
        options2.Authentication = AuthenticationLevel.PacketPrivacy
        Dim msc2 As ManagementScope = New ManagementScope(computerconnect2, options2)

        Try
            msc2.Connect()
            Dim QueryOptions = New EnumerationOptions
            QueryOptions.Timeout = New TimeSpan(0, 0, 10)

            Dim query_command2 As String = "SELECT * FROM Win32_PerfFormattedData_PerfProc_Process"
            Dim select_query2 As SelectQuery = New SelectQuery(query_command2)
            Dim Srch2 As New ManagementObjectSearcher(msc2, select_query2, QueryOptions)
            Dim objMgmt2 As ManagementObject

            Try
                For Each objMgmt2 In Srch2.Get
                    lvwP.UseItemStyleForSubItems = False
                    lvwP.Font = New Font(ListViewProcessorUsage.Font, FontStyle.Regular)

                    If objMgmt2("Name") <> "_Total" And objMgmt2("Name") <> "Idle" Then

                        lvwP = ListViewProcessorUsage.Items.Add(objMgmt2("Name"))

                        lvwP.SubItems.Add(objMgmt2("IDProcess")).Font = New Font(ListViewProcessorUsage.Font, FontStyle.Regular)

                        If objMgmt2("PercentProcessorTime") = 0 Then
                            lvwP.SubItems.Add(" ").Font = New Font(ListViewProcessorUsage.Font, FontStyle.Regular)
                        Else
                            lvwP.SubItems.Add(objMgmt2("PercentProcessorTime")).Font = New Font(ListViewProcessorUsage.Font, FontStyle.Regular)
                        End If

                    End If
                Next

            Catch
            End Try

        Catch ex As Exception
            BackgroundWorkerSpinner.CancelAsync()
            MetroProgressBar.Hide()
            PCNAME.Focus()
            MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
            Exit Sub
        End Try

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
        PCNAME.Focus()

        Try
            msc2 = Nothing
        Catch
        End Try

    End Sub



    Private Sub SaveEMAnumber_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveEMAnumber.Click
        BackgroundWorkerSpinnerStopWorker()
        If MachineName = "" Then
            Exit Sub
        End If
        Try
            Dim regKey As Microsoft.Win32.RegistryKey
            regKey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey("Software\RDT\Computers\" & MachineName, True)
            regKey.SetValue("EMAdetails", SaveEMAdetails.Text)
            regKey.Close()
        Catch ex As Exception
        End Try
        Try
            Dim regKey As Microsoft.Win32.RegistryKey
            regKey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey("Software\RDT\Computers\" & MachineName, True)
            regKey.SetValue("HelpdeskNumber", Helpdesknumber.Text)
            regKey.Close()
        Catch ex As Exception
        End Try

        PCNAME.Focus()
    End Sub

    Private Sub SCCMCertMaintTask_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SCCMCertMaintTask.Click
        BackgroundWorkerSpinnerStopWorker()
        If MachineName = "" Then
            Exit Sub
        End If

        SCCMCERTMAINTASK(username, password, domain, txtpcname)
    End Sub
    Private Sub SCCMCERTMAINTASK(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)
        Dim wmi_out As ManagementBaseObject
        Dim objManagementScope As ManagementScope
        Dim objManagementClass As ManagementClass = Nothing
        Dim objManagementBaseObject As ManagementBaseObject = Nothing

        Dim retValue As Integer
        Dim Command As String = "WMIC /node:" & txtpcname & " /namespace:\\root\ccm path sms_client CALL TriggerSchedule " & Chr(34) & "{00000000-0000-0000-0000-000000000051}" & Chr(34) & " /NOINTERACTIVE"

        Try

            Dim options As ConnectionOptions
            options = New ConnectionOptions()
            Dim computerconnect As String = "\\" & txtpcname & "\root\cimv2:Win32_Process"

            options.Username = txtusername
            options.Password = txtpassword
            options.Timeout = TimeSpan.FromSeconds(30)
            options.Authority = "NTLMDOMAIN:" & txtdomain
            options.Authentication = AuthenticationLevel.PacketPrivacy
            objManagementScope = New ManagementScope(computerconnect, options)

            If objManagementScope.IsConnected = True Then
            Else
                Try
                    objManagementScope.Connect()
                Catch ex As Exception
                    MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                    Exit Sub
                End Try
            End If

            objManagementClass = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
            objManagementClass.Scope = objManagementScope

            objManagementBaseObject = objManagementClass.GetMethodParameters("Create")
            objManagementBaseObject.SetPropertyValue("CommandLine", Command)
            wmi_out = objManagementClass.InvokeMethod("Create", objManagementBaseObject, Nothing)

            retValue = Convert.ToInt32(wmi_out("returnValue"))
            Select Case retValue
                Case 0

                Case 2
                    Throw New ApplicationException("Access denied")
                Case 3
                    Throw New ApplicationException("Insufficient privilege")
                Case 8
                    Throw New ApplicationException("Unknown failure")
                Case 9
                    Throw New ApplicationException("Path not found")
                Case 21
                    Throw New ApplicationException("Invalid parameter")
                Case Else
                    Throw New ApplicationException("Unknown return code " & retValue)
            End Select
        Catch ex As Exception
            MsgBox(txtpcname & ": Can't create the process. " & ex.Message)
        End Try
        Try
            objManagementScope = Nothing
            objManagementBaseObject.Dispose()
            objManagementClass.Dispose()
        Catch
        End Try
    End Sub

    Private Sub SCCMREPAIRWMI_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SCCMREPAIRWMI.Click
        SCCMREPAIRWMI2(username, password, domain, txtpcname)
    End Sub

    Private Sub SCCMREPAIRWMI2(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)
        If MachineName = "" Then
            Exit Sub
        End If

        BackgroundWorkerSpinnerStopWorker()

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Try
            Dim objManagementScope As ManagementScope

            Dim options As ConnectionOptions
            options = New ConnectionOptions()
            Dim computerconnect As String = "\\" & txtpcname & "\root\cimv2"

            options.Username = username
            options.Password = password
            options.Timeout = TimeSpan.FromSeconds(30)
            options.Authority = "NTLMDOMAIN:" & domain
            options.Authentication = AuthenticationLevel.PacketPrivacy
            objManagementScope = New ManagementScope(computerconnect, options)

            If objManagementScope.IsConnected = True Then
            Else
                Try
                    objManagementScope.Connect()
                Catch ex As Exception
                    BackgroundWorkerSpinner.CancelAsync()
                    MetroProgressBar.Hide()
                    PCNAME.Focus()
                    MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                    Exit Sub
                End Try
            End If

            ' define a select query
            Dim query As New SelectQuery("SELECT * FROM Win32_Service Where Name =""CcmExec""")
            Dim searcher As New ManagementObjectSearcher(objManagementScope, query)
            Dim args As Object = Nothing
            Try
                For Each mo As ManagementObject In searcher.[Get]()
                    mo.InvokeMethod("StopService", args)
                Next
            Catch ex As Exception
                'MsgBox(ex.Message)
                'PCNAME.Focus()
                'Exit Sub
            End Try
        Catch ex As Exception
            'MsgBox(ex.Message)
            'PCNAME.Focus()
            'Exit Sub
        End Try

        Thread.Sleep(3000)

        Try
            Dim objManagementScope As ManagementScope

            Dim options As ConnectionOptions
            options = New ConnectionOptions()
            Dim computerconnect As String = "\\" & txtpcname & "\root\cimv2"

            options.Username = username
            options.Password = password
            options.Timeout = TimeSpan.FromSeconds(30)
            options.Authority = "NTLMDOMAIN:" & domain
            options.Authentication = AuthenticationLevel.PacketPrivacy
            objManagementScope = New ManagementScope(computerconnect, options)

            If objManagementScope.IsConnected = True Then
            Else
                Try
                    objManagementScope.Connect()
                Catch ex As Exception
                    BackgroundWorkerSpinner.CancelAsync()
                    MetroProgressBar.Hide()
                    PCNAME.Focus()
                    MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                    Exit Sub
                End Try
            End If

            ' define a select query
            Dim query As New SelectQuery("SELECT * FROM Win32_Service Where Name =""winmgmt""")
            Dim searcher As New ManagementObjectSearcher(objManagementScope, query)
            Dim args As Object = Nothing
            Try
                For Each mo As ManagementObject In searcher.[Get]()
                    mo.InvokeMethod("StopService", args)
                Next
            Catch ex As Exception
                'MsgBox(ex.Message)
                'PCNAME.Focus()
                'Exit Sub
            End Try
        Catch ex As Exception
            'MsgBox(ex.Message)
            'PCNAME.Focus()
            'Exit Sub
        End Try

        Thread.Sleep(3000)

        Try
            Dim wmi_out As ManagementBaseObject
            Dim objManagementScope As ManagementScope
            Dim objManagementClass As ManagementClass = Nothing
            Dim objManagementBaseObject As ManagementBaseObject = Nothing
            Dim retValue As Integer
            Dim Command As String = "CMD /C RD /S /Q %windir%\system32\wbem\Repository"

            Try
                Dim options As ConnectionOptions
                options = New ConnectionOptions()
                Dim computerconnect As String = "\\" & txtpcname & "\root\cimv2:Win32_Process"

                options.Username = username
                options.Password = password
                options.Timeout = TimeSpan.FromSeconds(30)
                options.Authority = "NTLMDOMAIN:" & domain
                options.Authentication = AuthenticationLevel.PacketPrivacy
                objManagementScope = New ManagementScope(computerconnect, options)

                If objManagementScope.IsConnected = True Then
                Else
                    Try
                        objManagementScope.Connect()
                    Catch ex As Exception
                        BackgroundWorkerSpinner.CancelAsync()
                        MetroProgressBar.Hide()
                        PCNAME.Focus()
                        MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                        Exit Sub
                    End Try
                End If

                objManagementClass = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
                objManagementClass.Scope = objManagementScope

                objManagementBaseObject = objManagementClass.GetMethodParameters("Create")
                objManagementBaseObject.SetPropertyValue("CommandLine", Command)
                wmi_out = objManagementClass.InvokeMethod("Create", objManagementBaseObject, Nothing)

                retValue = Convert.ToInt32(wmi_out("returnValue"))
                Select Case retValue
                    Case 0

                    Case 2
                        Throw New ApplicationException("Access denied")
                    Case 3
                        Throw New ApplicationException("Insufficient privilege")
                    Case 8
                        Throw New ApplicationException("Unknown failure")
                    Case 9
                        Throw New ApplicationException("Path not found")
                    Case 21
                        Throw New ApplicationException("Invalid parameter")
                    Case Else
                        Throw New ApplicationException("Unknown return code " & retValue)
                End Select
            Catch ex As Exception
                BackgroundWorkerSpinner.CancelAsync()
                MetroProgressBar.Hide()
                PCNAME.Focus()
                MsgBox(txtpcname & ": Can't create the kill process. " & ex.Message)
                Exit Sub
            End Try
            objManagementBaseObject.Dispose()
            objManagementClass.Dispose()
        Catch
            BackgroundWorkerSpinner.CancelAsync()
            MetroProgressBar.Hide()
            PCNAME.Focus()
            MessageBox.Show("Could not remove directory C:\Windows\system32\wbem\Repository, " & Err.Description, "Error:", MessageBoxButtons.OK, MessageBoxIcon.Stop)
            Exit Sub
        End Try

        Try
            Dim objManagementScope As ManagementScope

            Dim options As ConnectionOptions
            options = New ConnectionOptions()
            Dim computerconnect As String = "\\" & txtpcname & "\root\cimv2"

            options.Username = username
            options.Password = password
            options.Timeout = TimeSpan.FromSeconds(30)
            options.Authority = "NTLMDOMAIN:" & domain
            options.Authentication = AuthenticationLevel.PacketPrivacy
            objManagementScope = New ManagementScope(computerconnect, options)

            If objManagementScope.IsConnected = True Then
            Else
                Try
                    objManagementScope.Connect()
                Catch ex As Exception
                    BackgroundWorkerSpinner.CancelAsync()
                    MetroProgressBar.Hide()
                    PCNAME.Focus()
                    MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                    Exit Sub
                End Try
            End If

            ' define a select query
            Dim query As New SelectQuery("SELECT * FROM Win32_Service Where Name =""winmgmt""")
            Dim searcher As New ManagementObjectSearcher(objManagementScope, query)
            Dim args As Object = Nothing
            Try
                For Each mo As ManagementObject In searcher.[Get]()
                    mo.InvokeMethod("StartService", args)
                Next
            Catch ex As Exception
                MsgBox(ex.Message)
                BackgroundWorkerSpinner.CancelAsync()
                MetroProgressBar.Hide()
                PCNAME.Focus()
                Exit Sub
            End Try
        Catch ex As Exception
            BackgroundWorkerSpinner.CancelAsync()
            MetroProgressBar.Hide()
            PCNAME.Focus()
            MsgBox(ex.Message)
            Exit Sub
        End Try

        Try
            Dim objManagementScope As ManagementScope

            Dim options As ConnectionOptions
            options = New ConnectionOptions()
            Dim computerconnect As String = "\\" & txtpcname & "\root\cimv2"

            options.Username = username
            options.Password = password
            options.Timeout = TimeSpan.FromSeconds(30)
            options.Authority = "NTLMDOMAIN:" & domain
            options.Authentication = AuthenticationLevel.PacketPrivacy
            objManagementScope = New ManagementScope(computerconnect, options)

            If objManagementScope.IsConnected = True Then
            Else
                Try
                    objManagementScope.Connect()
                Catch ex As Exception
                    BackgroundWorkerSpinner.CancelAsync()
                    MetroProgressBar.Hide()
                    PCNAME.Focus()
                    MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                    Exit Sub
                End Try
            End If

            ' define a select query
            Dim query As New SelectQuery("SELECT * FROM Win32_Service Where Name =""CcmExec""")
            Dim searcher As New ManagementObjectSearcher(objManagementScope, query)
            Dim args As Object = Nothing
            Try
                For Each mo As ManagementObject In searcher.[Get]()
                    mo.InvokeMethod("StartService", args)
                Next
            Catch ex As Exception
                BackgroundWorkerSpinner.CancelAsync()
                MetroProgressBar.Hide()
                PCNAME.Focus()
                MsgBox(ex.Message)
                Exit Sub
            End Try

            Try
                objManagementScope = Nothing
            Catch
            End Try

        Catch ex As Exception
            BackgroundWorkerSpinner.CancelAsync()
            MetroProgressBar.Hide()
            PCNAME.Focus()
            MsgBox(ex.Message)
            Exit Sub
        End Try

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
        PCNAME.Focus()
    End Sub

    Private Sub AdvertisementsUser_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AdvertisementsUser.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If
        DataGridView25.Rows.Clear()
        AdvIDUser.Text = "AdvID"
        PkgIDUser.Text = "PkgID"
        AdvertNameUser.Text = "AdvertName"

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        SCCMADVUSER()

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
        PCNAME.Focus()
    End Sub

    Private Sub SCCMADVUSER()

        If userdomainComboBox.Text = "" Then
            Exit Sub
        End If

        Dim SIDKEY As String = ""
        Dim SIDUSER As String = ""

        Dim lookforbackslash As Integer = InStr(userdomainComboBox.Text, "\")
        If lookforbackslash <> 0 Then
            Dim wordArr As String() = userdomainComboBox.Text.Split("\")
            Dim result As String = wordArr(1)
            LoggedOnUserNameOnly = result
            SIDKEY = GetSIDUsingADSearch(LoggedOnUserNameOnly)
        End If

        SIDKEY = Replace(SIDKEY, "-", "_")

        Try
            Dim AdvID As String = Nothing
            Dim PkgID As String = Nothing
            Dim Name As String = Nothing
            Dim SoftwareVersion As String = Nothing
            Dim Program As String = Nothing
            Dim Command As String = Nothing
            Dim ContentSize As String = Nothing

            Dim objManagementScope As ManagementScope

            Dim options As ConnectionOptions
            options = New ConnectionOptions()
            Dim computerconnect As String = "\\" & txtpcname & "\root\ccm\policy\" & SIDKEY
            options.Username = username
            options.Password = password
            options.Timeout = TimeSpan.FromSeconds(30)
            options.Authority = "NTLMDOMAIN:" & domain
            options.Authentication = AuthenticationLevel.PacketPrivacy
            objManagementScope = New ManagementScope(computerconnect, options)

            If objManagementScope.IsConnected = True Then
            Else
                objManagementScope.Connect()
            End If

            Dim QueryOptions = New EnumerationOptions
            QueryOptions.Timeout = New TimeSpan(0, 0, 10)
            Dim query As New SelectQuery("SELECT * FROM CCM_SoftwareDistribution")
            Dim searcher As New ManagementObjectSearcher(objManagementScope, query, QueryOptions)
            For Each mo As ManagementObject In searcher.[Get]()
                AdvID = mo("ADV_AdvertisementID")
                PkgID = mo("PKG_PackageID")
                Name = mo("PKG_Name")
                SoftwareVersion = mo("PKG_SourceVersion")
                Program = mo("PRG_ProgramName")
                Command = mo("PRG_CommandLine")
                ContentSize = mo("PKG_ContentSize")

                If Program = "*" Then
                    DataGridView25.RowTemplate.DefaultCellStyle.ForeColor = Color.Orange
                    Program = "* (TASK SEQUENCE/TASK SEQUENCE ACTION!)"
                    Command = mo("PRG_Comment")
                End If

                DataGridView25.Rows.Add(AdvID, PkgID, Name, ContentSize, SoftwareVersion, Program, LoggedOnUserNameOnly)
                DataGridView25.RowTemplate.DefaultCellStyle.ForeColor = Color.Black

                Try
                    DataGridView25.Sort(DataGridView25.Columns(2), System.ComponentModel.ListSortDirection.Ascending)
                Catch ex As Exception
                End Try

            Next

            Try
                objManagementScope = Nothing
            Catch
            End Try

        Catch ex As Exception
        End Try

        PCNAME.Focus()

    End Sub

    Private Sub ReRunAdvertMachine_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ReRunAdvertMachine.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If
        If PkgIDMachine.Text = "" Then
            Exit Sub
        End If

        Dim response As MsgBoxResult
        response = MsgBox("Are you sure you want to ReRun Advert : " & AdvertNameMachine.Text & " ?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "Confirm")
        If response = MsgBoxResult.Yes Then
            ' Continue Install
        ElseIf response = MsgBoxResult.No Then
            Exit Sub
        End If

        Dim wmi_out As ManagementBaseObject
        Dim objManagementScope As ManagementScope
        Dim objManagementClass As ManagementClass = Nothing
        Dim objManagementBaseObject As ManagementBaseObject = Nothing
        Dim retValue As Integer
        Dim Command As String = "REG DELETE ""HKLM\SOFTWARE\Microsoft\SMS\Mobile Client\Software Distribution\Execution History\System\" & PkgIDMachine.Text & """ /f"

        Try
            Dim options As ConnectionOptions
            options = New ConnectionOptions()
            Dim computerconnect As String = "\\" & txtpcname & "\root\cimv2:Win32_Process"

            options.Username = username
            options.Password = password
            options.Timeout = TimeSpan.FromSeconds(30)
            options.Authority = "NTLMDOMAIN:" & domain
            options.Authentication = AuthenticationLevel.PacketPrivacy
            objManagementScope = New ManagementScope(computerconnect, options)

            If objManagementScope.IsConnected = True Then
            Else
                Try
                    objManagementScope.Connect()
                Catch ex As Exception
                    MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                    PCNAME.Focus()
                    Exit Sub
                End Try
            End If

            objManagementClass = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
            objManagementClass.Scope = objManagementScope

            objManagementBaseObject = objManagementClass.GetMethodParameters("Create")
            objManagementBaseObject.SetPropertyValue("CommandLine", Command)
            wmi_out = objManagementClass.InvokeMethod("Create", objManagementBaseObject, Nothing)

            retValue = Convert.ToInt32(wmi_out("returnValue"))
            Select Case retValue
                Case 0
                    ' Msgbox success!
                Case 2
                    Throw New ApplicationException("Access denied")
                Case 3
                    Throw New ApplicationException("Insufficient privilege")
                Case 8
                    Throw New ApplicationException("Unknown failure")
                Case 9
                    Throw New ApplicationException("Path not found")
                Case 21
                    Throw New ApplicationException("Invalid parameter")
                Case Else
                    Throw New ApplicationException("Unknown return code " & retValue)
            End Select
        Catch ex As Exception
            MsgBox(txtpcname & ": Can't create the process. " & ex.Message)
        End Try
        objManagementBaseObject.Dispose()
        objManagementClass.Dispose()


        Dim Command2 As String = "REG DELETE ""HKLM\SOFTWARE\Wow6432Node\Microsoft\SMS\Mobile Client\Software Distribution\Execution History\System\" & PkgIDMachine.Text & """ /f"
        Try
            Dim options As ConnectionOptions
            options = New ConnectionOptions()
            Dim computerconnect As String = "\\" & txtpcname & "\root\cimv2:Win32_Process"

            options.Username = username
            options.Password = password
            options.Timeout = TimeSpan.FromSeconds(30)
            options.Authority = "NTLMDOMAIN:" & domain
            options.Authentication = AuthenticationLevel.PacketPrivacy
            objManagementScope = New ManagementScope(computerconnect, options)

            If objManagementScope.IsConnected = True Then
            Else
                Try
                    objManagementScope.Connect()
                Catch ex As Exception
                    MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                    PCNAME.Focus()
                    Exit Sub
                End Try
            End If

            objManagementClass = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
            objManagementClass.Scope = objManagementScope

            objManagementBaseObject = objManagementClass.GetMethodParameters("Create")
            objManagementBaseObject.SetPropertyValue("CommandLine", Command2)
            wmi_out = objManagementClass.InvokeMethod("Create", objManagementBaseObject, Nothing)

            retValue = Convert.ToInt32(wmi_out("returnValue"))
            Select Case retValue
                Case 0
                    ' Msgbox success!
                Case 2
                    Throw New ApplicationException("Access denied")
                Case 3
                    Throw New ApplicationException("Insufficient privilege")
                Case 8
                    Throw New ApplicationException("Unknown failure")
                Case 9
                    Throw New ApplicationException("Path not found")
                Case 21
                    Throw New ApplicationException("Invalid parameter")
                Case Else
                    Throw New ApplicationException("Unknown return code " & retValue)
            End Select
        Catch ex As Exception
            MsgBox(txtpcname & ": Can't create the process. " & ex.Message)
        End Try
        Try
            objManagementScope = Nothing
            objManagementBaseObject.Dispose()
            objManagementClass.Dispose()
        Catch
        End Try

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Dim GetAdvSchMsgID As String = Nothing
        Dim BackedupMsgID As String = Nothing
        Try
            Dim options2 As ConnectionOptions
            options2 = New ConnectionOptions()
            Dim computerconnect2 As String = "\\" & txtpcname & "\root\ccm\policy\machine\actualconfig"
            options2.Username = username
            options2.Password = password
            options2.Timeout = TimeSpan.FromSeconds(30)
            options2.Authority = "NTLMDOMAIN:" & domain
            options2.Authentication = AuthenticationLevel.PacketPrivacy
            Dim msc As ManagementScope = New ManagementScope(computerconnect2, options2)
            Dim query_command As String = "Select * from CCM_Scheduler_ScheduledMessage"
            Dim select_query As SelectQuery = New SelectQuery(query_command)
            Dim Srch As New ManagementObjectSearcher(msc, select_query)
            Dim objMgmt As ManagementObject
            For Each objMgmt In Srch.Get
                If InStr(objMgmt("ScheduledMessageID"), AdvIDMachine.Text) > 0 Then
                    GetAdvSchMsgID = objMgmt("ScheduledMessageID")
                    'MsgBox(GetAdvSchMsgID)
                    Exit For
                End If
            Next
            Dim query As New SelectQuery("Select * from CCM_SoftwareDistribution Where ADV_AdvertisementID = " & Chr(34) & AdvIDMachine.Text & Chr(34) & " ")
            Dim searcher As New ManagementObjectSearcher(msc, query)
            For Each mo As ManagementObject In searcher.[Get]()
                BackedupMsgID = mo("ADV_RepeatRunBehavior")
                If mo("ADV_RepeatRunBehavior") <> "RerunAlways" Then
                    mo("ADV_RepeatRunBehavior") = "RerunAlways"
                    mo.Put()
                End If
            Next
        Catch ex As Exception
        End Try

        Dim Command3 As String = "WMIC /node:" & txtpcname & " /namespace:\\root\ccm path sms_client CALL TriggerSchedule " & Chr(34) & GetAdvSchMsgID & Chr(34) & " /NOINTERACTIVE"

        Try
            Dim options As ConnectionOptions
            options = New ConnectionOptions()
            Dim computerconnect As String = "\\" & txtpcname & "\root\cimv2:Win32_Process"

            options.Username = username
            options.Password = password
            options.Timeout = TimeSpan.FromSeconds(30)
            options.Authority = "NTLMDOMAIN:" & domain
            options.Authentication = AuthenticationLevel.PacketPrivacy
            objManagementScope = New ManagementScope(computerconnect, options)

            If objManagementScope.IsConnected = True Then
            Else
                Try
                    objManagementScope.Connect()
                Catch ex As Exception
                    BackgroundWorkerSpinner.CancelAsync()
                    MetroProgressBar.Hide()
                    PCNAME.Focus()
                    MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                    Exit Sub
                End Try
            End If

            objManagementClass = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
            objManagementClass.Scope = objManagementScope

            objManagementBaseObject = objManagementClass.GetMethodParameters("Create")
            objManagementBaseObject.SetPropertyValue("CommandLine", Command3)
            wmi_out = objManagementClass.InvokeMethod("Create", objManagementBaseObject, Nothing)

            retValue = Convert.ToInt32(wmi_out("returnValue"))
            Select Case retValue
                Case 0
                    ' Msgbox success!
                Case 2
                    Throw New ApplicationException("Access denied")
                Case 3
                    Throw New ApplicationException("Insufficient privilege")
                Case 8
                    Throw New ApplicationException("Unknown failure")
                Case 9
                    Throw New ApplicationException("Path not found")
                Case 21
                    Throw New ApplicationException("Invalid parameter")
                Case Else
                    Throw New ApplicationException("Unknown return code " & retValue)
            End Select
        Catch ex As Exception
            MsgBox(txtpcname & ": Can't create the process. " & ex.Message)
        End Try

        Try
            objManagementScope = Nothing
            objManagementBaseObject.Dispose()
            objManagementClass.Dispose()
        Catch
        End Try

        Try
            Thread.Sleep(5000)
            Dim options5 As ConnectionOptions
            options5 = New ConnectionOptions()
            Dim computerconnect2 As String = "\\" & txtpcname & "\root\ccm\policy\machine\actualconfig"
            options5.Username = username
            options5.Password = password
            options5.Timeout = TimeSpan.FromSeconds(30)
            options5.Authority = "NTLMDOMAIN:" & domain
            options5.Authentication = AuthenticationLevel.PacketPrivacy
            Dim msc As ManagementScope = New ManagementScope(computerconnect2, options5)
            Dim query5 As New SelectQuery("Select * from CCM_SoftwareDistribution Where ADV_AdvertisementID = " & Chr(34) & AdvIDMachine.Text & Chr(34) & " ")
            Dim searcher As New ManagementObjectSearcher(msc, query5)
            For Each mo As ManagementObject In searcher.[Get]()
                mo("ADV_RepeatRunBehavior") = BackedupMsgID
                mo.Put()
            Next
        Catch ex As Exception
        End Try
        objManagementBaseObject.Dispose()
        objManagementClass.Dispose()

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
        PCNAME.Focus()

        MsgBox("Advert Successfully reRun for machine!")

    End Sub

    Private Sub ReRunAdvertUser_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ReRunAdvertUser.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If
        If PkgIDUser.Text = "" Then
            Exit Sub
        End If

        Dim response As MsgBoxResult
        response = MsgBox("Are you sure you want to ReRun Advert : " & AdvertNameUser.Text & " ?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "Confirm")
        If response = MsgBoxResult.Yes Then
            ' Continue Install
        ElseIf response = MsgBoxResult.No Then
            Exit Sub
        End If

        Dim wmi_out As ManagementBaseObject
        Dim objManagementScope As ManagementScope
        Dim objManagementClass As ManagementClass = Nothing
        Dim objManagementBaseObject As ManagementBaseObject = Nothing
        Dim retValue As Integer
        Dim Command As String = "REG DELETE ""HKLM\SOFTWARE\Microsoft\SMS\Mobile Client\Software Distribution\Execution History\System\" & PkgIDUser.Text & """ /f"

        Try

            Dim options As ConnectionOptions
            options = New ConnectionOptions()
            Dim computerconnect As String = "\\" & txtpcname & "\root\cimv2:Win32_Process"

            options.Username = username
            options.Password = password
            options.Timeout = TimeSpan.FromSeconds(30)
            options.Authority = "NTLMDOMAIN:" & domain
            options.Authentication = AuthenticationLevel.PacketPrivacy
            objManagementScope = New ManagementScope(computerconnect, options)

            If objManagementScope.IsConnected = True Then
            Else
                Try
                    objManagementScope.Connect()
                Catch ex As Exception
                    MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                    PCNAME.Focus()
                    Exit Sub
                End Try
            End If

            objManagementClass = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
            objManagementClass.Scope = objManagementScope

            objManagementBaseObject = objManagementClass.GetMethodParameters("Create")
            objManagementBaseObject.SetPropertyValue("CommandLine", Command)
            wmi_out = objManagementClass.InvokeMethod("Create", objManagementBaseObject, Nothing)

            retValue = Convert.ToInt32(wmi_out("returnValue"))
            Select Case retValue
                Case 0
                    ' Msgbox success!
                Case 2
                    Throw New ApplicationException("Access denied")
                Case 3
                    Throw New ApplicationException("Insufficient privilege")
                Case 8
                    Throw New ApplicationException("Unknown failure")
                Case 9
                    Throw New ApplicationException("Path not found")
                Case 21
                    Throw New ApplicationException("Invalid parameter")
                Case Else
                    Throw New ApplicationException("Unknown return code " & retValue)
            End Select
        Catch ex As Exception
            MsgBox(txtpcname & ": Can't create the process. " & ex.Message)
        End Try

        Try
            objManagementScope = Nothing
            objManagementBaseObject.Dispose()
            objManagementClass.Dispose()
        Catch
        End Try


        Dim Command2 As String = "REG DELETE ""HKLM\SOFTWARE\Wow6432Node\Microsoft\SMS\Mobile Client\Software Distribution\Execution History\System\" & PkgIDUser.Text & """ /f"
        Try
            Dim options As ConnectionOptions
            options = New ConnectionOptions()
            Dim computerconnect As String = "\\" & txtpcname & "\root\cimv2:Win32_Process"

            options.Username = username
            options.Password = password
            options.Timeout = TimeSpan.FromSeconds(30)
            options.Authority = "NTLMDOMAIN:" & domain
            options.Authentication = AuthenticationLevel.PacketPrivacy
            objManagementScope = New ManagementScope(computerconnect, options)

            If objManagementScope.IsConnected = True Then
            Else
                Try
                    objManagementScope.Connect()
                Catch ex As Exception
                    MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                    PCNAME.Focus()
                    Exit Sub
                End Try
            End If

            objManagementClass = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
            objManagementClass.Scope = objManagementScope

            objManagementBaseObject = objManagementClass.GetMethodParameters("Create")
            objManagementBaseObject.SetPropertyValue("CommandLine", Command2)
            wmi_out = objManagementClass.InvokeMethod("Create", objManagementBaseObject, Nothing)

            retValue = Convert.ToInt32(wmi_out("returnValue"))
            Select Case retValue
                Case 0
                    ' Msgbox success!
                Case 2
                    Throw New ApplicationException("Access denied")
                Case 3
                    Throw New ApplicationException("Insufficient privilege")
                Case 8
                    Throw New ApplicationException("Unknown failure")
                Case 9
                    Throw New ApplicationException("Path not found")
                Case 21
                    Throw New ApplicationException("Invalid parameter")
                Case Else
                    Throw New ApplicationException("Unknown return code " & retValue)
            End Select
        Catch ex As Exception
            MsgBox(txtpcname & ": Can't create the process. " & ex.Message)
        End Try

        Try
            objManagementScope = Nothing
            objManagementBaseObject.Dispose()
            objManagementClass.Dispose()
        Catch
        End Try

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Dim SIDKEY As String = ""
        Dim SIDUSER As String = ""
        Dim GetAdvSchMsgID As String = Nothing
        Try
            Dim options2 As ConnectionOptions
            options2 = New ConnectionOptions()
            Dim computerconnect2 As String = "\\" & txtpcname & "\root\cimv2"
            options2.Username = username
            options2.Password = password
            options2.Timeout = TimeSpan.FromSeconds(30)
            options2.Authority = "NTLMDOMAIN:" & domain
            options2.Authentication = AuthenticationLevel.PacketPrivacy
            Dim msc As ManagementScope = New ManagementScope(computerconnect2, options2)
            Dim query_command As String = "Select * from Win32_Process Where Name='explorer.exe'"
            Dim select_query As SelectQuery = New SelectQuery(query_command)
            Dim Srch As New ManagementObjectSearcher(msc, select_query)
            Dim objMgmt As ManagementObject
            For Each objMgmt In Srch.[Get]()
                Dim s(1) As String
                objMgmt.InvokeMethod("GetOwnerSID", CType(s, Object()))
                SIDKEY = s(0)
                SIDKEY = Replace(SIDKEY, "-", "_")

                Dim objManagementScope3 As ManagementScope
                Dim options As ConnectionOptions
                options = New ConnectionOptions()
                Dim computerconnect As String = "\\" & txtpcname & "\root\ccm\policy\" & SIDKEY & "\actualconfig"
                options.Username = username
                options.Password = password
                options.Timeout = TimeSpan.FromSeconds(30)
                options.Authority = "NTLMDOMAIN:" & domain
                options.Authentication = AuthenticationLevel.PacketPrivacy
                objManagementScope3 = New ManagementScope(computerconnect, options)

                If objManagementScope3.IsConnected = True Then
                Else
                    objManagementScope3.Connect()
                End If

                Dim query As New SelectQuery("Select * from CCM_Scheduler_ScheduledMessage")
                Dim searcher As New ManagementObjectSearcher(objManagementScope3, query)
                For Each mo As ManagementObject In searcher.[Get]()
                    If InStr(mo("ScheduledMessageID"), AdvIDUser.Text) > 0 Then
                        GetAdvSchMsgID = mo("ScheduledMessageID")
                        mo.Delete()
                        MsgBox("Successfully found User Schedule for " & AdvertNameUser.Text & " and Reset it. Following a ""User Policy Retrieval"", then a ""User Policy Evalution"" the User Advert will Rerun. Will attempt a policy refresh for you now!")
                        Exit For
                    End If
                Next
                'Dim query4 As New SelectQuery("Select * from CCM_SoftwareDistribution Where ADV_AdvertisementID = " & Chr(34) & AdvIDUser.Text & Chr(34) & " ")
                'Dim searcher4 As New ManagementObjectSearcher(objManagementScope3, query4)
                'For Each mo As ManagementObject In searcher4.[Get]()
                'mo("ADV_RepeatRunBehavior") = "RerunAlways"
                'mo.Put()
                'Next
            Next
        Catch ex As Exception
        End Try

        If GetAdvSchMsgID = Nothing Then
            MsgBox("No User Schedule for " & AdvertNameUser.Text & " found, will attempt a policy refresh for you now.")
        End If

        Dim Command3 As String = "WMIC /node:" & txtpcname & " /namespace:\\root\ccm path sms_client CALL TriggerSchedule " & Chr(34) & "{00000000-0000-0000-0000-000000000021}" & Chr(34) & " /NOINTERACTIVE"

        Try
            Dim options As ConnectionOptions
            options = New ConnectionOptions()
            Dim computerconnect As String = "\\" & txtpcname & "\root\cimv2:Win32_Process"

            options.Username = username
            options.Password = password
            options.Timeout = TimeSpan.FromSeconds(30)
            options.Authority = "NTLMDOMAIN:" & domain
            options.Authentication = AuthenticationLevel.PacketPrivacy
            objManagementScope = New ManagementScope(computerconnect, options)

            If objManagementScope.IsConnected = True Then
            Else
                Try
                    objManagementScope.Connect()
                Catch ex As Exception
                    BackgroundWorkerSpinner.CancelAsync()
                    MetroProgressBar.Hide()
                    PCNAME.Focus()
                    MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                    Exit Sub
                End Try
            End If

            objManagementClass = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
            objManagementClass.Scope = objManagementScope

            objManagementBaseObject = objManagementClass.GetMethodParameters("Create")
            objManagementBaseObject.SetPropertyValue("CommandLine", Command3)
            wmi_out = objManagementClass.InvokeMethod("Create", objManagementBaseObject, Nothing)

            retValue = Convert.ToInt32(wmi_out("returnValue"))
            Select Case retValue
                Case 0
                    'MsgBox(success!)
                Case 2
                    Throw New ApplicationException("Access denied")
                Case 3
                    Throw New ApplicationException("Insufficient privilege")
                Case 8
                    Throw New ApplicationException("Unknown failure")
                Case 9
                    Throw New ApplicationException("Path not found")
                Case 21
                    Throw New ApplicationException("Invalid parameter")
                Case Else
                    Throw New ApplicationException("Unknown return code " & retValue)
            End Select
        Catch ex As Exception
            MsgBox(txtpcname & ": Can't create the process. " & ex.Message)
        End Try

        Thread.Sleep(5000)

        Dim Command4 As String = "WMIC /node:" & txtpcname & " /namespace:\\root\ccm path sms_client CALL TriggerSchedule " & Chr(34) & "{00000000-0000-0000-0000-000000000001}" & Chr(34) & " /NOINTERACTIVE"

        Try
            Dim options As ConnectionOptions
            options = New ConnectionOptions()
            Dim computerconnect As String = "\\" & txtpcname & "\root\cimv2:Win32_Process"

            options.Username = username
            options.Password = password
            options.Timeout = TimeSpan.FromSeconds(30)
            options.Authority = "NTLMDOMAIN:" & domain
            options.Authentication = AuthenticationLevel.PacketPrivacy
            objManagementScope = New ManagementScope(computerconnect, options)

            If objManagementScope.IsConnected = True Then
            Else
                Try
                    objManagementScope.Connect()
                Catch ex As Exception
                    BackgroundWorkerSpinner.CancelAsync()
                    MetroProgressBar.Hide()
                    PCNAME.Focus()
                    Exit Sub
                    MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                End Try
            End If

            objManagementClass = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
            objManagementClass.Scope = objManagementScope

            objManagementBaseObject = objManagementClass.GetMethodParameters("Create")
            objManagementBaseObject.SetPropertyValue("CommandLine", Command4)
            wmi_out = objManagementClass.InvokeMethod("Create", objManagementBaseObject, Nothing)

            retValue = Convert.ToInt32(wmi_out("returnValue"))
            Select Case retValue
                Case 0
                    'MsgBox(success!)
                Case 2
                    Throw New ApplicationException("Access denied")
                Case 3
                    Throw New ApplicationException("Insufficient privilege")
                Case 8
                    Throw New ApplicationException("Unknown failure")
                Case 9
                    Throw New ApplicationException("Path not found")
                Case 21
                    Throw New ApplicationException("Invalid parameter")
                Case Else
                    Throw New ApplicationException("Unknown return code " & retValue)
            End Select
        Catch ex As Exception
            MsgBox(txtpcname & ": Can't create the process. " & ex.Message)
        End Try

        Try
            objManagementScope = Nothing
            objManagementBaseObject.Dispose()
            objManagementClass.Dispose()
        Catch
        End Try

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
        PCNAME.Focus()

        MsgBox("Advert Successfully reRun for user! Please give it a few minutes for the policy to refresh (Usually 15-20 minutes on average) and the user will get the application reinstalled.")

    End Sub

    Private Sub DataGridView8_CellClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView8.CellClick
        Dim x As String = Nothing
        x = DataGridView8.CurrentRow.Cells.Item(0).Value
        AdvIDMachine.Text = x
        x = DataGridView8.CurrentRow.Cells.Item(1).Value
        PkgIDMachine.Text = x
        x = DataGridView8.CurrentRow.Cells.Item(2).Value
        AdvertNameMachine.Text = x
    End Sub

    Private Sub DataGridView25_CellClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView25.CellClick
        Dim x As String = Nothing
        x = DataGridView25.CurrentRow.Cells.Item(0).Value
        AdvIDUser.Text = x
        x = DataGridView25.CurrentRow.Cells.Item(1).Value
        PkgIDUser.Text = x
        x = DataGridView25.CurrentRow.Cells.Item(2).Value
        AdvertNameUser.Text = x

    End Sub

    Private Sub ForceReboot_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ForceReboot.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        Dim response As MsgBoxResult
        response = MsgBox("Are you sure you want to ""Force - Restart"" the remote PC : " & txtpcname & " ?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "Confirm")
        If response = MsgBoxResult.Yes Then
            ' Continue Install
        ElseIf response = MsgBoxResult.No Then
            Exit Sub
        End If

        Try
            Dim wmi_out As ManagementBaseObject
            Dim objManagementScope As ManagementScope
            Dim objManagementClass As ManagementClass = Nothing
            Dim objManagementBaseObject As ManagementBaseObject = Nothing
            Dim retValue As Integer
            Dim Command As String = "shutdown /f /r /d p:02:17"

            Try
                Dim options As ConnectionOptions
                options = New ConnectionOptions()
                Dim computerconnect As String = "\\" & txtpcname & "\root\cimv2:Win32_Process"

                options.Username = username
                options.Password = password
                options.Timeout = TimeSpan.FromSeconds(30)
                options.Authority = "NTLMDOMAIN:" & domain
                options.Authentication = AuthenticationLevel.PacketPrivacy
                objManagementScope = New ManagementScope(computerconnect, options)

                If objManagementScope.IsConnected = True Then
                Else
                    Try
                        objManagementScope.Connect()
                    Catch ex As Exception
                        MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                        Exit Sub
                    End Try
                End If

                objManagementClass = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
                objManagementClass.Scope = objManagementScope

                objManagementBaseObject = objManagementClass.GetMethodParameters("Create")
                objManagementBaseObject.SetPropertyValue("CommandLine", Command)
                wmi_out = objManagementClass.InvokeMethod("Create", objManagementBaseObject, Nothing)

                retValue = Convert.ToInt32(wmi_out("returnValue"))
                Select Case retValue
                    Case 0
                        ' success!
                        MsgBox("Shutdown request accepted by remote PC!", MessageBoxButtons.OK, MessageBoxIcon.Stop)
                    Case 2
                        Throw New ApplicationException("Access denied")
                    Case 3
                        Throw New ApplicationException("Insufficient privilege")
                    Case 8
                        Throw New ApplicationException("Unknown failure")
                    Case 9
                        Throw New ApplicationException("Path not found")
                    Case 21
                        Throw New ApplicationException("Invalid parameter")
                    Case Else
                        Throw New ApplicationException("Unknown return code " & retValue)
                End Select
            Catch ex As Exception
                MsgBox(txtpcname & ": Can't create the shutdown process. " & ex.Message)
            End Try
            Try
                objManagementScope = Nothing
                objManagementBaseObject.Dispose()
                objManagementClass.Dispose()
            Catch
            End Try
        Catch
            MessageBox.Show("Could not create shutdown process, " & Err.Description, "Error:", MessageBoxButtons.OK, MessageBoxIcon.Stop)
        End Try

        PCNAME.Focus()
    End Sub

    Private Sub Gather1EResults_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Gather1EResults.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        IPAddressValue.Text = ""
        IPsubnetValue.Text = ""
        NomadProductVersionValue.Text = ""
        PXEProductVersionValue.Text = ""
        NomadServiceValue.Text = ""
        PXEServiceValue.Text = ""
        NomadFolderSizeValue.Text = ""

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Try
            Dim options2 As ConnectionOptions
            options2 = New ConnectionOptions()
            Dim computerconnect2 As String = "\\" & txtpcname & "\root\cimv2"
            options2.Username = username
            options2.Password = password
            options2.Timeout = TimeSpan.FromSeconds(30)
            options2.Authority = "NTLMDOMAIN:" & domain
            options2.Authentication = AuthenticationLevel.PacketPrivacy
            Dim msc As ManagementScope = New ManagementScope(computerconnect2, options2)

            Dim QueryOptions = New EnumerationOptions
            QueryOptions.Timeout = New TimeSpan(0, 0, 10)
            Dim query_command As String = "Select * from Win32_NetworkAdapterConfiguration Where IPEnabled='True'"
            Dim select_query As SelectQuery = New SelectQuery(query_command)
            Dim Srch As New ManagementObjectSearcher(msc, select_query, QueryOptions)
            Dim objMgmt As ManagementObject
            For Each objMgmt In Srch.Get
                IPAddressValue.Text = Join(objMgmt.GetPropertyValue("IPAddress"))
                IPsubnetValue.Text = Join(objMgmt.GetPropertyValue("IPSubnet"))
            Next
        Catch ex As Exception
        End Try

        Try
            Dim NomadProductversion As String
            Dim PXEProductversion As String
            Dim objManagementScope As ManagementScope = Nothing
            Dim objManagementClass As ManagementClass = Nothing
            Dim objManagementBaseObject As ManagementBaseObject = Nothing
            Dim intRegistryHive As Microsoft.Win32.RegistryHive
            intRegistryHive = Microsoft.Win32.RegistryHive.LocalMachine
            Dim options As ConnectionOptions
            options = New ConnectionOptions()
            Dim computerconnect As String = "\\" & txtpcname & "\root\DEFAULT"

            options.Username = username
            options.Password = password
            options.Timeout = TimeSpan.FromSeconds(30)
            options.Authority = "NTLMDOMAIN:" & domain
            options.Authentication = AuthenticationLevel.PacketPrivacy
            objManagementScope = New ManagementScope(computerconnect, options)

            If objManagementScope.IsConnected = True Then
            Else
                objManagementScope.Connect()
            End If

            objManagementClass = New ManagementClass("StdRegProv")
            With objManagementClass
                .Scope = objManagementScope
                objManagementBaseObject = .GetMethodParameters("GetStringValue")

                With objManagementBaseObject
                    .SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                    .SetPropertyValue("sSubKeyName", "SOFTWARE\1E\NomadBranch")
                    .SetPropertyValue("sValueName", "ProductVersion")
                End With
                Dim OutParams As ManagementBaseObject = .InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                NomadProductversion = CType(OutParams("sValue"), String)
                NomadProductVersionValue.Text = NomadProductversion
                If NomadProductVersionValue.Text = "" Then
                    With objManagementBaseObject
                        .SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                        .SetPropertyValue("sSubKeyName", "SOFTWARE\Wow6432Node\1E\NomadBranch")
                        .SetPropertyValue("sValueName", "ProductVersion")
                    End With
                    OutParams = .InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                    NomadProductversion = CType(OutParams("sValue"), String)
                    NomadProductVersionValue.Text = NomadProductversion
                End If

                With objManagementBaseObject
                    .SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                    .SetPropertyValue("sSubKeyName", "SOFTWARE\1E\PXELiteServer")
                    .SetPropertyValue("sValueName", "ProductVersion")
                End With
                OutParams = .InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                PXEProductversion = CType(OutParams("sValue"), String)
                PXEProductVersionValue.Text = PXEProductversion
                If PXEProductVersionValue.Text = "" Then
                    With objManagementBaseObject
                        .SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                        .SetPropertyValue("sSubKeyName", "SOFTWARE\Wow6432Node\1E\PXELiteServer")
                        .SetPropertyValue("sValueName", "ProductVersion")
                    End With
                    OutParams = .InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                    PXEProductversion = CType(OutParams("sValue"), String)
                    PXEProductVersionValue.Text = PXEProductversion
                End If
            End With
            Try
                objManagementScope = Nothing
            Catch
            End Try
        Catch ex As Exception
        End Try



        Dim objManagementScope3 As ManagementScope
        Dim options3 As ConnectionOptions
        options3 = New ConnectionOptions()
        Dim computerconnect3 As String = "\\" & txtpcname & "\root\cimv2"

        options3.Username = username
        options3.Password = password
        options3.Timeout = TimeSpan.FromSeconds(30)
        options3.Authority = "NTLMDOMAIN:" & domain
        options3.Authentication = AuthenticationLevel.PacketPrivacy
        objManagementScope3 = New ManagementScope(computerconnect3, options3)

        If objManagementScope3.IsConnected = True Then
        Else
            Try
                objManagementScope3.Connect()
            Catch ex As Exception
                BackgroundWorkerSpinner.CancelAsync()
                MetroProgressBar.Hide()
                PCNAME.Focus()
                MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                Exit Sub
            End Try
        End If
        Try
            Dim QueryOptions = New EnumerationOptions
            QueryOptions.Timeout = New TimeSpan(0, 0, 10)
            Dim query As New SelectQuery("SELECT * FROM Win32_Service Where Name='NomadBranch'")
            Dim searcher As New ManagementObjectSearcher(objManagementScope3, query, QueryOptions)
            For Each mo As ManagementObject In searcher.[Get]()
                NomadServiceValue.Text = mo("State")
            Next
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
        Try
            Dim QueryOptions = New EnumerationOptions
            QueryOptions.Timeout = New TimeSpan(0, 0, 10)
            Dim query2 As New SelectQuery("SELECT * FROM Win32_Service Where Name='PXELiteServer'")
            Dim searcher2 As New ManagementObjectSearcher(objManagementScope3, query2, QueryOptions)
            For Each mo2 As ManagementObject In searcher2.[Get]()
                PXEServiceValue.Text = mo2("State")
            Next
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

        Try
            Dim NomadFolderSize As Long
            NomadFolderSize = GetFolderSize("\\" & txtpcname & "\c$\ProgramData\1E\NomadBranch")
            NomadFolderSizeValue.Text = CStr(NomadFolderSize)
        Catch Ex As Exception
        End Try

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
        PCNAME.Focus()

        Try
            objManagementScope3 = Nothing
        Catch
        End Try

    End Sub

    Function GetFolderSize(ByVal DirPath As String, Optional ByVal IncludeSubFolders As Boolean = True) As Long

        Dim lngDirSize As Long
        Dim objFileInfo As FileInfo
        Dim objDir As DirectoryInfo = New DirectoryInfo(DirPath)
        Dim objSubFolder As DirectoryInfo

        Try

            'add length of each file
            For Each objFileInfo In objDir.GetFiles()
                lngDirSize += objFileInfo.Length
            Next

            'call recursively to get sub folders
            'if you don't want this set optional
            'parameter to false 
            If IncludeSubFolders Then
                For Each objSubFolder In objDir.GetDirectories()
                    lngDirSize += GetFolderSize(objSubFolder.FullName)
                Next
            End If

        Catch Ex As Exception
        End Try

        Return lngDirSize
    End Function

    Private Sub OpenNomad_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OpenNomad.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        Dim strUsername As String
        Dim strPassword As String
        strUsername = domain & "\" & username
        strPassword = password


        Dim oNet = CreateObject("WScript.Network")
        Try
            oNet.RemoveNetworkDrive("\\" & txtpcname & "\ipc$", True, False)
            oNet.RemoveNetworkDrive("\\" & txtpcname & "\admin$", True, False)
        Catch
        End Try
        oNet.MapNetworkDrive("", "\\" & txtpcname & "\ipc$", False, strUsername, strPassword)

        PCNAME.Focus()

        Try
            Dim path As String
            path = "\\" & txtpcname & "\c$\ProgramData\1E\NomadBranch"
            Dim objShell = CreateObject("Wscript.Shell")
            objShell.run(path)
        Catch ex As Exception
        End Try
        Try
            ' dismount the previously mounted secure channel
            oNet.RemoveNetworkDrive("\\" & txtpcname & "\ipc$", True, False)
        Catch ex As Exception
        End Try

    End Sub

    Private Sub PXEFolderOpen_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PXEFolderOpen.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        Dim strUsername As String
        Dim strPassword As String
        strUsername = domain & "\" & username
        strPassword = password

        Dim oNet = CreateObject("WScript.Network")
        Try
            oNet.RemoveNetworkDrive("\\" & txtpcname & "\ipc$", True, False)
            oNet.RemoveNetworkDrive("\\" & txtpcname & "\admin$", True, False)
        Catch
        End Try
        oNet.MapNetworkDrive("", "\\" & txtpcname & "\ipc$", False, strUsername, strPassword)

        PCNAME.Focus()

        Try
            Dim path As String
            path = "\\" & txtpcname & "\c$\ProgramData\1E\PXELite"
            Dim objShell = CreateObject("Wscript.Shell")
            objShell.run(path)
        Catch ex As Exception
        End Try
        Try
            ' dismount the previously mounted secure channel
            oNet.RemoveNetworkDrive("\\" & txtpcname & "\ipc$", True, False)
        Catch ex As Exception
        End Try

    End Sub

    Private Sub OpenNomadLogFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OpenNomadLogFile.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        Dim strUsername As String
        Dim strPassword As String
        strUsername = domain & "\" & username
        strPassword = password

        Dim oNet = CreateObject("WScript.Network")
        Try
            oNet.RemoveNetworkDrive("\\" & txtpcname & "\ipc$", True, False)
            oNet.RemoveNetworkDrive("\\" & txtpcname & "\admin$", True, False)
        Catch
        End Try
        oNet.MapNetworkDrive("", "\\" & txtpcname & "\ipc$", False, strUsername, strPassword)

        PCNAME.Focus()

        Try
            Dim path As String
            path = "\\" & txtpcname & "\c$\ProgramData\1E\NomadBranch\Logfiles\NomadBranch.log"
            Dim objShell = CreateObject("Wscript.Shell")
            objShell.run(path)
        Catch ex As Exception
        End Try
        Try
            ' dismount the previously mounted secure channel
            oNet.RemoveNetworkDrive("\\" & txtpcname & "\ipc$", True, False)
        Catch ex As Exception
        End Try

    End Sub

    Private Sub PXElogOpen_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PXElogOpen.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        Dim strUsername As String
        Dim strPassword As String
        strUsername = domain & "\" & username
        strPassword = password

        Dim oNet = CreateObject("WScript.Network")
        Try
            oNet.RemoveNetworkDrive("\\" & txtpcname & "\ipc$", True, False)
            oNet.RemoveNetworkDrive("\\" & txtpcname & "\admin$", True, False)
        Catch
        End Try
        oNet.MapNetworkDrive("", "\\" & txtpcname & "\ipc$", False, strUsername, strPassword)

        PCNAME.Focus()

        Try
            Dim path As String
            path = "\\" & txtpcname & "\c$\ProgramData\1E\PXELite\PXELiteServer.log"
            Dim objShell = CreateObject("Wscript.Shell")
            objShell.run(path)
        Catch ex As Exception
        End Try
        Try
            ' dismount the previously mounted secure channel
            oNet.RemoveNetworkDrive("\\" & txtpcname & "\ipc$", True, False)
        Catch ex As Exception
        End Try

    End Sub

    Private Sub OpenTftrootImages_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OpenTftrootImages.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        Dim strUsername As String
        Dim strPassword As String
        strUsername = domain & "\" & username
        strPassword = password

        Dim oNet = CreateObject("WScript.Network")
        Try
            oNet.RemoveNetworkDrive("\\" & txtpcname & "\ipc$", True, False)
            oNet.RemoveNetworkDrive("\\" & txtpcname & "\admin$", True, False)
        Catch
        End Try
        oNet.MapNetworkDrive("", "\\" & txtpcname & "\ipc$", False, strUsername, strPassword)

        PCNAME.Focus()

        Try
            Dim path As String
            path = "\\" & txtpcname & "\c$\ProgramData\1E\PXELite\TftpRoot\Images"
            Dim objShell = CreateObject("Wscript.Shell")
            objShell.run(path)
        Catch ex As Exception
        End Try
        Try
            ' dismount the previously mounted secure channel
            oNet.RemoveNetworkDrive("\\" & txtpcname & "\ipc$", True, False)
        Catch ex As Exception
        End Try

    End Sub

    Function GetAppvVersion()
        BackgroundWorkerSpinnerStopWorker()

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Dim ReturnAPPVdetect As String = Nothing

        Dim strRead15 As String = Nothing
        Dim OutParams As ManagementBaseObject
        Dim objManagementScope As ManagementScope = Nothing
        Dim objManagementClass As ManagementClass = Nothing
        Dim objManagementBaseObject As ManagementBaseObject = Nothing
        Dim intRegistryHive As Microsoft.Win32.RegistryHive
        intRegistryHive = Microsoft.Win32.RegistryHive.LocalMachine

        Dim options As Management.ConnectionOptions
        options = New Management.ConnectionOptions()
        Dim computerconnect As String = "\\" & txtpcname & "\root\DEFAULT"
        options.Username = username
        options.Password = password
        options.Timeout = TimeSpan.FromSeconds(30)
        options.Authority = "NTLMDOMAIN:" & domain
        options.Authentication = Management.AuthenticationLevel.PacketPrivacy
        objManagementScope = New Management.ManagementScope(computerconnect, options)

        If objManagementScope.IsConnected = True Then
        Else
            objManagementScope.Connect()
        End If

        Try
            objManagementClass = New ManagementClass("StdRegProv")
            With objManagementClass

                .Scope = objManagementScope
                objManagementBaseObject = .GetMethodParameters("GetStringValue")

                With objManagementBaseObject
                    .SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                    .SetPropertyValue("sSubKeyName", "SOFTWARE\Microsoft\SoftGrid\4.5\Client\Configuration")
                    .SetPropertyValue("sValueName", "Version")
                End With
                OutParams = .InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                strRead15 = CType(OutParams("sValue"), String)
                If strRead15 = Nothing Then
                    With objManagementBaseObject
                        .SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                        .SetPropertyValue("sSubKeyName", "SOFTWARE\WOW6432node\Microsoft\SoftGrid\4.5\Client\Configuration")
                        .SetPropertyValue("sValueName", "Version")
                    End With
                    OutParams = .InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                    strRead15 = CType(OutParams("sValue"), String)
                End If

            End With

            ReturnAPPVdetect = strRead15

        Catch
        End Try

        If ReturnAPPVdetect = Nothing Then
            Try
                objManagementClass = New ManagementClass("StdRegProv")
                With objManagementClass

                    .Scope = objManagementScope
                    objManagementBaseObject = .GetMethodParameters("GetStringValue")

                    With objManagementBaseObject
                        .SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                        .SetPropertyValue("sSubKeyName", "SOFTWARE\Microsoft\AppV\Client")
                        .SetPropertyValue("sValueName", "Version")
                    End With
                    OutParams = .InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                    strRead15 = CType(OutParams("sValue"), String)
                End With

                ReturnAPPVdetect = strRead15

            Catch
            End Try

        End If

        objManagementScope = Nothing
        objManagementBaseObject.Dispose()
        objManagementClass.Dispose()

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
        PCNAME.Focus()
        Return ReturnAPPVdetect

    End Function

    Private Sub NSlookup_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NSlookup.Click
        BackgroundWorkerSpinnerStopWorker()

        Dim path As String
        Dim sResult As String
        Dim objShell = CreateObject("Wscript.Shell")
        path = "cmd.exe /k nslookup.exe " & PCNAME.Text
        Try
            sResult = objShell.run(path, 1, False)
        Catch ex As Exception
        End Try

    End Sub

    Private Sub SDlistpackages_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SDlistpackages.Click
        BackgroundWorkerSpinnerStopWorker()

        Dim ResultmapDrive = False
        Dim ReplacementString As String = ""

        MapDriveAdminRemove(username, password, domain, txtpcname)

        MapDriveAdmin(username, password, domain, txtpcname)

        If SDListDirectory.Text = "" Then
            Exit Sub
        End If

        SDList1.Items.Clear()
        SDList1Files.Items.Clear()


        If SDListDirectory.Items.Contains(SDListDirectory.Text) Then

        Else
            SDListDirectory.Items.Add(SDListDirectory.Text)
        End If



        Try
            Dim regKey As Microsoft.Win32.RegistryKey
            regKey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey("Software", True)
            regKey.CreateSubKey("RDT")
            regKey.Close()
        Catch ex As Exception
        End Try
        Try
            Dim regKey As Microsoft.Win32.RegistryKey
            regKey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey("Software\RDT", True)
            regKey.CreateSubKey("RDTExecuteDirShare")
            regKey.Close()
        Catch ex As Exception
        End Try

        ReplacementString = SDListDirectory.Text.Replace("\", "*")

        Try
            Dim regKey As Microsoft.Win32.RegistryKey
            regKey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey("Software\RDT\RDTExecuteDirShare", True)
            regKey.CreateSubKey(ReplacementString)
            regKey.Close()
        Catch ex As Exception
        End Try

        Dim di As New IO.DirectoryInfo(SDListDirectory.Text)
        Dim diar1 As IO.DirectoryInfo()
        Dim dra As IO.DirectoryInfo

        Try
            diar1 = di.GetDirectories()
        Catch
            MsgBox("Can list objects in the directory : Error!")
            PCNAME.Focus()
            Exit Sub
        End Try

        For Each dra In diar1
            SDList1.Items.Add(dra)
        Next


        MapDriveAdminRemove(username, password, domain, txtpcname)

        PCNAME.Focus()
    End Sub




    Private Sub DetectAPPV_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DetectAPPV.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If
        Dim strValueName As String = Nothing
        Dim TextOutput As String = Nothing
        Dim TextOut As String = Nothing
        Dim strRead1 As String = ""
        Dim strRead2 As String = ""
        Dim strRead3 As String = ""
        Dim strRead4 As String = ""
        Dim DetectedAPPVVersiontest As String = ""

        Try
            DetectedAPPVVersion = Nothing
            DetectedAPPVVersion = GetAppvVersion()

            If DetectedAPPVVersion = Nothing Then
                MsgBox("No APPV Client detected!")
                Exit Sub
            End If

            DetectedAPPVVersiontest = Microsoft.VisualBasic.Left(DetectedAPPVVersion, 1)
            If DetectedAPPVVersiontest = 5 Then
                Appv5.Show()
            End If
            If DetectedAPPVVersiontest = 4 Then
                AppV.Show()
            End If

        Catch ex As Exception
        End Try

    End Sub

    Private Sub NLTEST_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NLTEST.Click
        BackgroundWorkerSpinnerStopWorker()

        If userdomainComboBox.Text = "" Then
            Exit Sub
        End If

        If MachineName = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Dim lookforbackslash As Integer = InStr(userdomainComboBox.Text, "\")
        If lookforbackslash <> 0 Then
            Dim wordArr As String() = userdomainComboBox.Text.Split("\")
            Dim result As String = wordArr(1)
            LoggedOnUserNameOnly = result
            ' userbeingqueried.Text = LoggedOnUserNameOnly
            SIDKEY = GetSIDUsingADSearch(LoggedOnUserNameOnly)
        Else
            Exit Sub
        End If

        Dim DriveLetter = ""
        Dim strUsers = userdomainComboBox.Text
        Dim strComputerName As String = txtpcname
        Dim strStringValue As String = ""
        Dim strKeyPath As String = ""
        Dim objManagementScope As ManagementScope = Nothing
        Dim objManagementClass As ManagementClass = Nothing
        Dim objManagementBaseObject As ManagementBaseObject = Nothing
        Dim myValue As String = "....."
        'Dim aSubKeys2() As String
        Dim intRegistryHive As Microsoft.Win32.RegistryHive
        intRegistryHive = Microsoft.Win32.RegistryHive.Users


        Dim options As ConnectionOptions
        options = New ConnectionOptions()
        Dim computerconnect As String = "\\" & txtpcname & "\root\DEFAULT"

        options.Username = username
        options.Password = password
        options.Timeout = TimeSpan.FromSeconds(30)
        options.Authority = "NTLMDOMAIN:" & domain
        options.Authentication = AuthenticationLevel.PacketPrivacy
        objManagementScope = New ManagementScope(computerconnect, options)

        If objManagementScope.IsConnected = True Then
        Else
            Try
                objManagementScope.Connect()
            Catch ex As Exception
                BackgroundWorkerSpinner.CancelAsync()
                MetroProgressBar.Hide()
                PCNAME.Focus()
                MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                Exit Sub
            End Try
        End If

        strKeyPath = ""
        strKeyPath = SIDKEY & "\Volatile Environment\"

        Try
            objManagementClass = New ManagementClass("stdRegProv")
            objManagementClass.Scope = objManagementScope
            objManagementBaseObject = objManagementClass.GetMethodParameters("GetStringValue")
            objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
            objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath)
            objManagementBaseObject.SetPropertyValue("sValueName", "LOGONSERVER")
            objManagementBaseObject = objManagementClass.InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
            myValue = objManagementBaseObject("sValue")
            MessageBox.Show(LoggedOnUserNameOnly & " used LogonServer = " & myValue)
        Catch EX As Exception
        End Try

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
        PCNAME.Focus()

        Try
            objManagementScope = Nothing
            objManagementBaseObject.Dispose()
            objManagementClass.Dispose()
        Catch
        End Try

    End Sub

    Private Sub CheckAntivirus_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckAntivirus.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        Antivirus(username, password, domain, txtpcname)

    End Sub

    Private Sub Antivirus(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)
        If MachineName = "" Then
            Exit Sub
        End If

        Dim tbdisplayName As String = ""
        Dim AvStatus As String = ""
        Dim tbAvStatus As String = ""
        Dim tbAvCurrent As String = ""

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Try
            Dim objManagementScope2 As ManagementScope
            Dim options2 As ConnectionOptions
            options2 = New ConnectionOptions()
            Dim computerconnect2 As String = "\\" & txtpcname & "\root\SecurityCenter2"
            options2.Username = username
            options2.Password = password
            options2.Timeout = TimeSpan.FromSeconds(30)
            options2.Authority = "NTLMDOMAIN:" & domain
            options2.Authentication = AuthenticationLevel.PacketPrivacy
            objManagementScope2 = New ManagementScope(computerconnect2, options2)
            If objManagementScope2.IsConnected = True Then
            Else
                objManagementScope2.Connect()
            End If

            Dim QueryOptions = New EnumerationOptions
            QueryOptions.Timeout = New TimeSpan(0, 0, 10)
            Dim query2 As New SelectQuery("SELECT * FROM AntivirusProduct")
            Dim searcher2 As New ManagementObjectSearcher(objManagementScope2, query2, QueryOptions)
            For Each mo As ManagementObject In searcher2.[Get]()
                tbdisplayName = mo("displayName").ToString
                AvStatus = Hex(mo("ProductState")).ToString
                If Mid(AvStatus, 2, 2) = "10" Or Mid(AvStatus, 2, 2) = "11" Then
                    tbAvStatus = "AntiVirus enabled"
                ElseIf Mid(AvStatus, 2, 2) = "00" Or Mid(AvStatus, 2, 2) = "01" Then
                    tbAvStatus = "AntiVirus disabled"
                End If
                If Mid(AvStatus, 4, 2) = "00" Then
                    tbAvCurrent = "AntiVirus up-to-date"
                ElseIf Mid(AvStatus, 4, 2) = "10" Then
                    tbAvCurrent = "AntiVirus outdated"
                End If

                If tbdisplayName = "McAfee VirusScan Enterprise" Then

                    Try
                        Dim strStringValue As String = ""
                        Dim objManagementScope As ManagementScope = Nothing
                        Dim objManagementClass As ManagementClass = Nothing
                        Dim objManagementBaseObject As ManagementBaseObject = Nothing
                        Dim intRegistryHive As Microsoft.Win32.RegistryHive
                        intRegistryHive = Microsoft.Win32.RegistryHive.LocalMachine
                        Dim options As ConnectionOptions
                        options = New ConnectionOptions()
                        Dim computerconnect As String = "\\" & txtpcname & "\root\DEFAULT"
                        options.Username = txtusername
                        options.Password = txtpassword
                        options.Timeout = TimeSpan.FromSeconds(30)
                        options.Authority = "NTLMDOMAIN:" & txtdomain
                        options.Authentication = AuthenticationLevel.PacketPrivacy
                        objManagementScope = New ManagementScope(computerconnect, options)
                        If objManagementScope.IsConnected = True Then
                        Else
                            objManagementScope.Connect()
                        End If

                        objManagementClass = New ManagementClass("StdRegProv")

                        With objManagementClass
                            .Scope = objManagementScope
                            objManagementBaseObject = .GetMethodParameters("GetStringValue")
                            Dim OutParams As ManagementBaseObject

                            With objManagementBaseObject
                                .SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                                .SetPropertyValue("sSubKeyName", "SOFTWARE\McAfee\AVEngine")
                                .SetPropertyValue("sValueName", "AVDatDate")
                            End With
                            OutParams = .InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                            tbAvCurrent = CType(OutParams("sValue"), String)
                            If Len(tbAvCurrent) > 0 Then
                                'tbAvCurrent = "Yes"
                            Else
                                tbAvCurrent = ""
                            End If
                            If tbAvCurrent = "" Then
                                With objManagementBaseObject
                                    .SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                                    .SetPropertyValue("sSubKeyName", "SOFTWARE\WOW6432node\McAfee\AVEngine")
                                    .SetPropertyValue("sValueName", "AVDatDate")
                                End With
                                OutParams = .InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                                tbAvCurrent = CType(OutParams("sValue"), String)
                            End If
                        End With
                        Try
                            objManagementScope = Nothing
                            objManagementBaseObject.Dispose()
                            objManagementClass.Dispose()
                        Catch
                        End Try

                    Catch
                    End Try
                    BackgroundWorkerSpinner.CancelAsync()
                    MetroProgressBar.Hide()
                    PCNAME.Focus()
                    MsgBox(tbdisplayName & " ~ " & tbAvStatus & " ~ " & tbAvCurrent)
                Else
                    BackgroundWorkerSpinner.CancelAsync()
                    MetroProgressBar.Hide()
                    PCNAME.Focus()
                    MsgBox(tbdisplayName & " ~ " & tbAvStatus & " ~ " & tbAvCurrent & " ~ " & AvStatus)
                End If
            Next
        Catch
            MsgBox("Unable to connect to the ""Windows Control Centre"" on the remote machine.")
        End Try

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
        PCNAME.Focus()
    End Sub

    Private Sub GetUptime_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GetUptime.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        On Error Resume Next

        uptime1.Text = " "
        Dim uptime As String = Nothing
        Dim objManagementScope As ManagementScope = Nothing
        Dim objManagementClass As ManagementClass = Nothing
        Dim computerconnect As String
        Dim options As ConnectionOptions
        Dim ServerBootTime As String = Nothing
        options = New ConnectionOptions()
        computerconnect = "\\" & txtpcname & "\root\cimv2"
        options.Username = username
        options.Password = password
        options.Timeout = TimeSpan.FromSeconds(30)
        options.Authority = "NTLMDOMAIN:" & domain
        options.Authentication = AuthenticationLevel.PacketPrivacy
        objManagementScope = New ManagementScope(computerconnect, options)
        If objManagementScope.IsConnected = True Then
        Else
            objManagementScope.Connect()
        End If

        Dim QueryOptions = New EnumerationOptions
        QueryOptions.Timeout = New TimeSpan(0, 0, 10)
        Dim query_command2 As String = "SELECT LastBootUpTime FROM Win32_OperatingSystem WHERE Primary='true'"
        Dim select_query2 As SelectQuery = New SelectQuery(query_command2)
        Dim Srch2 As New ManagementObjectSearcher(objManagementScope, select_query2, QueryOptions)
        Dim objMgmt2 As ManagementObject
        For Each objMgmt2 In Srch2.Get
            'Dim ts As TimeSpan = TimeSpan.FromSeconds(objMgmt2("SystemUpTime"))
            'uptime = ts.Days & " days, " & ts.Hours & " hours, " & ts.Minutes & " minutes."
            uptime = ManagementDateTimeConverter.ToDateTime(objMgmt2.Properties("LastBootUpTime").Value.ToString())
            uptime1.Text = uptime
        Next

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
        PCNAME.Focus()


        objManagementScope = Nothing
        objManagementClass.Dispose()

    End Sub

    Private Sub SCCMMODE_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SCCMMODE.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Dim SCCMProvMode As String = ""
        Dim objManagementScope As ManagementScope = Nothing
        Dim objManagementClass As ManagementClass = Nothing
        Dim objManagementBaseObject As ManagementBaseObject = Nothing
        Dim intRegistryHive As Microsoft.Win32.RegistryHive
        intRegistryHive = Microsoft.Win32.RegistryHive.LocalMachine

        SCCMProvisioningMode.Text = ""

        Dim options As ConnectionOptions
        options = New ConnectionOptions()
        Dim computerconnect As String = "\\" & txtpcname & "\root\DEFAULT"

        options.Username = username
        options.Password = password
        options.Timeout = TimeSpan.FromSeconds(30)
        options.Authority = "NTLMDOMAIN:" & domain
        options.Authentication = AuthenticationLevel.PacketPrivacy
        objManagementScope = New ManagementScope(computerconnect, options)

        If objManagementScope.IsConnected = True Then
        Else
            Try
                objManagementScope.Connect()
            Catch ex As Exception
                BackgroundWorkerSpinner.CancelAsync()
                MetroProgressBar.Hide()
                PCNAME.Focus()
                Exit Sub
            End Try
        End If

        objManagementClass = New ManagementClass("StdRegProv")

        Try
            With objManagementClass
                .Scope = objManagementScope
                objManagementBaseObject = .GetMethodParameters("GetStringValue")

                With objManagementBaseObject
                    .SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                    .SetPropertyValue("sSubKeyName", "SOFTWARE\Microsoft\CCM\CcmExec")
                    .SetPropertyValue("sValueName", "ProvisioningMode")
                End With
                Dim OutParams As ManagementBaseObject = .InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                SCCMProvMode = CType(OutParams("sValue"), String)
            End With
        Catch ex As Exception
        End Try

        If SCCMProvMode = "" Then
            Try
                With objManagementClass
                    .Scope = objManagementScope
                    objManagementBaseObject = .GetMethodParameters("GetStringValue")

                    With objManagementBaseObject
                        .SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                        .SetPropertyValue("sSubKeyName", "SOFTWARE\Wow6432Node\Microsoft\CCM\CcmExec")
                        .SetPropertyValue("sValueName", "ProvisioningMode")
                    End With
                    Dim OutParams As ManagementBaseObject = .InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                    SCCMProvMode = CType(OutParams("sValue"), String)
                End With
            Catch ex As Exception
            End Try
        End If

        If SCCMProvMode = "false" Then SCCMProvisioningMode.ForeColor = Color.Green
        If SCCMProvMode = "false" Then SCCMProvisioningMode.Text = "False."
        If SCCMProvMode = "true" Then SCCMProvisioningMode.ForeColor = Color.Red
        If SCCMProvMode = "true" Then SCCMProvisioningMode.Text = "True!"

        PCNAME.Focus()

        Try
            objManagementScope = Nothing
            objManagementBaseObject.Dispose()
            objManagementClass.Dispose()
        Catch
        End Try

    End Sub

    Private Sub RetrieveEMAnumber_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Try
            Dim regKey As Microsoft.Win32.RegistryKey
            regKey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey("Software\RDT\" & MachineName, True)
            SaveEMAdetails.Text = regKey.GetValue("EMAdetails")
            regKey.Close()
        Catch ex As Exception
        End Try

        Try
            Dim regKey As Microsoft.Win32.RegistryKey
            regKey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey("Software\RDT\" & MachineName, True)
            Helpdesknumber.Text = regKey.GetValue("HelpdeskNumber")
            regKey.Close()
        Catch ex As Exception
        End Try

        PCNAME.Focus()
    End Sub

    Private Sub Helpme_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Helpme.Click
        Dim sResult As String
        Dim objShell = CreateObject("Wscript.Shell")
        Dim path2 As String = Directory.GetCurrentDirectory()
        Try
            sResult = objShell.run("help.pdf", 1, False)
        Catch ex As Exception
        End Try
    End Sub


    Private Sub DomainRobocopy()

        MapDriveAdmin(username, password, domain, txtpcname)

        Try
            Dim fullPath As String = "\\" & txtpcname & "\c$\Program Files\RDT"
            Directory.CreateDirectory(fullPath)
            Dim fullPath2 As String = "\\" & txtpcname & "\c$\Program Files\RDT\RDT"
            Directory.CreateDirectory(fullPath2)
            Dim fullPath3 As String = "\\" & txtpcname & "\c$\Program Files\RDT\RDT\" & SDBOXFolder.Text
            Directory.CreateDirectory(fullPath3)

            Dim UserAccount As String = domain & "\" & username
            Dim FolderInfo As IO.DirectoryInfo = New IO.DirectoryInfo(fullPath3)
            Dim FolderAcl As New System.Security.AccessControl.DirectorySecurity
            FolderAcl = FolderInfo.GetAccessControl()
            FolderAcl.AddAccessRule(New System.Security.AccessControl.FileSystemAccessRule(UserAccount, FileSystemRights.FullControl, InheritanceFlags.ContainerInherit Or InheritanceFlags.ObjectInherit, PropagationFlags.None, AccessControlType.Allow))
            FolderInfo.SetAccessControl(FolderAcl)
        Catch ex As Exception
        End Try

        Try
            Dim securepass As New Security.SecureString
            Dim c As Char
            For Each c In password
                securepass.AppendChar(c)
            Next
            Dim jumper As Process = Process.Start(New ProcessStartInfo() With {.UseShellExecute = False, .FileName = "CMD.exe", .UserName = username, .Password = securepass, .Domain = domain, .Arguments = "/C ROBOCOPY " & Chr(34) & SDListDirectory.Text & "\" & SDBOXFolder.Text & Chr(34) & " " & Chr(34) & "\\" & MachineName & "\c$\Progra~1\RDT\RDT\" & SDBOXFolder.Text & Chr(34) & " /S /E /Z", .WorkingDirectory = "C:\Windows\System32", .WindowStyle = ProcessWindowStyle.Hidden})
            jumper.WaitForExit()
        Catch ex As Exception
        End Try

        MapDriveAdminRemove(username, password, domain, txtpcname)

    End Sub

    Private Sub Createcopylocal(ByVal txtpcname As String)
        Try

            Dim fullPath As String = "\\" & txtpcname & "\c$\Program Files\RDT"
            Directory.CreateDirectory(fullPath)
            Dim fullPath2 As String = "\\" & txtpcname & "\c$\Program Files\RDT\RDT"
            Directory.CreateDirectory(fullPath2)
            Dim fullPath3 As String = "\\" & txtpcname & "\c$\Program Files\RDT\RDT\" & SDBOXFolder.Text
            Directory.CreateDirectory(fullPath3)

            Dim UserAccount As String = domain & "\" & username
            Dim FolderInfo As IO.DirectoryInfo = New IO.DirectoryInfo(fullPath3)
            Dim FolderAcl As New System.Security.AccessControl.DirectorySecurity
            FolderAcl = FolderInfo.GetAccessControl()
            FolderAcl.AddAccessRule(New System.Security.AccessControl.FileSystemAccessRule(UserAccount, FileSystemRights.FullControl, InheritanceFlags.ContainerInherit Or InheritanceFlags.ObjectInherit, PropagationFlags.None, AccessControlType.Allow))
            FolderInfo.SetAccessControl(FolderAcl)

            Dim W As New IO.StreamWriter("\\" & txtpcname & "\c$\Program Files\RDT\CopyLocal.bat")
            W.WriteLine("set SEE_MASK_NOZONECHECKS=1")
            W.WriteLine("net use " & Inst_RemDriveLetter.Text & ": " & Chr(34) & SDListDirectory.Text & "\" & SDBOXFolder.Text & Chr(34) & " /user:%1\%2 %3")
            'W.WriteLine(Inst_RemDriveLetter.Text & ":")
            W.WriteLine("ROBOCOPY " & Inst_RemDriveLetter.Text & ":\ " & Chr(34) & "C:\Program Files\RDT\RDT\" & SDBOXFolder.Text & Chr(34) & " /S /E /Z")
            W.WriteLine("net use " & Inst_RemDriveLetter.Text & ": /DELETE /YES")
            W.WriteLine("EXIT 0")
            W.Close()

        Catch
        End Try
    End Sub


    Private Sub Copylocalfiles()
        Dim processID As UInteger = 0

        Try
            Dim connOptions As New Management.ConnectionOptions()
            connOptions.Username = username
            connOptions.Password = password
            connOptions.Timeout = TimeSpan.FromSeconds(30)
            connOptions.Authority = "NTLMDOMAIN:" & domain
            connOptions.EnablePrivileges = True
            connOptions.Authentication = AuthenticationLevel.PacketPrivacy
            connOptions.Impersonation = ImpersonationLevel.Impersonate
            connOptions.EnablePrivileges = True
            Dim manScope As New Management.ManagementScope([String].Format("\\{0}\ROOT\CIMV2", txtpcname), connOptions)

            Try
                manScope.Connect()
            Catch
                MsgBox("Couldn't connect to remote PC.")
                Exit Sub
            End Try
            Dim Commandtorun As String = ""
            Dim objectGetOptions As New Management.ObjectGetOptions()
            Dim managementPath As New Management.ManagementPath("Win32_Process")
            Using processClass As New Management.ManagementClass(manScope, managementPath, objectGetOptions)
                Using inParams As Management.ManagementBaseObject = processClass.GetMethodParameters("Create")
                    inParams("CommandLine") = Chr(34) & "C:\Program Files\RDT\CopyLocal.bat" & Chr(34) & " " & domain & " " & username & " " & password
                    Using outParams As Management.ManagementBaseObject = processClass.InvokeMethod("Create", inParams, Nothing)
                        If CUInt(outParams("returnValue")) <> 0 Then
                            MsgBox("Copy process failed...")
                            Commandtorun = "CMD.EXE /C RD /S /Q " & Chr(34) & "\\" & MachineName & "\c$\Progra~1\RDT" & Chr(34)
                            Try
                                Dim objShell = CreateObject("Wscript.Shell")
                                objShell.run(Commandtorun, 0, False)
                            Catch ex As Exception
                            End Try
                        Else
                            MsgBox("Copy process started at : " & Now & " : with a process Id of : " & CUInt(outParams("processId")))
                            processID = CUInt(outParams("processId"))
                        End If
                    End Using
                End Using
            End Using
        Catch
        End Try

    End Sub



    Private Sub GatherBIOSInfo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GatherBIOSInfo.Click
        BackgroundWorkerSpinnerStopWorker()
        If MachineName = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Try
            GETSTRVALUESBIOS(username, password, domain, txtpcname)
        Catch
        End Try

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
        PCNAME.Focus()
    End Sub

    Public Sub GETSTRVALUESBIOS(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)
        On Error Resume Next

        Dim strRead7 As String = Nothing
        Dim strRead8 As String = Nothing
        Dim strRead9 As String = Nothing
        Dim strRead10 As String = Nothing
        Dim strRead11 As String = Nothing

        DataGridViewDetails.Rows.Clear()

        If PCnameFordetails.Text <> "" Then

            Dim strStringValue As String = ""
            Dim strSubKeyName As String
            Dim objManagementScope As ManagementScope = Nothing
            Dim objManagementClass As ManagementClass = Nothing
            Dim objManagementBaseObject As ManagementBaseObject = Nothing
            Dim intRegistryHive As Microsoft.Win32.RegistryHive
            intRegistryHive = Microsoft.Win32.RegistryHive.LocalMachine
            Dim options As ConnectionOptions
            options = New ConnectionOptions()
            Dim computerconnect As String = "\\" & txtpcname & "\root\DEFAULT"
            options.Username = txtusername
            options.Password = txtpassword
            options.Timeout = TimeSpan.FromSeconds(30)
            options.Authority = "NTLMDOMAIN:" & txtdomain
            options.Authentication = AuthenticationLevel.PacketPrivacy
            objManagementScope = New ManagementScope(computerconnect, options)
            If objManagementScope.IsConnected = True Then
            Else
                objManagementScope.Connect()
            End If

            objManagementClass = New ManagementClass("StdRegProv")

            With objManagementClass
                .Scope = objManagementScope
                objManagementBaseObject = .GetMethodParameters("GetStringValue")
                Dim OutParams As ManagementBaseObject

                With objManagementBaseObject
                    .SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                    .SetPropertyValue("sSubKeyName", "HARDWARE\DESCRIPTION\System\BIOS")
                    .SetPropertyValue("sValueName", "SystemManufacturer")
                End With
                OutParams = .InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                strRead7 = CType(OutParams("sValue"), String)

                With objManagementBaseObject
                    .SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                    .SetPropertyValue("sSubKeyName", "HARDWARE\DESCRIPTION\System\BIOS")
                    .SetPropertyValue("sValueName", "SystemProductName")
                End With
                OutParams = .InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                strRead8 = CType(OutParams("sValue"), String)

                With objManagementBaseObject
                    .SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                    .SetPropertyValue("sSubKeyName", "HARDWARE\DESCRIPTION\System\BIOS")
                    .SetPropertyValue("sValueName", "BIOSVendor")
                End With
                OutParams = .InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                strRead9 = CType(OutParams("sValue"), String)

                With objManagementBaseObject
                    .SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                    .SetPropertyValue("sSubKeyName", "HARDWARE\DESCRIPTION\System\BIOS")
                    .SetPropertyValue("sValueName", "BIOSVersion")
                End With
                OutParams = .InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                strRead10 = CType(OutParams("sValue"), String)

                With objManagementBaseObject
                    .SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                    .SetPropertyValue("sSubKeyName", "HARDWARE\DESCRIPTION\System\BIOS")
                    .SetPropertyValue("sValueName", "BIOSReleaseDate")
                End With
                OutParams = .InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                strRead11 = CType(OutParams("sValue"), String)

            End With


            DataGridViewDetails.Rows.Add("Bios System Manufacturer", strRead7)
            DataGridViewDetails.Rows.Add("Bios System Product Name", strRead8)
            DataGridViewDetails.Rows.Add("Bios Vendor", strRead9)
            DataGridViewDetails.Rows.Add("Bios Version", strRead10)
            DataGridViewDetails.Rows.Add("Bios Release Date", strRead11)
            DataGridViewDetails.Rows.Add(" ", " ")
            objManagementScope = Nothing


            Dim objManagementScope2 As ManagementScope
                Dim options2 As ConnectionOptions
                options2 = New ConnectionOptions()
                Dim computerconnect2 As String = "\\" & txtpcname & "\root\cimv2"
                options2.Username = username
                options2.Password = password
                options2.Timeout = TimeSpan.FromSeconds(30)
                options2.Authority = "NTLMDOMAIN:" & domain
                options2.Authentication = AuthenticationLevel.PacketPrivacy
                objManagementScope2 = New ManagementScope(computerconnect2, options2)
                If objManagementScope2.IsConnected = True Then
                Else
                    objManagementScope2.Connect()
                End If

                Dim QueryOptions = New EnumerationOptions
                QueryOptions.Timeout = New TimeSpan(0, 0, 10)
                Dim query2 As New SelectQuery("SELECT * FROM Win32_Bios")
                Dim searcher2 As New ManagementObjectSearcher(objManagementScope2, query2, QueryOptions)
                For Each mo As ManagementObject In searcher2.[Get]()
                    strRead7 = mo("Manufacturer")
                    strRead8 = mo("Name")
                strRead9 = mo("BIOSVersion")
                strRead10 = mo("SerialNumber")
                strRead11 = mo("ReleaseDate")

                DataGridViewDetails.Rows.Add("WMI - Bios System Manufacturer", strRead7)
                DataGridViewDetails.Rows.Add("WMI - Bios System Product Name", strRead8)
                DataGridViewDetails.Rows.Add("WMI - Bios Serial Number", strRead10)
                DataGridViewDetails.Rows.Add("WMI - Bios Version", strRead9)
                DataGridViewDetails.Rows.Add("WMI - Bios Release Date", strRead11)
            Next

            objManagementScope2 = Nothing
            objManagementScope = Nothing
            objManagementBaseObject.Dispose()
            objManagementClass.Dispose()

        End If

    End Sub


    Private Sub GatherVideoInfo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GatherVideoInfo.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Try
            GETSTRVALUESVIDEO(username, password, domain, txtpcname)
        Catch
        End Try

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
        PCNAME.Focus()
    End Sub

    Public Sub GETSTRVALUESVIDEO(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)
        On Error Resume Next

        Dim VideoName As String = Nothing
        Dim VideoDriverVersion As String = Nothing
        Dim VideoAdapterRAM As String = Nothing
        Dim VideoDriverDate As DateTime = Nothing
        Dim VideoModeDescription As String = Nothing

        DataGridViewDetails.Rows.Clear()

        If PCnameFordetails.Text <> "" Then

            Dim objManagementScope2 As ManagementScope
            Dim options2 As ConnectionOptions
            options2 = New ConnectionOptions()
            Dim computerconnect2 As String = "\\" & txtpcname & "\root\cimv2"
            options2.Username = username
            options2.Password = password
            options2.Timeout = TimeSpan.FromSeconds(30)
            options2.Authority = "NTLMDOMAIN:" & domain
            options2.Authentication = AuthenticationLevel.PacketPrivacy
            objManagementScope2 = New ManagementScope(computerconnect2, options2)
            If objManagementScope2.IsConnected = True Then
            Else
                objManagementScope2.Connect()
            End If

            Dim QueryOptions = New EnumerationOptions
            QueryOptions.Timeout = New TimeSpan(0, 0, 10)
            Dim query4 As New SelectQuery("SELECT * FROM Win32_VideoController")
            Dim searcher4 As New ManagementObjectSearcher(objManagementScope2, query4, QueryOptions)
            For Each mo As ManagementObject In searcher4.[Get]()
                VideoName = mo("Name").ToString
                VideoDriverVersion = mo("DriverVersion").ToString
                VideoDriverDate = ManagementDateTimeConverter.ToDateTime(CStr(mo("DriverDate")))
                VideoAdapterRAM = mo("AdapterRAM").ToString
                VideoModeDescription = mo("VideoModeDescription")
            Next

            DataGridViewDetails.Rows.Add("Video Adapter", VideoName)
            DataGridViewDetails.Rows.Add("Video Driver Version", VideoDriverVersion)
            DataGridViewDetails.Rows.Add("Video Driver Date", VideoDriverDate)
            DataGridViewDetails.Rows.Add("Video Adapter Memory", VideoAdapterRAM)
            DataGridViewDetails.Rows.Add("Video Mode Description", VideoModeDescription)


            objManagementScope2 = Nothing

        End If

    End Sub

    Private Sub GatherNetworkInfo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GatherNetworkInfo.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Try
            GETSTRVALUESNetwork(username, password, domain, txtpcname)
        Catch
        End Try

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
        PCNAME.Focus()
    End Sub

    Public Sub GETSTRVALUESNetwork(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)
        On Error Resume Next

        Dim sActiveName As String = Nothing
        Dim sMACAddress As String = Nothing
        Dim NetworkDeviceName As String = Nothing
        Dim NetworkDriverVersion As String = Nothing
        Dim NetworkDriverDate As DateTime = Nothing

        DataGridViewDetails.Rows.Clear()

        If PCnameFordetails.Text <> "" Then

            Dim objManagementScope2 As ManagementScope
            Dim options2 As ConnectionOptions
            options2 = New ConnectionOptions()
            Dim computerconnect2 As String = "\\" & txtpcname & "\root\cimv2"
            options2.Username = username
            options2.Password = password
            options2.Timeout = TimeSpan.FromSeconds(30)
            options2.Authority = "NTLMDOMAIN:" & domain
            options2.Authentication = AuthenticationLevel.PacketPrivacy
            objManagementScope2 = New ManagementScope(computerconnect2, options2)
            If objManagementScope2.IsConnected = True Then
            Else
                objManagementScope2.Connect()
            End If

            Dim QueryOptions = New EnumerationOptions
            QueryOptions.Timeout = New TimeSpan(0, 0, 10)
            Dim query5 As New SelectQuery("Select * from Win32_NetworkAdapter Where NetConnectionStatus = 2")
            Dim searcher5 As New ManagementObjectSearcher(objManagementScope2, query5, QueryOptions)
            For Each mo As ManagementObject In searcher5.[Get]()
                sActiveName = mo("description").ToString
                sMACAddress = mo("MACAddress").ToString
            Next
            Dim query6 As New SelectQuery("Select * from Win32_PnPSignedDriver where deviceclass = 'net' and Devicename = '" & sActiveName & "'")
            Dim searcher6 As New ManagementObjectSearcher(objManagementScope2, query6)
            For Each mo As ManagementObject In searcher6.[Get]()
                NetworkDeviceName = mo("DeviceName").ToString
                NetworkDriverDate = ManagementDateTimeConverter.ToDateTime(CStr(mo("DriverDate")))
                NetworkDriverVersion = mo("DriverVersion").ToString()
            Next

            DataGridViewDetails.Rows.Add("Network Adapter Name", NetworkDeviceName)
            DataGridViewDetails.Rows.Add("Network Adapter Address", sMACAddress)
            DataGridViewDetails.Rows.Add("Network Driver Version", NetworkDriverVersion)
            DataGridViewDetails.Rows.Add("Network Driver Date", NetworkDriverDate)

            objManagementScope2 = Nothing
        End If

    End Sub

    Private Sub DefragC_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DefragC.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        Dim errResult = Nothing
        Dim errorcodes = "0 = Completed successfully" & vbLf
        errorcodes = errorcodes + "2 = Unsuccessful; not enough free space" & vbLf
        errorcodes = errorcodes + "3 = The process was interrupted before completing" & vbLf
        errorcodes = errorcodes + "4 = Unsuccessful; drive contains errors" & vbLf
        errorcodes = errorcodes + "5 = Unsuccessful; error reading from drive" & vbLf
        errorcodes = errorcodes + "6 = Unsuccessful; error writing to drive" & vbLf
        errorcodes = errorcodes + "9 = Unsuccessful; not enough memory" & vbLf
        errorcodes = errorcodes + "10 = Unsuccessful; the drive was invalid" & vbLf
        errorcodes = errorcodes + "15 = Unsuccessful; disk was write-protected" & vbLf
        errorcodes = errorcodes + "26 = Unsuccessful; could not access drive" & vbLf
        errorcodes = errorcodes + "105 = Unsuccessful; drive was locked" & vbLf
        errorcodes = errorcodes + "106 = Unsuccessful; could not access drive" & vbLf
        errorcodes = errorcodes + "108 = Unsuccessful; could not access drive" & vbLf
        errorcodes = errorcodes + "109 = Unsuccessful; 32-bit compression driver not installed" & vbLf
        errorcodes = errorcodes + "249 = One or more drives could not be defragmented" & vbLf

        Dim response As MsgBoxResult = MsgBoxResult.No
        response = MsgBox("Are you sure you want to Defrag the remote C Drive (this may take some time to run and hang the RDT tool while it completes) ?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "Confirm")
        If response = MsgBoxResult.Yes Then

            Try
                Dim objManagementScope As ManagementScope

                Dim options As ConnectionOptions
                options = New ConnectionOptions()
                Dim computerconnect As String = "\\" & txtpcname & "\root\cimv2"

                options.Username = username
                options.Password = password
                options.Timeout = TimeSpan.FromSeconds(30)
                options.Authority = "NTLMDOMAIN:" & domain
                options.Authentication = AuthenticationLevel.PacketPrivacy
                objManagementScope = New ManagementScope(computerconnect, options)

                If objManagementScope.IsConnected = True Then
                Else
                    Try
                        objManagementScope.Connect()
                    Catch ex As Exception
                        MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                        PCNAME.Focus()
                        Exit Sub
                    End Try
                End If

                ' define a select query
                Dim QueryOptions = New EnumerationOptions
                QueryOptions.Timeout = New TimeSpan(0, 0, 10)
                Dim query As New SelectQuery("Select * from Win32_Volume Where Name = 'C:\\'")
                Dim searcher As New ManagementObjectSearcher(objManagementScope, query, QueryOptions)
                Dim args As Object = Nothing
                Try
                    For Each mo As ManagementObject In searcher.[Get]()
                        MsgBox("Defrag started on C: Drive of : " & MachineName)
                        errResult = mo.InvokeMethod("Defrag", args)
                        errorcodes = errorcodes + " " & vbLf
                        errorcodes = errorcodes + "Your Defrag finished with ExitCode : " & errResult
                        MsgBox(errorcodes)
                    Next
                Catch ex As Exception
                    PCNAME.Focus()
                    MsgBox("Error Code : " & ex.Message)
                End Try
                Try
                    objManagementScope = Nothing
                Catch
                End Try
            Catch ex As Exception
                PCNAME.Focus()
                MsgBox(ex.Message)
            End Try
            PCNAME.Focus()
        ElseIf response = MsgBoxResult.No Then
            Exit Sub
        End If

    End Sub

    Private Sub SetServiceStartDisabled_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SetServiceStartDisabled.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Try

            Dim objManagementScope As ManagementScope
            Dim objManagementClass As ManagementClass = Nothing
            Dim objManagementBaseObject As ManagementBaseObject = Nothing

            Dim options As ConnectionOptions
            options = New ConnectionOptions()
            Dim computerconnect As String = "\\" & txtpcname & "\root\cimv2"

            options.Username = username
            options.Password = password
            options.Timeout = TimeSpan.FromSeconds(30)
            options.Authority = "NTLMDOMAIN:" & domain
            options.Authentication = AuthenticationLevel.PacketPrivacy
            objManagementScope = New ManagementScope(computerconnect, options)

            If objManagementScope.IsConnected = True Then
            Else
                Try
                    objManagementScope.Connect()
                Catch ex As Exception
                    BackgroundWorkerSpinner.CancelAsync()
                    MetroProgressBar.Hide()
                    PCNAME.Focus()
                    MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                    Exit Sub
                End Try
            End If

            Dim QueryOptions = New EnumerationOptions
            QueryOptions.Timeout = New TimeSpan(0, 0, 10)
            Dim query As New SelectQuery("SELECT * FROM Win32_Service Where Name = " & Chr(34) & ServiceNameSelected.Text & Chr(34) & " ")
            Dim searcher As New ManagementObjectSearcher(objManagementScope, query, QueryOptions)
            Dim args As Object = Nothing
            Try
                For Each mo As ManagementObject In searcher.[Get]()
                    Dim inParams As ManagementBaseObject
                    inParams = mo.GetMethodParameters("ChangeStartMode")
                    inParams("StartMode") = "Disabled"
                    mo.InvokeMethod("ChangeStartMode", inParams, Nothing)
                Next
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
            Try
                objManagementScope = Nothing
                objManagementBaseObject.Dispose()
                objManagementClass.Dispose()
            Catch
            End Try
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        GetServices2()

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
        PCNAME.Focus()
    End Sub

    Private Sub GetSCCMinfo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GetSCCMinfo.Click
        If MachineName = "" Then
            Exit Sub
        End If

        Dim strKeyPath As String = "SOFTWARE\Microsoft\SMS\Mobile Client"
        Dim strKeyPath64 As String = "SOFTWARE\WOW6432node\Microsoft\SMS\Mobile Client"
        Dim SCCMAssignedSiteCode As String = ""
        Dim SCCMProductVersion As String = ""
        Dim objManagementScope As ManagementScope = Nothing
        Dim objManagementClass As ManagementClass = Nothing
        Dim objManagementBaseObject As ManagementBaseObject = Nothing
        Dim intRegistryHive As Microsoft.Win32.RegistryHive
        intRegistryHive = Microsoft.Win32.RegistryHive.LocalMachine

        Dim options As ConnectionOptions
        options = New ConnectionOptions()
        Dim computerconnect As String = "\\" & txtpcname & "\root\DEFAULT"

        options.Username = username
        options.Password = password
        options.Timeout = TimeSpan.FromSeconds(30)
        options.Authority = "NTLMDOMAIN:" & domain
        options.Authentication = AuthenticationLevel.PacketPrivacy
        objManagementScope = New ManagementScope(computerconnect, options)

        If objManagementScope.IsConnected = True Then
        Else
            Try
                objManagementScope.Connect()
            Catch ex As Exception
                PCNAME.Focus()
                Exit Sub
            End Try
        End If

        objManagementClass = New ManagementClass("StdRegProv")

        Try
            With objManagementClass
                .Scope = objManagementScope
                objManagementBaseObject = .GetMethodParameters("GetStringValue")

                With objManagementBaseObject
                    .SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                    .SetPropertyValue("sSubKeyName", strKeyPath)
                    .SetPropertyValue("sValueName", "AssignedSiteCode")
                End With
                Dim OutParams As ManagementBaseObject = .InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                SCCMAssignedSiteCode = CType(OutParams("sValue"), String)
            End With
        Catch ex As Exception
        End Try

        Try
            With objManagementClass
                .Scope = objManagementScope
                objManagementBaseObject = .GetMethodParameters("GetStringValue")

                With objManagementBaseObject
                    .SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                    .SetPropertyValue("sSubKeyName", strKeyPath)
                    .SetPropertyValue("sValueName", "SmsClientVersion")
                End With
                Dim OutParams As ManagementBaseObject = .InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                SCCMProductVersion = CType(OutParams("sValue"), String)
            End With
        Catch ex As Exception
        End Try

        If SCCMAssignedSiteCode = "" Then
            Try
                With objManagementClass
                    .Scope = objManagementScope
                    objManagementBaseObject = .GetMethodParameters("GetStringValue")

                    With objManagementBaseObject
                        .SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                        .SetPropertyValue("sSubKeyName", strKeyPath64)
                        .SetPropertyValue("sValueName", "AssignedSiteCode")
                    End With
                    Dim OutParams As ManagementBaseObject = .InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                    SCCMAssignedSiteCode = CType(OutParams("sValue"), String)
                End With
            Catch ex As Exception
            End Try
        End If

        If SCCMProductVersion = "" Then
            Try
                With objManagementClass
                    .Scope = objManagementScope
                    objManagementBaseObject = .GetMethodParameters("GetStringValue")

                    With objManagementBaseObject
                        .SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                        .SetPropertyValue("sSubKeyName", strKeyPath64)
                        .SetPropertyValue("sValueName", "SmsClientVersion")
                    End With
                    Dim OutParams As ManagementBaseObject = .InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                    SCCMProductVersion = CType(OutParams("sValue"), String)
                End With
            Catch ex As Exception
            End Try
        End If

        PCNAME.Focus()

        MsgBox("AssignedSiteCode=" & SCCMAssignedSiteCode & " , SmsClientVersion=" & SCCMProductVersion)

        Try
            objManagementScope = Nothing
            objManagementBaseObject.Dispose()
            objManagementClass.Dispose()
        Catch
        End Try

    End Sub

    Private Sub ExportDataGridViewDetails_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExportDataGridViewDetails.Click
        Using outputFile As New IO.StreamWriter("c:\windows\temp\export.csv")
            outputFile.WriteLine(MachineName)
            outputFile.WriteLine(txtpcname)
            outputFile.WriteLine(" ")
            Try
                For Each row As DataGridViewRow In DataGridViewDetails.Rows
                    If Not row.IsNewRow Then
                        Dim line As String = String.Empty
                        For x As Integer = 0 To row.Cells.Count - 1
                            line &= row.Cells(x).Value & ","
                        Next
                        outputFile.WriteLine(line.Remove(line.Length - 1, 1))
                    End If
                Next
                outputFile.Flush()
            Catch ex As Exception
            End Try
        End Using
        Try
            Dim objShell = CreateObject("Wscript.Shell")
            objShell.run("c:\windows\temp\export.csv")
        Catch ex As Exception
        End Try
    End Sub

    Private Sub ExportDISK_DETAILS_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExportDISK_DETAILS.Click
        Try
            Using outputFile As New IO.StreamWriter("c:\windows\temp\export.csv")
                outputFile.WriteLine(MachineName)
                outputFile.WriteLine(txtpcname)
                outputFile.WriteLine(" ")
                Try
                    Dim array As String() = New String(DataGridViewDisk2.Columns.Count - 1) {}
                    'get column header text from all columns:
                    For j As Integer = 0 To DataGridViewDisk2.Columns.Count - 1
                        array(j) = DataGridViewDisk2.Columns(j).HeaderText
                    Next
                    outputFile.WriteLine([String].Join(",", array))
                Catch ex As Exception
                End Try
                For Each row As DataGridViewRow In DataGridViewDisk2.Rows
                    If Not row.IsNewRow Then
                        Dim line As String = String.Empty
                        For x As Integer = 0 To row.Cells.Count - 1
                            line &= row.Cells(x).Value & ","
                        Next
                        outputFile.WriteLine(line.Remove(line.Length - 1, 1))
                    End If
                Next
                outputFile.WriteLine(" ")
                Try
                    Dim array As String() = New String(DataGridViewDisk.Columns.Count - 1) {}
                    'get column header text from all columns:
                    For j As Integer = 0 To DataGridViewDisk.Columns.Count - 1
                        array(j) = DataGridViewDisk.Columns(j).HeaderText
                    Next
                    outputFile.WriteLine([String].Join(",", array))
                Catch ex As Exception
                End Try
                For Each row As DataGridViewRow In DataGridViewDisk.Rows
                    If Not row.IsNewRow Then
                        Dim line As String = String.Empty
                        For x As Integer = 0 To row.Cells.Count - 1
                            line &= row.Cells(x).Value & ","
                        Next
                        outputFile.WriteLine(line.Remove(line.Length - 1, 1))
                    End If
                Next
                outputFile.Flush()
            End Using
        Catch ex As Exception
        End Try
        Try
            Dim objShell = CreateObject("Wscript.Shell")
            objShell.run("c:\windows\temp\export.csv")
        Catch ex As Exception
        End Try
    End Sub

    Private Sub ExportFileTypes_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExportFileTypes.Click
        Try
            Dim entry As String
            Dim sw As System.IO.StreamWriter = New System.IO.StreamWriter("c:\windows\temp\export.csv")
            sw.WriteLine(MachineName)
            sw.WriteLine(txtpcname)
            sw.WriteLine(" ")
            For Each entry In FileTypes.Items
                sw.WriteLine(entry)
            Next
            sw.Close()
        Catch ex As Exception
        End Try
        Try
            Dim objShell = CreateObject("Wscript.Shell")
            objShell.run("c:\windows\temp\export.csv")
        Catch ex As Exception
        End Try
    End Sub

    Private Sub ExportPatches_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExportPatches.Click
        Try
            Using outputFile As New IO.StreamWriter("c:\windows\temp\export.csv")
                outputFile.WriteLine(MachineName)
                outputFile.WriteLine(txtpcname)
                outputFile.WriteLine(" ")
                Try
                    Dim array As String() = New String(DataGridView10.Columns.Count - 1) {}
                    'get column header text from all columns:
                    For j As Integer = 0 To DataGridView10.Columns.Count - 1
                        array(j) = DataGridView10.Columns(j).HeaderText
                    Next
                    outputFile.WriteLine([String].Join(",", array))
                Catch ex As Exception
                End Try
                For Each row As DataGridViewRow In DataGridView10.Rows
                    If Not row.IsNewRow Then
                        Dim line As String = String.Empty
                        For x As Integer = 0 To row.Cells.Count - 1
                            line &= row.Cells(x).Value & ","
                        Next
                        outputFile.WriteLine(line.Remove(line.Length - 1, 1))
                    End If
                Next
                outputFile.Flush()
            End Using
        Catch ex As Exception
        End Try
        Try
            Dim objShell = CreateObject("Wscript.Shell")
            objShell.run("c:\windows\temp\export.csv")
        Catch ex As Exception
        End Try
    End Sub

    Private Sub ExportSCCMhistory_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExportSCCMhistory.Click
        Try
            Using outputFile As New IO.StreamWriter("c:\windows\temp\export.csv")
                outputFile.WriteLine(MachineName)
                outputFile.WriteLine(txtpcname)
                outputFile.WriteLine(" ")
                Try
                    Dim array As String() = New String(DataGridView9.Columns.Count - 1) {}
                    'get column header text from all columns:
                    For j As Integer = 0 To DataGridView9.Columns.Count - 1
                        array(j) = DataGridView9.Columns(j).HeaderText
                    Next
                    outputFile.WriteLine([String].Join(",", array))
                Catch ex As Exception
                End Try
                For Each row As DataGridViewRow In DataGridView9.Rows
                    If Not row.IsNewRow Then
                        Dim line As String = String.Empty
                        For x As Integer = 0 To row.Cells.Count - 1
                            line &= row.Cells(x).Value & ","
                        Next
                        outputFile.WriteLine(line.Remove(line.Length - 1, 1))
                    End If
                Next
                outputFile.Flush()
            End Using
        Catch ex As Exception
        End Try
        Try
            Dim objShell = CreateObject("Wscript.Shell")
            objShell.run("c:\windows\temp\export.csv")
        Catch ex As Exception
        End Try
    End Sub

    Private Sub ExportServices_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExportServices.Click
        Try
            Using outputFile As New IO.StreamWriter("c:\windows\temp\export.csv")
                outputFile.WriteLine(MachineName)
                outputFile.WriteLine(txtpcname)
                outputFile.WriteLine(" ")
                Try
                    Dim array As String() = New String(DataGridView7.Columns.Count - 1) {}
                    'get column header text from all columns:
                    For j As Integer = 0 To DataGridView7.Columns.Count - 1
                        array(j) = DataGridView7.Columns(j).HeaderText
                    Next
                    outputFile.WriteLine([String].Join(",", array))
                Catch ex As Exception
                End Try
                For Each row As DataGridViewRow In DataGridView7.Rows
                    If Not row.IsNewRow Then
                        Dim line As String = String.Empty
                        For x As Integer = 0 To row.Cells.Count - 1
                            line &= row.Cells(x).Value & ","
                        Next
                        outputFile.WriteLine(line.Remove(line.Length - 1, 1))
                    End If
                Next
                outputFile.Flush()
            End Using
        Catch ex As Exception
        End Try
        Try
            Dim objShell = CreateObject("Wscript.Shell")
            objShell.run("c:\windows\temp\export.csv")
        Catch ex As Exception
        End Try
    End Sub

    Private Sub ExportFullSoftwareList_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExportFullSoftwareList.Click
        Try
            Using outputFile As New IO.StreamWriter("c:\windows\temp\export.csv")
                outputFile.WriteLine(MachineName)
                outputFile.WriteLine(txtpcname)
                outputFile.WriteLine(" ")
                Try
                    Dim array As String() = New String(DataGridView1.Columns.Count - 1) {}
                    'get column header text from all columns:
                    For j As Integer = 0 To DataGridView1.Columns.Count - 1
                        array(j) = DataGridView1.Columns(j).HeaderText
                    Next
                    outputFile.WriteLine([String].Join(",", array))
                Catch ex As Exception
                End Try
                For Each row As DataGridViewRow In DataGridView1.Rows
                    If Not row.IsNewRow Then
                        Dim line As String = String.Empty
                        For x As Integer = 0 To row.Cells.Count - 1
                            line &= row.Cells(x).Value & ","
                        Next
                        outputFile.WriteLine(line.Remove(line.Length - 1, 1))
                    End If
                Next
                outputFile.Flush()
            End Using
        Catch ex As Exception
        End Try
        Try
            Dim objShell = CreateObject("Wscript.Shell")
            objShell.run("c:\windows\temp\export.csv")
        Catch ex As Exception
        End Try
    End Sub

    Private Sub ExportSoftwareListMSI_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExportSoftwareListMSI.Click
        Try
            Using outputFile As New IO.StreamWriter("c:\windows\temp\export.csv")
                outputFile.WriteLine(MachineName)
                outputFile.WriteLine(txtpcname)
                outputFile.WriteLine(" ")
                Try
                    Dim array As String() = New String(DataGridView6.Columns.Count - 1) {}
                    'get column header text from all columns:
                    For j As Integer = 0 To DataGridView6.Columns.Count - 1
                        array(j) = DataGridView6.Columns(j).HeaderText
                    Next
                    outputFile.WriteLine([String].Join(",", array))
                Catch ex As Exception
                End Try
                For Each row As DataGridViewRow In DataGridView6.Rows
                    If Not row.IsNewRow Then
                        Dim line As String = String.Empty
                        For x As Integer = 0 To row.Cells.Count - 1
                            line &= row.Cells(x).Value & ","
                        Next
                        outputFile.WriteLine(line.Remove(line.Length - 1, 1))
                    End If
                Next
                outputFile.Flush()
            End Using
        Catch ex As Exception
        End Try
        Try
            Dim objShell = CreateObject("Wscript.Shell")
            objShell.run("c:\windows\temp\export.csv")
        Catch ex As Exception
        End Try
    End Sub

    Private Sub Exporttaskmanager_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Exporttaskmanager.Click
        Dim csvFileContents As New System.Text.StringBuilder
        Dim CurrLine As String = String.Empty
        csvFileContents.AppendLine(MachineName)
        csvFileContents.AppendLine(txtpcname)
        csvFileContents.AppendLine(" ")
        For columnIndex As Int32 = 0 To lvwProcesses.Columns.Count - 1
            CurrLine &= (String.Format("{0},", lvwProcesses.Columns(columnIndex).Text))
        Next
        'Remove trailing comma
        csvFileContents.AppendLine(CurrLine.Substring(0, CurrLine.Length - 1))
        CurrLine = String.Empty
        'Write out the data.
        For Each item As ListViewItem In lvwProcesses.Items
            For Each subItem As ListViewItem.ListViewSubItem In item.SubItems
                CurrLine &= (String.Format("{0},", subItem.Text))
            Next
            'Remove trailing comma
            csvFileContents.AppendLine(CurrLine.Substring(0, CurrLine.Length - 1))
            CurrLine = String.Empty
        Next
        'Create the file.
        Dim Sys As New System.IO.StreamWriter("C:\windows\temp\export.csv")
        Sys.WriteLine(csvFileContents.ToString)
        Sys.Flush()
        Sys.Dispose()
        Try
            Dim objShell = CreateObject("Wscript.Shell")
            objShell.run("c:\windows\temp\export.csv")
        Catch ex As Exception
        End Try
    End Sub

    Private Sub ExportUserDetails_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExportUserDetails.Click
        Try
            Using outputFile As New IO.StreamWriter("c:\windows\temp\export.csv")
                outputFile.WriteLine(MachineName)
                outputFile.WriteLine(txtpcname)
                outputFile.WriteLine(" ")
                outputFile.WriteLine(DefaultPrinter.Text)
                outputFile.WriteLine(" ")
                Try
                    Dim array As String() = New String(DataGridViewPrinters.Columns.Count - 1) {}
                    'get column header text from all columns:
                    For j As Integer = 0 To DataGridViewPrinters.Columns.Count - 1
                        array(j) = DataGridViewPrinters.Columns(j).HeaderText
                    Next
                    outputFile.WriteLine([String].Join(",", array))
                Catch ex As Exception
                End Try
                For Each row As DataGridViewRow In DataGridViewPrinters.Rows
                    If Not row.IsNewRow Then
                        Dim line As String = String.Empty
                        For x As Integer = 0 To row.Cells.Count - 1
                            line &= row.Cells(x).Value & ","
                        Next
                        outputFile.WriteLine(line.Remove(line.Length - 1, 1))
                    End If
                Next
                outputFile.WriteLine(" ")
                Try
                    Dim array As String() = New String(DataGridViewNetwork.Columns.Count - 1) {}
                    'get column header text from all columns:
                    For j As Integer = 0 To DataGridViewNetwork.Columns.Count - 1
                        array(j) = DataGridViewNetwork.Columns(j).HeaderText
                    Next
                    outputFile.WriteLine([String].Join(",", array))
                Catch ex As Exception
                End Try
                For Each row As DataGridViewRow In DataGridViewNetwork.Rows
                    If Not row.IsNewRow Then
                        Dim line As String = String.Empty
                        For x As Integer = 0 To row.Cells.Count - 1
                            line &= row.Cells(x).Value & ","
                        Next
                        outputFile.WriteLine(line.Remove(line.Length - 1, 1))
                    End If
                Next
                outputFile.WriteLine(" ")
                Try
                    Dim array As String() = New String(DataGridViewODBC.Columns.Count - 1) {}
                    'get column header text from all columns:
                    For j As Integer = 0 To DataGridViewODBC.Columns.Count - 1
                        array(j) = DataGridViewODBC.Columns(j).HeaderText
                    Next
                    outputFile.WriteLine([String].Join(",", array))
                Catch ex As Exception
                End Try
                For Each row As DataGridViewRow In DataGridViewODBC.Rows
                    If Not row.IsNewRow Then
                        Dim line As String = String.Empty
                        For x As Integer = 0 To row.Cells.Count - 1
                            line &= row.Cells(x).Value & ","
                        Next
                        outputFile.WriteLine(line.Remove(line.Length - 1, 1))
                    End If
                Next
                outputFile.Flush()
            End Using
        Catch ex As Exception
        End Try
        Try
            Dim objShell = CreateObject("Wscript.Shell")
            objShell.run("c:\windows\temp\export.csv")
        Catch ex As Exception
        End Try
    End Sub

    Private Sub RDTReadWriteRegistry_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RDTReadWriteRegistry.Click
        If MachineName = "" Then
            Exit Sub
        End If

        Dim lookforbackslash As Integer = InStr(userdomainComboBox.Text, "\")
        If lookforbackslash <> 0 Then
            Dim wordArr As String() = userdomainComboBox.Text.Split(" ")
            Dim result As String = wordArr(0)
            LoggedOnUserNameOnly = result
            wordArr = LoggedOnUserNameOnly.Split("\")
            result = wordArr(1)
            LoggedOnUserNameOnly = result
            SIDKEY = GetSIDUsingADSearch(LoggedOnUserNameOnly)
        Else
            RemoteRegistry.RegistryBox1.Items.RemoveAt(1)
        End If

        PCNAME.Focus()

        RemoteRegistry.Show()

    End Sub

    Private Shared Function ConnectToAD() As Boolean
        Try
            deDomainRoot = New DirectoryEntry("LDAP://rootDSE")
            strDomainPath = "LDAP://" + deDomainRoot.Properties("DefaultNamingContext")(0).ToString()
            deDomainRoot = New DirectoryEntry(strDomainPath)
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Shared Function GetSIDUsingADSearch(ByVal Username As String) As String
        If (ConnectToAD()) Then
            Dim dirSearcher As New DirectorySearcher
            Dim singleQueryResult As SearchResult
            Dim strSID As String = ""
            Dim intSuccess As Integer
            Try
                dirSearcher.SearchScope = SearchScope.Subtree
                dirSearcher.SearchRoot = deDomainRoot
                dirSearcher.Filter = "(&(sAMAccountName=" & Username & "))"
                singleQueryResult = dirSearcher.FindOne()
                Dim sidBytes As Byte() = CType(singleQueryResult.Properties("objectSid")(0), Byte())
                Dim sidPtr As IntPtr = System.Runtime.InteropServices.Marshal.AllocHGlobal(sidBytes.Length)
                System.Runtime.InteropServices.Marshal.Copy(sidBytes, 0, sidPtr, sidBytes.Length)
                intSuccess = ConvertSidToStringSid(sidPtr, strSID)
                Return strSID.Trim()
            Catch ex As Exception

            End Try
        End If

        Return ""
    End Function

    Private Sub BackgroundWorker3_DoWork(ByVal sender As System.Object, ByVal e As System.ComponentModel.DoWorkEventArgs) Handles BackgroundWorker3.DoWork
        Dim helperBW As New BackgroundWorker
        BackgroundProcessLogicMethodCopying(helperBW)
    End Sub

    Function BackgroundProcessLogicMethodCopying(ByVal bw As BackgroundWorker) As Int16
        Copylocalfiles()
        Return 0
    End Function

    Private Sub BackgroundWorkerSpinner_DoWork(sender As Object, e As DoWorkEventArgs) Handles BackgroundWorkerSpinner.DoWork
        Dim helperBW As New BackgroundWorker
        BackgroundProcessSpinner(helperBW)
    End Sub

    Function BackgroundProcessSpinner(ByVal bw As BackgroundWorker) As Int16
        Dim counter As Integer = 1
        Do
            If BackgroundWorkerSpinner.CancellationPending Then
                MetroProgressBar.Value = 0
                Exit Do
            End If

            MetroProgressBar.Value = MetroProgressBar.Value + 1
            counter = counter + 1
            If MetroProgressBar.Value = 100 Then
                MetroProgressBar.Value = 0
            End If
            Thread.Sleep(500)
        Loop While (counter <= 999999999999999999)

    End Function


    Private Sub Runcommandonly_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Runcommandonly.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If
        If runcommandonlytext.Text = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Dim processID As UInteger = 0
        Dim ExitCode = 1

        Try
            Dim connOptions As New Management.ConnectionOptions()
            connOptions.Username = username
            connOptions.Password = password
            connOptions.Timeout = TimeSpan.FromSeconds(30)
            connOptions.Authority = "NTLMDOMAIN:" & domain
            connOptions.EnablePrivileges = True
            connOptions.Authentication = AuthenticationLevel.PacketPrivacy
            connOptions.Impersonation = ImpersonationLevel.Impersonate
            connOptions.EnablePrivileges = True
            Dim manScope As New Management.ManagementScope([String].Format("\\{0}\ROOT\CIMV2", txtpcname), connOptions)

            Try
                manScope.Connect()
            Catch
                BackgroundWorkerSpinner.CancelAsync()
                MetroProgressBar.Hide()
                MsgBox("Couldn't connect to remote PC.")
                Exit Sub
            End Try
            Dim objectGetOptions As New Management.ObjectGetOptions()
            Dim managementPath As New Management.ManagementPath("Win32_Process")
            Using processClass As New Management.ManagementClass(manScope, managementPath, objectGetOptions)
                Using inParams As Management.ManagementBaseObject = processClass.GetMethodParameters("Create")
                    inParams("CommandLine") = runcommandonlytext.Text
                    Using outParams As Management.ManagementBaseObject = processClass.InvokeMethod("Create", inParams, Nothing)
                        If CUInt(outParams("returnValue")) <> 0 Then
                            BackgroundWorkerSpinner.CancelAsync()
                            MetroProgressBar.Hide()
                            PCNAME.Focus()
                            MsgBox("Command failed to execute...")
                        Else
                            BackgroundWorkerSpinner.CancelAsync()
                            MetroProgressBar.Hide()
                            PCNAME.Focus()
                            MsgBox("Command executed at : " & Now & " : " & runcommandonlytext.Text)
                            'processID = CUInt(outParams("processId"))
                        End If
                    End Using
                End Using
            End Using
            Try
                manScope = Nothing
            Catch
            End Try

        Catch
        End Try

    End Sub


    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        If MachineName = "" Then
            Exit Sub
        End If
        SCCMButton6(username, password, domain, txtpcname)
    End Sub

    Private Sub SCCMButton6(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)
        Dim wmi_out As ManagementBaseObject
        Dim objManagementScope As ManagementScope
        Dim objManagementClass As ManagementClass = Nothing
        Dim objManagementBaseObject As ManagementBaseObject = Nothing

        Dim retValue As Integer
        Dim Command As String = "WMIC /node:" & txtpcname & " /namespace:\\root\ccm path sms_client CALL TriggerSchedule " & Chr(34) & "{00000000-0000-0000-0000-000000000026}" & Chr(34) & " /NOINTERACTIVE"

        Try

            Dim options As ConnectionOptions
            options = New ConnectionOptions()
            Dim computerconnect As String = "\\" & txtpcname & "\root\cimv2:Win32_Process"

            options.Username = txtusername
            options.Password = txtpassword
            options.Timeout = TimeSpan.FromSeconds(30)
            options.Authority = "NTLMDOMAIN:" & txtdomain
            options.Authentication = AuthenticationLevel.PacketPrivacy
            objManagementScope = New ManagementScope(computerconnect, options)

            If objManagementScope.IsConnected = True Then
            Else
                Try
                    objManagementScope.Connect()
                Catch ex As Exception
                    MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                    Exit Sub
                End Try
            End If

            objManagementClass = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
            objManagementClass.Scope = objManagementScope

            objManagementBaseObject = objManagementClass.GetMethodParameters("Create")
            objManagementBaseObject.SetPropertyValue("CommandLine", Command)
            wmi_out = objManagementClass.InvokeMethod("Create", objManagementBaseObject, Nothing)

            'wmi = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
            'wmi_in = wmi.GetMethodParameters("Create")
            'wmi_in("CommandLine") = "cmd /c md c:\temp\temptd"
            'wmi_out = wmi.InvokeMethod("Create", wmi_in, Nothing)

            retValue = Convert.ToInt32(wmi_out("returnValue"))
            Select Case retValue
                Case 0

                Case 2
                    Throw New ApplicationException("Access denied")
                Case 3
                    Throw New ApplicationException("Insufficient privilege")
                Case 8
                    Throw New ApplicationException("Unknown failure")
                Case 9
                    Throw New ApplicationException("Path not found")
                Case 21
                    Throw New ApplicationException("Invalid parameter")
                Case Else
                    Throw New ApplicationException("Unknown return code " & retValue)
            End Select
        Catch ex As Exception
            MsgBox(txtpcname & ": Can't create the process. " & ex.Message)
        End Try
        Try
            objManagementScope = Nothing
            objManagementBaseObject.Dispose()
            objManagementClass.Dispose()
        Catch
        End Try
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        If MachineName = "" Then
            Exit Sub
        End If
        SCCMButton7(username, password, domain, txtpcname)
    End Sub

    Private Sub SCCMButton7(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)
        Dim wmi_out As ManagementBaseObject
        Dim objManagementScope As ManagementScope
        Dim objManagementClass As ManagementClass = Nothing
        Dim objManagementBaseObject As ManagementBaseObject = Nothing

        Dim retValue As Integer
        Dim Command As String = "WMIC /node:" & txtpcname & " /namespace:\\root\ccm path sms_client CALL TriggerSchedule " & Chr(34) & "{00000000-0000-0000-0000-000000000121}" & Chr(34) & " /NOINTERACTIVE"

        Try

            Dim options As ConnectionOptions
            options = New ConnectionOptions()
            Dim computerconnect As String = "\\" & txtpcname & "\root\cimv2:Win32_Process"

            options.Username = txtusername
            options.Password = txtpassword
            options.Timeout = TimeSpan.FromSeconds(30)
            options.Authority = "NTLMDOMAIN:" & txtdomain
            options.Authentication = AuthenticationLevel.PacketPrivacy
            objManagementScope = New ManagementScope(computerconnect, options)

            If objManagementScope.IsConnected = True Then
            Else
                Try
                    objManagementScope.Connect()
                Catch ex As Exception
                    MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                    Exit Sub
                End Try
            End If

            objManagementClass = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
            objManagementClass.Scope = objManagementScope

            objManagementBaseObject = objManagementClass.GetMethodParameters("Create")
            objManagementBaseObject.SetPropertyValue("CommandLine", Command)
            wmi_out = objManagementClass.InvokeMethod("Create", objManagementBaseObject, Nothing)

            'wmi = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
            'wmi_in = wmi.GetMethodParameters("Create")
            'wmi_in("CommandLine") = "cmd /c md c:\temp\temptd"
            'wmi_out = wmi.InvokeMethod("Create", wmi_in, Nothing)

            retValue = Convert.ToInt32(wmi_out("returnValue"))
            Select Case retValue
                Case 0

                Case 2
                    Throw New ApplicationException("Access denied")
                Case 3
                    Throw New ApplicationException("Insufficient privilege")
                Case 8
                    Throw New ApplicationException("Unknown failure")
                Case 9
                    Throw New ApplicationException("Path not found")
                Case 21
                    Throw New ApplicationException("Invalid parameter")
                Case Else
                    Throw New ApplicationException("Unknown return code " & retValue)
            End Select
        Catch ex As Exception
            MsgBox(txtpcname & ": Can't create the process. " & ex.Message)
        End Try
        Try
            objManagementScope = Nothing
            objManagementBaseObject.Dispose()
            objManagementClass.Dispose()
        Catch
        End Try
    End Sub

    Private Sub Button9_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.Click
        If MachineName = "" Then
            Exit Sub
        End If
        SCCMButton9(username, password, domain, txtpcname)
    End Sub

    Private Sub SCCMButton9(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)
        Dim wmi_out As ManagementBaseObject
        Dim objManagementScope As ManagementScope
        Dim objManagementClass As ManagementClass = Nothing
        Dim objManagementBaseObject As ManagementBaseObject = Nothing

        Dim retValue As Integer
        Dim Command As String = "WMIC /node:" & txtpcname & " /namespace:\\root\ccm path sms_client CALL ResetPolicy 1 /NOINTERACTIVE"

        Try

            Dim options As ConnectionOptions
            options = New ConnectionOptions()
            Dim computerconnect As String = "\\" & txtpcname & "\root\cimv2:Win32_Process"

            options.Username = txtusername
            options.Password = txtpassword
            options.Timeout = TimeSpan.FromSeconds(30)
            options.Authority = "NTLMDOMAIN:" & txtdomain
            options.Authentication = AuthenticationLevel.PacketPrivacy
            objManagementScope = New ManagementScope(computerconnect, options)

            If objManagementScope.IsConnected = True Then
            Else
                Try
                    objManagementScope.Connect()
                Catch ex As Exception
                    MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                    Exit Sub
                End Try
            End If

            objManagementClass = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
            objManagementClass.Scope = objManagementScope

            objManagementBaseObject = objManagementClass.GetMethodParameters("Create")
            objManagementBaseObject.SetPropertyValue("CommandLine", Command)
            wmi_out = objManagementClass.InvokeMethod("Create", objManagementBaseObject, Nothing)

            'wmi = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
            'wmi_in = wmi.GetMethodParameters("Create")
            'wmi_in("CommandLine") = "cmd /c md c:\temp\temptd"
            'wmi_out = wmi.InvokeMethod("Create", wmi_in, Nothing)

            retValue = Convert.ToInt32(wmi_out("returnValue"))
            Select Case retValue
                Case 0

                Case 2
                    Throw New ApplicationException("Access denied")
                Case 3
                    Throw New ApplicationException("Insufficient privilege")
                Case 8
                    Throw New ApplicationException("Unknown failure")
                Case 9
                    Throw New ApplicationException("Path not found")
                Case 21
                    Throw New ApplicationException("Invalid parameter")
                Case Else
                    Throw New ApplicationException("Unknown return code " & retValue)
            End Select
        Catch ex As Exception
            MsgBox(txtpcname & ": Can't create the process. " & ex.Message)
        End Try
        Try
            objManagementScope = Nothing
            objManagementBaseObject.Dispose()
            objManagementClass.Dispose()
        Catch
        End Try



        Try
            Dim options As ConnectionOptions
            options = New ConnectionOptions()
            Dim computerconnect As String = "\\" & txtpcname & "\root\cimv2"

            options.Username = username
            options.Password = password
            options.Timeout = TimeSpan.FromSeconds(30)
            options.Authority = "NTLMDOMAIN:" & domain
            options.Authentication = AuthenticationLevel.PacketPrivacy
            objManagementScope = New ManagementScope(computerconnect, options)

            If objManagementScope.IsConnected = True Then
            Else
                Try
                    objManagementScope.Connect()
                Catch ex As Exception
                    MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                    PCNAME.Focus()
                    Exit Sub
                End Try
            End If

            ' define a select query
            Dim query As New SelectQuery("SELECT * FROM Win32_Service Where Name =""CcmExec""")
            Dim searcher As New ManagementObjectSearcher(objManagementScope, query)
            Dim args As Object = Nothing
            Try
                For Each mo As ManagementObject In searcher.[Get]()
                    mo.InvokeMethod("StopService", args)
                    Thread.Sleep(10000)
                    mo.InvokeMethod("StartService", args)
                Next
            Catch ex As Exception
                'MsgBox(ex.Message)
                PCNAME.Focus()
                Exit Sub
            End Try
        Catch ex As Exception
            'MsgBox(ex.Message)
            PCNAME.Focus()
            Exit Sub
        End Try

        PCNAME.Focus()

        Try
            objManagementScope = Nothing
            objManagementBaseObject.Dispose()
            objManagementClass.Dispose()
        Catch
        End Try

    End Sub

    Private Sub Button65_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub GetEmailAddress_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GetEmailAddress.Click
        EmailAddress.Text = ""

        If userdomainComboBox.Text = "" Then
            Exit Sub
        End If

        If MachineName = "" Then
            Exit Sub
        End If

        Dim lookforbackslash As Integer = InStr(userdomainComboBox.Text, "\")
        If lookforbackslash <> 0 Then
            Dim wordArr As String() = userdomainComboBox.Text.Split("\")
            Dim result As String = wordArr(1)
            LoggedOnUserNameOnly = result
            EmailAddress.Text = GetEmailUsingADSearch(LoggedOnUserNameOnly)
        Else
            Exit Sub
        End If
    End Sub

    Private Sub GetPhoneNumber_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GetPhoneNumber.Click
        PhoneNumber1.Text = ""
        PhoneNumber2.Text = ""

        If userdomainComboBox.Text = "" Then
            Exit Sub
        End If

        If MachineName = "" Then
            Exit Sub
        End If

        Dim lookforbackslash As Integer = InStr(userdomainComboBox.Text, "\")
        If lookforbackslash <> 0 Then
            Dim wordArr As String() = userdomainComboBox.Text.Split("\")
            Dim result As String = wordArr(1)
            LoggedOnUserNameOnly = result
            PhoneNumber1.Text = "int : " & GetPhone1UsingADSearch(LoggedOnUserNameOnly)
            PhoneNumber2.Text = "ext : " & GetPhone2UsingADSearch(LoggedOnUserNameOnly)
        Else
            Exit Sub
        End If
    End Sub

    Private Sub GetMobileNumber_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GetMobileNumber.Click
        MobileNumber.Text = ""

        If userdomainComboBox.Text = "" Then
            Exit Sub
        End If

        If MachineName = "" Then
            Exit Sub
        End If

        Dim lookforbackslash As Integer = InStr(userdomainComboBox.Text, "\")
        If lookforbackslash <> 0 Then
            Dim wordArr As String() = userdomainComboBox.Text.Split("\")
            Dim result As String = wordArr(1)
            LoggedOnUserNameOnly = result
            MobileNumber.Text = GetMobileUsingADSearch(LoggedOnUserNameOnly)
        Else
            Exit Sub
        End If
    End Sub

    Private Shared Function GetEmailUsingADSearch(ByVal Username As String) As String
        If (ConnectToAD()) Then
            Dim dirSearcher As New DirectorySearcher
            Dim singleQueryResult As SearchResult
            Try
                dirSearcher.SearchScope = SearchScope.Subtree
                dirSearcher.SearchRoot = deDomainRoot
                dirSearcher.Filter = "(&(sAMAccountName=" & Username & "))"
                singleQueryResult = dirSearcher.FindOne()
                Dim Email As String = singleQueryResult.Properties("mail")(0).ToString
                Return Email
            Catch ex As Exception

            End Try
        End If

        Return ""
    End Function

    Private Shared Function GetPhone1UsingADSearch(ByVal Username As String) As String
        If (ConnectToAD()) Then
            Dim dirSearcher As New DirectorySearcher
            Dim singleQueryResult As SearchResult
            Try
                dirSearcher.SearchScope = SearchScope.Subtree
                dirSearcher.SearchRoot = deDomainRoot
                dirSearcher.Filter = "(&(sAMAccountName=" & Username & "))"
                singleQueryResult = dirSearcher.FindOne()
                Dim Phone As String = singleQueryResult.Properties("telephoneNumber")(0).ToString
                Return Phone
            Catch ex As Exception

            End Try
        End If

        Return ""
    End Function

    Private Shared Function GetPhone2UsingADSearch(ByVal Username As String) As String
        If (ConnectToAD()) Then
            Dim dirSearcher As New DirectorySearcher
            Dim singleQueryResult As SearchResult
            Try
                dirSearcher.SearchScope = SearchScope.Subtree
                dirSearcher.SearchRoot = deDomainRoot
                dirSearcher.Filter = "(&(sAMAccountName=" & Username & "))"
                singleQueryResult = dirSearcher.FindOne()
                Dim Phone As String = singleQueryResult.Properties("otherTelephone")(0).ToString
                Return Phone
            Catch ex As Exception

            End Try
        End If

        Return ""
    End Function

    Private Shared Function GetMobileUsingADSearch(ByVal Username As String) As String
        If (ConnectToAD()) Then
            Dim dirSearcher As New DirectorySearcher
            Dim singleQueryResult As SearchResult
            Try
                dirSearcher.SearchScope = SearchScope.Subtree
                dirSearcher.SearchRoot = deDomainRoot
                dirSearcher.Filter = "(&(sAMAccountName=" & Username & "))"
                singleQueryResult = dirSearcher.FindOne()
                Dim Mobile As String = singleQueryResult.Properties("mobile")(0).ToString
                Return Mobile
            Catch ex As Exception

            End Try
        End If

        Return ""
    End Function

    Private Sub Clear_email(ByVal sender As System.Object, ByVal e As System.EventArgs)
        EmailAddress.Text = ""
        PhoneNumber1.Text = ""
        PhoneNumber2.Text = ""
        MobileNumber.Text = ""
    End Sub


    Private Sub BackgroundWorkerEval_DoWork(sender As Object, e As DoWorkEventArgs) Handles BackgroundWorkerEval.DoWork
        Dim helperBW As New BackgroundWorker
        BackgroundEval(helperBW)
    End Sub

    Function BackgroundEval(ByVal bw As BackgroundWorker) As Int16
        Dim StartDate As DateTime = DateTime.Parse(Now)

        Do
            Thread.Sleep(180000)
            Dim CheckDate As DateTime = DateTime.Parse(Now)
            If CheckDate > StartDate.AddHours(24) Then
                End
            End If
        Loop

    End Function


    Private Sub ConnectToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ConnectToolStripMenuItem.Click

        Try
            If TreeView.SelectedNode.Text = "" Then Exit Sub
        Catch ex As Exception
        End Try

        Try
            If TreeView.SelectedNode.Checked = True Then Exit Sub
        Catch ex As Exception
        End Try

        Try
            PCNAME.Text = TreeView.SelectedNode.Text
            If PCNAME.Text = "" Then Exit Sub
        Catch ex As Exception
        End Try

        FormTabControl.SelectedIndex = 0

        Dim Result As String = Nothing
        Dim IP4Address As String = ""
        MachineName = ""
        Dim strValueName As String = Nothing
        Dim strValueKey As String = Nothing
        Dim TextOutput As String = Nothing
        Dim TextOut As String = Nothing
        Dim ROW2 As String = Nothing
        Dim strRead2 As String = Nothing
        Dim strRead3 As String = Nothing
        Dim strRead4 As String = Nothing
        Reboot.Text = Nothing
        UpdatesLabel.Text = Nothing
        uptime1.Text = " "
        Alive.Text = Nothing
        AliveButton.BackColor = Color.White
        ProgressBar2.Value = 0
        PCNAME.ForeColor = Color.Black
        Alive.ForeColor = Color.Black
        StatusOfConnection.ForeColor = Color.Black
        Host.Text = " "
        Reboot.Text = " "
        DataGridViewDetails.Rows.Clear()
        DataGridView1.Rows.Clear()
        DataGridView6.Rows.Clear()
        DataGridView7.Rows.Clear()
        DataGridView8.Rows.Clear()
        DataGridView9.Rows.Clear()
        DataGridView10.Rows.Clear()
        DataGridView11.Rows.Clear()
        DataGridView25.Rows.Clear()
        DataGridViewDisk.Rows.Clear()
        DataGridViewDisk2.Rows.Clear()
        DataGridViewPrinters.Rows.Clear()
        DataGridViewNetwork.Rows.Clear()
        DataGridViewODBC.Rows.Clear()
        DataGridViewSCCMRunning.Rows.Clear()
        OptionalFeaturesDataGrid.Rows.Clear()
        PnPSignedDriverDataGrid.Rows.Clear()
        StoreAppsDataGridView.Rows.Clear()
        DataGridViewProfiles.Rows.Clear()
        DataGridViewNet64.Rows.Clear()
        DataGridViewNet32.Rows.Clear()
        DataGridViewNetCore.Rows.Clear()
        PagefileDetails.Text = "Page File Details :  "
        TotalPhysicalMemoryDetails.Text = "Total Physical Memory : "
        Reboot.ForeColor = Nothing
        ServiceNameSelected.Text = " "
        FileTypes.Items.Clear()
        lvwProcesses.Items.Clear()
        groupview1.Items.Clear()
        userview1.Items.Clear()
        Userlist.Items.Clear()
        MBSAlistBox.Items.Clear()
        ListViewProcessorUsage.Items.Clear()
        Label50.Text = " "
        Label51.Text = " "
        Label52.Text = " "
        Label53.Text = " "
        Label54.Text = " "
        Label55.Text = " "
        Label56.Text = " "
        Label59.Text = " "
        Label63.Text = " "
        Label62.Text = " "
        Label11.Text = " "
        Label13.Text = " "
        Label17.Text = " "
        Label28.Text = " "

        Label001.Text = "00:00:00"
        Label002.Text = "00:00:00"
        Label003.Text = "00:00:00"
        Label021.Text = "00:00:00"
        Label108.Text = "00:00:00"
        Label113.Text = "00:00:00"
        Label010.Text = "00:00:00"
        Label032.Text = "00:00:00"
        Label031.Text = "00:00:00"
        Label061.Text = "00:00:00"
        Label051.Text = "00:00:00"
        Label026.Text = "00:00:00"
        Label121.Text = "00:00:00"

        Label11.Text = " "
        Label15.Text = " "
        Label13.Text = " "
        Label19.Text = " "
        Label17.Text = " "
        Label48.Text = " "
        Label28.Text = " "
        Label193.Text = " "
        Label191.Text = " "
        Label14.Text = " "
        Label14a.Text = " "
        SCCMProvisioningMode.Text = Nothing
        SCCMCacheLabel.Text = " "
        TextBox1.Text = " "
        TextBoxMSIZAP.Text = " "
        KBTextBox.Text = " "
        PCnameFordetails.Text = ""
        DefaultPrinter.Text = "....."
        tnsadmin.Text = "....."
        KeyboardLayout.Text = "....."
        userlogonserver.Text = "....."
        userbeingqueried.Text = "....."
        SaveEMAdetails.Text = ""
        IPAddressValue.Text = ""
        IPsubnetValue.Text = ""
        NomadProductVersionValue.Text = ""
        PXEProductVersionValue.Text = ""
        NomadServiceValue.Text = ""
        PXEServiceValue.Text = ""
        NomadFolderSizeValue.Text = ""
        Labelstoreapps2.Text = ""
        Labelstoreapps1.Text = ""
        LabelMBSA1.Text = ""
        LabelMBSA2.Text = ""
        Dim TextOut4 As String = Nothing
        Dim TextOut5 As String = Nothing
        Dim strRead1 As String = Nothing
        Dim strRead5 As String = Nothing
        Dim strRead6 As String = Nothing
        Dim strRead7 As String = Nothing
        Dim strRead8 As String = Nothing
        Dim strRead9 As String = Nothing
        Dim strRead10 As String = Nothing
        Dim strRead11 As String = Nothing
        Dim strRead12 As String = Nothing
        Dim strRead13 As String = Nothing
        Dim strRead14 As String = Nothing
        Dim strRead15 As String = ""
        Dim strReadAPPV As String = "No"
        Dim strRead16 As String = ""
        Dim strReadSCCM As String = "No"
        Dim strread17 As String = Nothing
        Dim strread18 As String = Nothing
        Dim strread18_64 As String = Nothing
        Dim strread19 As String = Nothing
        Dim strread19A As String = Nothing
        Dim strread19Array As Array = Nothing
        Dim strread20 As String = Nothing
        Dim strread20_64 As String = Nothing
        Dim strread21 As String = Nothing
        Dim strread22 As String = Nothing
        Dim strread23 As Date = Nothing
        Dim strread24 As String = Nothing
        Dim strread25 As String = Nothing
        Dim strread26 As String = Nothing
        Dim strread27 As String = Nothing
        Dim strread28 As String = Nothing
        Dim strread28a As String = Nothing
        Dim strread29 As String = Nothing
        Dim strread30 As String = Nothing
        Dim strread31 As String = Nothing
        Dim strread32 As String = Nothing
        Dim strread33 As String = Nothing
        Dim strread34 As String = Nothing
        Dim DetectedAPPVVersion As String = Nothing
        userdomainComboBox.Items.Clear()
        userdomainComboBox.Text = ""
        EmailAddress.Text = ""
        PhoneNumber1.Text = ""
        PhoneNumber2.Text = ""
        MobileNumber.Text = ""
        StatusOfConnection.Text = ""
        PnPSignedDriverLabel1.Text = ""
        PnPSignedDriverLabel2.Text = ""
        WIM_OptionalFeaturesLabel1.Text = ""
        WIM_OptionalFeaturesLabel2.Text = ""
        Helpdesknumber.Text = ""
        LabelProfiles1.Text = ""
        LabelProfiles2.Text = ""
        ListMissingUpdatesSCCMDatagrid.Rows.Clear()
        SCCMPatchesInstalledDataGridView.Rows.Clear()
        SCCMcomplianceDataGridView1.Rows.Clear()
        SCCMcomplianceDataGridView2.Rows.Clear()

        Label16.Text = " "
        Label1.Text = " "
        RebootRequiredCheck1.ForeColor = Color.Black
        RebootRequiredCheck1.Text = "False"
        RebootRequiredCheck2.ForeColor = Color.Black
        RebootRequiredCheck2.Text = "False"
        RebootRequiredCheck3.ForeColor = Color.Black
        RebootRequiredCheck3.Text = "False"
        RebootRequiredCheck4.ForeColor = Color.Black
        RebootRequiredCheck4.Text = "False"

        Try
            AppV.Close()
        Catch ex As Exception
        End Try
        Try
            Appv5.Close()
        Catch ex As Exception
        End Try
        Try
            RemoteRegistry.Close()
        Catch ex As Exception
        End Try
        Try
            StartupItems.Close()
        Catch ex As Exception
        End Try

        AdvIDMachine.Text = "AdvID"
        PkgIDMachine.Text = "PkgID"
        AdvertNameMachine.Text = "AdvertName"
        AdvIDUser.Text = "AdvID"
        PkgIDUser.Text = "PkgID"
        AdvertNameUser.Text = "AdvertName"

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Try
            For Each IPA As IPAddress In Dns.GetHostAddresses(PCNAME.Text)
                If IPA.AddressFamily.ToString() = "InterNetwork" Then
                    IP4Address = IPA.ToString()
                    Exit For
                End If
            Next
        Catch
        End Try

        If IP4Address <> String.Empty Then
            AliveButton.BackColor = Color.DarkOrange
            Alive.ForeColor = Color.DarkOrange
            Alive.Text = IP4Address
            StatusOfConnection.ForeColor = Color.DarkOrange
            StatusOfConnection.Text = "Resolved IP"

            TreeView.SelectedNode.ImageIndex = 3
            TreeView.SelectedNode.SelectedImageIndex = 3

            txtpcname = IP4Address
            Label50.Text = IP4Address
            Label51.Text = IP4Address
            Label52.Text = IP4Address
            Label53.Text = IP4Address
            Label54.Text = IP4Address
            Label55.Text = IP4Address
            Label56.Text = IP4Address
            Label59.Text = IP4Address
            Label62.Text = IP4Address
            Label11.Text = IP4Address
            Label13.Text = IP4Address
            Label17.Text = IP4Address
            Label28.Text = IP4Address
            Label191.Text = IP4Address
            Label1.Text = IP4Address
            PnPSignedDriverLabel2.Text = IP4Address
            WIM_OptionalFeaturesLabel2.Text = IP4Address
            Labelstoreapps2.Text = IP4Address
            LabelProfiles2.Text = IP4Address
            Label14a.Text = IP4Address
            LabelMBSA2.Text = IP4Address

            PCNAME.ForeColor = Color.DarkOrange
            'PCNAME.Text = IP4Address

            Dim ip As IPAddress = IPAddress.Parse(IP4Address)
            ' Dim client As New Net.Sockets.TcpClient()
            'client.Connect(ip, 3389 or 445)

            Dim targetEndPoint As New IPEndPoint(ip, 445)
            Dim myTimeout As Integer = 2000 '2 seconds
            Dim cliConnect As New cliConnector

            Try
                Dim tcpCli As Sockets.TcpClient = cliConnect.Connect(targetEndPoint, myTimeout)
            Catch ex As Exception
                Label50.Text = ""
                Label51.Text = ""
                Label52.Text = ""
                Label53.Text = ""
                Label54.Text = ""
                Label55.Text = ""
                Label56.Text = ""
                Label59.Text = ""
                Label62.Text = ""
                Label11.Text = ""
                Label13.Text = ""
                Label17.Text = ""
                Label28.Text = ""
                Label191.Text = ""
                LabelMBSA1.Text = ""
                LabelMBSA2.Text = ""
                Label1.Text = ""
                Label16.Text = ""
                PnPSignedDriverLabel2.Text = ""
                WIM_OptionalFeaturesLabel2.Text = ""
                Labelstoreapps2.Text = ""
                LabelProfiles2.Text = ""
                Label14a.Text = ""
                BackgroundWorkerSpinner.CancelAsync()
                MetroProgressBar.Hide()
                PCNAME.Text = Nothing
                TreeView.SelectedNode.ImageIndex = 3
                TreeView.SelectedNode.SelectedImageIndex = 3
                MessageBox.Show("Couldn't connect to PC : " + ex.Message, "Error")
                Exit Sub
            End Try

            ProgressBar2.ForeColor = Color.DarkGreen
            ProgressBar2.Value = 50
            PCNAME.ForeColor = Color.Green
            StatusOfConnection.ForeColor = Color.Green
            StatusOfConnection.Text = "Gathering Data.."

            Try
                TreeView.SelectedNode.ImageIndex = 3
                TreeView.SelectedNode.SelectedImageIndex = 3
            Catch
            End Try

            Try
                Dim strStringValue As String = ""
                Dim strSubKeyName As String
                Dim objManagementScope As ManagementScope = Nothing
                Dim objManagementClass As ManagementClass = Nothing
                Dim objManagementBaseObject As ManagementBaseObject = Nothing
                Dim intRegistryHive As Microsoft.Win32.RegistryHive

                intRegistryHive = Microsoft.Win32.RegistryHive.LocalMachine
                strSubKeyName = strValueKey

                Dim options As ConnectionOptions
                options = New ConnectionOptions()
                Dim computerconnect As String = "\\" & txtpcname & "\root\DEFAULT"

                options.Username = username
                options.Password = password
                options.Timeout = TimeSpan.FromSeconds(30)
                options.Authority = "NTLMDOMAIN:" & domain
                options.EnablePrivileges = True
                options.Authentication = AuthenticationLevel.PacketPrivacy
                options.Impersonation = ImpersonationLevel.Impersonate
                options.EnablePrivileges = True
                objManagementScope = New ManagementScope(computerconnect, options)

                If objManagementScope.IsConnected = True Then
                Else
                    Try
                        objManagementScope.Connect()
                    Catch ex As Exception
                        Label50.Text = ""
                        Label51.Text = ""
                        Label52.Text = ""
                        Label53.Text = ""
                        Label54.Text = ""
                        Label55.Text = ""
                        Label56.Text = ""
                        Label59.Text = ""
                        Label62.Text = ""
                        Label11.Text = ""
                        Label13.Text = ""
                        Label17.Text = ""
                        Label28.Text = ""
                        Label191.Text = ""
                        LabelMBSA1.Text = ""
                        LabelMBSA2.Text = ""
                        Label1.Text = ""
                        Label16.Text = ""
                        PnPSignedDriverLabel2.Text = ""
                        WIM_OptionalFeaturesLabel2.Text = ""
                        Labelstoreapps2.Text = ""
                        LabelProfiles2.Text = ""
                        Label14a.Text = ""
                        BackgroundWorkerSpinner.CancelAsync()
                        MetroProgressBar.Hide()
                        PCNAME.Text = Nothing
                        TreeView.SelectedNode.ImageIndex = 3
                        TreeView.SelectedNode.SelectedImageIndex = 3
                        MessageBox.Show("Couldn't connect to WMI : " + ex.Message, "Error")
                        Exit Sub
                    End Try
                End If

                Try

                    Dim fullPath As String = TEMPDIR & "\RDT"
                    Directory.CreateDirectory(fullPath)
                    Dim fullPath2 As String = TEMPDIR & "\RDT\RDT"
                    Directory.CreateDirectory(fullPath2)

                    objManagementClass = New ManagementClass("StdRegProv")

                    With objManagementClass
                        .Scope = objManagementScope
                        objManagementBaseObject = .GetMethodParameters("GetStringValue")

                        With objManagementBaseObject
                            .SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                            .SetPropertyValue("sSubKeyName", "SYSTEM\CurrentControlSet\services\Tcpip\Parameters")
                            .SetPropertyValue("sValueName", "Hostname")
                        End With
                        Dim OutParams As ManagementBaseObject = .InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                        Host.Text = CType(OutParams("sValue"), String)
                        If Host.Text = Nothing Then Host.Text = ""
                        PCnameFordetails.Text = Host.Text
                        MachineName = Host.Text

                    End With

                    Try
                        Dim regKey As Microsoft.Win32.RegistryKey
                        regKey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey("Software\RDT\Computers\" & MachineName, True)
                        SaveEMAdetails.Text = regKey.GetValue("EMAdetails")
                        regKey.Close()
                    Catch ex As Exception
                    End Try

                    Try
                        Dim regKey As Microsoft.Win32.RegistryKey
                        regKey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey("Software\RDT\Computers\" & MachineName, True)
                        Helpdesknumber.Text = regKey.GetValue("HelpdeskNumber")
                        regKey.Close()
                    Catch ex As Exception
                    End Try

                    Try
                        Dim options2 As ConnectionOptions
                        options2 = New ConnectionOptions()
                        Dim computerconnect2 As String = "\\" & txtpcname & "\root\cimv2"
                        options2.Username = username
                        options2.Password = password
                        options2.Timeout = TimeSpan.FromSeconds(30)
                        options2.Authority = "NTLMDOMAIN:" & domain
                        options2.Authentication = AuthenticationLevel.PacketPrivacy
                        Dim msc As ManagementScope = New ManagementScope(computerconnect2, options2)

                        Dim QueryOptions = New EnumerationOptions
                        QueryOptions.Timeout = New TimeSpan(0, 0, 10)
                        Dim query_command As String = "Select * from Win32_ComputerSystem"
                        Dim select_query As SelectQuery = New SelectQuery(query_command)
                        Dim Srch As New ManagementObjectSearcher(msc, select_query, QueryOptions)
                        Dim objMgmt As ManagementObject
                        Dim userdomaindetected = ""
                        For Each objMgmt In Srch.Get
                            userdomaindetected = ""
                            userdomaindetected = objMgmt("Username")
                            If userdomaindetected <> "" Then
                                If userdomainComboBox.Items.Contains(userdomaindetected) Then

                                Else
                                    userdomainComboBox.Items.Add(objMgmt("Username").ToString.ToLower)
                                    userdomainComboBox.Text = objMgmt("Username").ToString.ToLower
                                End If
                            End If
                        Next
                        Dim query_command2 As String = "Select * from Win32_Process Where Name='explorer.exe'"
                        Dim select_query2 As SelectQuery = New SelectQuery(query_command2)
                        Dim Srch2 As New ManagementObjectSearcher(msc, select_query2, QueryOptions)
                        Dim objMgmt2 As ManagementObject
                        For Each objMgmt2 In Srch2.Get
                            Dim s(1) As String
                            Dim SessionID As String = Nothing
                            SessionID = objMgmt2("SessionId").ToString()

                            objMgmt2.InvokeMethod("GetOwner", CType(s, Object()))
                            userdomaindetected = (s(1) + ("\" + s(0)))
                            userdomaindetected = userdomaindetected.ToString.ToLower
                            userdomaindetected = userdomaindetected & " = SessionID " & SessionID

                            If userdomaindetected <> "\" Then
                                If userdomainComboBox.Items.Contains(userdomaindetected) Then

                                Else
                                    userdomainComboBox.Items.Add(userdomaindetected)
                                    userdomainComboBox.Text = userdomaindetected
                                End If
                            End If
                        Next

                    Catch ex As Exception
                        MessageBox.Show("Couldn't get username: " + ex.Message, "Error")
                    End Try

                    Const HKEY_LOCAL_MACHINE = &H80000002
                    Dim strvalue = ""
                    Dim objReg
                    Dim objSWbemServices
                    Dim objSWbemLocator
                    Try
                        objSWbemLocator = CreateObject("wbemScripting.SwbemLocator")
                        objSWbemLocator.Security_.AuthenticationLevel = 6 'Packet Privacy.
                        objSWbemServices = objSWbemLocator.ConnectServer(txtpcname, "root\default", domain & "\" & username, password)
                        objReg = objSWbemServices.Get("StdRegProv")
                        strRead2 = objReg.GetStringValue(HKEY_LOCAL_MACHINE, "SYSTEM\CurrentControlSet\Control\Session Manager", "PendingFileRenameOperations")
                    Catch
                    End Try
                    If strRead2 <> "1" Then
                        Reboot.Text = "Reboot Needed"
                        Reboot.ForeColor = Color.Red
                    End If

                Catch
                End Try

                Dim Commandtorun As String = "CMD.EXE /C RD /S /Q " & Chr(34) & "\\" & MachineName & "\c$\Progra~1\RDT" & Chr(34)
                Try
                    Dim objShell = CreateObject("Wscript.Shell")
                    objShell.run(Commandtorun, 0, False)
                Catch ex As Exception
                End Try

                Try
                    objManagementScope = Nothing
                    objManagementBaseObject.Dispose()
                    objManagementClass.Dispose()
                Catch
                End Try

                Alive.ForeColor = Color.Green
                AliveButton.BackColor = Color.Green
                PCNAME.ForeColor = Color.Green
                ProgressBar2.ForeColor = Color.DarkGreen
                ProgressBar2.Value = 100
                StatusOfConnection.ForeColor = Color.Green
                StatusOfConnection.Text = "Connected"

                Try
                    TreeView.SelectedNode.ImageIndex = 0
                    TreeView.SelectedNode.SelectedImageIndex = 0
                Catch
                End Try

            Catch
                ProgressBar2.Value = 0
            End Try

            BackgroundWorkerSpinner.CancelAsync()
            MetroProgressBar.Hide()
            PCNAME.Focus()
        End If

        If IP4Address = String.Empty Then
            BackgroundWorkerSpinner.CancelAsync()
            MetroProgressBar.Hide()
            PCNAME.Text = Nothing
            TreeView.SelectedNode.ImageIndex = 2
            TreeView.SelectedNode.SelectedImageIndex = 2
            MsgBox("Unable to resolve IP via DNS")
            Exit Sub
        End If

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
        PCNAME.Focus()

    End Sub

    Function Ping(ByVal nametocheck As String) As Boolean

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Dim myping As Ping = New Ping
        Dim pingreply As PingReply
        Dim Timeout = 500
        Dim PacketSize = 32
        Dim data As String = ""
        Dim i As Integer
        Dim options As PingOptions = New PingOptions
        options.DontFragment = True

        For i = 1 To PacketSize
            data = String.Concat(data, "a")
        Next

        Dim buffer() As Byte = Encoding.ASCII.GetBytes(data)

        Try
            pingreply = myping.Send(nametocheck, Timeout, buffer, options)

            If pingreply.Status = IPStatus.Success Then
                DirectCast(myping, IDisposable).Dispose() 'Cast the Ping object as IDisposable and destroy it
                BackgroundWorkerSpinner.CancelAsync()
                MetroProgressBar.Hide()
                Return (True)
            Else
                DirectCast(myping, IDisposable).Dispose() 'Cast the Ping object as IDisposable and destroy it
                BackgroundWorkerSpinner.CancelAsync()
                MetroProgressBar.Hide()
                Return (False)
            End If
        Catch ex As Exception
            DirectCast(myping, IDisposable).Dispose() 'Cast the Ping object as IDisposable and destroy it
            BackgroundWorkerSpinner.CancelAsync()
            MetroProgressBar.Hide()
            Return (False)

        End Try

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()

    End Function


    Private Sub AddPC_Click(sender As Object, e As EventArgs) Handles AddPC.Click

        Dim INPC As String = InputBox("Enter PC name :").ToString
        If INPC = "" Then Exit Sub
        INPC = INPC.ToUpper()
        Dim i As Integer
        Dim serverinlist = 0
        Try
            Dim TopLevelAD As TreeNode
            'TopLevelAD = TreeView.SelectedNode
            If TreeView.Nodes.Count > 0 Then
                For i = 0 To TreeView.Nodes.Count - 1
                    If TreeView.Nodes(i).Text = INPC Then
                        MsgBox("PC name already in list!")
                        serverinlist = 1
                        TopLevelAD = TreeView.Nodes(i)
                        TreeView.SelectedNode = TopLevelAD
                        Try
                            Dim PingAnswer = Nothing
                            PingAnswer = Ping(INPC)
                            If PingAnswer = True Then
                                TopLevelAD.ImageIndex = 4
                                TopLevelAD.SelectedImageIndex = 4
                            End If
                            If PingAnswer = False Then
                                TopLevelAD.ImageIndex = 5
                                TopLevelAD.SelectedImageIndex = 5
                            End If
                        Catch ex As Exception
                        End Try

                    End If
                Next
                If serverinlist = 0 Then
                    TopLevelAD = AddTreeViewNode(TreeView.Nodes, INPC, 1)
                    TreeView.SelectedNode = TopLevelAD

                    Try
                        Dim regKey As Microsoft.Win32.RegistryKey
                        regKey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey("Software\RDT\Computers", True)
                        regKey.CreateSubKey(INPC)
                        regKey.Close()
                    Catch ex As Exception
                    End Try

                    Try
                        Dim PingAnswer = Nothing
                        PingAnswer = Ping(INPC)
                        If PingAnswer = True Then
                            TopLevelAD.ImageIndex = 4
                            TopLevelAD.SelectedImageIndex = 4
                        End If
                        If PingAnswer = False Then
                            TopLevelAD.ImageIndex = 5
                            TopLevelAD.SelectedImageIndex = 5
                        End If
                    Catch ex As Exception
                    End Try

                End If
            End If

            TreeView.Sort()

        Catch ex As Exception
        End Try
    End Sub

    Private Sub PingALL_Click(sender As Object, e As EventArgs)

        Dim nodeslist As New List(Of String)
        For Each childNode As TreeNode In TreeView.Nodes
            Dim PingAnswer = Nothing
            PingAnswer = Ping(childNode.Text)
            If PingAnswer = True Then
                TreeView.SelectedNode = childNode
                TreeView.SelectedNode.ImageIndex = 0
                TreeView.SelectedNode.SelectedImageIndex = 0
            End If
            If PingAnswer = False Then
                TreeView.SelectedNode = childNode
                TreeView.SelectedNode.ImageIndex = 2
                TreeView.SelectedNode.SelectedImageIndex = 2
            End If
        Next

    End Sub

    Private Sub DeletePC_Click(sender As Object, e As EventArgs) Handles DeletePC.Click
        Try
            If TreeView.SelectedNode.Checked = True Then Exit Sub
            Dim INPC As String = TreeView.SelectedNode.Text
            Registry.CurrentUser.DeleteSubKey("Software\RDT\Computers\" & INPC, True)
        Catch ex As Exception
        End Try

        Try
            TreeView.Nodes.Remove(TreeView.SelectedNode)
        Catch ex As Exception
        End Try
    End Sub

    Private Sub DataGridView10_CellClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs)
        Dim x As String
        x = DataGridView10.CurrentRow.Cells.Item(0).Value
        KBTextBox.Text = x
    End Sub
    Private Sub KBRemoveButton_Click(sender As Object, e As EventArgs) Handles KBRemoveButton.Click

        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        Dim response As MsgBoxResult
        response = MsgBox("Are you sure you want to uninstall : " & KBTextBox.Text & " ?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "Confirm")
        If response = MsgBoxResult.Yes Then

            MetroProgressBar.Show()
            BackgroundWorkerSpinner.RunWorkerAsync()

            Dim Command As String = Nothing

            Dim x As String
            x = KBTextBox.Text

            Try
                Dim strComputerName As String = txtpcname
                Dim strStringValue As String = ""
                Dim strKeyPath As String = "SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\Packages\"
                Dim objManagementScope2 As ManagementScope = Nothing
                Dim objManagementClass2 As ManagementClass = Nothing
                Dim objManagementBaseObject2 As ManagementBaseObject = Nothing
                Dim strkey As String
                Dim myValue1 As String
                Dim myValue2 As String
                Dim aSubKeys() As String
                Dim intRegistryHive As Microsoft.Win32.RegistryHive
                intRegistryHive = Microsoft.Win32.RegistryHive.LocalMachine

                Dim options As ConnectionOptions
                options = New ConnectionOptions()
                Dim computerconnect As String = "\\" & txtpcname & "\root\DEFAULT"

                options.Username = username
                options.Password = password
                options.Timeout = TimeSpan.FromSeconds(30)
                options.Authority = "NTLMDOMAIN:" & domain
                options.Authentication = AuthenticationLevel.PacketPrivacy
                objManagementScope2 = New ManagementScope(computerconnect, options)

                If objManagementScope2.IsConnected = True Then
                Else
                    Try
                        objManagementScope2.Connect()
                    Catch ex As Exception
                        MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                        BackgroundWorkerSpinner.CancelAsync()
                        MetroProgressBar.Hide()
                        PCNAME.Focus()
                        Exit Sub
                    End Try
                End If

                Try
                    objManagementClass2 = New ManagementClass("stdRegProv")
                    objManagementClass2.Scope = objManagementScope2
                    objManagementBaseObject2 = objManagementClass2.GetMethodParameters("EnumKey")
                    objManagementBaseObject2.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                    objManagementBaseObject2.SetPropertyValue("sSubKeyName", strKeyPath)
                    aSubKeys = CType(objManagementClass2.InvokeMethod("EnumKey", objManagementBaseObject2, Nothing).Properties.Item("sNames").Value, String())
                    Try
                        For Each strkey In aSubKeys

                            If strkey.Contains("Package_for_" & x & "~31bf3856ad364e35~") Then
                                Command = "DISM.exe /Online /Remove-Package /PackageName:" & strkey & " /norestart /quiet"
                            Else
                                If strkey.Contains("Package_for_") Then
                                    If strkey.Contains("Package_for_" & x & "_") Then

                                    Else
                                        objManagementBaseObject2 = objManagementClass2.GetMethodParameters("GetStringValue")
                                        objManagementBaseObject2.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                                        objManagementBaseObject2.SetPropertyValue("sSubKeyName", strKeyPath & strkey)
                                        objManagementBaseObject2.SetPropertyValue("sValueName", "InstallLocation")
                                        objManagementBaseObject2 = objManagementClass2.InvokeMethod("GetStringValue", objManagementBaseObject2, Nothing)
                                        myValue2 = objManagementBaseObject2("sValue")

                                        objManagementBaseObject2 = objManagementClass2.GetMethodParameters("GetStringValue")
                                        objManagementBaseObject2.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                                        objManagementBaseObject2.SetPropertyValue("sSubKeyName", strKeyPath & strkey)
                                        objManagementBaseObject2.SetPropertyValue("sValueName", "InstallName")
                                        objManagementBaseObject2 = objManagementClass2.InvokeMethod("GetStringValue", objManagementBaseObject2, Nothing)
                                        myValue1 = objManagementBaseObject2("sValue")
                                        If myValue2.Contains(x) OrElse myValue1.Contains(x) Then
                                            Command = "DISM.exe /Online /Remove-Package /PackageName:" & strkey & " /norestart /quiet"
                                        End If
                                    End If

                                End If
                            End If

                        Next
                    Catch ex As Exception
                    End Try
                Catch ex As Exception
                End Try

                Try
                    objManagementScope2 = Nothing
                    objManagementBaseObject2.Dispose()
                    objManagementClass2.Dispose()
                Catch
                End Try

                If Command = "" Then
                    BackgroundWorkerSpinner.CancelAsync()
                    MetroProgressBar.Hide()
                    Exit Sub
                End If

                Dim processID As UInteger = 0
                Dim ExitCode = 1

                Try
                    Dim connOptions As New Management.ConnectionOptions()
                    connOptions.Username = username
                    connOptions.Password = password
                    connOptions.Timeout = TimeSpan.FromSeconds(30)
                    connOptions.Authority = "NTLMDOMAIN:" & domain
                    connOptions.EnablePrivileges = True
                    connOptions.Authentication = AuthenticationLevel.PacketPrivacy
                    connOptions.Impersonation = ImpersonationLevel.Impersonate
                    connOptions.EnablePrivileges = True
                    Dim manScope As New Management.ManagementScope([String].Format("\\{0}\ROOT\CIMV2", txtpcname), connOptions)

                    Try
                        manScope.Connect()
                    Catch
                        MsgBox("Couldn't connect to remote PC.")
                        BackgroundWorkerSpinner.CancelAsync()
                        MetroProgressBar.Hide()
                        Exit Sub
                    End Try
                    Dim objectGetOptions As New Management.ObjectGetOptions()
                    Dim managementPath As New Management.ManagementPath("Win32_Process")
                    Using processClass As New Management.ManagementClass(manScope, managementPath, objectGetOptions)
                        Using inParams As Management.ManagementBaseObject = processClass.GetMethodParameters("Create")
                            inParams("CommandLine") = "CMD.EXE /C " & Command
                            Using outParams As Management.ManagementBaseObject = processClass.InvokeMethod("Create", inParams, Nothing)
                                If CUInt(outParams("returnValue")) <> 0 Then
                                    BackgroundWorkerSpinner.CancelAsync()
                                    MetroProgressBar.Hide()
                                    PCNAME.Focus()
                                    MsgBox("Command failed to execute...")
                                Else
                                    BackgroundWorkerSpinner.CancelAsync()
                                    MetroProgressBar.Hide()
                                    PCNAME.Focus()
                                    MsgBox("Command executed at : " & Now & " : " & Command)
                                    'processID = CUInt(outParams("processId"))
                                End If
                            End Using
                        End Using
                    End Using

                    Try
                        manScope = Nothing
                    Catch
                    End Try

                Catch
                End Try

                BackgroundWorkerSpinner.CancelAsync()
                MetroProgressBar.Hide()
                PCNAME.Focus()

            Catch ex As Exception
            End Try

        ElseIf response = MsgBoxResult.No Then
            Exit Sub
        End If


    End Sub

    Private Sub WIM_OptionalFeaturesButton_Click(sender As Object, e As EventArgs) Handles WIM_OptionalFeaturesButton.Click
        If MachineName = "" Then
            Exit Sub
        End If
        OptionalFeaturesDataGrid.Rows.Clear()
        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()
        Try
            Dim objManagementScope2 As ManagementScope
            Dim options2 As ConnectionOptions
            options2 = New ConnectionOptions()
            Dim computerconnect2 As String = "\\" & txtpcname & "\root\cimv2"
            options2.Username = username
            options2.Password = password
            options2.Timeout = TimeSpan.FromSeconds(30)
            options2.Authority = "NTLMDOMAIN:" & domain
            options2.Authentication = AuthenticationLevel.PacketPrivacy
            objManagementScope2 = New ManagementScope(computerconnect2, options2)
            If objManagementScope2.IsConnected = True Then
            Else
                objManagementScope2.Connect()
            End If

            Dim QueryOptions = New EnumerationOptions
            QueryOptions.Timeout = New TimeSpan(0, 0, 60)
            Dim query2 As New SelectQuery("SELECT * FROM Win32_OptionalFeature")
            Dim searcher2 As New ManagementObjectSearcher(objManagementScope2, query2, QueryOptions)
            For Each mo As ManagementObject In searcher2.[Get]()
                Dim DriverState As String = Nothing
                Dim Devicename As String = Nothing
                Devicename = mo("Name")
                DriverState = mo("InstallState")
                If DriverState = "1" Then DriverState = "Enabled"
                If DriverState = "2" Then DriverState = "Disabled"
                OptionalFeaturesDataGrid.Rows.Add(Devicename, DriverState)
            Next
            OptionalFeaturesDataGrid.Sort(OptionalFeaturesDataGrid.Columns(0), System.ComponentModel.ListSortDirection.Ascending)

            Try
                objManagementScope2 = Nothing
            Catch
            End Try

        Catch
        End Try
        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()

    End Sub

    Private Sub WIM_OptionalFeaturesExportButton_Click(sender As Object, e As EventArgs) Handles WIM_OptionalFeaturesExportButton.Click
        Try
            Using outputFile As New IO.StreamWriter("c:\windows\temp\export.csv")
                outputFile.WriteLine(MachineName)
                outputFile.WriteLine(txtpcname)
                outputFile.WriteLine(" ")
                Try
                    Dim array As String() = New String(OptionalFeaturesDataGrid.Columns.Count - 1) {}
                    'get column header text from all columns:
                    For j As Integer = 0 To OptionalFeaturesDataGrid.Columns.Count - 1
                        array(j) = OptionalFeaturesDataGrid.Columns(j).HeaderText
                    Next
                    outputFile.WriteLine([String].Join(",", array))
                Catch ex As Exception
                End Try
                For Each row As DataGridViewRow In OptionalFeaturesDataGrid.Rows
                    If Not row.IsNewRow Then
                        Dim line As String = String.Empty
                        For x As Integer = 0 To row.Cells.Count - 1
                            line &= row.Cells(x).Value & ","
                        Next
                        outputFile.WriteLine(line.Remove(line.Length - 1, 1))
                    End If
                Next
                outputFile.Flush()
            End Using
        Catch ex As Exception
        End Try
        Try
            Dim objShell = CreateObject("Wscript.Shell")
            objShell.run("c:\windows\temp\export.csv")
        Catch ex As Exception
        End Try
    End Sub

    Private Sub PnPSignedDriverExportButton_Click(sender As Object, e As EventArgs) Handles PnPSignedDriverExportButton.Click
        Try
            Using outputFile As New IO.StreamWriter("c:\windows\temp\export.csv")
                outputFile.WriteLine(MachineName)
                outputFile.WriteLine(txtpcname)
                outputFile.WriteLine(" ")
                Try
                    Dim array As String() = New String(PnPSignedDriverDataGrid.Columns.Count - 1) {}
                    'get column header text from all columns:
                    For j As Integer = 0 To PnPSignedDriverDataGrid.Columns.Count - 1
                        array(j) = PnPSignedDriverDataGrid.Columns(j).HeaderText
                    Next
                    outputFile.WriteLine([String].Join(",", array))
                Catch ex As Exception
                End Try
                For Each row As DataGridViewRow In PnPSignedDriverDataGrid.Rows
                    If Not row.IsNewRow Then
                        Dim line As String = String.Empty
                        For x As Integer = 0 To row.Cells.Count - 1
                            line &= row.Cells(x).Value & ","
                        Next
                        outputFile.WriteLine(line.Remove(line.Length - 1, 1))
                    End If
                Next
                outputFile.Flush()
            End Using
        Catch ex As Exception
        End Try
        Try
            Dim objShell = CreateObject("Wscript.Shell")
            objShell.run("c:\windows\temp\export.csv")
        Catch ex As Exception
        End Try
    End Sub

    Private Sub PnPSignedDriverButton_Click(sender As Object, e As EventArgs) Handles PnPSignedDriverButton.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        PnPSignedDriverDataGrid.Rows.Clear()
        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()
        Try
            Dim objManagementScope2 As ManagementScope
            Dim options2 As ConnectionOptions
            options2 = New ConnectionOptions()
            Dim computerconnect2 As String = "\\" & txtpcname & "\root\cimv2"
            options2.Username = username
            options2.Password = password
            options2.Timeout = TimeSpan.FromSeconds(30)
            options2.Authority = "NTLMDOMAIN:" & domain
            options2.Authentication = AuthenticationLevel.PacketPrivacy
            objManagementScope2 = New ManagementScope(computerconnect2, options2)
            If objManagementScope2.IsConnected = True Then
            Else
                objManagementScope2.Connect()
            End If

            Dim QueryOptions = New EnumerationOptions
            QueryOptions.Timeout = New TimeSpan(0, 0, 60)
            Dim query2 As New SelectQuery("SELECT * FROM Win32_PnPSignedDriver")
            Dim searcher2 As New ManagementObjectSearcher(objManagementScope2, query2, QueryOptions)
            For Each mo As ManagementObject In searcher2.[Get]()
                Dim DeviceID As String = Nothing
                Dim DriverVersion As String = Nothing
                'Dim Devicename As String = Nothing
                Dim dtmInstallDate As DateTime = Nothing
                Dim DriverProviderName As String = Nothing
                Dim DeviceClass As String = Nothing
                Dim InfName As String = Nothing
                'Devicename = mo("DeviceName")
                DriverVersion = mo("DriverVersion")
                DeviceID = mo("DeviceID")
                DriverProviderName = mo("DriverProviderName")
                DeviceClass = mo("DeviceClass")
                InfName = mo("InfName")
                Try
                    dtmInstallDate = ManagementDateTimeConverter.ToDateTime(CStr(mo("DriverDate")))
                Catch ex As Exception
                End Try
                If DriverProviderName = "Microsoft" Or DriverProviderName = "" Then

                Else
                    PnPSignedDriverDataGrid.Rows.Add(DeviceClass, DriverProviderName, dtmInstallDate, DriverVersion, InfName, DeviceID)
                End If
                'dtmInstallDate = DateTime.ParseExact(dtmInstallDate, "yyyyMMdd", System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat)
            Next
            PnPSignedDriverDataGrid.Sort(PnPSignedDriverDataGrid.Columns(0), System.ComponentModel.ListSortDirection.Ascending)
        Catch
        End Try
        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
    End Sub

    Private Sub StopTimer_Click(sender As Object, e As EventArgs)
        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
    End Sub

    Private Sub Home_Click(sender As Object, e As EventArgs) Handles Home.Click
        FormTabControl.SelectedIndex = 0
    End Sub

    Private Sub PowershellCMD_Click(sender As Object, e As EventArgs) Handles PowershellCMD.Click
        If MachineName = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Dim powersetup As Boolean = False
        powersetup = SETUPPowerShellonRemote()
        If powersetup = False Then
            MsgBox("Unable to configure Powershell for connection on computer : " & txtpcname)
            BackgroundWorkerSpinner.CancelAsync()
            MetroProgressBar.Hide()
            Exit Sub
        End If

        Try

            Dim securepass As New Security.SecureString
            Dim c As Char
            For Each c In password
                securepass.AppendChar(c)
            Next
            Process.Start(New ProcessStartInfo() With {.UseShellExecute = False, .FileName = "powershell.exe", .UserName = username, .Password = securepass, .Domain = domain, .Arguments = "-Noexit enter-pssession " & MachineName, .WorkingDirectory = "C:\Windows\Temp"})

        Catch ex As Exception
        End Try

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()

    End Sub

    Public Function RunRemotePSScript(ByVal connectTo As String, ByVal user As String, ByVal password As String, ByVal script As String)
        Const SHELL_URI As String = "http://schemas.microsoft.com/powershell/Microsoft.PowerShell"
        Dim serverUri As New Uri("http://" & connectTo & ":5985/wsman")

        Dim securepass As New Security.SecureString
        Dim c As Char
        For Each c In password
            securepass.AppendChar(c)
        Next
        Dim remotecred As New PSCredential(user, securepass)

        Dim connectionInfo As New WSManConnectionInfo(serverUri, SHELL_URI, remotecred)
        Dim myRunSpace As Runspace = RunspaceFactory.CreateRunspace(connectionInfo)
        Dim psresult As New ObjectModel.Collection(Of PSObject)
        myRunSpace.Open()
        'myRunSpace.SessionStateProxy.Path.SetLocation("C:\Windows\System32")

        Dim psh As PowerShell = PowerShell.Create()
        psh.Runspace = myRunSpace

        'MsgBox(script)
        psh.AddScript(script)

        Try
            psresult = psh.Invoke()
        Catch ex As Exception
            MsgBox(ex)
        End Try

        ' convert the script result into a single string 
        Dim MyStringBuilder As New StringBuilder()
        If Not IsNothing(psresult) Then
            For Each obj As PSObject In psresult
                MyStringBuilder.AppendLine(obj.ToString())
            Next
        End If

        psh.Dispose()
        myRunSpace.Dispose()

        'MsgBox(MyStringBuilder.ToString())
        Return MyStringBuilder.ToString()

    End Function

    Private Function IsPortOpen(ByVal Host As String, ByVal PortNumber As Integer) As Boolean

        Const SHELL_URI As String = "http://schemas.microsoft.com/powershell/Microsoft.PowerShell"
        Dim serverUri As New Uri("http://" & MachineName & ":5985/wsman")

        Dim securepass As New Security.SecureString
        Dim c As Char
        For Each c In password
            securepass.AppendChar(c)
        Next
        Dim remotecred As New PSCredential(username, securepass)

        Dim connectionInfo As New WSManConnectionInfo(serverUri, SHELL_URI, remotecred)
        Dim myRunSpace As Runspace = RunspaceFactory.CreateRunspace(connectionInfo)
        Dim psresult As New ObjectModel.Collection(Of PSObject)
        Try
            myRunSpace.Open()
        Catch ex As Exception
        End Try

        'myRunSpace.SessionStateProxy.Path.SetLocation("C:\Windows\System32")

        Dim psh As PowerShell = PowerShell.Create()
        psh.Runspace = myRunSpace

        psh.AddScript("Test-WSMan -ComputerName " & MachineName)

        Try
            psresult = psh.Invoke()
        Catch ex As Exception
            Try
                psh.Dispose()
                myRunSpace.Dispose()
            Catch ex2 As Exception
            End Try

            Return False
            Exit Function
        End Try

        Try
            psh.Dispose()
            myRunSpace.Dispose()
        Catch ex As Exception
        End Try

        Return True

    End Function

    Public Sub BackgroundWorkerSpinnerStopWorker()
        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
    End Sub

    Private Function SETUPPowerShellonRemote() As Boolean

        Dim Port As Integer = 5985
        Dim Hostname As String = IP4Address

        Dim PortOpen As Boolean = IsPortOpen(Hostname, Port)

        If PortOpen = True Then
            'MsgBox("Port 5985 Open!")
            Return True
            Exit Function
        ElseIf PortOpen = False Then
            MsgBox("Powershell not configured on remote computer! Attempting to Enable Powershell on remote computer now...")
        End If

        If PortOpen = False Then

            Dim wmi_out As Management.ManagementBaseObject
            Dim objManagementScope As Management.ManagementScope
            Dim objManagementClass As Management.ManagementClass = Nothing
            Dim objManagementBaseObject As Management.ManagementBaseObject = Nothing
            Dim retValue As Integer
            Dim Command As String = "CMD.EXE /C winrm quickconfig -quiet"

            Try
                Dim options As Management.ConnectionOptions
                options = New Management.ConnectionOptions()
                Dim computerconnect As String = "\\" & txtpcname & "\root\cimv2:Win32_Process"

                options.Username = username
                options.Password = password
                options.Timeout = TimeSpan.FromSeconds(30)
                options.Authority = "NTLMDOMAIN:" & domain
                options.EnablePrivileges = True
                options.Authentication = AuthenticationLevel.PacketPrivacy
                objManagementScope = New ManagementScope(computerconnect, options)

                If objManagementScope.IsConnected = True Then
                Else
                    Try
                        objManagementScope.Connect()
                    Catch ex As Exception
                        PCNAME.Focus()
                        'MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                        Return False
                        Exit Function
                    End Try
                End If

                objManagementClass = New Management.ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
                objManagementClass.Scope = objManagementScope

                objManagementBaseObject = objManagementClass.GetMethodParameters("Create")
                objManagementBaseObject.SetPropertyValue("CommandLine", Command)
                wmi_out = objManagementClass.InvokeMethod("Create", objManagementBaseObject, Nothing)

                retValue = Convert.ToInt32(wmi_out("returnValue"))
                Select Case retValue
                    Case 0
                            ' success!
                            'MsgBox("Run winrm quickconfig -quiet")
                    Case 2
                        Throw New ApplicationException("Access denied")
                    Case 3
                        Throw New ApplicationException("Insufficient privilege")
                    Case 8
                        Throw New ApplicationException("Unknown failure")
                    Case 9
                        Throw New ApplicationException("Path not found")
                    Case 21
                        Throw New ApplicationException("Invalid parameter")
                    Case Else
                        Throw New ApplicationException("Unknown return code " & retValue)
                End Select
            Catch ex As Exception
                'MsgBox(txtpcname & ": Can't create the process. " & ex.Message)
            End Try

            Try
                objManagementScope = Nothing
                objManagementBaseObject.Dispose()
                objManagementClass.Dispose()
            Catch
            End Try

            Thread.Sleep(3000)

            Command = "CMD.EXE /C winrm create winrm" & Chr(47) & "config" & Chr(47) & "listener" & Chr(63) & "Address=" & Chr(42) & Chr(43) & "Transport" & Chr(61) & "HTTP"
            'MsgBox(Command)
            Try
                Dim options As Management.ConnectionOptions
                options = New Management.ConnectionOptions()
                Dim computerconnect As String = "\\" & txtpcname & "\root\cimv2:Win32_Process"

                options.Username = username
                options.Password = password
                options.Timeout = TimeSpan.FromSeconds(30)
                options.Authority = "NTLMDOMAIN:" & domain
                options.EnablePrivileges = True
                options.Authentication = AuthenticationLevel.PacketPrivacy
                objManagementScope = New ManagementScope(computerconnect, options)

                If objManagementScope.IsConnected = True Then
                Else
                    Try
                        objManagementScope.Connect()
                    Catch ex As Exception
                        PCNAME.Focus()
                        'MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                        Return False
                        Exit Function
                    End Try
                End If

                objManagementClass = New Management.ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
                objManagementClass.Scope = objManagementScope

                objManagementBaseObject = objManagementClass.GetMethodParameters("Create")
                objManagementBaseObject.SetPropertyValue("CommandLine", Command)
                wmi_out = objManagementClass.InvokeMethod("Create", objManagementBaseObject, Nothing)

                retValue = Convert.ToInt32(wmi_out("returnValue"))
                Select Case retValue
                    Case 0
                            ' success!
                            'MsgBox("Run winrm create winrm/config/listener?Address=*+Transport=HTTP")
                    Case 2
                        Throw New ApplicationException("Access denied")
                    Case 3
                        Throw New ApplicationException("Insufficient privilege")
                    Case 8
                        Throw New ApplicationException("Unknown failure")
                    Case 9
                        Throw New ApplicationException("Path not found")
                    Case 21
                        Throw New ApplicationException("Invalid parameter")
                    Case Else
                        Throw New ApplicationException("Unknown return code " & retValue)
                End Select
            Catch ex As Exception
                MsgBox(txtpcname & ": Can't create the process. " & ex.Message)

                Try
                    objManagementScope = Nothing
                    objManagementBaseObject.Dispose()
                    objManagementClass.Dispose()
                Catch
                End Try

                PCNAME.Focus()
                Return False
                Exit Function
            End Try

        End If

        Return True

    End Function

    Private Sub PowershellCopyLocalExecuteButton_Click(sender As Object, e As EventArgs) Handles PowershellCopyLocalExecuteButton.Click
        If MachineName = "" Then
            Exit Sub
        End If
        If SDBOXFolder.Text = "" Then
            Exit Sub
        End If
        If SDListDirectory.Text = "" Then
            Exit Sub
        End If
        If PSEXECUTEPackageText.Text = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Dim powersetup As Boolean = False
        powersetup = SETUPPowerShellonRemote()
        If powersetup = False Then
            MsgBox("Unable to configure Powershell for connection on computer : " & txtpcname)
            BackgroundWorkerSpinner.CancelAsync()
            MetroProgressBar.Hide()
            Exit Sub
        End If

        Dim Commandtorun As String = "Get-PSDrive " & Inst_RemDriveLetter.Text
        Dim psresult As String = ""
        psresult = RunRemotePSScript(MachineName, username, password, Commandtorun)
        Dim newString As String = psresult.Replace(vbCr, "").Replace(vbLf, "")
        'MsgBox("---" & newString & "---")
        If newString.Equals(Inst_RemDriveLetter.Text) Then
            MsgBox("Drive Letter already in use - please pick another Drive")
            BackgroundWorkerSpinner.CancelAsync()
            MetroProgressBar.Hide()
            Exit Sub
        End If

        Dim response As MsgBoxResult
        psresult = ""
        response = MsgBox("Do you have enough space to copy " & SDBOXFolder.Text & " to " & txtpcname & " C:\Program Files\RDT\RDT\" & SDBOXFolder.Text & " ?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "Confirm")
        If response = MsgBoxResult.Yes Then
            Createcopylocal(txtpcname)
            Copylocalfiles()
        ElseIf response = MsgBoxResult.No Then
            Commandtorun = "CMD.EXE /C RD /S /Q " & Chr(34) & "\\" & MachineName & "\c$\Progra~1\RDT" & Chr(34)
            Try
                psresult = RunPSCommand(MachineName, username, password, Commandtorun)
            Catch ex As Exception
            End Try
            BackgroundWorkerSpinner.CancelAsync()
            MetroProgressBar.Hide()
            PCNAME.Focus()
            Exit Sub
        End If

        Dim response2 As MsgBoxResult
        psresult = ""
        Dim psresultrun As String = Nothing
        Dim ExitCode = 1
        MsgBox("Please check the files have finished copying to \\" & txtpcname & "\c$\Program Files\RDT\RDT\" & SDBOXFolder.Text)
        response2 = MsgBox("Copy complete? Do you want to Run : " & PSEXECUTEPackageText.Text & " : command line now ?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "Confirm")
        If response2 = MsgBoxResult.Yes Then
            'createpsexecutebat(txtpcname)
            Try
                psresultrun = RUNPOWERSHELL(username, password, domain, txtpcname)
            Catch ex As Exception
                MsgBox(ex)
            End Try

            Thread.Sleep(3000) ' 3000 milliseconds = 3 seconds

            Commandtorun = "CMD.EXE /C RD /S /Q " & Chr(34) & "\\" & MachineName & "\c$\Progra~1\RDT" & Chr(34)
            Try
                psresult = RunPSCommand(MachineName, username, password, Commandtorun)
            Catch ex As Exception
            End Try

            BackgroundWorkerSpinner.CancelAsync()
            MetroProgressBar.Hide()

            If psresult <> "" Then
                MsgBox(psresultrun)
            End If

        ElseIf response2 = MsgBoxResult.No Then
            Commandtorun = "CMD.EXE /C RD /S /Q " & Chr(34) & "\\" & MachineName & "\c$\Progra~1\RDT" & Chr(34)
            Try
                psresult = RunPSCommand(MachineName, username, password, Commandtorun)
            Catch ex As Exception
            End Try

            BackgroundWorkerSpinner.CancelAsync()
            MetroProgressBar.Hide()
        End If

        PCNAME.Focus()

    End Sub


    Private Function RUNPOWERSHELL(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)
        Dim psresult As String = ""
        Dim meout As String = ""

        Dim cmdtoexe As String = PSEXECUTEPackageText.Text
        Dim array = Nothing
        Try
            array = Split(cmdtoexe, " ")
        Catch
        End Try

        If array.Length = 1 Then
            meout = "CMD.EXE" & " /C " & Chr(34) & "C:\Program Files\RDT\RDT\" & SDBOXFolder.Text & "\" & array(0) & Chr(34)
        End If
        If array.Length = 2 Then
            meout = "CMD.EXE" & " /C " & Chr(34) & "C:\Program Files\RDT\RDT\" & SDBOXFolder.Text & "\" & array(0) & Chr(34) & " " & array(1)
        End If
        If array.Length = 3 Then
            meout = "CMD.EXE" & " /C " & Chr(34) & "C:\Program Files\RDT\RDT\" & SDBOXFolder.Text & "\" & array(0) & Chr(34) & " " & array(1) & " " & array(2)
        End If
        If array.Length = 4 Then
            meout = "CMD.EXE" & " /C " & Chr(34) & "C:\Program Files\RDT\RDT\" & SDBOXFolder.Text & "\" & array(0) & Chr(34) & " " & array(1) & " " & array(2) & " " & array(3)
        End If
        If array.Length = 5 Then
            meout = "CMD.EXE" & " /C " & Chr(34) & "C:\Program Files\RDT\RDT\" & SDBOXFolder.Text & "\" & array(0) & Chr(34) & " " & array(1) & " " & array(2) & " " & array(3) & " " & array(4)
        End If
        If array.Length = 6 Then
            meout = "CMD.EXE" & " /C " & Chr(34) & "C:\Program Files\RDT\RDT\" & SDBOXFolder.Text & "\" & array(0) & Chr(34) & " " & array(1) & " " & array(2) & " " & array(3) & " " & array(4) & " " & array(5)
        End If
        If array.Length = 7 Then
            meout = "CMD.EXE" & " /C " & Chr(34) & "C:\Program Files\RDT\RDT\" & SDBOXFolder.Text & "\" & array(0) & Chr(34) & " " & array(1) & " " & array(2) & " " & array(3) & " " & array(4) & " " & array(5) & " " & array(6)
        End If
        If array.Length = 8 Then
            meout = "CMD.EXE" & " /C " & Chr(34) & "C:\Program Files\RDT\RDT\" & SDBOXFolder.Text & "\" & array(0) & Chr(34) & " " & array(1) & " " & array(2) & " " & array(3) & " " & array(4) & " " & array(5) & " " & array(6) & " " & array(7)
        End If
        If array.Length = 9 Then
            meout = "CMD.EXE" & " /C " & Chr(34) & "C:\Program Files\RDT\RDT\" & SDBOXFolder.Text & "\" & array(0) & Chr(34) & " " & array(1) & " " & array(2) & " " & array(3) & " " & array(4) & " " & array(5) & " " & array(6) & " " & array(7) & " " & array(8)
        End If
        If array.Length = 10 Then
            meout = "CMD.EXE" & " /C " & Chr(34) & "C:\Program Files\RDT\RDT\" & SDBOXFolder.Text & "\" & array(0) & Chr(34) & " " & array(1) & " " & array(2) & " " & array(3) & " " & array(4) & " " & array(5) & " " & array(6) & " " & array(7) & " " & array(8) & " " & array(9)
        End If
        If array.Length = 11 Then
            meout = "CMD.EXE" & " /C " & Chr(34) & "C:\Program Files\RDT\RDT\" & SDBOXFolder.Text & "\" & array(0) & Chr(34) & " " & array(1) & " " & array(2) & " " & array(3) & " " & array(4) & " " & array(5) & " " & array(6) & " " & array(7) & " " & array(8) & " " & array(9) & " " & array(10)
        End If
        If array.Length = 12 Then
            meout = "CMD.EXE" & " /C " & Chr(34) & "C:\Program Files\RDT\RDT\" & SDBOXFolder.Text & "\" & array(0) & Chr(34) & " " & array(1) & " " & array(2) & " " & array(3) & " " & array(4) & " " & array(5) & " " & array(6) & " " & array(7) & " " & array(8) & " " & array(9) & " " & array(10) & " " & array(11)
        End If
        If array.Length = 13 Then
            meout = "CMD.EXE" & " /C " & Chr(34) & "C:\Program Files\RDT\RDT\" & SDBOXFolder.Text & "\" & array(0) & Chr(34) & " " & array(1) & " " & array(2) & " " & array(3) & " " & array(4) & " " & array(5) & " " & array(6) & " " & array(7) & " " & array(8) & " " & array(9) & " " & array(10) & " " & array(11) & " " & array(12)
        End If
        If array.Length = 14 Then
            meout = "CMD.EXE" & " /C " & Chr(34) & "C:\Program Files\RDT\RDT\" & SDBOXFolder.Text & "\" & array(0) & Chr(34) & " " & array(1) & " " & array(2) & " " & array(3) & " " & array(4) & " " & array(5) & " " & array(6) & " " & array(7) & " " & array(8) & " " & array(9) & " " & array(10) & " " & array(11) & " " & array(12) & " " & array(13)
        End If
        If array.Length = 15 Then
            meout = "CMD.EXE" & " /C " & Chr(34) & "C:\Program Files\RDT\RDT\" & SDBOXFolder.Text & "\" & array(0) & Chr(34) & " " & array(1) & " " & array(2) & " " & array(3) & " " & array(4) & " " & array(5) & " " & array(6) & " " & array(7) & " " & array(8) & " " & array(9) & " " & array(10) & " " & array(11) & " " & array(12) & " " & array(13) & " " & array(14)
        End If
        If array.Length = 16 Then
            meout = "CMD.EXE" & " /C " & Chr(34) & "C:\Program Files\RDT\RDT\" & SDBOXFolder.Text & "\" & array(0) & Chr(34) & " " & array(1) & " " & array(2) & " " & array(3) & " " & array(4) & " " & array(5) & " " & array(6) & " " & array(7) & " " & array(8) & " " & array(9) & " " & array(10) & " " & array(11) & " " & array(12) & " " & array(13) & " " & array(14) & " " & array(15)
        End If

        Try
            psresult = RunRemotePSScript(MachineName, username, password, meout)
        Catch ex As Exception
        End Try

        Return psresult

    End Function

    Private Function WMI_RUN_Impersonate(ByVal stringtorun As String) As Boolean
        If MachineName = "" Then
            Exit Function
        End If

        Dim processID As UInteger = 0
        Dim ExitCode = 1

        Try
            Dim connOptions As New Management.ConnectionOptions()
            connOptions.Username = username
            connOptions.Password = password
            connOptions.Timeout = TimeSpan.FromSeconds(30)
            connOptions.Authority = "NTLMDOMAIN:" & domain
            connOptions.EnablePrivileges = True
            connOptions.Authentication = AuthenticationLevel.PacketPrivacy
            connOptions.Impersonation = ImpersonationLevel.Impersonate
            connOptions.EnablePrivileges = True
            Dim manScope As New Management.ManagementScope([String].Format("\\{0}\ROOT\CIMV2", txtpcname), connOptions)

            Try
                manScope.Connect()
            Catch
                MsgBox("Couldn't connect to remote PC.")
                Return 1
                Exit Function
            End Try
            Dim objectGetOptions As New Management.ObjectGetOptions()
            Dim managementPath As New Management.ManagementPath("Win32_Process")
            Using processClass As New Management.ManagementClass(manScope, managementPath, objectGetOptions)
                Using inParams As Management.ManagementBaseObject = processClass.GetMethodParameters("Create")
                    inParams("CommandLine") = stringtorun
                    Using outParams As Management.ManagementBaseObject = processClass.InvokeMethod("Create", inParams, Nothing)
                        If CUInt(outParams("returnValue")) <> 0 Then
                            PCNAME.Focus()
                            MsgBox("Command failed to execute...")
                            Return 1
                        Else
                            PCNAME.Focus()
                            'MsgBox("Command executed at : " & Now & " : " & stringtorun)
                            'processID = CUInt(outParams("processId"))
                            Return 0
                        End If
                    End Using
                End Using
            End Using

            Try
                manScope = Nothing
            Catch
            End Try
        Catch
        End Try

    End Function

    Public Function RunPSCommand(ByVal connectTo As String, ByVal user As String, ByVal password As String, ByVal script As String)
        Const SHELL_URI As String = "http://schemas.microsoft.com/powershell/Microsoft.PowerShell"
        Dim serverUri As New Uri("http://" & connectTo & ":5985/wsman")

        Dim securepass As New Security.SecureString
        Dim c As Char
        For Each c In password
            securepass.AppendChar(c)
        Next
        Dim remotecred As New PSCredential(user, securepass)

        Dim connectionInfo As New WSManConnectionInfo(serverUri, SHELL_URI, remotecred)
        Dim myRunSpace As Runspace = RunspaceFactory.CreateRunspace(connectionInfo)
        Dim psresult As New ObjectModel.Collection(Of PSObject)
        myRunSpace.Open()
        'myRunSpace.SessionStateProxy.Path.SetLocation("C:\Windows\System32")

        Dim psh As PowerShell = PowerShell.Create()
        psh.Runspace = myRunSpace

        'MsgBox(script)
        psh.AddScript(script)

        Try
            psresult = psh.Invoke()
        Catch ex As Exception
            MsgBox(ex)
        End Try

        ' convert the script result into a single string 
        Dim MyStringBuilder As New StringBuilder()
        MyStringBuilder.AppendLine("Command executed at : " & Now)
        MyStringBuilder.AppendLine(" ")
        If Not IsNothing(psresult) Then
            For Each obj As PSObject In psresult
                MyStringBuilder.AppendLine(obj.ToString())
            Next
        End If

        psh.Dispose()
        myRunSpace.Dispose()

        'MsgBox(MyStringBuilder.ToString())
        Return MyStringBuilder.ToString()

    End Function

    Private Sub RunPSCommandButton_Click(sender As Object, e As EventArgs) Handles RunPSCommandButton.Click
        If MachineName = "" Then
            Exit Sub
        End If
        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Dim powersetup As Boolean = False
        powersetup = SETUPPowerShellonRemote()
        If powersetup = False Then
            MsgBox("Unable to configure Powershell for connection on computer : " & txtpcname)
            BackgroundWorkerSpinner.CancelAsync()
            MetroProgressBar.Hide()
            Exit Sub
        End If

        Dim Commandtorun As String = RunPSCommandTextBox.Text
        Dim psresult As String = Nothing
        Try
            psresult = RunPSCommand(MachineName, username, password, Commandtorun)
        Catch ex As Exception
        End Try

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()

        MsgBox(psresult)

    End Sub

    Private Sub DeleteEMAnumber_Click(sender As Object, e As EventArgs) Handles DeleteEMAnumber.Click
        If MachineName = "" Then
            Exit Sub
        End If
        Try
            Dim regKey As Microsoft.Win32.RegistryKey
            regKey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey("Software\RDT\" & MachineName, True)
            regKey.SetValue("EMAdetails", "")
            regKey.Close()
        Catch ex As Exception
        End Try
        Try
            Dim regKey As Microsoft.Win32.RegistryKey
            regKey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey("Software\RDT\" & MachineName, True)
            regKey.SetValue("HelpdeskNumber", "")
            regKey.Close()
        Catch ex As Exception
        End Try

        Helpdesknumber.Text = ""
        SaveEMAdetails.Text = ""

        PCNAME.Focus()
    End Sub

    Private Sub Eventlog_Click_1(sender As Object, e As EventArgs) Handles Eventlog.Click
        If MachineName = "" Then
            Exit Sub
        End If

        Dim strUsername As String
        Dim strPassword As String
        strUsername = domain & "\" & username
        strPassword = password

        Dim oNet = CreateObject("WScript.Network")
        Try
            oNet.RemoveNetworkDrive("\\" & txtpcname & "\ipc$", True, False)
            oNet.RemoveNetworkDrive("\\" & txtpcname & "\admin$", True, False)
        Catch
        End Try
        oNet.MapNetworkDrive("", "\\" & txtpcname & "\ipc$", False, strUsername, strPassword)

        Try
            Dim path As String
            path = "Eventvwr \\" & txtpcname
            Dim objShell = CreateObject("Wscript.Shell")
            objShell.run(path)
        Catch
        End Try
        Try
            ' dismount the previously mounted secure channel
            oNet.RemoveNetworkDrive("\\" & txtpcname & "\ipc$", True, False)
        Catch ex As Exception
        End Try

        PCNAME.Focus()
    End Sub

    Private Sub TaskSched_Click_1(sender As Object, e As EventArgs) Handles TaskSched.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        Dim strUsername As String
        Dim strPassword As String
        strUsername = domain & "\" & username
        strPassword = password

        Dim oNet = CreateObject("WScript.Network")
        Try
            oNet.RemoveNetworkDrive("\\" & txtpcname & "\ipc$", True, False)
            oNet.RemoveNetworkDrive("\\" & txtpcname & "\admin$", True, False)
        Catch
        End Try
        oNet.MapNetworkDrive("", "\\" & txtpcname & "\ipc$", False, strUsername, strPassword)

        PCNAME.Focus()

        Try
            Dim path As String
            path = "taskschd.msc /s"
            Dim objShell = CreateObject("Wscript.Shell")
            objShell.run(path)
        Catch
        End Try
        Try
            ' dismount the previously mounted secure channel
            oNet.RemoveNetworkDrive("\\" & txtpcname & "\ipc$", True, False)
        Catch ex As Exception
        End Try
    End Sub

    Private Sub StartupItemsList_Click_1(sender As Object, e As EventArgs) Handles StartupItemsList.Click
        If MachineName = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Dim lookforbackslash As Integer = InStr(userdomainComboBox.Text, "\")
        If lookforbackslash <> 0 Then
            Dim wordArr As String() = userdomainComboBox.Text.Split("\")
            Dim result As String = wordArr(1)
            LoggedOnUserNameOnly = result
            SIDKEY = GetSIDUsingADSearch(LoggedOnUserNameOnly)
        End If

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
        PCNAME.Focus()

        StartupItems.Show()
    End Sub

    Private Sub ListStoreApps_Click(sender As Object, e As EventArgs) Handles ListStoreApps.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        StoreAppsDataGridView.Rows.Clear()

        GETStoreApps()

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
        PCNAME.Focus()
    End Sub

    Sub GETStoreApps()
        On Error Resume Next

        Dim strRead1 As String = Nothing
        Dim strRead2 As String = Nothing
        Dim strRead3 As String = Nothing
        Dim strRead4 As String = Nothing
        Dim strRead5 As String = Nothing
        Dim strRead6 As String = Nothing


        StoreAppsDataGridView.Rows.Clear()


        If PCnameFordetails.Text <> "" Then

            Dim objManagementScope2 As ManagementScope
            Dim options2 As ConnectionOptions
            options2 = New ConnectionOptions()
            Dim computerconnect2 As String = "\\" & txtpcname & "\root\cimv2"
            options2.Username = username
            options2.Password = password
            options2.Timeout = TimeSpan.FromSeconds(30)
            options2.Authority = "NTLMDOMAIN:" & domain
            options2.Authentication = AuthenticationLevel.PacketPrivacy
            objManagementScope2 = New ManagementScope(computerconnect2, options2)
            If objManagementScope2.IsConnected = True Then
            Else
                objManagementScope2.Connect()
            End If

            Dim QueryOptions = New EnumerationOptions
            QueryOptions.Timeout = New TimeSpan(0, 0, 10)
            Dim query2 As New SelectQuery("SELECT * FROM Win32_InstalledStoreProgram")
            Dim searcher2 As New ManagementObjectSearcher(objManagementScope2, query2, QueryOptions)
            For Each mo As ManagementObject In searcher2.[Get]()
                strRead1 = Nothing
                strRead2 = Nothing
                strRead3 = Nothing
                strRead4 = Nothing
                strRead5 = Nothing
                strRead6 = Nothing

                strRead1 = mo("Name")
                strRead2 = mo("Version")
                strRead3 = mo("Architecture")
                strRead4 = mo("ProgramId")
                strRead5 = mo("Language")
                strRead6 = mo("Vendor")

                StoreAppsDataGridView.Rows.Add(strRead1, strRead2, strRead3, strRead4, strRead5, strRead6)
                StoreAppsDataGridView.Sort(StoreAppsDataGridView.Columns(0), System.ComponentModel.ListSortDirection.Ascending)
            Next


            objManagementScope2 = Nothing

        End If

    End Sub

    Private Sub ExportStoreApps_Click(sender As Object, e As EventArgs) Handles ExportStoreApps.Click
        Try
            Using outputFile As New IO.StreamWriter("c:\windows\temp\export.csv")
                outputFile.WriteLine(MachineName)
                outputFile.WriteLine(txtpcname)
                outputFile.WriteLine(" ")
                Try
                    Dim array As String() = New String(StoreAppsDataGridView.Columns.Count - 1) {}
                    'get column header text from all columns:
                    For j As Integer = 0 To StoreAppsDataGridView.Columns.Count - 1
                        array(j) = StoreAppsDataGridView.Columns(j).HeaderText
                    Next
                    outputFile.WriteLine([String].Join(",", array))
                Catch ex As Exception
                End Try
                For Each row As DataGridViewRow In StoreAppsDataGridView.Rows
                    If Not row.IsNewRow Then
                        Dim line As String = String.Empty
                        For x As Integer = 0 To row.Cells.Count - 1
                            line &= row.Cells(x).Value & ","
                        Next
                        outputFile.WriteLine(line.Remove(line.Length - 1, 1))
                    End If
                Next
                outputFile.Flush()
            End Using
        Catch ex As Exception
        End Try
        Try
            Dim objShell = CreateObject("Wscript.Shell")
            objShell.run("c:\windows\temp\export.csv")
        Catch ex As Exception
        End Try
    End Sub

    Private Sub ClearAllComputers_Click(sender As Object, e As EventArgs) Handles ClearAllComputers.Click
        Try

            Dim lngCount As Integer
            For lngCount = TreeView.Nodes.Count To 1 Step -1
                If lngCount - 1 = 0 Then Exit Sub
                TreeView.SelectedNode = TreeView.Nodes.Item(lngCount - 1)
                Dim INPC As String = TreeView.SelectedNode.Text
                Registry.CurrentUser.DeleteSubKey("Software\RDT\Computers\" & INPC, True)
                TreeView.Nodes.RemoveAt(lngCount - 1)
            Next

        Catch ex As Exception
        End Try
    End Sub

    Private Sub DetectProfiles_Click(sender As Object, e As EventArgs) Handles DetectProfiles.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        DataGridViewProfiles.Rows.Clear()

        MapDriveAdmin(username, password, domain, txtpcname)

        Dim foldertosearch As String = ""
        Dim Replacementstring As String = ""
        Dim strComputerName As String = txtpcname
        Dim strStringValue As String = ""
        Dim strKeyPath As String = "SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList\"
        Dim objManagementScope As ManagementScope = Nothing
        Dim objManagementClass As ManagementClass = Nothing
        Dim objManagementBaseObject As ManagementBaseObject = Nothing
        Dim strkey As String
        Dim myKey As String
        Dim myValue As String
        Dim aSubKeys() As String
        Dim intRegistryHive As Microsoft.Win32.RegistryHive
        intRegistryHive = Microsoft.Win32.RegistryHive.LocalMachine

        Dim options As ConnectionOptions
        options = New ConnectionOptions()
        Dim computerconnect As String = "\\" & txtpcname & "\root\CIMV2"

        options.Username = username
        options.Password = password
        options.Timeout = TimeSpan.FromSeconds(30)
        options.Authority = "NTLMDOMAIN:" & domain
        options.Authentication = AuthenticationLevel.PacketPrivacy
        objManagementScope = New ManagementScope(computerconnect, options)

        If objManagementScope.IsConnected = True Then
        Else
            Try
                objManagementScope.Connect()
            Catch ex As Exception
                BackgroundWorkerSpinner.CancelAsync()
                MetroProgressBar.Hide()
                PCNAME.Focus()
                MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                Exit Sub
            End Try
        End If

        Try
            objManagementClass = New ManagementClass("stdRegProv")
            objManagementClass.Scope = objManagementScope
            objManagementBaseObject = objManagementClass.GetMethodParameters("EnumKey")
            objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
            objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath)
            aSubKeys = CType(objManagementClass.InvokeMethod("EnumKey", objManagementBaseObject, Nothing).Properties.Item("sNames").Value, String())

            For Each strkey In aSubKeys
                myKey = strkey
                objManagementBaseObject = objManagementClass.GetMethodParameters("GetStringValue")
                objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath & strkey)
                objManagementBaseObject.SetPropertyValue("sValueName", "ProfileImagePath")
                objManagementBaseObject = objManagementClass.InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                myValue = objManagementBaseObject("sValue")

                'MsgBox(myKey & " " & myValue)

                If myKey = "S-1-5-18" Then myKey = ""
                If myKey = "S-1-5-19" Then myKey = ""
                If myKey = "S-1-5-20" Then myKey = ""


                Dim dtmInstallDate
                Dim UserSID1, userloaded1, localpath1 As String

                Dim objManagementScope2 As ManagementScope
                Dim options2 As ConnectionOptions
                options2 = New ConnectionOptions()
                Dim computerconnect2 As String = "\\" & txtpcname & "\root\cimv2"
                options2.Username = username
                options2.Password = password
                options2.Timeout = TimeSpan.FromSeconds(30)
                options2.Authority = "NTLMDOMAIN:" & domain
                options2.Authentication = AuthenticationLevel.PacketPrivacy
                objManagementScope2 = New ManagementScope(computerconnect2, options2)
                If objManagementScope2.IsConnected = True Then
                Else
                    objManagementScope2.Connect()
                End If

                Dim QueryOptions = New EnumerationOptions
                QueryOptions.Timeout = New TimeSpan(0, 0, 10)
                Dim query2 As New SelectQuery("SELECT * FROM Win32_UserProfile")
                Dim searcher2 As New ManagementObjectSearcher(objManagementScope2, query2, QueryOptions)
                For Each mo As ManagementObject In searcher2.[Get]()
                    UserSID1 = mo("SID")
                    userloaded1 = mo("Loaded")
                    localpath1 = mo("localpath")
                    dtmInstallDate = ManagementDateTimeConverter.ToDateTime(CStr(mo("LastUseTime")))
                    'MsgBox(UserSID1 & " " & userloaded1)

                    If myKey = UserSID1 Then
                        If myKey <> "" Then

                            Dim Output As Long = 0
                            Replacementstring = myValue.Replace("C:\", "C$\")
                            foldertosearch = "\\" & txtpcname & "\" & Replacementstring

                            Output = GetDirectorySize(foldertosearch, True)
                            Output = Output / 1024 / 1024
                            DataGridViewProfiles.Rows.Add(localpath1, Output, userloaded1, dtmInstallDate, myKey)
                        End If
                    End If
                    'Next
                Next


            Next
        Catch ex As Exception
            'MessageBox.Show(ex.Message)
        End Try

        MapDriveAdminRemove(username, password, domain, txtpcname)

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()

        DataGridViewProfiles.Sort(DataGridViewProfiles.Columns(3), System.ComponentModel.ListSortDirection.Descending)

        Try
            objManagementScope = Nothing
            objManagementBaseObject.Dispose()
            objManagementClass.Dispose()
        Catch
        End Try

    End Sub

    Public Function GetDirectorySize(ByVal path As String, Optional recurse As Boolean = False) As Long
        Dim totalSize As Long = 0

        Try
            Dim files() As String = Directory.GetFiles(path)
            Parallel.For(0, files.Length,
                   Sub(index As Integer)
                       Dim fi As New FileInfo(files(index))
                       Dim size As Long = fi.Length
                       Interlocked.Add(totalSize, size)
                   End Sub)
        Catch ex As Exception
        End Try

        Try
            If recurse Then
                Dim subDirs() As String = Directory.GetDirectories(path)
                Dim subTotal As Long = 0
                Parallel.For(0, subDirs.Length,
                       Function(index As Integer)
                           If (File.GetAttributes(subDirs(index)) And FileAttributes.ReparsePoint) <> FileAttributes.ReparsePoint Then
                               Interlocked.Add(subTotal, GetDirectorySize(subDirs(index), True))
                               Return subTotal
                           End If
                           Return 0
                       End Function)
                Interlocked.Add(totalSize, subTotal)
            End If
        Catch ex As Exception
        End Try

        Return totalSize
    End Function

    Private Sub DeleteProfile_Click(sender As Object, e As EventArgs) Handles DeleteProfile.Click

        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        Dim foldernameselected As String = ""
        'foldernameselected = DataGridViewProfiles.CurrentRow.Cells.Item(0).Value
        Dim SIDSelected As String = ""
        'SIDSelected = DataGridViewProfiles.CurrentRow.Cells.Item(4).Value

        Try
            For Each selectedItem As DataGridViewRow In DataGridViewProfiles.SelectedRows
                foldernameselected = selectedItem.Cells.Item(0).Value.ToString
                SIDSelected = selectedItem.Cells.Item(4).Value.ToString
                'MessageBox.Show(foldernameselected & " " & SIDSelected)

                If foldernameselected = "" Then
                    BackgroundWorkerSpinner.CancelAsync()
                    MetroProgressBar.Hide()
                    Exit Sub
                End If

                If SIDSelected = "" Then
                    BackgroundWorkerSpinner.CancelAsync()
                    MetroProgressBar.Hide()
                    Exit Sub
                End If

                Dim result As DialogResult = MessageBox.Show("Are you sure you want to delete the profile > " & foldernameselected & " on PC " & LabelProfiles1.Text & " ?", "Delete Profile Confirmation", MessageBoxButtons.YesNo)
                If (result = vbYes) Then
                    'MsgBox("Yes pressed")

                    MetroProgressBar.Show()
                    BackgroundWorkerSpinner.RunWorkerAsync()

                    Try
                        Dim UserSID1, userloaded1, localpath1 As String

                        Dim objManagementScope2 As ManagementScope
                        Dim options2 As ConnectionOptions
                        options2 = New ConnectionOptions()
                        Dim computerconnect2 As String = "\\" & txtpcname & "\root\cimv2"
                        options2.Username = username
                        options2.Password = password
                        options2.Timeout = TimeSpan.FromSeconds(30)
                        options2.Authority = "NTLMDOMAIN:" & domain
                        options2.Authentication = AuthenticationLevel.PacketPrivacy
                        objManagementScope2 = New ManagementScope(computerconnect2, options2)
                        If objManagementScope2.IsConnected = True Then
                        Else
                            objManagementScope2.Connect()
                        End If

                        Dim QueryOptions = New EnumerationOptions
                        QueryOptions.Timeout = New TimeSpan(0, 0, 10)
                        Dim query2 As New SelectQuery("SELECT * FROM Win32_UserProfile")
                        Dim searcher2 As New ManagementObjectSearcher(objManagementScope2, query2, QueryOptions)

                        For Each mo As ManagementObject In searcher2.[Get]()
                            UserSID1 = mo("SID")
                            localpath1 = mo("localpath")
                            userloaded1 = mo("Loaded")

                            If foldernameselected = localpath1 Then
                                If SIDSelected = UserSID1 Then
                                    If userloaded1 = True Then
                                        BackgroundWorkerSpinner.CancelAsync()
                                        MetroProgressBar.Hide()
                                        MessageBox.Show("We can't Delete a profile that is in use, get the user to logoff first!")
                                    Else
                                        mo.Delete()
                                        RunWMIcommand(foldernameselected)
                                        MessageBox.Show("Profile has been deleted!")
                                    End If
                                End If
                            End If
                        Next

                        Try
                            objManagementScope2 = Nothing
                        Catch
                        End Try

                    Catch ex As Exception
                        BackgroundWorkerSpinner.CancelAsync()
                        MetroProgressBar.Hide()
                        ' MessageBox.Show(ex.Message)
                    End Try
                Else
                    'MsgBox("No pressed")
                End If

            Next

        Catch ex As Exception
            'MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub RunWMIcommand(foldernameselected As String)

        Dim processID As UInteger = 0
        Dim ExitCode = 1

        Try
            Dim connOptions As New Management.ConnectionOptions()
            connOptions.Username = username
            connOptions.Password = password
            connOptions.Timeout = TimeSpan.FromSeconds(30)
            connOptions.Authority = "NTLMDOMAIN:" & domain
            connOptions.EnablePrivileges = True
            connOptions.Authentication = AuthenticationLevel.PacketPrivacy
            connOptions.Impersonation = ImpersonationLevel.Impersonate
            connOptions.EnablePrivileges = True
            Dim manScope As New Management.ManagementScope([String].Format("\\{0}\ROOT\CIMV2", txtpcname), connOptions)

            Try
                manScope.Connect()
            Catch
                BackgroundWorkerSpinner.CancelAsync()
                MetroProgressBar.Hide()
                MsgBox("Couldn't connect to remote PC.")
                Exit Sub
            End Try
            Dim objectGetOptions As New Management.ObjectGetOptions()
            Dim managementPath As New Management.ManagementPath("Win32_Process")
            Using processClass As New Management.ManagementClass(manScope, managementPath, objectGetOptions)
                Using inParams As Management.ManagementBaseObject = processClass.GetMethodParameters("Create")
                    inParams("CommandLine") = "CMD.EXE /C RD /S /Q " & foldernameselected
                    Using outParams As Management.ManagementBaseObject = processClass.InvokeMethod("Create", inParams, Nothing)
                        If CUInt(outParams("returnValue")) <> 0 Then
                            BackgroundWorkerSpinner.CancelAsync()
                            MetroProgressBar.Hide()
                        Else
                            BackgroundWorkerSpinner.CancelAsync()
                            MetroProgressBar.Hide()
                            'PCNAME.Focus()
                            'MsgBox("Command executed at : " & Now & " : " & runcommandonlytext.Text)
                            'processID = CUInt(outParams("processId"))
                        End If
                    End Using
                End Using
            End Using

            Try
                manScope = Nothing
            Catch
            End Try

        Catch
        End Try
    End Sub


    Private Sub ListADUsers_Click(sender As Object, e As EventArgs) Handles ListADUsers_Computers.Click

        ListViewAD.Clear()
        Try
            Dim defaultNamingContext As String
            Using rootDSE As New DirectoryEntry("LDAP://RootDSE")
                defaultNamingContext = rootDSE.Properties("defaultNamingContext").Value.ToString()
            End Using
            'MsgBox(defaultNamingContext)

            Dim de As New DirectoryEntry("LDAP://" & domain & "/" & defaultNamingContext)

            Dim dirEntry As DirectoryEntry = de
            Dim pcList As New Collection()
            Dim dirSearcher As DirectorySearcher = New DirectorySearcher(dirEntry)
            dirSearcher.Filter = ("(objectClass=User)")

            Dim dirSearchResults As SearchResult

            For Each dirSearchResults In dirSearcher.FindAll()
                Dim array1 = Split(dirSearchResults.GetDirectoryEntry().Name.ToString().ToString, "=")
                Dim userresults = array1(1).ToString
                ListViewAD.Items.Add(userresults)
            Next
        Catch ex As Exception
        End Try

    End Sub

    Private Sub ListUsersInGroupButton_Click(sender As Object, e As EventArgs) Handles ListUsersInGroupButton.Click
        ListViewAD.Clear()

        Try
            Dim defaultNamingContext As String
            Using rootDSE As New DirectoryEntry("LDAP://RootDSE")
                defaultNamingContext = rootDSE.Properties("defaultNamingContext").Value.ToString()
            End Using
            'MsgBox(defaultNamingContext)

            Dim UsersInGroup As New Collection()
            Dim user
            Dim de As New DirectoryEntry("LDAP://" & domain & "/" & defaultNamingContext)

            Dim MemberSearcher As New DirectorySearcher

            With MemberSearcher
                .SearchRoot = de
                .Filter = "(&(ObjectClass=Group)(CN=" & ListUsersInGroupBox.Text & "))"
                .PropertiesToLoad.Add("Member")
            End With

            Dim mySearchResults As SearchResult = MemberSearcher.FindOne()

            For Each user In mySearchResults.Properties("Member")
                Dim array1 = Split(user, ",")
                Dim array2 = Split(array1(0).ToString, "=")
                Dim userresults = array2(1).ToString
                ListViewAD.Items.Add(userresults)
            Next
        Catch ex As Exception
        End Try

    End Sub

    Private Sub ListADGroups_Click(sender As Object, e As EventArgs) Handles ListADGroups.Click

        ListViewAD.Clear()
        Try
            Dim defaultNamingContext As String
            Using rootDSE As New DirectoryEntry("LDAP://RootDSE")
                defaultNamingContext = rootDSE.Properties("defaultNamingContext").Value.ToString()
            End Using
            'MsgBox(defaultNamingContext)

            Dim de As New DirectoryEntry("LDAP://" & domain & "/" & defaultNamingContext)

            Dim dirEntry As DirectoryEntry = de
            Dim pcList As New Collection()
            Dim dirSearcher As DirectorySearcher = New DirectorySearcher(dirEntry)
            dirSearcher.Filter = ("(objectClass=group)")

            Dim dirSearchResults As SearchResult

            For Each dirSearchResults In dirSearcher.FindAll()
                Dim array1 = Split(dirSearchResults.GetDirectoryEntry().Name.ToString().ToString, "=")
                Dim userresults = array1(1).ToString
                ListViewAD.Items.Add(userresults)
            Next
        Catch ex As Exception
        End Try

    End Sub

    Private Sub ListViewAD_MouseClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles ListViewAD.MouseClick
        ListUsersInGroupBox.Text = ""
        Try
            Dim x As String
            x = ListViewAD.SelectedItems.Item(0).Text
            ListUsersInGroupBox.Text = x
        Catch ex As Exception
        End Try

    End Sub

    Private Sub AddPCFromFile_Click(sender As Object, e As EventArgs) Handles AddPCFromFile.Click
        Dim newPath As String = ""

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Try

            Using dialog As New OpenFileDialog
                If dialog.ShowDialog() <> DialogResult.OK Then
                    BackgroundWorkerSpinner.CancelAsync()
                    MetroProgressBar.Hide()
                    Exit Sub
                Else

                    newPath = Path.GetFullPath(dialog.FileName)
                    'MsgBox(newPath)

                    Dim INPC As String = ""
                    Dim i As Integer
                    Dim serverinlist = 0


                    If System.IO.File.Exists(newPath) = True Then



                        Dim objReader As New System.IO.StreamReader(newPath)
                        Do While objReader.Peek() <> -1

                            serverinlist = 0
                            INPC = objReader.ReadLine()
                            INPC = INPC.ToUpper()
                            'MsgBox(INPC)

                            Dim TopLevelAD As TreeNode
                            'TopLevelAD = TreeView.SelectedNode
                            If TreeView.Nodes.Count > 0 Then

                                For i = 0 To TreeView.Nodes.Count - 1
                                    If TreeView.Nodes(i).Text = INPC Then
                                        'MsgBox("PC name already in list!")
                                        serverinlist = 1

                                        TopLevelAD = TreeView.Nodes(i)
                                        TreeView.SelectedNode = TopLevelAD
                                        Try
                                            Dim PingAnswer = Nothing
                                            PingAnswer = Ping(INPC)
                                            If PingAnswer = True Then
                                                TopLevelAD.ImageIndex = 4
                                                TopLevelAD.SelectedImageIndex = 4
                                            End If
                                            If PingAnswer = False Then
                                                TopLevelAD.ImageIndex = 5
                                                TopLevelAD.SelectedImageIndex = 5
                                            End If
                                        Catch ex As Exception
                                        End Try

                                    End If
                                Next
                                If serverinlist = 0 Then
                                    TopLevelAD = AddTreeViewNode(TreeView.Nodes, INPC, 1)
                                    TreeView.SelectedNode = TopLevelAD

                                    Try
                                        Dim regKey As Microsoft.Win32.RegistryKey
                                        regKey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey("Software\RDT\Computers", True)
                                        regKey.CreateSubKey(INPC)
                                        regKey.Close()
                                    Catch ex As Exception
                                    End Try

                                    Try
                                        Dim PingAnswer = Nothing
                                        PingAnswer = Ping(INPC)
                                        If PingAnswer = True Then
                                            TopLevelAD.ImageIndex = 4
                                            TopLevelAD.SelectedImageIndex = 4
                                        End If
                                        If PingAnswer = False Then
                                            TopLevelAD.ImageIndex = 5
                                            TopLevelAD.SelectedImageIndex = 5
                                        End If
                                    Catch ex As Exception
                                    End Try
                                End If

                            End If


                        Loop

                        objReader.Close()

                        TreeView.Sort()

                    Else
                        'MessageBox.Show("File Does Not Exist")
                        BackgroundWorkerSpinner.CancelAsync()
                        MetroProgressBar.Hide()
                    End If


                End If
            End Using

            BackgroundWorkerSpinner.CancelAsync()
            MetroProgressBar.Hide()

        Catch
        End Try

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()

    End Sub

    Private Sub CreateSearchProgram()
        Try

            Dim fullPath As String = "\\" & txtpcname & "\c$\Program Files\RDT"
            Directory.CreateDirectory(fullPath)
            Dim fullPath2 As String = "\\" & txtpcname & "\c$\Program Files\RDT\RDT"
            Directory.CreateDirectory(fullPath2)

            Dim UserAccount As String = domain & "\" & username
            Dim FolderInfo As IO.DirectoryInfo = New IO.DirectoryInfo(fullPath2)
            Dim FolderAcl As New System.Security.AccessControl.DirectorySecurity
            FolderAcl = FolderInfo.GetAccessControl()
            FolderAcl.AddAccessRule(New System.Security.AccessControl.FileSystemAccessRule(UserAccount, FileSystemRights.FullControl, InheritanceFlags.ContainerInherit Or InheritanceFlags.ObjectInherit, PropagationFlags.None, AccessControlType.Allow))
            FolderInfo.SetAccessControl(FolderAcl)

            Dim W As New IO.StreamWriter("\\" & txtpcname & "\c$\Program Files\RDT\RDT\PF.vbs")
            W.WriteLine("Const HKEY_CLASSES_ROOT = &H80000000")
            W.WriteLine("Const HKEY_CURRENT_USER = &H80000001")
            W.WriteLine("Const HKEY_LOCAL_MACHINE = &H80000002")
            W.WriteLine("Const HKEY_USERS = &H80000003")
            W.WriteLine("Const HKEY_CURRENT_CONFIG = &H80000004")
            W.WriteLine("Const HKEY_DYN_DATA = &H80000005")
            W.WriteLine(" ")
            W.WriteLine("strComputer = "".""")
            W.WriteLine(" ")
            W.WriteLine("set oWsh = createobject(""wscript.shell"")")
            W.WriteLine(" ")
            W.WriteLine("Set oReg = GetObject(""winmgmts:{impersonationLevel=impersonate}!\\"" & strComputer & ""\root\default:StdRegProv"")")
            W.WriteLine(" ")
            W.WriteLine("strKeyPath = ""software\microsoft\windows\currentversion\uninstall""")
            W.WriteLine("strKey2Path = ""SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall""")
            W.WriteLine(" ")
            W.WriteLine("sMatch = """ & SearchProgramBox.Text & """")
            W.WriteLine(" ")
            W.WriteLine("Set objFSO=CreateObject(""Scripting.FileSystemObject"")")
            W.WriteLine("outFile = ""c:\Program Files\RDT\RDT\PF.txt""")
            W.WriteLine("If objFSO.FileExists(outFile) Then")
            W.WriteLine("objFSO.DeleteFile outFile")
            W.WriteLine("End If")
            W.WriteLine(" ")
            W.WriteLine("Set objFile = objFSO.CreateTextFile(outFile,True)")
            W.WriteLine(" ")
            W.WriteLine("oReg.EnumKey HKEY_LOCAL_MACHINE, strKeyPath, arrSubKeys")
            W.WriteLine("For Each subkey In arrSubKeys")
            W.WriteLine("On Error Resume Next")
            W.WriteLine("sDisplayName = oWsh.Regread(""HKLM\"" & strKeyPath & ""\"" & subkey & ""\DisplayName"")")
            W.WriteLine("If Err.Number = 0 Then")
            W.WriteLine("On Error GoTo 0")
            W.WriteLine("If InStr(1, sDisplayName, sMatch, vbTextCompare) > 0 Then")
            W.WriteLine("On Error Resume Next")
            W.WriteLine("sVersion = oWsh.Regread(""HKLM\"" & strKeyPath & ""\"" & subkey & ""\DisplayVersion"")")
            W.WriteLine("If Err.Number = 0 Then")
            W.WriteLine(" ")
            W.WriteLine("Else")
            W.WriteLine("sVersion = """"")
            W.WriteLine("End If")
            W.WriteLine("sInstallDate = oWsh.Regread(""HKLM\"" & strKeyPath & ""\"" & subkey & ""\InstallDate"")")
            W.WriteLine("If Err.Number = 0 Then")
            W.WriteLine(" ")
            W.WriteLine("Else")
            W.WriteLine("sInstallDate = """"")
            W.WriteLine("End If")
            W.WriteLine("objFile.Write sDisplayName & "","" & sVersion & "","" & sInstallDate & "","" & subkey & vbCrLf")
            W.WriteLine("On Error GoTo 0")
            W.WriteLine("End If")
            W.WriteLine("End If")
            W.WriteLine("Next")
            W.WriteLine("On Error GoTo 0")
            W.WriteLine(" ")
            W.WriteLine("oReg.EnumKey HKEY_LOCAL_MACHINE, strKey2Path, arrSubKeys")
            W.WriteLine("For Each subkey In arrSubKeys")
            W.WriteLine("On Error Resume Next")
            W.WriteLine("sDisplayName = oWsh.Regread(""HKLM\"" & strKey2Path & ""\"" & subkey & ""\DisplayName"")")
            W.WriteLine("If Err.Number = 0 Then")
            W.WriteLine("On Error GoTo 0")
            W.WriteLine("If InStr(1, sDisplayName, sMatch, vbTextCompare) > 0 Then")
            W.WriteLine("On Error Resume Next")
            W.WriteLine("sVersion = oWsh.Regread(""HKLM\"" & strKey2Path & ""\"" & subkey & ""\DisplayVersion"")")
            W.WriteLine("If Err.Number = 0 Then")
            W.WriteLine(" ")
            W.WriteLine("Else")
            W.WriteLine("sVersion = """"")
            W.WriteLine("End If")
            W.WriteLine("sInstallDate = oWsh.Regread(""HKLM\"" & strKey2Path & ""\"" & subkey & ""\InstallDate"")")
            W.WriteLine("If Err.Number = 0 Then")
            W.WriteLine(" ")
            W.WriteLine("Else")
            W.WriteLine("sInstallDate = """"")
            W.WriteLine("End If")
            W.WriteLine("objFile.Write sDisplayName & "","" & sVersion & "","" & sInstallDate & "","" & subkey & vbCrLf")
            W.WriteLine("On Error GoTo 0")
            W.WriteLine("End If")
            W.WriteLine("End If")
            W.WriteLine("Next")
            W.WriteLine("On Error GoTo 0")
            W.WriteLine(" ")
            W.WriteLine("objFile.Close")

            W.Close()
            W.Dispose()

        Catch
        End Try
    End Sub

    Private Sub SearchProgram(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)

        Dim strComputerName As String = txtpcname
        Dim strStringValue As String = ""
        Dim strKeyPath As String = "SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\"
        Dim strKeyPath2 As String = "SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\"
        Dim objManagementScope As ManagementScope = Nothing
        Dim objManagementClass As ManagementClass = Nothing
        Dim objManagementBaseObject As ManagementBaseObject = Nothing
        Dim strkey As String
        Dim myKey As String
        Dim myValue As String
        Dim myValue1 As String
        Dim myValue2 As String
        Dim aSubKeys() As String
        Dim intRegistryHive As Microsoft.Win32.RegistryHive
        intRegistryHive = Microsoft.Win32.RegistryHive.LocalMachine

        Dim options As ConnectionOptions
        options = New ConnectionOptions()
        Dim computerconnect As String = "\\" & txtpcname & "\root\DEFAULT"

        options.Username = txtusername
        options.Password = txtpassword
        options.Timeout = TimeSpan.FromSeconds(30)
        options.Authority = "NTLMDOMAIN:  " & txtdomain
        options.Authentication = AuthenticationLevel.PacketPrivacy
        objManagementScope = New ManagementScope(computerconnect, options)

        If objManagementScope.IsConnected = True Then
        Else
            Try
                objManagementScope.Connect()
            Catch ex As Exception
                BackgroundWorkerSpinner.CancelAsync()
                MetroProgressBar.Hide()
                PCNAME.Focus()
                MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                Exit Sub
            End Try
        End If

        Try
            objManagementClass = New ManagementClass("stdRegProv")
            objManagementClass.Scope = objManagementScope
            objManagementBaseObject = objManagementClass.GetMethodParameters("EnumKey")
            objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
            objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath)
            aSubKeys = CType(objManagementClass.InvokeMethod("EnumKey", objManagementBaseObject, Nothing).Properties.Item("sNames").Value, String())

            For Each strkey In aSubKeys
                myKey = strkey
                objManagementBaseObject = objManagementClass.GetMethodParameters("GetStringValue")
                objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath & strkey)
                objManagementBaseObject.SetPropertyValue("sValueName", "DisplayName")
                objManagementBaseObject = objManagementClass.InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                myValue = objManagementBaseObject("sValue")

                objManagementBaseObject = objManagementClass.GetMethodParameters("GetStringValue")
                objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath & strkey)
                objManagementBaseObject.SetPropertyValue("sValueName", "DisplayVersion")
                objManagementBaseObject = objManagementClass.InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                myValue1 = objManagementBaseObject("sValue")

                objManagementBaseObject = objManagementClass.GetMethodParameters("GetStringValue")
                objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath & strkey)
                objManagementBaseObject.SetPropertyValue("sValueName", "InstallDate")
                objManagementBaseObject = objManagementClass.InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                myValue2 = objManagementBaseObject("sValue")
                If myValue2 <> "" Then
                    Try
                        myValue2 = DateTime.ParseExact(myValue2, "yyyyMMdd", System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat)
                    Catch ex As Exception
                        'MessageBox.Show(ex.Message)
                    End Try
                End If

                If Not myValue = "" Then
                    If myValue.IndexOf(SearchProgramBox.Text, 0, StringComparison.CurrentCultureIgnoreCase) > -1 Then
                        'MessageBox.Show("Found it")
                        DataGridView1.Rows.Add(myValue, myValue1, myValue2, strkey)
                    End If
                End If
            Next
        Catch ex As Exception
            'MessageBox.Show(ex.Message)
        End Try
        Try
            objManagementClass = New ManagementClass("stdRegProv")
            objManagementClass.Scope = objManagementScope
            objManagementBaseObject = objManagementClass.GetMethodParameters("EnumKey")
            objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
            objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath2)
            aSubKeys = CType(objManagementClass.InvokeMethod("EnumKey", objManagementBaseObject, Nothing).Properties.Item("sNames").Value, String())

            For Each strkey In aSubKeys
                myKey = strkey
                objManagementBaseObject = objManagementClass.GetMethodParameters("GetStringValue")
                objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath2 & strkey)
                objManagementBaseObject.SetPropertyValue("sValueName", "DisplayName")
                objManagementBaseObject = objManagementClass.InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                myValue = objManagementBaseObject("sValue")

                objManagementBaseObject = objManagementClass.GetMethodParameters("GetStringValue")
                objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath2 & strkey)
                objManagementBaseObject.SetPropertyValue("sValueName", "DisplayVersion")
                objManagementBaseObject = objManagementClass.InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                myValue1 = objManagementBaseObject("sValue")

                objManagementBaseObject = objManagementClass.GetMethodParameters("GetStringValue")
                objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath2 & strkey)
                objManagementBaseObject.SetPropertyValue("sValueName", "InstallDate")
                objManagementBaseObject = objManagementClass.InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
                myValue2 = objManagementBaseObject("sValue")
                If myValue2 <> "" Then
                    Try
                        myValue2 = DateTime.ParseExact(myValue2, "yyyyMMdd", System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat)
                    Catch ex As Exception
                        'MessageBox.Show(ex.Message)
                    End Try
                End If
                If Not myValue = "" Then
                    If myValue.IndexOf(SearchProgramBox.Text, 0, StringComparison.CurrentCultureIgnoreCase) > -1 Then
                        'MessageBox.Show("Found it")
                        DataGridView1.Rows.Add(myValue, myValue1, myValue2, strkey)
                    End If
                End If
            Next
        Catch ex As Exception
            'MessageBox.Show(ex.Message)
        End Try

        Try
            DataGridView1.Sort(DataGridView1.Columns(0), System.ComponentModel.ListSortDirection.Ascending)
        Catch ex As Exception
        End Try

        Try
            objManagementScope = Nothing
            objManagementBaseObject.Dispose()
            objManagementClass.Dispose()
        Catch
        End Try

        PCNAME.Focus()

    End Sub

    Private Sub SearchProgramButton_Click(sender As Object, e As EventArgs) Handles SearchProgramButton.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        DataGridView1.Rows.Clear()

        MapDriveAdmin(username, password, domain, txtpcname)

        CreateSearchProgram()
        ProgramSearch(username, password, domain, txtpcname)

        Try
            File.Delete("\\" & txtpcname & "\c$\Program Files\RDT\RDT\pf.vbs")
        Catch ex As Exception
        End Try
        Try
            File.Delete("\\" & txtpcname & "\c$\Program Files\RDT\RDT\pf.txt")
        Catch ex As Exception
        End Try

        MapDriveAdminRemove(username, password, domain, txtpcname)

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
        PCNAME.Focus()
    End Sub

    Private Sub ProgramSearch(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)

        If MachineName = "" Then
            Exit Sub
        End If

        'MapDriveAdmin(username, password, domain, txtpcname)

        Dim fullPath As String = "\\" & txtpcname & "\c$\Program Files\RDT"
        Directory.CreateDirectory(fullPath)
        Dim fullPath2 As String = "\\" & txtpcname & "\c$\Program Files\RDT\RDT"
        Directory.CreateDirectory(fullPath2)

        Dim wmi_out As ManagementBaseObject
        Dim objManagementScope As ManagementScope
        Dim objManagementClass As ManagementClass = Nothing
        Dim objManagementBaseObject As ManagementBaseObject = Nothing
        Dim retValue As Integer

        Dim options As ConnectionOptions
        options = New ConnectionOptions()
        Dim computerconnect As String = "\\" & txtpcname & "\root\cimv2:Win32_Process"

        options.Username = username
        options.Password = password
        options.Timeout = TimeSpan.FromSeconds(30)
        options.Authority = "NTLMDOMAIN:" & domain
        options.Authentication = AuthenticationLevel.PacketPrivacy
        objManagementScope = New ManagementScope(computerconnect, options)

        If objManagementScope.IsConnected = True Then
        Else
            Try
                objManagementScope.Connect()
            Catch ex As Exception
                MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                PCNAME.Focus()
                Exit Sub
            End Try
        End If

        Try
            objManagementClass = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
            objManagementClass.Scope = objManagementScope
            objManagementBaseObject = objManagementClass.GetMethodParameters("Create")
            objManagementBaseObject.SetPropertyValue("CommandLine", "cmd /c cscript c:\progra~1\RDT\RDT\pf.vbs")
            wmi_out = objManagementClass.InvokeMethod("Create", objManagementBaseObject, Nothing)

            'wmi = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
            'wmi_in = wmi.GetMethodParameters("Create")
            'wmi_in("CommandLine") = "cmd /c md c:\temp\temptd"
            'wmi_out = wmi.InvokeMethod("Create", wmi_in, Nothing)

            retValue = Convert.ToInt32(wmi_out("returnValue"))
            Select Case retValue
                Case 0
                    ' success!
                    Thread.Sleep(3000)

                    For Each Line As String In File.ReadLines("\\" & txtpcname & "\c$\Program Files\RDT\RDT\pf.txt")
                        Dim aStr() As String = Split(Line, ",")

                        If aStr(2) <> "" Then
                            Try
                                aStr(2) = DateTime.ParseExact(aStr(2), "yyyyMMdd", System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat)
                            Catch ex As Exception
                                'MessageBox.Show(ex.Message)
                            End Try
                        End If

                        If Not aStr(0) = "" Then
                            Dim MyvalueCompare As Integer = 0
                            Dim MyvalueCompare2 As Integer = 0
                            MyvalueCompare = InStr(aStr(0), "Security Update", vbTextCompare)
                            MyvalueCompare2 = InStr(aStr(0), "Update for", vbTextCompare)
                            If MyvalueCompare = 0 Then
                                If MyvalueCompare2 = 0 Then
                                    DataGridView1.Rows.Add(aStr(0), aStr(1), aStr(2), aStr(3))
                                End If
                            End If
                        End If

                    Next

                Case 2
                    Throw New ApplicationException("Access denied")
                Case 3
                    Throw New ApplicationException("Insufficient privilege")
                Case 8
                    Throw New ApplicationException("Unknown failure")
                Case 9
                    Throw New ApplicationException("Path not found")
                Case 21
                    Throw New ApplicationException("Invalid parameter")
                Case Else
                    Throw New ApplicationException("Unknown return code " & retValue)
            End Select
        Catch ex As Exception
            'MsgBox(txtpcname & ": Can't create the process. " & ex.Message)
        End Try

        Dim commandtorun As String = "CMD.EXE /C RD /S /Q " & Chr(34) & "\\" & MachineName & "\c$\Progra~1\RDT" & Chr(34)
        Try
            Dim objShell = CreateObject("Wscript.Shell")
            objShell.run(commandtorun, 0, False)
        Catch ex As Exception
        End Try

        Try
            objManagementScope = Nothing
            objManagementBaseObject.Dispose()
            objManagementClass.Dispose()
        Catch
        End Try

        'Thread.Sleep(5000)

        'MapDriveAdminRemove(username, password, domain, txtpcname)

        PCNAME.Focus()
    End Sub

    Private Sub ShaddowUserSession_Click(sender As Object, e As EventArgs) Handles ShaddowUserSession.Click
        If MachineName = "" Then
            Exit Sub
        End If
        If userdomainComboBox.Text = "" Then
            Exit Sub
        End If

        Dim strUsername As String
        Dim strPassword As String
        strUsername = domain & "\" & username
        strPassword = password

        Dim oNet = CreateObject("WScript.Network")
        Try
            oNet.RemoveNetworkDrive("\\" & txtpcname & "\ipc$", True, False)
            oNet.RemoveNetworkDrive("\\" & txtpcname & "\admin$", True, False)
        Catch
        End Try
        oNet.MapNetworkDrive("", "\\" & txtpcname & "\ipc$", False, strUsername, strPassword)

        Try
            Dim clyde As String = userdomainComboBox.Text
            Dim SessionID As Char = clyde(clyde.Length - 1)

            Dim path As String
            path = "mstsc /v:" & txtpcname & " /prompt /control /shadow:" & SessionID

            Dim objShell = CreateObject("Wscript.Shell")
            objShell.run(path)
        Catch ex As Exception
        End Try
        Try
            ' dismount the previously mounted secure channel
            oNet.RemoveNetworkDrive("\\" & txtpcname & "\ipc$", True, False)
        Catch ex As Exception
        End Try

        PCNAME.Focus()
    End Sub

    Private Sub DotNetDetect_Click(sender As Object, e As EventArgs) Handles DotNetDetect.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        DataGridViewNet64.Rows.Clear()
        DataGridViewNet32.Rows.Clear()
        DataGridViewNetCore.Rows.Clear()

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        GETDOTNETCORE(username, password, domain, txtpcname)
        GETDOTNETVERSIONS64(username, password, domain, txtpcname)
        GETDOTNETVERSIONS32(username, password, domain, txtpcname)

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
        PCNAME.Focus()
    End Sub

    Private Sub GETDOTNETVERSIONS64(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)

        Const REG_SZ = 1
        Const REG_EXPAND_SZ = 2
        Const REG_BINARY = 3
        Const REG_DWORD = 4
        Const REG_MULTI_SZ = 7
        Const REG_QWORD = 11

        On Error Resume Next

        Dim intRegistryHive As Microsoft.Win32.RegistryHive
        intRegistryHive = Microsoft.Win32.RegistryHive.LocalMachine
        Dim objReg
        Dim objSWbemServices
        Dim objSWbemLocator
        objSWbemLocator = CreateObject("wbemScripting.SwbemLocator")

        objSWbemLocator.Security_.AuthenticationLevel = 6 'Packet Privacy. 

        objSWbemServices = objSWbemLocator.ConnectServer(txtpcname, "root\default", txtdomain & "\" & txtusername, txtpassword)
        objReg = objSWbemServices.Get("StdRegProv")

        Dim strKeyPath As String = Nothing
        Dim dotnetvalue As String = Nothing
        Dim VersionValue As String = Nothing
        Dim SPValue As String = Nothing
        Dim ReleaseValue As String = Nothing
        Dim InstalledValue As Integer = 0
        strKeyPath = "Software\Microsoft\.NETFramework\Policy\v1.0\3705"
        objReg.GetDWORDValue(intRegistryHive, strKeyPath, "Install", InstalledValue)
        If InstalledValue = 1 Then
            objReg.GetStringValue(intRegistryHive, strKeyPath, "Version", VersionValue)
            objReg.GetDWORDValue(intRegistryHive, strKeyPath, "SP", SPValue)
            objReg.GetDWORDValue(intRegistryHive, strKeyPath, "Release", ReleaseValue)
            DataGridViewNet64.Rows.Add("Dotnet Framework : 1.0 SP" & SPValue, VersionValue, SPValue, ReleaseValue)
        End If

        dotnetvalue = Nothing
        VersionValue = Nothing
        SPValue = Nothing
        ReleaseValue = Nothing
        InstalledValue = 0
        strKeyPath = "Software\Microsoft\NET Framework Setup\NDP\v1.1.4322"
        objReg.GetDWORDValue(intRegistryHive, strKeyPath, "Install", InstalledValue)
        If InstalledValue = 1 Then
            objReg.GetStringValue(intRegistryHive, strKeyPath, "Version", VersionValue)
            objReg.GetDWORDValue(intRegistryHive, strKeyPath, "SP", SPValue)
            objReg.GetDWORDValue(intRegistryHive, strKeyPath, "Release", ReleaseValue)
            DataGridViewNet64.Rows.Add("Dotnet Framework : 1.1 SP" & SPValue, VersionValue, SPValue, ReleaseValue)
        End If

        dotnetvalue = Nothing
        VersionValue = Nothing
        SPValue = Nothing
        ReleaseValue = Nothing
        InstalledValue = 0
        strKeyPath = "Software\Microsoft\NET Framework Setup\NDP\v2.0.50727"
        objReg.GetDWORDValue(intRegistryHive, strKeyPath, "Install", InstalledValue)
        If InstalledValue = 1 Then
            objReg.GetStringValue(intRegistryHive, strKeyPath, "Version", VersionValue)
            objReg.GetDWORDValue(intRegistryHive, strKeyPath, "SP", SPValue)
            objReg.GetDWORDValue(intRegistryHive, strKeyPath, "Release", ReleaseValue)
            DataGridViewNet64.Rows.Add("Dotnet Framework : 2.0 SP" & SPValue, VersionValue, SPValue, ReleaseValue)
        End If

        dotnetvalue = Nothing
        VersionValue = Nothing
        SPValue = Nothing
        ReleaseValue = Nothing
        InstalledValue = 0
        strKeyPath = "Software\Microsoft\NET Framework Setup\NDP\v3.0"
        objReg.GetDWORDValue(intRegistryHive, strKeyPath, "Install", InstalledValue)
        If InstalledValue = 1 Then
            objReg.GetStringValue(intRegistryHive, strKeyPath, "Version", VersionValue)
            objReg.GetDWORDValue(intRegistryHive, strKeyPath, "SP", SPValue)
            objReg.GetDWORDValue(intRegistryHive, strKeyPath, "Release", ReleaseValue)
            DataGridViewNet64.Rows.Add("Dotnet Framework : 3.0 SP" & SPValue, VersionValue, SPValue, ReleaseValue)
        End If

        dotnetvalue = Nothing
        VersionValue = Nothing
        SPValue = Nothing
        ReleaseValue = Nothing
        InstalledValue = 0
        strKeyPath = "Software\Microsoft\NET Framework Setup\NDP\v3.5"
        objReg.GetDWORDValue(intRegistryHive, strKeyPath, "Install", InstalledValue)
        If InstalledValue = 1 Then
            objReg.GetStringValue(intRegistryHive, strKeyPath, "Version", VersionValue)
            objReg.GetDWORDValue(intRegistryHive, strKeyPath, "SP", SPValue)
            objReg.GetDWORDValue(intRegistryHive, strKeyPath, "Release", ReleaseValue)
            DataGridViewNet64.Rows.Add("Dotnet Framework : 3.5 SP" & SPValue, VersionValue, SPValue, ReleaseValue)
        End If

        dotnetvalue = Nothing
        VersionValue = Nothing
        SPValue = Nothing
        ReleaseValue = Nothing
        InstalledValue = 0
        strKeyPath = "SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full"
        objReg.GetDWORDValue(intRegistryHive, strKeyPath, "Install", InstalledValue)
        If InstalledValue = 1 Then
            objReg.GetStringValue(intRegistryHive, strKeyPath, "Version", VersionValue)
            objReg.GetDWORDValue(intRegistryHive, strKeyPath, "Servicing", SPValue)
            objReg.GetDWORDValue(intRegistryHive, strKeyPath, "Release", ReleaseValue)
            dotnetvalue = CheckFor45PlusVersion(ReleaseValue)
            DataGridViewNet64.Rows.Add("Dotnet Framework : " & dotnetvalue, VersionValue, SPValue, ReleaseValue)
        End If


    End Sub

    Private Sub GETDOTNETVERSIONS32(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)

        Const REG_SZ = 1
        Const REG_EXPAND_SZ = 2
        Const REG_BINARY = 3
        Const REG_DWORD = 4
        Const REG_MULTI_SZ = 7
        Const REG_QWORD = 11

        On Error Resume Next

        Dim intRegistryHive As Microsoft.Win32.RegistryHive
        intRegistryHive = Microsoft.Win32.RegistryHive.LocalMachine
        Dim objReg
        Dim objSWbemServices
        Dim objSWbemLocator
        objSWbemLocator = CreateObject("wbemScripting.SwbemLocator")

        objSWbemLocator.Security_.AuthenticationLevel = 6 'Packet Privacy. 

        objSWbemServices = objSWbemLocator.ConnectServer(txtpcname, "root\default", txtdomain & "\" & txtusername, txtpassword)
        objReg = objSWbemServices.Get("StdRegProv")

        Dim strKeyPath As String = Nothing
        Dim dotnetvalue As String = Nothing
        Dim VersionValue As String = Nothing
        Dim SPValue As String = Nothing
        Dim ReleaseValue As String = Nothing
        Dim InstalledValue As Integer = 0
        strKeyPath = "SOFTWARE\WOW6432Node\Microsoft\.NETFramework\Policy\v1.0\3705"
        objReg.GetDWORDValue(intRegistryHive, strKeyPath, "Install", InstalledValue)
        If InstalledValue = 1 Then
            objReg.GetStringValue(intRegistryHive, strKeyPath, "Version", VersionValue)
            objReg.GetDWORDValue(intRegistryHive, strKeyPath, "SP", SPValue)
            objReg.GetDWORDValue(intRegistryHive, strKeyPath, "Release", ReleaseValue)
            DataGridViewNet32.Rows.Add("Dotnet Framework : 1.0 SP" & SPValue, VersionValue, SPValue, ReleaseValue)
        End If

        dotnetvalue = Nothing
        VersionValue = Nothing
        SPValue = Nothing
        ReleaseValue = Nothing
        InstalledValue = 0
        strKeyPath = "SOFTWARE\WOW6432Node\Microsoft\NET Framework Setup\NDP\v1.1.4322"
        objReg.GetDWORDValue(intRegistryHive, strKeyPath, "Install", InstalledValue)
        If InstalledValue = 1 Then
            objReg.GetStringValue(intRegistryHive, strKeyPath, "Version", VersionValue)
            objReg.GetDWORDValue(intRegistryHive, strKeyPath, "SP", SPValue)
            objReg.GetDWORDValue(intRegistryHive, strKeyPath, "Release", ReleaseValue)
            DataGridViewNet32.Rows.Add("Dotnet Framework : 1.1 SP" & SPValue, VersionValue, SPValue, ReleaseValue)
        End If

        dotnetvalue = Nothing
        VersionValue = Nothing
        SPValue = Nothing
        ReleaseValue = Nothing
        InstalledValue = 0
        strKeyPath = "SOFTWARE\WOW6432Node\Microsoft\NET Framework Setup\NDP\v2.0.50727"
        objReg.GetDWORDValue(intRegistryHive, strKeyPath, "Install", InstalledValue)
        If InstalledValue = 1 Then
            objReg.GetStringValue(intRegistryHive, strKeyPath, "Version", VersionValue)
            objReg.GetDWORDValue(intRegistryHive, strKeyPath, "SP", SPValue)
            objReg.GetDWORDValue(intRegistryHive, strKeyPath, "Release", ReleaseValue)
            DataGridViewNet32.Rows.Add("Dotnet Framework : 2.0 SP" & SPValue, VersionValue, SPValue, ReleaseValue)
        End If

        dotnetvalue = Nothing
        VersionValue = Nothing
        SPValue = Nothing
        ReleaseValue = Nothing
        InstalledValue = 0
        strKeyPath = "SOFTWARE\WOW6432Node\Microsoft\NET Framework Setup\NDP\v3.0"
        objReg.GetDWORDValue(intRegistryHive, strKeyPath, "Install", InstalledValue)
        If InstalledValue = 1 Then
            objReg.GetStringValue(intRegistryHive, strKeyPath, "Version", VersionValue)
            objReg.GetDWORDValue(intRegistryHive, strKeyPath, "SP", SPValue)
            objReg.GetDWORDValue(intRegistryHive, strKeyPath, "Release", ReleaseValue)
            DataGridViewNet32.Rows.Add("Dotnet Framework : 3.0 SP" & SPValue, VersionValue, SPValue, ReleaseValue)
        End If

        dotnetvalue = Nothing
        VersionValue = Nothing
        SPValue = Nothing
        ReleaseValue = Nothing
        InstalledValue = 0
        strKeyPath = "SOFTWARE\WOW6432Node\Microsoft\NET Framework Setup\NDP\v3.5"
        objReg.GetDWORDValue(intRegistryHive, strKeyPath, "Install", InstalledValue)
        If InstalledValue = 1 Then
            objReg.GetStringValue(intRegistryHive, strKeyPath, "Version", VersionValue)
            objReg.GetDWORDValue(intRegistryHive, strKeyPath, "SP", SPValue)
            objReg.GetDWORDValue(intRegistryHive, strKeyPath, "Release", ReleaseValue)
            DataGridViewNet32.Rows.Add("Dotnet Framework : 3.5 SP" & SPValue, VersionValue, SPValue, ReleaseValue)
        End If

        dotnetvalue = Nothing
        VersionValue = Nothing
        SPValue = Nothing
        ReleaseValue = Nothing
        InstalledValue = 0
        strKeyPath = "SOFTWARE\WOW6432Node\Microsoft\NET Framework Setup\NDP\v4\Full"
        objReg.GetDWORDValue(intRegistryHive, strKeyPath, "Install", InstalledValue)
        If InstalledValue = 1 Then
            objReg.GetStringValue(intRegistryHive, strKeyPath, "Version", VersionValue)
            objReg.GetDWORDValue(intRegistryHive, strKeyPath, "Servicing", SPValue)
            objReg.GetDWORDValue(intRegistryHive, strKeyPath, "Release", ReleaseValue)
            dotnetvalue = CheckFor45PlusVersion(ReleaseValue)
            DataGridViewNet32.Rows.Add("Dotnet Framework : " & dotnetvalue, VersionValue, SPValue, ReleaseValue)
        End If


    End Sub

    Private Sub GETDOTNETCORE(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)

        Const REG_SZ = 1
        Const REG_EXPAND_SZ = 2
        Const REG_BINARY = 3
        Const REG_DWORD = 4
        Const REG_MULTI_SZ = 7
        Const REG_QWORD = 11

        On Error Resume Next

        Dim intRegistryHive As Microsoft.Win32.RegistryHive
        intRegistryHive = Microsoft.Win32.RegistryHive.LocalMachine
        Dim objReg
        Dim objSWbemServices
        Dim objSWbemLocator
        objSWbemLocator = CreateObject("wbemScripting.SwbemLocator")

        objSWbemLocator.Security_.AuthenticationLevel = 6 'Packet Privacy. 

        objSWbemServices = objSWbemLocator.ConnectServer(txtpcname, "root\default", txtdomain & "\" & txtusername, txtpassword)
        objReg = objSWbemServices.Get("StdRegProv")

        Dim strKeyPath As String = Nothing
        Dim arrValueNames = Nothing
        Dim arrValueTypes = Nothing
        Dim i As Integer = Nothing
        Dim strValueName = Nothing
        Dim arrValues = Nothing

        objReg.EnumValues(intRegistryHive, "SOFTWARE\WOW6432Node\dotnet\Setup\InstalledVersions\x64\sharedfx\Microsoft.NETCore.App", arrValueNames, arrValueTypes)
        For i = 0 To UBound(arrValueNames)
            strValueName = Nothing
            arrValues = Nothing

            strValueName = arrValueNames(i)

            Select Case arrValueTypes(i)
                Case REG_DWORD
                    DataGridViewNetCore.Rows.Add("x64", strValueName)
            End Select
        Next

        arrValueNames = Nothing
        arrValueTypes = Nothing
        i = Nothing

        objReg.EnumValues(intRegistryHive, "SOFTWARE\WOW6432Node\dotnet\Setup\InstalledVersions\x86\sharedfx\Microsoft.NETCore.App", arrValueNames, arrValueTypes)
        For i = 0 To UBound(arrValueNames)
            strValueName = Nothing
            arrValues = Nothing

            strValueName = arrValueNames(i)

            Select Case arrValueTypes(i)
                Case REG_DWORD
                    DataGridViewNetCore.Rows.Add("x86", strValueName)
            End Select
        Next

        'Dim VersionValue As String = Nothing
        'strKeyPath = "SOFTWARE\dotnet\Setup\InstalledVersions\x64\sharedhost"
        'objReg.GetStringValue(intRegistryHive, strKeyPath, "Version", VersionValue)
        'DataGridViewNetCore.Rows.Add("SOFTWARE\dotnet\Setup\InstalledVersions\x64\sharedhost", VersionValue)

        'VersionValue = Nothing
        'strKeyPath = "SOFTWARE\WOW6432Node\dotnet\Setup\InstalledVersions\x86\hostfxr"
        'objReg.GetStringValue(intRegistryHive, strKeyPath, "Version", VersionValue)
        'DataGridViewNetCore.Rows.Add("SOFTWARE\WOW6432Node\dotnet\Setup\InstalledVersions\x86\hostfxr", VersionValue)

        'VersionValue = Nothing
        'strKeyPath = "SOFTWARE\WOW6432Node\dotnet\Setup\InstalledVersions\x64\hostfxr"
        'objReg.GetStringValue(intRegistryHive, strKeyPath, "Version", VersionValue)
        'DataGridViewNetCore.Rows.Add("SOFTWARE\WOW6432Node\dotnet\Setup\InstalledVersions\x64\hostfxr", VersionValue)

    End Sub


    ' Checking the version using >= enables forward compatibility.
    Private Function CheckFor45PlusVersion(releaseKey As Integer) As String
        If releaseKey >= 533320 Then
            Return "4.8.1"
        ElseIf releaseKey >= 528040 Then
            Return "4.8"
        ElseIf releaseKey >= 461808 Then
            Return "4.7.2"
        ElseIf releaseKey >= 461308 Then
            Return "4.7.1"
        ElseIf releaseKey >= 460798 Then
            Return "4.7"
        ElseIf releaseKey >= 394802 Then
            Return "4.6.2"
        ElseIf releaseKey >= 394254 Then
            Return "4.6.1"
        ElseIf releaseKey >= 393295 Then
            Return "4.6"
        ElseIf releaseKey >= 379893 Then
            Return "4.5.2"
        ElseIf releaseKey >= 378675 Then
            Return "4.5.1"
        ElseIf releaseKey >= 378389 Then
            Return "4.5"
        End If
        ' This code should never execute. A non-null release key should mean
        ' that 4.5 or later is installed.
        Return "No 4.5 or later version detected"
    End Function

    Private Sub ExportDOTNETlist_Click(sender As Object, e As EventArgs) Handles ExportDOTNETlist.Click
        Try
            Using outputFile As New IO.StreamWriter("c:\windows\temp\export.csv")
                outputFile.WriteLine(MachineName)
                outputFile.WriteLine(txtpcname)
                outputFile.WriteLine(" ")
                Try
                    Dim array As String() = New String(DataGridViewNetCore.Columns.Count - 1) {}
                    'get column header text from all columns:
                    For j As Integer = 0 To DataGridViewNetCore.Columns.Count - 1
                        array(j) = DataGridViewNetCore.Columns(j).HeaderText
                    Next
                    outputFile.WriteLine([String].Join(",", array))
                Catch ex As Exception
                End Try
                For Each row As DataGridViewRow In DataGridViewNetCore.Rows
                    If Not row.IsNewRow Then
                        Dim line As String = String.Empty
                        For x As Integer = 0 To row.Cells.Count - 1
                            line &= row.Cells(x).Value & ","
                        Next
                        outputFile.WriteLine(line.Remove(line.Length - 1, 1))
                    End If
                Next
                outputFile.WriteLine(" ")
                Try
                    Dim array As String() = New String(DataGridViewNet64.Columns.Count - 1) {}
                    'get column header text from all columns:
                    For j As Integer = 0 To DataGridViewNet64.Columns.Count - 1
                        array(j) = DataGridViewNet64.Columns(j).HeaderText
                    Next
                    outputFile.WriteLine([String].Join(",", array))
                Catch ex As Exception
                End Try
                For Each row As DataGridViewRow In DataGridViewNet64.Rows
                    If Not row.IsNewRow Then
                        Dim line As String = String.Empty
                        For x As Integer = 0 To row.Cells.Count - 1
                            line &= row.Cells(x).Value & ","
                        Next
                        outputFile.WriteLine(line.Remove(line.Length - 1, 1))
                    End If
                Next
                outputFile.WriteLine(" ")
                Try
                    Dim array As String() = New String(DataGridViewNet32.Columns.Count - 1) {}
                    'get column header text from all columns:
                    For j As Integer = 0 To DataGridViewNet32.Columns.Count - 1
                        array(j) = DataGridViewNet32.Columns(j).HeaderText
                    Next
                    outputFile.WriteLine([String].Join(",", array))
                Catch ex As Exception
                End Try
                For Each row As DataGridViewRow In DataGridViewNet32.Rows
                    If Not row.IsNewRow Then
                        Dim line As String = String.Empty
                        For x As Integer = 0 To row.Cells.Count - 1
                            line &= row.Cells(x).Value & ","
                        Next
                        outputFile.WriteLine(line.Remove(line.Length - 1, 1))
                    End If
                Next
                outputFile.Flush()
            End Using
        Catch ex As Exception
        End Try
        Try
            Dim objShell = CreateObject("Wscript.Shell")
            objShell.run("c:\windows\temp\export.csv")
        Catch ex As Exception
        End Try
    End Sub

    Private Sub ToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem1.Click
        If Host.Text = "" Then Exit Sub
        Clipboard.Clear()
        Clipboard.SetText(Host.Text)
    End Sub

    Private Sub ToolStripMenuItem2_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem2.Click
        If Alive.Text = "" Then Exit Sub
        Clipboard.Clear()
        Clipboard.SetText(Alive.Text)
    End Sub

    Private Sub CopyNameToClipBoardToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CopyNameToClipBoardToolStripMenuItem.Click

        Try
            If TreeView.SelectedNode.Checked = True Then Exit Sub
            Clipboard.Clear()
            Clipboard.SetText(TreeView.SelectedNode.Text)
        Catch ex As Exception
        End Try

    End Sub

    Private Sub FileVersionFinder_Click(sender As Object, e As EventArgs) Handles FileVersionFinder.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        FileVersionFinderRoutine(username, password, domain, txtpcname)

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
        PCNAME.Focus()

    End Sub

    Private Sub FileVersionFinderRoutine(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)

        Dim strComputerName As String = txtpcname
        Dim strStringValue As String = ""
        Dim strKeyPath As String = ""
        strKeyPath = InputBox("Enter a valid filepath please", "FilePath")
        Dim objManagementScope As ManagementScope = Nothing
        Dim objManagementClass As ManagementClass = Nothing
        Dim objManagementBaseObject As ManagementBaseObject = Nothing
        Dim strkey As String = Nothing
        Dim myKey As String = Nothing
        Dim myValue As String = Nothing
        Dim myValue1 As String = Nothing
        Dim myValueMSI As String = Nothing
        Dim myVersionValue As String = Nothing
        Dim fileName As String = Nothing
        Dim dtCreationDate As DateTime = Nothing
        Dim dtFileVersion As FileVersionInfo = Nothing
        Dim intRegistryHive As Microsoft.Win32.RegistryHive
        Dim fvAsString As String = Nothing
        intRegistryHive = Microsoft.Win32.RegistryHive.LocalMachine

        'DataGridView6.Rows.Clear()

        'Dim options As ConnectionOptions
        'options = New ConnectionOptions()
        'Dim computerconnect As String = "\\" & txtpcname & "\root\DEFAULT"

        'options.Username = txtusername
        'options.Password = txtpassword
        'options.Timeout = TimeSpan.FromSeconds(30)
        'options.Authority = "NTLMDOMAIN:" & txtdomain
        'options.Authentication = AuthenticationLevel.PacketPrivacy
        'objManagementScope = New ManagementScope(computerconnect, options)

        'If objManagementScope.IsConnected = True Then
        'Else
        'Try
        'objManagementScope.Connect()
        'Catch ex As Exception
        'MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
        'Exit Sub
        'End Try
        'End If
        Try

            Try

                strKeyPath = strKeyPath.ToUpper

                myValueMSI = strKeyPath.Replace("C:", "C$")

                fileName = "\\" & txtpcname & "\" & myValueMSI

                'MsgBox(fileName)

                If Dir(fileName) <> "" Then

                    Try
                        dtFileVersion = FileVersionInfo.GetVersionInfo(fileName)
                    Catch ex As Exception
                        MessageBox.Show(ex.Message)
                    End Try

                    Try
                        fvAsString = dtFileVersion.FileVersion
                    Catch ex As Exception
                        'MessageBox.Show(ex.Message)
                    End Try

                    Try
                        MsgBox(fvAsString)
                    Catch ex As Exception
                        'MessageBox.Show(ex.Message)
                    End Try

                End If

            Catch ex As Exception
                'MessageBox.Show(ex.Message)
            End Try


        Catch ex As Exception
            'MessageBox.Show(ex.Message)
        End Try


        'objManagementBaseObject.Dispose()
        'objManagementClass.Dispose()

    End Sub

    Private Sub MBSA_Run_Click(sender As Object, e As EventArgs) Handles MBSA_Run.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Dim powersetup As Boolean = False
        powersetup = SETUPPowerShellonRemote()
        If powersetup = False Then
            MsgBox("Unable to configure Powershell for connection on computer : " & txtpcname)
            BackgroundWorkerSpinner.CancelAsync()
            MetroProgressBar.Hide()
            Exit Sub
        End If

        Dim Commandtorun As String = "Expand-Archive -Path c:\progra~1\RDT\MBSA\Scan-UpdatesOffline.zip -DestinationPath C:\progra~1\RDT\MBSA -force"
        Dim psresultRun As String = ""
        Dim Commandtorun2 As String = "Set-ExecutionPolicy RemoteSigned -Force"
        Dim psresultRun2 As String = ""
        Dim Commandtorun3 As String = "C:\Progra~1\RDT\MBSA\Scan-UpdatesOffline\Scan-UpdatesOffline.ps1 | Out-File C:\Progra~1\RDT\MBSA\MBSA-Results.txt"
        Dim psresultRun3 As String = ""
        Dim Commandtorun4 As String = "Set-ExecutionPolicy Restricted -Force"
        Dim psresultRun4 As String = ""
        Dim Commandtorun5 As String = "Remove-Item -Path C:\Progra~1\RDT\MBSA\Scan-UpdatesOffline.zip -Force"
        Dim psresultRun5 As String = ""


        Dim response As MsgBoxResult
        response = MsgBox("Are you sure you want to Run a MBSA Scan on : " & MachineName & " : ?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "Confirm")
        If response = MsgBoxResult.Yes Then

            MBSAlistBox.Items.Clear()

            MapDriveAdmin(username, password, domain, txtpcname)
            Try
                Dim fullPath As String = "\\" & txtpcname & "\c$\Program Files\RDT"
                Directory.CreateDirectory(fullPath)
                Dim fullPath2 As String = "\\" & txtpcname & "\c$\Program Files\RDT\MBSA"
                Directory.CreateDirectory(fullPath2)

                Dim UserAccount As String = domain & "\" & username
                Dim FolderInfo As IO.DirectoryInfo = New IO.DirectoryInfo(fullPath2)
                Dim FolderAcl As New System.Security.AccessControl.DirectorySecurity
                FolderAcl = FolderInfo.GetAccessControl()
                FolderAcl.AddAccessRule(New System.Security.AccessControl.FileSystemAccessRule(UserAccount, FileSystemRights.FullControl, InheritanceFlags.ContainerInherit Or InheritanceFlags.ObjectInherit, PropagationFlags.None, AccessControlType.Allow))
                FolderInfo.SetAccessControl(FolderAcl)
            Catch ex As Exception
            End Try
            Try
                Dim securepass As New Security.SecureString
                Dim c As Char
                For Each c In password
                    securepass.AppendChar(c)
                Next
                Dim jumper As Process = Process.Start(New ProcessStartInfo() With {.UseShellExecute = False, .FileName = "CMD.exe", .UserName = username, .Password = securepass, .Domain = domain, .Arguments = "/C ROBOCOPY " & Chr(34) & MBSATextBox.Text & Chr(34) & " " & Chr(34) & "\\" & MachineName & "\c$\Progra~1\RDT\MBSA" & Chr(34) & " /S /E /Z", .WorkingDirectory = "C:\Windows\System32", .WindowStyle = ProcessWindowStyle.Hidden})
                jumper.WaitForExit()
            Catch ex As Exception
            End Try
            MapDriveAdminRemove(username, password, domain, txtpcname)
            Try
                psresultRun = RunPSCommand(MachineName, username, password, Commandtorun)
            Catch ex As Exception
            End Try
            Try
                psresultRun2 = RunPSCommand(MachineName, username, password, Commandtorun2)
            Catch ex As Exception
            End Try
            Try
                psresultRun3 = RunPSCommand(MachineName, username, password, Commandtorun3)
            Catch ex As Exception
            End Try
            Try
                psresultRun4 = RunPSCommand(MachineName, username, password, Commandtorun4)
            Catch ex As Exception
            End Try
            Try
                psresultRun5 = RunPSCommand(MachineName, username, password, Commandtorun5)
            Catch ex As Exception
            End Try

            BackgroundWorkerSpinner.CancelAsync()
            MetroProgressBar.Hide()

            Dim sr As New IO.StreamReader("\\" & txtpcname & "\c$\Program Files\RDT\MBSA\MBSA-Results.txt")
            MBSAlistBox.Items.AddRange(Strings.Split(sr.ReadToEnd(), Constants.vbCrLf))
            sr.Close()

            Thread.Sleep(2000) ' 2000 milliseconds = 2 seconds

            Commandtorun = "CMD.EXE /C RD /S /Q " & Chr(34) & "\\" & MachineName & "\c$\Progra~1\RDT" & Chr(34)
            Dim psresult As String = Nothing
            Try
                psresult = RunPSCommand(MachineName, username, password, Commandtorun)
            Catch ex As Exception
            End Try

        ElseIf response = MsgBoxResult.No Then
            BackgroundWorkerSpinner.CancelAsync()
            MetroProgressBar.Hide()
            Exit Sub
        End If
    End Sub

    Private Sub MBSAlistBox_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles MBSAlistBox.KeyDown

        If e.Control AndAlso e.KeyCode = Keys.C Then
            Dim copy_buffer As New System.Text.StringBuilder
            For Each item As Object In MBSAlistBox.SelectedItems
                copy_buffer.AppendLine(item.ToString)
            Next
            If copy_buffer.Length > 0 Then
                Clipboard.SetText(copy_buffer.ToString)
            End If
        End If
    End Sub

    Private Sub MetroLinkWSUSSCN2AB_Click(sender As Object, e As EventArgs) Handles MetroLinkWSUSSCN2AB.Click
        Process.Start("C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe", "https://catalog.s.download.windowsupdate.com/microsoftupdate/v6/wsusscan/wsusscn2.cab")  'Place a URL in text property or just a URL
    End Sub

    Private Sub REMCOMPackageFromDOMAIN_Click(sender As Object, e As EventArgs) Handles REMCOMPackageFromDOMAIN.Click

        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If
        If SDBOXFolder.Text = "" Then
            Exit Sub
        End If
        If SDListDirectory.Text = "" Then
            Exit Sub
        End If
        If REMCOMPackageText.Text = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Dim powersetup As Boolean = False
        powersetup = SETUPPowerShellonRemote()
        If powersetup = False Then
            MsgBox("Unable to configure Powershell for connection on computer : " & txtpcname)
            BackgroundWorkerSpinner.CancelAsync()
            MetroProgressBar.Hide()
            Exit Sub
        End If

        Dim Commandtorun As String = ""
        Dim psresultRun As String = ""

        Dim response As MsgBoxResult
        response = MsgBox("Are you sure you want to Run : " & SDBOXFolder.Text & " : " & REMCOMPackageText.Text & " : ?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "Confirm")
        If response = MsgBoxResult.Yes Then

            DomainRobocopy()

            Try
                psresultRun = RUNPOWERSHELL(username, password, domain, txtpcname)
            Catch ex As Exception
                MsgBox(ex)
            End Try

            Thread.Sleep(3000) ' 3000 milliseconds = 3 seconds

            Commandtorun = "CMD.EXE /C RD /S /Q " & Chr(34) & "\\" & MachineName & "\c$\Progra~1\RDT" & Chr(34)
            Dim psresult As String = Nothing
            Try
                psresult = RunPSCommand(MachineName, username, password, Commandtorun)
            Catch ex As Exception
            End Try

            BackgroundWorkerSpinner.CancelAsync()
            MetroProgressBar.Hide()

            If psresultRun <> "" Then
                MsgBox(psresultRun)
            End If

        ElseIf response = MsgBoxResult.No Then
            BackgroundWorkerSpinner.CancelAsync()
            MetroProgressBar.Hide()
            Exit Sub
        End If
    End Sub


    Private Function psresult() As String()
        Throw New NotImplementedException()
    End Function

    Private Sub SCCMPatchesMissing_Click(sender As Object, e As EventArgs) Handles SCCMPatchesMissing.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If
        ListMissingUpdatesSCCMDatagrid.Rows.Clear()

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        MissingUpdatesSCCM(username, password, domain, txtpcname)

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
        PCNAME.Focus()
    End Sub

    Private Sub MissingUpdatesSCCM(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)
        On Error Resume Next

        Dim objMgmt As ManagementObject
        Dim QueryOptions = New EnumerationOptions
        QueryOptions.Timeout = New TimeSpan(0, 0, 10)

        Dim options2 As ConnectionOptions
        options2 = New ConnectionOptions()
        Dim computerconnect2 As String = "\\" & txtpcname & "\root\ccm\SoftwareUpdates\UpdatesStore"
        options2.Username = username
        options2.Password = password
        options2.Timeout = TimeSpan.FromSeconds(30)
        options2.Authority = "NTLMDOMAIN:" & domain
        options2.Authentication = AuthenticationLevel.PacketPrivacy
        Dim msc As ManagementScope = New ManagementScope(computerconnect2, options2)

        If msc.IsConnected = True Then
        Else
            msc.Connect()
        End If

        If msc.IsConnected = False Then
            Exit Sub
        End If

        Dim query_command3 As String = "SELECT * FROM CCM_UpdateStatus"
        Dim select_query3 As SelectQuery = New SelectQuery(query_command3)
        Dim Srch3 As New ManagementObjectSearcher(msc, select_query3, QueryOptions)

        For Each objMgmt In Srch3.Get
            If objMgmt("status") = "Missing" Then
                ListMissingUpdatesSCCMDatagrid.Rows.Add(UCase(objMgmt("Title").ToString()))
            End If
        Next

        msc = Nothing

    End Sub

    Private Sub SCCMPatchesInstalled_Click(sender As Object, e As EventArgs) Handles SCCMPatchesInstalled.Click

        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If
        SCCMPatchesInstalledDataGridView.Rows.Clear()

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        InstalledUpdatesSCCM(username, password, domain, txtpcname)

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
        PCNAME.Focus()

    End Sub

    Private Sub InstalledUpdatesSCCM(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)
        On Error Resume Next

        Dim objMgmt As ManagementObject
        Dim QueryOptions = New EnumerationOptions
        QueryOptions.Timeout = New TimeSpan(0, 0, 10)

        Dim options2 As ConnectionOptions
        options2 = New ConnectionOptions()
        Dim computerconnect2 As String = "\\" & txtpcname & "\root\ccm\SoftwareUpdates\UpdatesStore"
        options2.Username = username
        options2.Password = password
        options2.Timeout = TimeSpan.FromSeconds(30)
        options2.Authority = "NTLMDOMAIN:" & domain
        options2.Authentication = AuthenticationLevel.PacketPrivacy
        Dim msc As ManagementScope = New ManagementScope(computerconnect2, options2)

        If msc.IsConnected = True Then
        Else
            msc.Connect()
        End If

        If msc.IsConnected = False Then
            Exit Sub
        End If

        Dim query_command3 As String = "SELECT * FROM CCM_UpdateStatus"
        Dim select_query3 As SelectQuery = New SelectQuery(query_command3)
        Dim Srch3 As New ManagementObjectSearcher(msc, select_query3, QueryOptions)

        For Each objMgmt In Srch3.Get
            If objMgmt("status") = "Installed" Then
                SCCMPatchesInstalledDataGridView.Rows.Add(UCase(objMgmt("Title").ToString()))
            End If
        Next

        msc = Nothing

    End Sub

    Private Sub RebootButton1_Click(sender As Object, e As EventArgs) Handles RebootButton1.Click

        Dim strRead1 = ""
        Dim strRead2 = ""
        Dim strRead3 = ""
        Dim strRead4 = ""
        Dim strRead5 = ""

        RebootRequiredCheck1.ForeColor = Color.Black
        RebootRequiredCheck1.Text = "False"
        RebootRequiredCheck2.ForeColor = Color.Black
        RebootRequiredCheck2.Text = "False"
        RebootRequiredCheck3.ForeColor = Color.Black
        RebootRequiredCheck3.Text = "False"
        RebootRequiredCheck4.ForeColor = Color.Black
        RebootRequiredCheck4.Text = "False"
        RebootRequiredCheck5.ForeColor = Color.Black
        RebootRequiredCheck5.Text = "False"

        Const HKEY_LOCAL_MACHINE = &H80000002
        Dim objReg
        Dim objSWbemServices
        Dim objSWbemLocator

        Try
            objSWbemLocator = CreateObject("wbemScripting.SwbemLocator")
            objSWbemLocator.Security_.AuthenticationLevel = 6 'Packet Privacy.
            objSWbemServices = objSWbemLocator.ConnectServer(txtpcname, "root\default", domain & "\" & username, password)
            objReg = objSWbemServices.Get("StdRegProv")
            strRead1 = objReg.GetStringValue(HKEY_LOCAL_MACHINE, "SYSTEM\CurrentControlSet\Control\Session Manager", "PendingFileRenameOperations")
        Catch
        End Try
        If strRead1 <> "1" Then
            RebootRequiredCheck1.ForeColor = Color.Red
            RebootRequiredCheck1.Text = "Reboot Needed"
        End If

        Try
            objSWbemLocator = CreateObject("wbemScripting.SwbemLocator")
            objSWbemLocator.Security_.AuthenticationLevel = 6 'Packet Privacy.
            objSWbemServices = objSWbemLocator.ConnectServer(txtpcname, "root\default", domain & "\" & username, password)
            objReg = objSWbemServices.Get("StdRegProv")
            strRead2 = objReg.GetStringValue(HKEY_LOCAL_MACHINE, "SYSTEM\CurrentControlSet\Control\Session Manager", "PendingFileRenameOperations2")
        Catch
        End Try
        If strRead2 <> "1" Then
            RebootRequiredCheck2.ForeColor = Color.Red
            RebootRequiredCheck2.Text = "Reboot Needed"
        End If

        Dim objMgmt As ManagementObject
        Dim QueryOptions = New EnumerationOptions
        QueryOptions.Timeout = New TimeSpan(0, 0, 10)

        Dim options2 As ConnectionOptions
        options2 = New ConnectionOptions()
        Dim computerconnect2 As String = "\\" & txtpcname & "\ROOT\ccm\ClientSDK"
        options2.Username = username
        options2.Password = password
        options2.Timeout = TimeSpan.FromSeconds(30)
        options2.Authority = "NTLMDOMAIN:" & domain
        options2.Authentication = AuthenticationLevel.PacketPrivacy
        Dim msc As ManagementScope = New ManagementScope(computerconnect2, options2)

        Try
            If msc.IsConnected = True Then
            Else
                msc.Connect()
            End If
        Catch
        End Try
        If msc.IsConnected = False Then
            Exit Sub
        End If
        Try
            Dim query_command3 As String = "SELECT DetermineifRebootPending FROM CCM_ClientUtilities"
            Dim select_query3 As SelectQuery = New SelectQuery(query_command3)
            Dim Srch3 As New ManagementObjectSearcher(msc, select_query3, QueryOptions)

            For Each objMgmt In Srch3.Get
                If objMgmt("RebootPending") <> "0" Then
                    RebootRequiredCheck3.ForeColor = Color.Red
                    RebootRequiredCheck3.Text = "Reboot Needed"
                End If
                If objMgmt("IsHardRebootPending") <> "0" Then
                    RebootRequiredCheck4.ForeColor = Color.Red
                    RebootRequiredCheck4.Text = "Reboot Needed"
                End If
            Next
            msc = Nothing
        Catch
        End Try

        Try
            objSWbemLocator = CreateObject("wbemScripting.SwbemLocator")
            objSWbemLocator.Security_.AuthenticationLevel = 6 'Packet Privacy.
            objSWbemServices = objSWbemLocator.ConnectServer(txtpcname, "root\default", domain & "\" & username, password)
            objReg = objSWbemServices.Get("StdRegProv")
            strRead5 = objReg.GetStringValue(HKEY_LOCAL_MACHINE, "Software\Microsoft\Updates", "UpdateExeVolatile")
        Catch
        End Try
        'MsgBox(strRead5)
        If strRead5 <> "2" Then
            RebootRequiredCheck5.ForeColor = Color.Red
            RebootRequiredCheck5.Text = "Reboot Needed"
        End If

    End Sub

    Private Sub SCCMcomplianceButton_Click(sender As Object, e As EventArgs) Handles SCCMcomplianceButton.Click
        SCCMcomplianceDataGridView1.Rows.Clear()
        SCCMcomplianceDataGridView2.Rows.Clear()

        On Error Resume Next

        Dim objMgmt As ManagementObject
        Dim QueryOptions = New EnumerationOptions
        QueryOptions.Timeout = New TimeSpan(0, 0, 10)

        Dim options2 As ConnectionOptions
        options2 = New ConnectionOptions()
        Dim computerconnect2 As String = "\\" & txtpcname & "\ROOT\ccm\Policy\Machine\ActualConfig"
        options2.Username = username
        options2.Password = password
        options2.Timeout = TimeSpan.FromSeconds(30)
        options2.Authority = "NTLMDOMAIN:" & domain
        options2.Authentication = AuthenticationLevel.PacketPrivacy
        Dim msc As ManagementScope = New ManagementScope(computerconnect2, options2)

        If msc.IsConnected = True Then
        Else
            msc.Connect()
        End If

        If msc.IsConnected = False Then
            Exit Sub
        End If

        Dim query_command3 As String = "SELECT * FROM CCM_UpdateCIAssignment"
        Dim select_query3 As SelectQuery = New SelectQuery(query_command3)
        Dim Srch3 As New ManagementObjectSearcher(msc, select_query3, QueryOptions)

        For Each objMgmt In Srch3.Get
            'If objMgmt("status") = "Installed" Then
            SCCMcomplianceDataGridView1.Rows.Add(UCase(objMgmt("AssignmentName").ToString()), UCase(objMgmt("AssignmentID").ToString()))
            'End If
        Next

        msc = Nothing



        Dim objMgmt5 As ManagementObject
        Dim QueryOptions5 = New EnumerationOptions
        QueryOptions5.Timeout = New TimeSpan(0, 0, 10)

        Dim options5 As ConnectionOptions
        options5 = New ConnectionOptions()
        Dim computerconnect5 As String = "\\" & txtpcname & "\ROOT\ccm\SoftwareUpdates\DeploymentAgent"
        options5.Username = username
        options5.Password = password
        options5.Timeout = TimeSpan.FromSeconds(30)
        options5.Authority = "NTLMDOMAIN:" & domain
        options5.Authentication = AuthenticationLevel.PacketPrivacy
        Dim msc5 As ManagementScope = New ManagementScope(computerconnect5, options5)

        If msc5.IsConnected = True Then
        Else
            msc5.Connect()
        End If

        If msc5.IsConnected = False Then
            Exit Sub
        End If

        Dim query_command5 As String = "SELECT * FROM CCM_AssignmentCompliance"
        Dim select_query5 As SelectQuery = New SelectQuery(query_command5)
        Dim Srch5 As New ManagementObjectSearcher(msc5, select_query5, QueryOptions5)

        For Each objMgmt In Srch5.Get
            'If objMgmt("IsCompliant") = "True" Then
            SCCMcomplianceDataGridView2.Rows.Add(UCase(objMgmt("AssignmentID").ToString()), UCase(objMgmt("IsCompliant").ToString()))
            'End If
        Next

        msc5 = Nothing

    End Sub

    Private Sub TAP001_Click(sender As Object, e As EventArgs) Handles TAP001.Click
        RUNTAP001(username, password, domain, txtpcname)
    End Sub

    Private Sub RUNTAP001(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)
        If MachineName = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Dim powersetup As Boolean = False
        powersetup = SETUPPowerShellonRemote()
        If powersetup = False Then
            MsgBox("Unable to configure Powershell for connection on computer : " & txtpcname)
            BackgroundWorkerSpinner.CancelAsync()
            MetroProgressBar.Hide()
            Exit Sub
        End If

        Dim Commandtorun As String = "Invoke-WmiMethod -Namespace root\ccm -Class sms_client -Name TriggerSchedule ""{00000000-0000-0000-0000-000000000001}"""
        Dim psresult As String = Nothing
        Try
            psresult = RunPSCommand(MachineName, username, password, Commandtorun)
        Catch ex As Exception
        End Try

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()

        MsgBox(psresult)
    End Sub

    Private Sub TAP002_Click(sender As Object, e As EventArgs) Handles TAP002.Click
        RUNTAP002(username, password, domain, txtpcname)
    End Sub

    Private Sub RUNTAP002(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)
        If MachineName = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Dim powersetup As Boolean = False
        powersetup = SETUPPowerShellonRemote()
        If powersetup = False Then
            MsgBox("Unable to configure Powershell for connection on computer : " & txtpcname)
            BackgroundWorkerSpinner.CancelAsync()
            MetroProgressBar.Hide()
            Exit Sub
        End If

        Dim Commandtorun As String = "Invoke-WmiMethod -Namespace root\ccm -Class sms_client -Name TriggerSchedule ""{00000000-0000-0000-0000-000000000002}"""
        Dim psresult As String = Nothing
        Try
            psresult = RunPSCommand(MachineName, username, password, Commandtorun)
        Catch ex As Exception
        End Try

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()

        MsgBox(psresult)
    End Sub

    Private Sub TAP003_Click(sender As Object, e As EventArgs) Handles TAP003.Click
        RUNTAP003(username, password, domain, txtpcname)
    End Sub

    Private Sub RUNTAP003(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)
        If MachineName = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Dim powersetup As Boolean = False
        powersetup = SETUPPowerShellonRemote()
        If powersetup = False Then
            MsgBox("Unable to configure Powershell for connection on computer : " & txtpcname)
            BackgroundWorkerSpinner.CancelAsync()
            MetroProgressBar.Hide()
            Exit Sub
        End If

        Dim Commandtorun As String = "Invoke-WmiMethod -Namespace root\ccm -Class sms_client -Name TriggerSchedule ""{00000000-0000-0000-0000-000000000003}"""
        Dim psresult As String = Nothing
        Try
            psresult = RunPSCommand(MachineName, username, password, Commandtorun)
        Catch ex As Exception
        End Try

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()

        MsgBox(psresult)
    End Sub

    Private Sub TAP021_Click(sender As Object, e As EventArgs) Handles TAP021.Click
        RUNTAP021(username, password, domain, txtpcname)
    End Sub

    Private Sub RUNTAP021(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)
        If MachineName = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Dim powersetup As Boolean = False
        powersetup = SETUPPowerShellonRemote()
        If powersetup = False Then
            MsgBox("Unable to configure Powershell for connection on computer : " & txtpcname)
            BackgroundWorkerSpinner.CancelAsync()
            MetroProgressBar.Hide()
            Exit Sub
        End If

        Dim Commandtorun As String = "Invoke-WmiMethod -Namespace root\ccm -Class sms_client -Name TriggerSchedule ""{00000000-0000-0000-0000-000000000021}"""
        Dim psresult As String = Nothing
        Try
            psresult = RunPSCommand(MachineName, username, password, Commandtorun)
        Catch ex As Exception
        End Try

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()

        MsgBox(psresult)
    End Sub

    Private Sub TAP108_Click(sender As Object, e As EventArgs) Handles TAP108.Click
        RUNTAP108(username, password, domain, txtpcname)
    End Sub

    Private Sub RUNTAP108(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)
        If MachineName = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Dim powersetup As Boolean = False
        powersetup = SETUPPowerShellonRemote()
        If powersetup = False Then
            MsgBox("Unable to configure Powershell for connection on computer : " & txtpcname)
            BackgroundWorkerSpinner.CancelAsync()
            MetroProgressBar.Hide()
            Exit Sub
        End If

        Dim Commandtorun As String = "Invoke-WmiMethod -Namespace root\ccm -Class sms_client -Name TriggerSchedule ""{00000000-0000-0000-0000-000000000108}"""
        Dim psresult As String = Nothing
        Try
            psresult = RunPSCommand(MachineName, username, password, Commandtorun)
        Catch ex As Exception
        End Try

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()

        MsgBox(psresult)
    End Sub

    Private Sub TAP113_Click(sender As Object, e As EventArgs) Handles TAP113.Click
        RUNTAP113(username, password, domain, txtpcname)
    End Sub

    Private Sub RUNTAP113(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)
        If MachineName = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Dim powersetup As Boolean = False
        powersetup = SETUPPowerShellonRemote()
        If powersetup = False Then
            MsgBox("Unable to configure Powershell for connection on computer : " & txtpcname)
            BackgroundWorkerSpinner.CancelAsync()
            MetroProgressBar.Hide()
            Exit Sub
        End If

        Dim Commandtorun As String = "Invoke-WmiMethod -Namespace root\ccm -Class sms_client -Name TriggerSchedule ""{00000000-0000-0000-0000-000000000113}"""
        Dim psresult As String = Nothing
        Try
            psresult = RunPSCommand(MachineName, username, password, Commandtorun)
        Catch ex As Exception
        End Try

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()

        MsgBox(psresult)
    End Sub

    Private Sub TAP010_Click(sender As Object, e As EventArgs) Handles TAP010.Click
        RUNTAP010(username, password, domain, txtpcname)
    End Sub

    Private Sub RUNTAP010(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)
        If MachineName = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Dim powersetup As Boolean = False
        powersetup = SETUPPowerShellonRemote()
        If powersetup = False Then
            MsgBox("Unable to configure Powershell for connection on computer : " & txtpcname)
            BackgroundWorkerSpinner.CancelAsync()
            MetroProgressBar.Hide()
            Exit Sub
        End If

        Dim Commandtorun As String = "Invoke-WmiMethod -Namespace root\ccm -Class sms_client -Name TriggerSchedule ""{00000000-0000-0000-0000-000000000010}"""
        Dim psresult As String = Nothing
        Try
            psresult = RunPSCommand(MachineName, username, password, Commandtorun)
        Catch ex As Exception
        End Try

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()

        MsgBox(psresult)
    End Sub

    Private Sub TAP032_Click(sender As Object, e As EventArgs) Handles TAP032.Click
        RUNTAP032(username, password, domain, txtpcname)
    End Sub

    Private Sub RUNTAP032(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)
        If MachineName = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Dim powersetup As Boolean = False
        powersetup = SETUPPowerShellonRemote()
        If powersetup = False Then
            MsgBox("Unable to configure Powershell for connection on computer : " & txtpcname)
            BackgroundWorkerSpinner.CancelAsync()
            MetroProgressBar.Hide()
            Exit Sub
        End If

        Dim Commandtorun As String = "Invoke-WmiMethod -Namespace root\ccm -Class sms_client -Name TriggerSchedule ""{00000000-0000-0000-0000-000000000032}"""
        Dim psresult As String = Nothing
        Try
            psresult = RunPSCommand(MachineName, username, password, Commandtorun)
        Catch ex As Exception
        End Try

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()

        MsgBox(psresult)
    End Sub

    Private Sub TAP031_Click(sender As Object, e As EventArgs) Handles TAP031.Click
        RUNTAP031(username, password, domain, txtpcname)
    End Sub

    Private Sub RUNTAP031(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)
        If MachineName = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Dim powersetup As Boolean = False
        powersetup = SETUPPowerShellonRemote()
        If powersetup = False Then
            MsgBox("Unable to configure Powershell for connection on computer : " & txtpcname)
            BackgroundWorkerSpinner.CancelAsync()
            MetroProgressBar.Hide()
            Exit Sub
        End If

        Dim Commandtorun As String = "Invoke-WmiMethod -Namespace root\ccm -Class sms_client -Name TriggerSchedule ""{00000000-0000-0000-0000-000000000031}"""
        Dim psresult As String = Nothing
        Try
            psresult = RunPSCommand(MachineName, username, password, Commandtorun)
        Catch ex As Exception
        End Try

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()

        MsgBox(psresult)
    End Sub

    Private Sub TAP061_Click(sender As Object, e As EventArgs) Handles TAP061.Click
        RUNTAP061(username, password, domain, txtpcname)
    End Sub

    Private Sub RUNTAP061(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)
        If MachineName = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Dim powersetup As Boolean = False
        powersetup = SETUPPowerShellonRemote()
        If powersetup = False Then
            MsgBox("Unable to configure Powershell for connection on computer : " & txtpcname)
            BackgroundWorkerSpinner.CancelAsync()
            MetroProgressBar.Hide()
            Exit Sub
        End If

        Dim Commandtorun As String = "Invoke-WmiMethod -Namespace root\ccm -Class sms_client -Name TriggerSchedule ""{00000000-0000-0000-0000-000000000061}"""
        Dim psresult As String = Nothing
        Try
            psresult = RunPSCommand(MachineName, username, password, Commandtorun)
        Catch ex As Exception
        End Try

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()

        MsgBox(psresult)
    End Sub

    Private Sub TAP051_Click(sender As Object, e As EventArgs) Handles TAP051.Click
        RUNTAP051(username, password, domain, txtpcname)
    End Sub

    Private Sub RUNTAP051(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)
        If MachineName = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Dim powersetup As Boolean = False
        powersetup = SETUPPowerShellonRemote()
        If powersetup = False Then
            MsgBox("Unable to configure Powershell for connection on computer : " & txtpcname)
            BackgroundWorkerSpinner.CancelAsync()
            MetroProgressBar.Hide()
            Exit Sub
        End If

        Dim Commandtorun As String = "Invoke-WmiMethod -Namespace root\ccm -Class sms_client -Name TriggerSchedule ""{00000000-0000-0000-0000-000000000051}"""
        Dim psresult As String = Nothing
        Try
            psresult = RunPSCommand(MachineName, username, password, Commandtorun)
        Catch ex As Exception
        End Try

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()

        MsgBox(psresult)
    End Sub

    Private Sub TAP026_Click(sender As Object, e As EventArgs) Handles TAP026.Click
        RUNTAP026(username, password, domain, txtpcname)
    End Sub

    Private Sub RUNTAP026(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)
        If MachineName = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Dim powersetup As Boolean = False
        powersetup = SETUPPowerShellonRemote()
        If powersetup = False Then
            MsgBox("Unable to configure Powershell for connection on computer : " & txtpcname)
            BackgroundWorkerSpinner.CancelAsync()
            MetroProgressBar.Hide()
            Exit Sub
        End If

        Dim Commandtorun As String = "Invoke-WmiMethod -Namespace root\ccm -Class sms_client -Name TriggerSchedule ""{00000000-0000-0000-0000-000000000026}"""
        Dim psresult As String = Nothing
        Try
            psresult = RunPSCommand(MachineName, username, password, Commandtorun)
        Catch ex As Exception
        End Try

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()

        MsgBox(psresult)
    End Sub

    Private Sub TAP121_Click(sender As Object, e As EventArgs) Handles TAP121.Click
        RUNTAP121(username, password, domain, txtpcname)
    End Sub

    Private Sub RUNTAP121(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)
        If MachineName = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Dim powersetup As Boolean = False
        powersetup = SETUPPowerShellonRemote()
        If powersetup = False Then
            MsgBox("Unable to configure Powershell for connection on computer : " & txtpcname)
            BackgroundWorkerSpinner.CancelAsync()
            MetroProgressBar.Hide()
            Exit Sub
        End If

        Dim Commandtorun As String = "Invoke-WmiMethod -Namespace root\ccm -Class sms_client -Name TriggerSchedule ""{00000000-0000-0000-0000-000000000121}"""
        Dim psresult As String = Nothing
        Try
            psresult = RunPSCommand(MachineName, username, password, Commandtorun)
        Catch ex As Exception
        End Try

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()

        MsgBox(psresult)
    End Sub

    Private Sub TAPREPAIRWMI_Click(sender As Object, e As EventArgs) Handles TAPREPAIRWMI.Click
        RUNREPAIRWMI(username, password, domain, txtpcname)
    End Sub

    Private Sub RUNREPAIRWMI(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)
        If MachineName = "" Then
            Exit Sub
        End If

        BackgroundWorkerSpinnerStopWorker()

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Dim powersetup As Boolean = False
        powersetup = SETUPPowerShellonRemote()
        If powersetup = False Then
            MsgBox("Unable to configure Powershell for connection on computer : " & txtpcname)
            BackgroundWorkerSpinner.CancelAsync()
            MetroProgressBar.Hide()
            Exit Sub
        End If

        Dim Commandtorun As String = "Get-Service -Name ""ccmexec"" | Stop-Service"
        Dim psresult As String = Nothing
        Try
            psresult = RunPSCommand(MachineName, username, password, Commandtorun)
        Catch ex As Exception
        End Try

        Thread.Sleep(3000)

        Dim Commandtorun2 As String = "Get-Service -Name ""winmgmt"" | Stop-Service"
        Dim psresult2 As String = Nothing
        Try
            psresult2 = RunPSCommand(MachineName, username, password, Commandtorun2)
        Catch ex As Exception
        End Try

        Thread.Sleep(3000)

        Dim Commandtorun3 As String = "Get-ChildItem -Path C:\Windows\System32\wbem\Repository -Recurse | Remove-Item -force -recurse"
        Dim psresult3 As String = Nothing
        Try
            psresult3 = RunPSCommand(MachineName, username, password, Commandtorun3)
        Catch ex As Exception
        End Try

        Thread.Sleep(3000)

        Dim Commandtorun4 As String = "Remove-Item C:\Windows\System32\wbem\Repository -Force"
        Dim psresult4 As String = Nothing
        Try
            psresult4 = RunPSCommand(MachineName, username, password, Commandtorun4)
        Catch ex As Exception
        End Try

        Thread.Sleep(3000)

        Dim Commandtorun5 As String = "Get-Service -Name ""winmgmt"" | Start-Service"
        Dim psresult5 As String = Nothing
        Try
            psresult5 = RunPSCommand(MachineName, username, password, Commandtorun5)
        Catch ex As Exception
        End Try

        Dim Commandtorun6 As String = "Get-Service -Name ""ccmexec"" | Start-Service"
        Dim psresult6 As String = Nothing
        Try
            psresult6 = RunPSCommand(MachineName, username, password, Commandtorun6)
        Catch ex As Exception
        End Try

        Thread.Sleep(3000)

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
    End Sub

    Private Sub TAPREPAIRSCCMCLIENT_Click(sender As Object, e As EventArgs) Handles TAPREPAIRSCCMCLIENT.Click
        runtaprepairsccmclient(username, password, domain, txtpcname)
    End Sub

    Private Sub runtaprepairsccmclient(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)
        If MachineName = "" Then
            Exit Sub
        End If

        BackgroundWorkerSpinnerStopWorker()

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Dim powersetup As Boolean = False
        powersetup = SETUPPowerShellonRemote()
        If powersetup = False Then
            MsgBox("Unable to configure Powershell for connection on computer : " & txtpcname)
            BackgroundWorkerSpinner.CancelAsync()
            MetroProgressBar.Hide()
            Exit Sub
        End If

        Dim Commandtorun As String = "C:\windows\ccm\ccmrepair.exe"
        Dim psresult As String = Nothing
        Try
            psresult = RunPSCommand(MachineName, username, password, Commandtorun)
        Catch ex As Exception
        End Try

        MsgBox(psresult)

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
    End Sub

    Private Sub GLRT021_Click(sender As Object, e As EventArgs) Handles GLRT021.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If
        Label021.Text = "00:00:00"

        Dim LastHWDate As DateTime

        Dim objManagementScope As ManagementScope
        Dim options As ConnectionOptions
        options = New ConnectionOptions()
        Dim computerconnect As String = "\\" & txtpcname & "\root\ccm\invagt"

        options.Username = username
        options.Password = password
        options.Timeout = TimeSpan.FromSeconds(30)
        options.Authority = "NTLMDOMAIN:" & domain
        options.Authentication = AuthenticationLevel.PacketPrivacy
        objManagementScope = New ManagementScope(computerconnect, options)

        If objManagementScope.IsConnected = True Then
        Else
            Try
                objManagementScope.Connect()
            Catch ex As Exception
                MessageBox.Show("Couldn't connect: " + ex.Message, "Error , Please check pc online and SCCM Agent is installed!")
                PCNAME.Focus()
                Exit Sub
            End Try
        End If
        Try
            Dim query As New SelectQuery("Select * From InventoryActionStatus where InventoryActionID = '{00000000-0000-0000-0000-000000000021}'")
            Dim searcher As New ManagementObjectSearcher(objManagementScope, query)
            For Each mo As ManagementObject In searcher.[Get]()
                LastHWDate = System.Management.ManagementDateTimeConverter.ToDateTime(mo("LastCycleStartedDate").ToString)
                Label021.Text = LastHWDate
            Next
        Catch ex As Exception
            MessageBox.Show("Unable to connect to SCCM Agent, Please check AGent is Installed!")
        End Try

        objManagementScope = Nothing
    End Sub

    Private Sub GLRT108_Click(sender As Object, e As EventArgs) Handles GLRT108.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If
        Label108.Text = "00:00:00"

        Dim LastHWDate As DateTime

        Dim objManagementScope As ManagementScope
        Dim options As ConnectionOptions
        options = New ConnectionOptions()
        Dim computerconnect As String = "\\" & txtpcname & "\root\ccm\invagt"

        options.Username = username
        options.Password = password
        options.Timeout = TimeSpan.FromSeconds(30)
        options.Authority = "NTLMDOMAIN:" & domain
        options.Authentication = AuthenticationLevel.PacketPrivacy
        objManagementScope = New ManagementScope(computerconnect, options)

        If objManagementScope.IsConnected = True Then
        Else
            Try
                objManagementScope.Connect()
            Catch ex As Exception
                MessageBox.Show("Couldn't connect: " + ex.Message, "Error , Please check pc online and SCCM Agent is installed!")
                PCNAME.Focus()
                Exit Sub
            End Try
        End If
        Try
            Dim query As New SelectQuery("Select * From InventoryActionStatus where InventoryActionID = '{00000000-0000-0000-0000-000000000108}'")
            Dim searcher As New ManagementObjectSearcher(objManagementScope, query)
            For Each mo As ManagementObject In searcher.[Get]()
                LastHWDate = System.Management.ManagementDateTimeConverter.ToDateTime(mo("LastCycleStartedDate").ToString)
                Label108.Text = LastHWDate
            Next
        Catch ex As Exception
            MessageBox.Show("Unable to connect to SCCM Agent, Please check AGent is Installed!")
        End Try

        objManagementScope = Nothing
    End Sub

    Private Sub GLRT113_Click(sender As Object, e As EventArgs) Handles GLRT113.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If
        Label113.Text = "00:00:00"

        Dim LastHWDate As DateTime

        Dim objManagementScope As ManagementScope
        Dim options As ConnectionOptions
        options = New ConnectionOptions()
        Dim computerconnect As String = "\\" & txtpcname & "\root\ccm\invagt"

        options.Username = username
        options.Password = password
        options.Timeout = TimeSpan.FromSeconds(30)
        options.Authority = "NTLMDOMAIN:" & domain
        options.Authentication = AuthenticationLevel.PacketPrivacy
        objManagementScope = New ManagementScope(computerconnect, options)

        If objManagementScope.IsConnected = True Then
        Else
            Try
                objManagementScope.Connect()
            Catch ex As Exception
                MessageBox.Show("Couldn't connect: " + ex.Message, "Error , Please check pc online and SCCM Agent is installed!")
                PCNAME.Focus()
                Exit Sub
            End Try
        End If
        Try
            Dim query As New SelectQuery("Select * From InventoryActionStatus where InventoryActionID = '{00000000-0000-0000-0000-000000000113}'")
            Dim searcher As New ManagementObjectSearcher(objManagementScope, query)
            For Each mo As ManagementObject In searcher.[Get]()
                LastHWDate = System.Management.ManagementDateTimeConverter.ToDateTime(mo("LastCycleStartedDate").ToString)
                Label113.Text = LastHWDate
            Next
        Catch ex As Exception
            MessageBox.Show("Unable to connect to SCCM Agent, Please check AGent is Installed!")
        End Try

        objManagementScope = Nothing
    End Sub

    Private Sub GLRT010_Click(sender As Object, e As EventArgs) Handles GLRT010.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If
        Label010.Text = "00:00:00"

        Dim LastHWDate As DateTime

        Dim objManagementScope As ManagementScope
        Dim options As ConnectionOptions
        options = New ConnectionOptions()
        Dim computerconnect As String = "\\" & txtpcname & "\root\ccm\invagt"

        options.Username = username
        options.Password = password
        options.Timeout = TimeSpan.FromSeconds(30)
        options.Authority = "NTLMDOMAIN:" & domain
        options.Authentication = AuthenticationLevel.PacketPrivacy
        objManagementScope = New ManagementScope(computerconnect, options)

        If objManagementScope.IsConnected = True Then
        Else
            Try
                objManagementScope.Connect()
            Catch ex As Exception
                MessageBox.Show("Couldn't connect: " + ex.Message, "Error , Please check pc online and SCCM Agent is installed!")
                PCNAME.Focus()
                Exit Sub
            End Try
        End If
        Try
            Dim query As New SelectQuery("Select * From InventoryActionStatus where InventoryActionID = '{00000000-0000-0000-0000-000000000010}'")
            Dim searcher As New ManagementObjectSearcher(objManagementScope, query)
            For Each mo As ManagementObject In searcher.[Get]()
                LastHWDate = System.Management.ManagementDateTimeConverter.ToDateTime(mo("LastCycleStartedDate").ToString)
                Label010.Text = LastHWDate
            Next
        Catch ex As Exception
            MessageBox.Show("Unable to connect to SCCM Agent, Please check AGent is Installed!")
        End Try

        objManagementScope = Nothing
    End Sub

    Private Sub GLRT032_Click(sender As Object, e As EventArgs) Handles GLRT032.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If
        Label032.Text = "00:00:00"

        Dim LastHWDate As DateTime

        Dim objManagementScope As ManagementScope
        Dim options As ConnectionOptions
        options = New ConnectionOptions()
        Dim computerconnect As String = "\\" & txtpcname & "\root\ccm\invagt"

        options.Username = username
        options.Password = password
        options.Timeout = TimeSpan.FromSeconds(30)
        options.Authority = "NTLMDOMAIN:" & domain
        options.Authentication = AuthenticationLevel.PacketPrivacy
        objManagementScope = New ManagementScope(computerconnect, options)

        If objManagementScope.IsConnected = True Then
        Else
            Try
                objManagementScope.Connect()
            Catch ex As Exception
                MessageBox.Show("Couldn't connect: " + ex.Message, "Error , Please check pc online and SCCM Agent is installed!")
                PCNAME.Focus()
                Exit Sub
            End Try
        End If
        Try
            Dim query As New SelectQuery("Select * From InventoryActionStatus where InventoryActionID = '{00000000-0000-0000-0000-000000000032}'")
            Dim searcher As New ManagementObjectSearcher(objManagementScope, query)
            For Each mo As ManagementObject In searcher.[Get]()
                LastHWDate = System.Management.ManagementDateTimeConverter.ToDateTime(mo("LastCycleStartedDate").ToString)
                Label032.Text = LastHWDate
            Next
        Catch ex As Exception
            MessageBox.Show("Unable to connect to SCCM Agent, Please check AGent is Installed!")
        End Try

        objManagementScope = Nothing
    End Sub

    Private Sub GLRT031_Click(sender As Object, e As EventArgs) Handles GLRT031.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If
        Label031.Text = "00:00:00"

        Dim LastHWDate As DateTime

        Dim objManagementScope As ManagementScope
        Dim options As ConnectionOptions
        options = New ConnectionOptions()
        Dim computerconnect As String = "\\" & txtpcname & "\root\ccm\invagt"

        options.Username = username
        options.Password = password
        options.Timeout = TimeSpan.FromSeconds(30)
        options.Authority = "NTLMDOMAIN:" & domain
        options.Authentication = AuthenticationLevel.PacketPrivacy
        objManagementScope = New ManagementScope(computerconnect, options)

        If objManagementScope.IsConnected = True Then
        Else
            Try
                objManagementScope.Connect()
            Catch ex As Exception
                MessageBox.Show("Couldn't connect: " + ex.Message, "Error , Please check pc online and SCCM Agent is installed!")
                PCNAME.Focus()
                Exit Sub
            End Try
        End If
        Try
            Dim query As New SelectQuery("Select * From InventoryActionStatus where InventoryActionID = '{00000000-0000-0000-0000-000000000031}'")
            Dim searcher As New ManagementObjectSearcher(objManagementScope, query)
            For Each mo As ManagementObject In searcher.[Get]()
                LastHWDate = System.Management.ManagementDateTimeConverter.ToDateTime(mo("LastCycleStartedDate").ToString)
                Label031.Text = LastHWDate
            Next
        Catch ex As Exception
            MessageBox.Show("Unable to connect to SCCM Agent, Please check AGent is Installed!")
        End Try

        objManagementScope = Nothing
    End Sub

    Private Sub GLRT061_Click(sender As Object, e As EventArgs) Handles GLRT061.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If
        Label061.Text = "00:00:00"

        Dim LastHWDate As DateTime

        Dim objManagementScope As ManagementScope
        Dim options As ConnectionOptions
        options = New ConnectionOptions()
        Dim computerconnect As String = "\\" & txtpcname & "\root\ccm\invagt"

        options.Username = username
        options.Password = password
        options.Timeout = TimeSpan.FromSeconds(30)
        options.Authority = "NTLMDOMAIN:" & domain
        options.Authentication = AuthenticationLevel.PacketPrivacy
        objManagementScope = New ManagementScope(computerconnect, options)

        If objManagementScope.IsConnected = True Then
        Else
            Try
                objManagementScope.Connect()
            Catch ex As Exception
                MessageBox.Show("Couldn't connect: " + ex.Message, "Error , Please check pc online and SCCM Agent is installed!")
                PCNAME.Focus()
                Exit Sub
            End Try
        End If
        Try
            Dim query As New SelectQuery("Select * From InventoryActionStatus where InventoryActionID = '{00000000-0000-0000-0000-000000000061}'")
            Dim searcher As New ManagementObjectSearcher(objManagementScope, query)
            For Each mo As ManagementObject In searcher.[Get]()
                LastHWDate = System.Management.ManagementDateTimeConverter.ToDateTime(mo("LastCycleStartedDate").ToString)
                Label061.Text = LastHWDate
            Next
        Catch ex As Exception
            MessageBox.Show("Unable to connect to SCCM Agent, Please check AGent is Installed!")
        End Try

        objManagementScope = Nothing
    End Sub

    Private Sub GLRT051_Click(sender As Object, e As EventArgs) Handles GLRT051.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If
        Label051.Text = "00:00:00"

        Dim LastHWDate As DateTime

        Dim objManagementScope As ManagementScope
        Dim options As ConnectionOptions
        options = New ConnectionOptions()
        Dim computerconnect As String = "\\" & txtpcname & "\root\ccm\invagt"

        options.Username = username
        options.Password = password
        options.Timeout = TimeSpan.FromSeconds(30)
        options.Authority = "NTLMDOMAIN:" & domain
        options.Authentication = AuthenticationLevel.PacketPrivacy
        objManagementScope = New ManagementScope(computerconnect, options)

        If objManagementScope.IsConnected = True Then
        Else
            Try
                objManagementScope.Connect()
            Catch ex As Exception
                MessageBox.Show("Couldn't connect: " + ex.Message, "Error , Please check pc online and SCCM Agent is installed!")
                PCNAME.Focus()
                Exit Sub
            End Try
        End If
        Try
            Dim query As New SelectQuery("Select * From InventoryActionStatus where InventoryActionID = '{00000000-0000-0000-0000-000000000051}'")
            Dim searcher As New ManagementObjectSearcher(objManagementScope, query)
            For Each mo As ManagementObject In searcher.[Get]()
                LastHWDate = System.Management.ManagementDateTimeConverter.ToDateTime(mo("LastCycleStartedDate").ToString)
                Label051.Text = LastHWDate
            Next
        Catch ex As Exception
            MessageBox.Show("Unable to connect to SCCM Agent, Please check AGent is Installed!")
        End Try

        objManagementScope = Nothing
    End Sub

    Private Sub GLRT026_Click(sender As Object, e As EventArgs) Handles GLRT026.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If
        Label026.Text = "00:00:00"

        Dim LastHWDate As DateTime

        Dim objManagementScope As ManagementScope
        Dim options As ConnectionOptions
        options = New ConnectionOptions()
        Dim computerconnect As String = "\\" & txtpcname & "\root\ccm\invagt"

        options.Username = username
        options.Password = password
        options.Timeout = TimeSpan.FromSeconds(30)
        options.Authority = "NTLMDOMAIN:" & domain
        options.Authentication = AuthenticationLevel.PacketPrivacy
        objManagementScope = New ManagementScope(computerconnect, options)

        If objManagementScope.IsConnected = True Then
        Else
            Try
                objManagementScope.Connect()
            Catch ex As Exception
                MessageBox.Show("Couldn't connect: " + ex.Message, "Error , Please check pc online and SCCM Agent is installed!")
                PCNAME.Focus()
                Exit Sub
            End Try
        End If
        Try
            Dim query As New SelectQuery("Select * From InventoryActionStatus where InventoryActionID = '{00000000-0000-0000-0000-000000000026}'")
            Dim searcher As New ManagementObjectSearcher(objManagementScope, query)
            For Each mo As ManagementObject In searcher.[Get]()
                LastHWDate = System.Management.ManagementDateTimeConverter.ToDateTime(mo("LastCycleStartedDate").ToString)
                Label026.Text = LastHWDate
            Next
        Catch ex As Exception
            MessageBox.Show("Unable to connect to SCCM Agent, Please check AGent is Installed!")
        End Try

        objManagementScope = Nothing
    End Sub

    Private Sub GLRT121_Click(sender As Object, e As EventArgs) Handles GLRT121.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If
        Label121.Text = "00:00:00"

        Dim LastHWDate As DateTime

        Dim objManagementScope As ManagementScope
        Dim options As ConnectionOptions
        options = New ConnectionOptions()
        Dim computerconnect As String = "\\" & txtpcname & "\root\ccm\invagt"

        options.Username = username
        options.Password = password
        options.Timeout = TimeSpan.FromSeconds(30)
        options.Authority = "NTLMDOMAIN:" & domain
        options.Authentication = AuthenticationLevel.PacketPrivacy
        objManagementScope = New ManagementScope(computerconnect, options)

        If objManagementScope.IsConnected = True Then
        Else
            Try
                objManagementScope.Connect()
            Catch ex As Exception
                MessageBox.Show("Couldn't connect: " + ex.Message, "Error , Please check pc online and SCCM Agent is installed!")
                PCNAME.Focus()
                Exit Sub
            End Try
        End If
        Try
            Dim query As New SelectQuery("Select * From InventoryActionStatus where InventoryActionID = '{00000000-0000-0000-0000-000000000121}'")
            Dim searcher As New ManagementObjectSearcher(objManagementScope, query)
            For Each mo As ManagementObject In searcher.[Get]()
                LastHWDate = System.Management.ManagementDateTimeConverter.ToDateTime(mo("LastCycleStartedDate").ToString)
                Label121.Text = LastHWDate
            Next
        Catch ex As Exception
            MessageBox.Show("Unable to connect to SCCM Agent, Please check AGent is Installed!")
        End Try

        objManagementScope = Nothing
    End Sub

    Private Sub TAPHRP_Click(sender As Object, e As EventArgs) Handles TAPHRP.Click

        'Dim Command As String = "WMIC /node:" & txtpcname & " /namespace:\\root\ccm path sms_client CALL ResetPolicy 1 /NOINTERACTIVE"

        'Invoke-CimMethod -Namespace root\ccm -ClassName sms_client -Name ResetPolicy -Arguments @{ uFlags = ([UInt32]1) }

        If MachineName = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Dim powersetup As Boolean = False
        powersetup = SETUPPowerShellonRemote()
        If powersetup = False Then
            MsgBox("Unable to configure Powershell for connection on computer : " & txtpcname)
            BackgroundWorkerSpinner.CancelAsync()
            MetroProgressBar.Hide()
            Exit Sub
        End If

        Dim Commandtorun As String = "Invoke-CimMethod -Namespace root\ccm -ClassName sms_client -Name ResetPolicy -Arguments @{ uFlags = ([UInt32]1) }"
        Dim psresult As String = Nothing
        Try
            psresult = RunPSCommand(MachineName, username, password, Commandtorun)
        Catch ex As Exception
        End Try

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()

        MsgBox(psresult)

    End Sub

    Private Sub PINGSinglePC_Click(sender As Object, e As EventArgs) Handles PINGSinglePC.Click
        Try
            If TreeView.SelectedNode.Checked = True Then Exit Sub
            Dim PingAnswer = Nothing
            PingAnswer = Ping(TreeView.SelectedNode.Text)
            'MsgBox(PingAnswer)
            If PingAnswer = True Then
                TreeView.SelectedNode.ImageIndex = 4
                TreeView.SelectedNode.SelectedImageIndex = 4
            End If
            If PingAnswer = False Then
                TreeView.SelectedNode.ImageIndex = 5
                TreeView.SelectedNode.SelectedImageIndex = 5
            End If
        Catch
        End Try
    End Sub

    Private Sub GatherAudioInfo_Click(sender As Object, e As EventArgs) Handles GatherAudioInfo.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Try
            GETSTRVALUESAUDIO(username, password, domain, txtpcname)
        Catch
        End Try

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
        PCNAME.Focus()
    End Sub

    Public Sub GETSTRVALUESAUDIO(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)
        On Error Resume Next

        Dim AudioDriverProviderName As String = Nothing
        Dim sActiveName As String = Nothing
        Dim AudioDeviceName As String = Nothing
        Dim AudioDriverVersion As String = Nothing
        Dim AudioFriendlyName As String = Nothing
        Dim AudioDriverDate As DateTime = Nothing

        DataGridViewDetails.Rows.Clear()

        If PCnameFordetails.Text <> "" Then

            Dim objManagementScope2 As ManagementScope
            Dim options2 As ConnectionOptions
            options2 = New ConnectionOptions()
            Dim computerconnect2 As String = "\\" & txtpcname & "\root\cimv2"
            options2.Username = username
            options2.Password = password
            options2.Timeout = TimeSpan.FromSeconds(30)
            options2.Authority = "NTLMDOMAIN:" & domain
            options2.Authentication = AuthenticationLevel.PacketPrivacy
            objManagementScope2 = New ManagementScope(computerconnect2, options2)
            If objManagementScope2.IsConnected = True Then
            Else
                objManagementScope2.Connect()
            End If

            Dim QueryOptions = New EnumerationOptions
            QueryOptions.Timeout = New TimeSpan(0, 0, 10)
            Dim query6 As New SelectQuery("Select * from Win32_PNPSignedDriver")
            Dim searcher6 As New ManagementObjectSearcher(objManagementScope2, query6)
            For Each mo As ManagementObject In searcher6.[Get]()
                AudioDriverProviderName = Nothing
                AudioDeviceName = Nothing
                AudioDriverVersion = Nothing
                AudioDriverDate = Nothing
                AudioFriendlyName = Nothing

                AudioFriendlyName = mo("FriendlyName")
                AudioDriverProviderName = mo("DriverProviderName")
                AudioDeviceName = mo("DeviceName").ToString
                AudioDriverDate = ManagementDateTimeConverter.ToDateTime(CStr(mo("DriverDate")))
                AudioDriverVersion = mo("DriverVersion").ToString()

                If AudioDeviceName <> "" Then
                    If AudioDeviceName.Contains("Audio") OrElse AudioDeviceName.Contains("Media") OrElse AudioDeviceName.Contains("Sound") Then
                        DataGridViewDetails.Rows.Add("Audio FriendlyName", AudioFriendlyName)
                        DataGridViewDetails.Rows.Add("Audio DriverProviderName", AudioDriverProviderName)
                        DataGridViewDetails.Rows.Add("Audio Devicename", AudioDeviceName)
                        DataGridViewDetails.Rows.Add("Audio Driver Version", AudioDriverVersion)
                        DataGridViewDetails.Rows.Add("Audio Driver Date", AudioDriverDate)
                        DataGridViewDetails.Rows.Add(" ")
                    End If
                End If


            Next

            objManagementScope2 = Nothing
        End If

    End Sub

    Private Sub GetHPBiosSettings_Click(sender As Object, e As EventArgs) Handles GetHPBiosSettings.Click
        BackgroundWorkerSpinnerStopWorker()

        If MachineName = "" Then
            Exit Sub
        End If

        MetroProgressBar.Show()
        BackgroundWorkerSpinner.RunWorkerAsync()

        Try
            GetHPBios(username, password, domain, txtpcname)
        Catch
        End Try

        BackgroundWorkerSpinner.CancelAsync()
        MetroProgressBar.Hide()
        PCNAME.Focus()
    End Sub



    Public Sub GetHPBios(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)
        On Error Resume Next

        DataGridViewDetails.Rows.Clear()

        Dim objMgmt As ManagementObject
        Dim QueryOptions = New EnumerationOptions
        QueryOptions.Timeout = New TimeSpan(0, 0, 10)

        Dim options2 As ConnectionOptions
        options2 = New ConnectionOptions()
        Dim computerconnect2 As String = "\\" & txtpcname & "\root\HP\InstrumentedBIOS"
        options2.Username = username
        options2.Password = password
        options2.Timeout = TimeSpan.FromSeconds(30)
        options2.Authority = "NTLMDOMAIN:" & domain
        options2.Authentication = AuthenticationLevel.PacketPrivacy
        Dim msc As ManagementScope = New ManagementScope(computerconnect2, options2)

        If msc.IsConnected = True Then
        Else
            msc.Connect()
        End If

        If msc.IsConnected = False Then
            Exit Sub
        End If

        Dim query_command3 As String = "Select * from HP_BIOSSetting"
        Dim select_query3 As SelectQuery = New SelectQuery(query_command3)
        Dim Srch3 As New ManagementObjectSearcher(msc, select_query3, QueryOptions)

        For Each objMgmt In Srch3.Get
            DataGridViewDetails.Rows.Add(UCase(objMgmt("Name").ToString()), UCase(objMgmt("Value").ToString()))
            DataGridViewDetails.Rows.Add(" ")
        Next

        msc = Nothing

    End Sub


End Class