Option Explicit On
Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Management
Imports System.Runtime.InteropServices
Imports System.Diagnostics.Process
Imports System.IO
Imports System.Net

Public Class Form2
    Public Declare Function WNetAddConnection2 Lib "mpr.dll" Alias "WNetAddConnection2A" (ByRef lpNetResource As NETRESOURCE, ByVal lpPassword As String, ByVal lpUserName As String, ByVal dwFlags As Integer) As Integer
    Public Declare Function WNetCancelConnection2 Lib "mpr" Alias "WNetCancelConnection2A" (ByVal lpName As String, ByVal dwFlags As Integer, ByVal fForce As Integer) As Integer

    <Runtime.InteropServices.StructLayout(LayoutKind.Sequential)> Public Structure NETRESOURCE
        Public dwScope As Integer
        Public dwType As Integer
        Public dwDisplayType As Integer
        Public dwUsage As Integer
        Public lpLocalName As String
        Public lpRemoteName As String
        Public lpComment As String
        Public lpProvider As String
    End Structure

    Public Const ForceDisconnect As Integer = 1
    Public Const RESOURCETYPE_DISK As Long = &H1

    Private Sub Form2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.Hide() 'or form.ShowDialog() for Modal forms
        Form1.Show() 'or form.ShowDialog() for Modal forms
    End Sub

    Public Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        If txtpcname = "" Then
            Exit Sub
        End If
        Dim strValueName As String
        Dim TextOutput As String = Nothing
        Dim TextOut As String = Nothing
        Dim strRead1 As String = Nothing
        Dim strRead2 As String = Nothing
        Dim strRead3 As String = Nothing
        Dim strRead4 As String = Nothing
        Dim strRead5 As String = Nothing
        Dim strRead6 As String = Nothing
        Dim strRead7 As String = Nothing
        Dim strRead8 As String = Nothing
        Dim strRead9 As String = Nothing
        Dim strRead10 As String = Nothing
        Dim strRead11 As String = Nothing

        strValueName = "ADMIN_PASS"
        strRead1 = GETSTRVALUESCSC(username, password, domain, txtpcname, strValueName)
        If strRead1 = "1" Then Exit Sub
        strValueName = "BuildRelease"
        strRead2 = GETSTRVALUESCSC(username, password, domain, txtpcname, strValueName)
        strValueName = "BuildType"
        strRead3 = GETSTRVALUESCSC(username, password, domain, txtpcname, strValueName)
        strValueName = "BuildVersion"
        strRead4 = GETSTRVALUESCSC(username, password, domain, txtpcname, strValueName)
        strValueName = "Customer"
        strRead5 = GETSTRVALUESCSC(username, password, domain, txtpcname, strValueName)
        strValueName = "DateInstalled"
        strRead6 = GETSTRVALUESCSC(username, password, domain, txtpcname, strValueName)
        strValueName = "Hardware"
        strRead7 = GETSTRVALUESCSC(username, password, domain, txtpcname, strValueName)
        strValueName = "HWINT"
        strRead8 = GETSTRVALUESCSC(username, password, domain, txtpcname, strValueName)
        strValueName = "MachineType"
        strRead9 = GETSTRVALUESCSC(username, password, domain, txtpcname, strValueName)
        strValueName = "Platform"
        strRead10 = GETSTRVALUESCSC(username, password, domain, txtpcname, strValueName)
        strValueName = "WorkStyle"
        strRead11 = GETSTRVALUESCSC(username, password, domain, txtpcname, strValueName)

        TextOutput = ""
        TextOutput = TextOutput & "ADMIN_PASS" & vbCrLf
        TextOutput = TextOutput & "BuildRelease" & vbCrLf
        TextOutput = TextOutput & "BuildType" & vbCrLf
        TextOutput = TextOutput & "BuildVersion" & vbCrLf
        TextOutput = TextOutput & "Customer" & vbCrLf
        TextOutput = TextOutput & "DateInstalled" & vbCrLf
        TextOutput = TextOutput & "Hardware" & vbCrLf
        TextOutput = TextOutput & "HWINT" & vbCrLf
        TextOutput = TextOutput & "MachineType" & vbCrLf
        TextOutput = TextOutput & "Platform" & vbCrLf
        TextOutput = TextOutput & "WorkStyle" & vbCrLf

        TextOut = ""
        TextOut = TextOut & strRead1 & vbCrLf
        TextOut = TextOut & strRead2 & vbCrLf
        TextOut = TextOut & strRead3 & vbCrLf
        TextOut = TextOut & strRead4 & vbCrLf
        TextOut = TextOut & strRead5 & vbCrLf
        TextOut = TextOut & strRead6 & vbCrLf
        TextOut = TextOut & strRead7 & vbCrLf
        TextOut = TextOut & strRead8 & vbCrLf
        TextOut = TextOut & strRead9 & vbCrLf
        TextOut = TextOut & strRead10 & vbCrLf
        TextOut = TextOut & strRead11 & vbCrLf

        GetBasicText.Text = TextOutput
        GetBasicOut.Text = TextOut

    End Sub

    Public Function PassParam(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String)
        username = txtusername
        password = txtpassword
        domain = txtdomain
        Return (username)
        Return (password)
        Return (domain)
    End Function

    Public Overloads Shared Function GETSTRVALUESCSC(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String, ByVal strValueName As String)

        Dim strStringValue As String = ""
        Dim strSubKeyName As String
        Dim objManagementScope As ManagementScope
        Dim objManagementClass As ManagementClass
        Dim objManagementBaseObject As ManagementBaseObject
        Dim intRegistryHive As Microsoft.Win32.RegistryHive

        intRegistryHive = Microsoft.Win32.RegistryHive.LocalMachine
        strSubKeyName = "Software\CSC"

        Dim options As ConnectionOptions
        options = New ConnectionOptions()
        Dim computerconnect As String = "\\" & txtpcname & "\root\DEFAULT"

        options.Username = txtusername
        options.Password = txtpassword
        options.Authority = "ntlmdomain:" & txtdomain

        objManagementScope = New ManagementScope(computerconnect, options)

        If objManagementScope.IsConnected = True Then
        Else
            Try
                objManagementScope.Connect()
            Catch
            End Try
            If objManagementScope.IsConnected = False Then
                MsgBox("Could not connect to PC name specified! Please check you inputed your username, password and domain correctly!")
                Return 1
                Exit Function
            End If
        End If

        objManagementClass = New ManagementClass("StdRegProv")

        With objManagementClass
            .Scope = objManagementScope
            objManagementBaseObject = .GetMethodParameters("GetStringValue")

            With objManagementBaseObject
                .SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                .SetPropertyValue("sSubKeyName", strSubKeyName)
                .SetPropertyValue("sValueName", strValueName)
            End With

            Dim OutParams As ManagementBaseObject = .InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
            strStringValue = CType(OutParams("sValue"), String)
            If strStringValue = Nothing Then strStringValue = ""
        End With

        objManagementScope = Nothing
        Return strStringValue
    End Function

    Public Sub PCname_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PCname.TextChanged
        txtpcname = PCname.Text
        Alive.Text = Nothing
        ProgressBar1.Value = 0
        PCname.ForeColor = Color.Black
        Host.Text = " "
        Reboot.Text = " "
        Reboot.ForeColor = Nothing
    End Sub

    Private Sub Form_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Dim response As MsgBoxResult
        response = MsgBox("Do you want to close?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "Confirm")
        If response = MsgBoxResult.Yes Then
            Form1.Dispose()
            Me.Dispose()
        ElseIf response = MsgBoxResult.No Then
            e.Cancel = True
            Exit Sub
        End If
    End Sub

    Public Overloads Shared Function GETKEYSCSC(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)

        Dim strStringKeys As Array = Nothing
        Dim strSubKeyName As String
        Dim objManagementScope As ManagementScope
        Dim objManagementClass As ManagementClass
        Dim objManagementBaseObject As ManagementBaseObject
        Dim intRegistryHive As Microsoft.Win32.RegistryHive

        intRegistryHive = Microsoft.Win32.RegistryHive.LocalMachine
        strSubKeyName = "Software\CSC\Packages"

        Dim options As ConnectionOptions
        options = New ConnectionOptions()
        Dim computerconnect As String = "\\" & txtpcname & "\root\DEFAULT"

        options.Username = txtusername
        options.Password = txtpassword
        options.Authority = "ntlmdomain:" & txtdomain

        objManagementScope = New ManagementScope(computerconnect, options)

        If objManagementScope.IsConnected = True Then
        Else
            Try
                objManagementScope.Connect()
            Catch
            End Try
            If objManagementScope.IsConnected = False Then
                MsgBox("Could not connect to PC name specified! Please check you inputed your username, password and domain correctly!")
                Return 1
                Exit Function
            End If
        End If

        objManagementClass = New ManagementClass("StdRegProv")

        With objManagementClass
            .Scope = objManagementScope
            objManagementBaseObject = .GetMethodParameters("GetSubKeyNames")

            With objManagementBaseObject
                .SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                .SetPropertyValue("sSubKeyName", strSubKeyName)
            End With

            Dim OutParams As ManagementBaseObject = .InvokeMethod("GetSubKeyNames", objManagementBaseObject, Nothing)
            strStringKeys = OutParams("Name")
        End With

        objManagementScope = Nothing
        Return strStringKeys
    End Function

    Private Sub GetKeysCSC_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GetKeysCSC_Button.Click
        If txtpcname = "" Then
            Exit Sub
        End If
        Me.DataGridViewCSCPackages.Rows.Clear()
        GETCSCPACKAGES(username, password, domain, txtpcname)
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GetSoftwareList.Click
        If txtpcname = "" Then
            Exit Sub
        End If
        Me.DataGridView1.Rows.Clear()
        GETADDREMOVE(username, password, domain, txtpcname)
    End Sub

    Private Sub GETADDREMOVE(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)
        Dim strComputerName As String = txtpcname
        Dim strStringValue As String = ""
        Dim strKeyPath As String = "SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\"
        Dim objManagementScope As ManagementScope
        Dim objManagementClass As ManagementClass
        Dim objManagementBaseObject As ManagementBaseObject
        Dim strkey As String
        Dim myKey As String
        Dim myValue As String
        Dim myValue1 As String
        Dim myValue2 As String
        Dim aSubKeys() As String
        Dim intRegistryHive As Microsoft.Win32.RegistryHive
        intRegistryHive = Microsoft.Win32.RegistryHive.LocalMachine


        Dim options As ConnectionOptions
        options = New ConnectionOptions()
        Dim computerconnect As String = "\\" & txtpcname & "\root\DEFAULT"

        options.Username = txtusername
        options.Password = txtpassword
        options.Authority = "ntlmdomain:" & txtdomain

        objManagementScope = New ManagementScope(computerconnect, options)

        If objManagementScope.IsConnected = True Then
        Else
            Try
                objManagementScope.Connect()
            Catch
            End Try
            If objManagementScope.IsConnected = False Then
                MsgBox("Could not connect to PC name specified! Please check you inputed your username, password and domain correctly!")
                Exit Sub
            End If
        End If

        objManagementClass = New ManagementClass("stdRegProv")
        objManagementClass.Scope = objManagementScope
        objManagementBaseObject = objManagementClass.GetMethodParameters("EnumKey")
        objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
        objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath)
        aSubKeys = CType(objManagementClass.InvokeMethod("EnumKey", objManagementBaseObject, Nothing).Properties.Item("sNames").Value, String())

        For Each strkey In aSubKeys
            myKey = strkey
            objManagementBaseObject = objManagementClass.GetMethodParameters("GetStringValue")
            objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
            objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath & strkey)
            objManagementBaseObject.SetPropertyValue("sValueName", "DisplayName")
            objManagementBaseObject = objManagementClass.InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
            myValue = objManagementBaseObject("sValue")

            objManagementBaseObject = objManagementClass.GetMethodParameters("GetStringValue")
            objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
            objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath & strkey)
            objManagementBaseObject.SetPropertyValue("sValueName", "DisplayVersion")
            objManagementBaseObject = objManagementClass.InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
            myValue1 = objManagementBaseObject("sValue")

            objManagementBaseObject = objManagementClass.GetMethodParameters("GetStringValue")
            objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
            objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath & strkey)
            objManagementBaseObject.SetPropertyValue("sValueName", "InstallDate")
            objManagementBaseObject = objManagementClass.InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
            myValue2 = objManagementBaseObject("sValue")

            If Not myValue = "" Then
                DataGridView1.Rows.Add(myValue, myValue1, myValue2, strkey)
            End If
        Next
        Return
    End Sub

    Private Sub GETCSCPACKAGES(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)
        Dim strComputerName As String = txtpcname
        Dim strStringValue As String = ""
        Dim strKeyPath As String = "SOFTWARE\CSC\PACKAGES\"
        Dim objManagementScope As ManagementScope
        Dim objManagementClass As ManagementClass
        Dim objManagementBaseObject As ManagementBaseObject
        Dim strkey As String
        Dim myKey As String
        Dim myValue As String
        Dim aSubKeys() As String
        Dim intRegistryHive As Microsoft.Win32.RegistryHive
        intRegistryHive = Microsoft.Win32.RegistryHive.LocalMachine


        Dim options As ConnectionOptions
        options = New ConnectionOptions()
        Dim computerconnect As String = "\\" & txtpcname & "\root\DEFAULT"

        options.Username = txtusername
        options.Password = txtpassword
        options.Authority = "ntlmdomain:" & txtdomain

        objManagementScope = New ManagementScope(computerconnect, options)

        If objManagementScope.IsConnected = True Then
        Else
            Try
                objManagementScope.Connect()
            Catch
            End Try
            If objManagementScope.IsConnected = False Then
                MsgBox("Could not connect to PC name specified! Please check you inputed your username, password and domain correctly!")
                Exit Sub
            End If
        End If

        objManagementClass = New ManagementClass("stdRegProv")
        objManagementClass.Scope = objManagementScope
        objManagementBaseObject = objManagementClass.GetMethodParameters("EnumKey")
        objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
        objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath)
        aSubKeys = CType(objManagementClass.InvokeMethod("EnumKey", objManagementBaseObject, Nothing).Properties.Item("sNames").Value, String())

        For Each strkey In aSubKeys
            myKey = strkey
            objManagementBaseObject = objManagementClass.GetMethodParameters("GetStringValue")
            objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
            objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath & strkey)
            objManagementBaseObject.SetPropertyValue("sValueName", "Installed")
            objManagementBaseObject = objManagementClass.InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
            myValue = objManagementBaseObject("sValue")

            If Not myValue = "" Then
                DataGridViewCSCPackages.Rows.Add(strkey, myValue)
            End If
        Next
        Return
    End Sub

    Private Sub BrowseAppslogs_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BrowseAppslogs.Click
        Dim txtpcname As String
        txtpcname = PCname.Text
        If txtpcname = "" Then
            Exit Sub
        End If
        MapDrive(username, password, domain, txtpcname)
        Dim path As String
        path = "\\" & txtpcname & "\C$\Windows\Appslogs"
        Dim objShell = CreateObject("Wscript.Shell")
        objShell.run(path)
    End Sub

    Public Function MapDrive(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String) As Boolean
        Dim nr As NETRESOURCE
        Dim strUsername As String
        Dim strPassword As String

        nr = New NETRESOURCE
        nr.lpRemoteName = "\\" & txtpcname & "\C$\Windows\Appslogs"
        nr.lpLocalName = Nothing
        strUsername = txtdomain & "\" & txtusername
        strPassword = txtpassword
        nr.dwType = RESOURCETYPE_DISK

        Dim result As Integer
        result = WNetAddConnection2(nr, strPassword, strUsername, 0)

        If result = 0 Then
            Return True
        Else
            Return False
        End If
    End Function

    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        Dim x As String
        x = DataGridView1.CurrentCell.Value
        TextBox1.Text = x
    End Sub

    Private Sub MSIUNINSTALL_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MSIUNINSTALL.Click
        Dim txtpcname As String
        txtpcname = PCname.Text
        If txtpcname = "" Then
            Exit Sub
        End If
        EXECUTECOMMANDMSIUNINSTALL(username, password, domain, txtpcname)
    End Sub

    Private Sub EXECUTECOMMANDMSIUNINSTALL(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)
        Dim wmi_out As ManagementBaseObject
        Dim objManagementScope As ManagementScope
        Dim objManagementClass As ManagementClass
        Dim objManagementBaseObject As ManagementBaseObject
        Dim retValue As Integer
        Dim Command As String = "MSIEXEC.EXE /x " & TextBox1.Text & " /qn /liea c:\windows\appslogs\" & TextBox1.Text & "_Remove.log"
        Try
            If TextBox1.Text = "" Then
                Exit Sub
            End If
            Dim options As ConnectionOptions
            options = New ConnectionOptions()
            Dim computerconnect As String = "\\" & txtpcname & "\root\cimv2:Win32_Process"

            options.Username = txtusername
            options.Password = txtpassword
            options.Authority = "ntlmdomain:" & txtdomain

            objManagementScope = New ManagementScope(computerconnect, options)

            If objManagementScope.IsConnected = True Then
            Else
                Try
                    objManagementScope.Connect()
                Catch
                End Try
                If objManagementScope.IsConnected = False Then
                    MsgBox("Could not connect to PC name specified! Please check you inputed your username, password and domain correctly!")
                    Exit Sub
                End If
            End If

            objManagementClass = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
            objManagementClass.Scope = objManagementScope

            objManagementBaseObject = objManagementClass.GetMethodParameters("Create")
            objManagementBaseObject.SetPropertyValue("CommandLine", Command)
            wmi_out = objManagementClass.InvokeMethod("Create", objManagementBaseObject, Nothing)

            'wmi = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
            'wmi_in = wmi.GetMethodParameters("Create")
            'wmi_in("CommandLine") = "cmd /c md c:\temp\temptd"
            'wmi_out = wmi.InvokeMethod("Create", wmi_in, Nothing)

            retValue = Convert.ToInt32(wmi_out("returnValue"))
            Select Case retValue
                Case 0
                    ' success!
                Case 2
                    Throw New ApplicationException("Access denied")
                Case 3
                    Throw New ApplicationException("Insufficient privilege")
                Case 8
                    Throw New ApplicationException("Unknown failure")
                Case 9
                    Throw New ApplicationException("Path not found")
                Case 21
                    Throw New ApplicationException("Invalid parameter")
                Case Else
                    Throw New ApplicationException("Unknown return code " & retValue)
            End Select
        Catch ex As Exception
            MsgBox(txtpcname & ": Can't create the process. " & ex.Message)
        End Try
    End Sub

    Private Sub greenlnklistpackages_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles greenlnklistpackages.Click

        Me.GreenlnkSD.Items.Clear()
        MapDriveGreenlnkSD(username, password, domain)

        Dim di As New IO.DirectoryInfo("\\greenlnk.net\sd")
        Dim diar1 As IO.DirectoryInfo()
        Dim dra As IO.DirectoryInfo

        Try
            diar1 = di.GetDirectories()
        Catch
            Exit Sub
        End Try

        For Each dra In diar1
            GreenlnkSD.Items.Add(dra)
        Next

    End Sub

    Public Function MapDriveGreenlnkSD(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String) As Boolean
        Dim nr As NETRESOURCE
        Dim strUsername As String
        Dim strPassword As String

        nr = New NETRESOURCE
        nr.lpRemoteName = "\\greenlnk.net\sd"
        nr.lpLocalName = Nothing
        strUsername = txtdomain & "\" & txtusername
        strPassword = txtpassword
        nr.dwType = RESOURCETYPE_DISK

        Dim result As Integer
        result = WNetAddConnection2(nr, strPassword, strUsername, 0)

        If result = 0 Then
            Return True
        Else
            Return False
        End If
    End Function

    Private Sub greenlnkSD_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GreenlnkSD.SelectedIndexChanged
        Dim x As String
        x = GreenlnkSD.SelectedItem.ToString
        GreenlnkSDBOX.Text = x
    End Sub

    Private Sub InstallSoftware_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles InstallSoftware.Click
        If txtpcname = "" Then
            Exit Sub
        End If
        If GreenlnkSDBOX.Text = "" Then
            Exit Sub
        End If
        CreateInstallBat(txtpcname)
        InstallPackage(username, password, domain, txtpcname)
    End Sub

    Private Sub RemoveSoftware_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RemoveSoftware.Click
        If txtpcname = "" Then
            Exit Sub
        End If
        If GreenlnkSDBOX.Text = "" Then
            Exit Sub
        End If
        CreateUnInstallBat(txtpcname)
        RemovePackage(username, password, domain, txtpcname)
    End Sub

    Private Sub InstallPackage(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)

        Dim path As String
        Dim sResult As String
        Dim objShell = CreateObject("Wscript.Shell")
        path = "remcom.exe \\" & txtpcname & " /user:" & txtdomain & "\" & txtusername & " /pwd:" & txtpassword & " " & Chr(34) & "c:\Program Files\CSC\BAE-ENG-ManualInstaller-1-GBL-R1\Install.bat" & Chr(34)
        MsgBox(path)
        sResult = objShell.run(path, 1, True)
        MsgBox(sResult)
        path = "remcom.exe \\" & txtpcname & " /user:" & txtdomain & "\" & txtusername & " /pwd:" & txtpassword & " " & Chr(34) & "subst a: /d" & Chr(34)
        MsgBox(path)
        objShell.run(path, 0, True)
    End Sub

    Private Sub RemovePackage(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)
        Dim path As String
        Dim sResult As String
        Dim objShell = CreateObject("Wscript.Shell")
        path = "remcom \\" & txtpcname & " /user:" & txtdomain & "\" & txtusername & " /pwd:" & txtpassword & " " & Chr(34) & "c:\Program Files\CSC\BAE-ENG-ManualInstaller-1-GBL-R1\UnInstall.bat" & Chr(34)
        'MsgBox(path)
        sResult = objShell.run(path, 1, True)
        MsgBox(sResult)
        path = "remcom \\" & txtpcname & " /user:" & txtdomain & "\" & txtusername & " /pwd:" & txtpassword & " " & Chr(34) & "subst a: /d" & Chr(34)
        'MsgBox(path)
        objShell.run(path, 0, True)
    End Sub
    Private Sub CreateInstallBat(ByVal txtpcname As String)
        'MapDrive(username, password, domain, txtpcname)
        Dim fullPath As String = "\\" & txtpcname & "\c$\Program Files\CSC"
        Directory.CreateDirectory(fullPath)
        Dim fullPath2 As String = "\\" & txtpcname & "\c$\Program Files\CSC\BAE-ENG-ManualInstaller-1-GBL-R1"
        Directory.CreateDirectory(fullPath2)
        Dim W As New IO.StreamWriter("\\" & txtpcname & "\c$\Program Files\CSC\BAE-ENG-ManualInstaller-1-GBL-R1\Install.bat")
        W.WriteLine("set SEE_MASK_NOZONECHECKS=1")
        W.WriteLine("Subst a: \\greenlnk\sd")
        W.WriteLine("a:")
        W.WriteLine("cd " & GreenlnkSDBOX.Text)
        W.WriteLine("Install.bat")
        W.Close()
    End Sub
    Private Sub CreateUnInstallBat(ByVal txtpcname As String)
        'MapDrive(username, password, domain, txtpcname)
        Dim fullPath As String = "\\" & txtpcname & "\c$\Program Files\CSC"
        Directory.CreateDirectory(fullPath)
        Dim fullPath2 As String = "\\" & txtpcname & "\c$\Program Files\CSC\BAE-ENG-ManualInstaller-1-GBL-R1"
        Directory.CreateDirectory(fullPath2)
        Dim W As New IO.StreamWriter("\\" & txtpcname & "\c$\Program Files\CSC\BAE-ENG-ManualInstaller-1-GBL-R1\UnInstall.bat")
        W.WriteLine("set SEE_MASK_NOZONECHECKS=1")
        W.WriteLine("Subst a: \\greenlnk\sd")
        W.WriteLine("a:")
        W.WriteLine("cd " & GreenlnkSDBOX.Text)
        W.WriteLine("UnInstall.bat")
        W.Close()
    End Sub

    Private Sub COmmand1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles COmmand1.Click
        Dim Result As String = Nothing
        Dim IP4Address As String = String.Empty
        Dim client As New Net.Sockets.TcpClient()
        Dim strValueName As String = Nothing
        Dim strValueKey As String = Nothing
        Dim TextOutput As String = Nothing
        Dim TextOut As String = Nothing
        Dim strRead1 As String = Nothing
        Dim strRead2 As String = Nothing

        Try
            For Each IPA As Net.IPAddress In System.Net.Dns.GetHostAddresses(PCname.Text)
                If IPA.AddressFamily.ToString() = "InterNetwork" Then
                    IP4Address = IPA.ToString()
                    Exit For
                End If
            Next
            If IP4Address <> String.Empty Then
                Alive.Text = IP4Address
                If My.Computer.Network.Ping(IP4Address) Then
                    ProgressBar1.Value = 100
                    PCname.ForeColor = Color.Green

                    strValueKey = "SYSTEM\CurrentControlSet\services\Tcpip\Parameters"
                    strValueName = "HostName"
                    strRead1 = GETSTRVALUE(username, password, domain, txtpcname, strValueKey, strValueName)
                    Host.Text = strRead1
                    strValueKey = "SYSTEM\CurrentControlSet\Control\Session Manager"
                    strValueName = "PendingFileRenameOperations"
                    strRead2 = GETMULTISTRVALUE(username, password, domain, txtpcname, strValueKey, strValueName)
                    If strRead2 <> "1" Then
                        Reboot.Text = "Reboot Needed"
                        Reboot.ForeColor = Color.Red
                    End If

                Else
                    Dim response As MsgBoxResult
                    response = MsgBox("no reply - did you want to test rdp connect ?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "Error")
                    If response = MsgBoxResult.Yes Then
                        Try
                            Dim ip As IPAddress = IPAddress.Parse(IP4Address)
                            client.Connect(ip, 3389)
                            ProgressBar1.Value = 100
                            PCname.ForeColor = Color.Green
                        Catch ex As Exception
                            MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
                        Finally
                            client.Close()
                        End Try
                    ElseIf response = MsgBoxResult.No Then
                        Exit Sub
                    End If
                End If
            End If
        Catch ex As Exception
            MessageBox.Show("Couldn't connect: " + ex.Message, "Error")
        End Try
    End Sub

    Private Sub COmmand1_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles COmmand1.GotFocus

    End Sub

    Private Sub DataGridViewCSCPackages_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridViewCSCPackages.CellContentClick
        Dim x As String
        x = DataGridView1.CurrentCell.Value
        GreenlnkSDBOX.Text = x
    End Sub

    Private Sub Button3_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim Form3 As New Form3()
        Form3.Show() 'or form.ShowDialog() for Modal forms
        Me.Hide() 'or form.ShowDialog() for Modal forms
    End Sub

    Private Sub ProgressBar1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ProgressBar1.Click

    End Sub

    Public Overloads Shared Function GETSTRVALUE(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String, ByVal strValueKey As String, ByVal strValueName As String)

        Dim strStringValue As String = ""
        Dim strSubKeyName As String
        Dim objManagementScope As ManagementScope
        Dim objManagementClass As ManagementClass
        Dim objManagementBaseObject As ManagementBaseObject
        Dim intRegistryHive As Microsoft.Win32.RegistryHive

        intRegistryHive = Microsoft.Win32.RegistryHive.LocalMachine
        strSubKeyName = strValueKey

        Dim options As ConnectionOptions
        options = New ConnectionOptions()
        Dim computerconnect As String = "\\" & txtpcname & "\root\DEFAULT"

        options.Username = txtusername
        options.Password = txtpassword
        options.Authority = "ntlmdomain:" & txtdomain

        objManagementScope = New ManagementScope(computerconnect, options)

        If objManagementScope.IsConnected = True Then
        Else
            Try
                objManagementScope.Connect()
            Catch
            End Try
            If objManagementScope.IsConnected = False Then
                MsgBox("Could not connect to PC name specified! Please check you inputed your username, password and domain correctly!")
                Return 1
                Exit Function
            End If
        End If

        objManagementClass = New ManagementClass("StdRegProv")

        With objManagementClass
            .Scope = objManagementScope
            objManagementBaseObject = .GetMethodParameters("GetStringValue")

            With objManagementBaseObject
                .SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                .SetPropertyValue("sSubKeyName", strSubKeyName)
                .SetPropertyValue("sValueName", strValueName)
            End With

            Dim OutParams As ManagementBaseObject = .InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
            strStringValue = CType(OutParams("sValue"), String)
            If strStringValue = Nothing Then strStringValue = ""
        End With

        objManagementScope = Nothing
        Return strStringValue
    End Function
    Public Overloads Shared Function GETMULTISTRVALUE(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String, ByVal strValueKey As String, ByVal strValueName As String)
        Const HKEY_LOCAL_MACHINE = &H80000002
        Dim strvalue = ""
        Dim objReg
        Dim objSWbemServices
        Dim objSWbemLocator

        objSWbemLocator = CreateObject("wbemScripting.SwbemLocator")
        objSWbemServices = objSWbemLocator.ConnectServer(txtpcname, "root\default", txtdomain & "\" & txtusername, txtpassword)
        objReg = objSWbemServices.Get("StdRegProv")

        Try
            strvalue = objReg.GetStringValue(HKEY_LOCAL_MACHINE, strValueKey, strValueName)
        Catch
        End Try
        ' MsgBox(strvalue)
        Return strvalue
    End Function

    Private Sub Label2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Host.Click

    End Sub

End Class








