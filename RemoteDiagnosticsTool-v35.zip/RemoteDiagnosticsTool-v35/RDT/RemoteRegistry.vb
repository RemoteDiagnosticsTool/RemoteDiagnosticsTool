﻿Imports System
Imports Microsoft.Win32
Imports Microsoft.VisualBasic
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Management
Imports System.Runtime.InteropServices
Imports System.Diagnostics.Process
Imports System.IO
Imports System.Net
Imports System.Text.RegularExpressions
Imports System.DirectoryServices
Imports System.Threading
Imports System.Text
Imports System.Security.AccessControl
Imports System.Security.Principal


Public Class RemoteRegistry
    Inherits MetroFramework.Forms.MetroForm

    Public Declare Function WNetAddConnection2 Lib "mpr.dll" Alias "WNetAddConnection2A" (ByRef lpNetResource As NETRESOURCE, ByVal lpPassword As String, ByVal lpUserName As String, ByVal dwFlags As Integer) As Integer
    Public Declare Function WNetCancelConnection2 Lib "mpr" Alias "WNetCancelConnection2A" (ByVal lpName As String, ByVal dwFlags As Integer, ByVal fForce As Integer) As Integer
    Public Const ForceDisconnect As Integer = 1
    Public Const RESOURCETYPE_DISK As Long = &H1

    <Runtime.InteropServices.StructLayout(LayoutKind.Sequential)> Public Structure NETRESOURCE
        Public dwScope As Integer
        Public dwType As Integer
        Public dwDisplayType As Integer
        Public dwUsage As Integer
        Public lpLocalName As String
        Public lpRemoteName As String
        Public lpComment As String
        Public lpProvider As String
    End Structure


    Private Sub RemoteRegistry_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Text = MachineName
        Me.KeyPreview = True
        'Dim ImageList2 As ImageList
        'ImageList2 = New ImageList
        'ImageList3.Images.Add("Explorer", System.Drawing.Icon.ExtractAssociatedIcon("c:\Windows\Explorer.exe"))
        'ImageList2.Images.Add("Regedit", System.Drawing.Icon.ExtractAssociatedIcon("c:\Windows\Regedit.exe"))
    End Sub

    Private Sub RemoteRegistry_KeyDown(ByVal sender As Object, ByVal e As KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.F5 Then
            TreeviewKeys_AddKey_Refresh()
        End If
    End Sub

    Public Sub RetrieveValues()
        Const REG_SZ = 1
        Const REG_EXPAND_SZ = 2
        Const REG_BINARY = 3
        Const REG_DWORD = 4
        Const REG_MULTI_SZ = 7
        Const REG_QWORD = 11

        DataGridViewValues.Rows.Clear()

        On Error Resume Next

        If RegistryBox1.Text <> "" Then

            Me.Cursor = Cursors.WaitCursor

            If RegistryBox1.Text = "LocalMachine" Then
                Dim intRegistryHive As Microsoft.Win32.RegistryHive
                intRegistryHive = Microsoft.Win32.RegistryHive.LocalMachine
                Dim strarray
                Dim objReg
                Dim objSWbemServices
                Dim objSWbemLocator
                Dim arrValueNames = Nothing
                Dim arrValueTypes = Nothing
                Dim strText = Nothing
                Dim strKeyPath As String = Nothing
                Dim i As Integer = Nothing
                Dim strValueName = Nothing
                Dim arrValues = Nothing
                Dim strvalue As String = Nothing
                Dim intValue As String = Nothing

                objSWbemLocator = CreateObject("wbemScripting.SwbemLocator")

                objSWbemLocator.Security_.AuthenticationLevel = 6 'Packet Privacy. 

                objSWbemServices = objSWbemLocator.ConnectServer(txtpcname, "root\default", domain & "\" & username, password)
                objReg = objSWbemServices.Get("StdRegProv")

                strKeyPath = TreeViewKeys.SelectedNode.FullPath
                objReg.EnumValues(intRegistryHive, strKeyPath, arrValueNames, arrValueTypes)

                objReg.GetStringValue(intRegistryHive, strKeyPath, "", strvalue)
                DataGridViewValues.RowTemplate.DefaultCellStyle.ForeColor = Color.DarkRed
                DataGridViewValues.Rows.Add("(Default)", "REG_SZ", strvalue)
                DataGridViewValues.RowTemplate.DefaultCellStyle.ForeColor = Color.Black

                For i = 0 To UBound(arrValueNames)
                    strValueName = Nothing
                    arrValues = Nothing
                    strvalue = Nothing
                    intValue = Nothing

                    strValueName = arrValueNames(i)

                    Select Case arrValueTypes(i)
                        Case REG_SZ
                            objReg.GetStringValue(intRegistryHive, strKeyPath, strValueName, strvalue)
                            'If strValueName = "" Then
                            'strValueName = "(Default)"
                            'End If
                            DataGridViewValues.RowTemplate.DefaultCellStyle.ForeColor = Color.DarkRed
                            DataGridViewValues.Rows.Add(strValueName, "REG_SZ", strvalue)
                            DataGridViewValues.RowTemplate.DefaultCellStyle.ForeColor = Color.Black
                        Case REG_DWORD
                            objReg.GetDWORDValue(intRegistryHive, strKeyPath, strValueName, intValue)
                            Dim p As Long = intValue
                            Dim hex As String = Conversion.Hex(p)
                            DataGridViewValues.RowTemplate.DefaultCellStyle.ForeColor = Color.DarkBlue
                            DataGridViewValues.Rows.Add(strValueName, "REG_DWORD", hex & " (" & intValue & ")")
                            DataGridViewValues.RowTemplate.DefaultCellStyle.ForeColor = Color.Black
                        Case REG_QWORD
                            objReg.GetQWORDValue(intRegistryHive, strKeyPath, strValueName, intValue)
                            Dim p As Long = intValue
                            Dim hex As String = Conversion.Hex(p)
                            DataGridViewValues.RowTemplate.DefaultCellStyle.ForeColor = Color.DarkSlateBlue
                            DataGridViewValues.Rows.Add(strValueName, "REG_QWORD", hex & " (" & intValue & ")")
                            DataGridViewValues.RowTemplate.DefaultCellStyle.ForeColor = Color.Black
                        Case REG_MULTI_SZ
                            objReg.GetMultiStringValue(intRegistryHive, strKeyPath, strValueName, arrValues)
                            Dim S As String = Nothing
                            For Each strvalue In arrValues
                                S &= strvalue & " "
                            Next
                            DataGridViewValues.RowTemplate.DefaultCellStyle.ForeColor = Color.DarkViolet
                            DataGridViewValues.Rows.Add(strValueName, "REG_MULTI_SZ", S)
                            DataGridViewValues.RowTemplate.DefaultCellStyle.ForeColor = Color.Black
                        Case REG_EXPAND_SZ
                            objReg.GetExpandedStringValue(intRegistryHive, strKeyPath, strValueName, strvalue)
                            strvalue = strvalue.ToLower
                            strvalue = strvalue.Replace("c:\windows", "%systemroot%")
                            strvalue = strvalue.Replace("c:\program files (x86)", "%programfiles(x86)%")
                            strvalue = strvalue.Replace("c:\program files", "%programfiles%")
                            strvalue = strvalue.Replace("c:\programdata", "%programdata%")
                            DataGridViewValues.RowTemplate.DefaultCellStyle.ForeColor = Color.DarkOliveGreen
                            DataGridViewValues.Rows.Add(strValueName, "REG_EXPAND_SZ", strvalue)
                            DataGridViewValues.RowTemplate.DefaultCellStyle.ForeColor = Color.Black
                        Case REG_BINARY
                            objReg.GetBinaryValue(intRegistryHive, strKeyPath, strValueName, arrValues)
                            Dim S As String = Nothing
                            For Each strvalue In arrValues
                                Dim p As Integer = (strvalue)
                                Dim hex As String = Conversion.Hex(p)
                                S &= hex & " "
                            Next
                            DataGridViewValues.Rows.Add(strValueName, "REG_BINARY", S)
                    End Select
                Next
            End If

            If RegistryBox1.Text = "CurrentUser" Then
                Dim intRegistryHive As Microsoft.Win32.RegistryHive
                intRegistryHive = Microsoft.Win32.RegistryHive.Users

                Dim strarray
                Dim objReg
                Dim objSWbemServices
                Dim objSWbemLocator
                Dim arrValueNames = Nothing
                Dim arrValueTypes = Nothing
                Dim strText = Nothing
                Dim strKeyPath As String = Nothing
                Dim i As Integer = Nothing
                Dim strValueName = Nothing
                Dim arrValues = Nothing
                Dim strvalue As String = Nothing
                Dim intValue As String = Nothing

                objSWbemLocator = CreateObject("wbemScripting.SwbemLocator")

                objSWbemLocator.Security_.AuthenticationLevel = 6 'Packet Privacy. 

                objSWbemServices = objSWbemLocator.ConnectServer(txtpcname, "root\default", domain & "\" & username, password)
                objReg = objSWbemServices.Get("StdRegProv")

                strKeyPath = SIDKEY & "\" & TreeViewKeys.SelectedNode.FullPath
                objReg.EnumValues(intRegistryHive, strKeyPath, arrValueNames, arrValueTypes)

                objReg.GetStringValue(intRegistryHive, strKeyPath, "", strvalue)
                DataGridViewValues.RowTemplate.DefaultCellStyle.ForeColor = Color.DarkRed
                DataGridViewValues.Rows.Add("(Default)", "REG_SZ", strvalue)
                DataGridViewValues.RowTemplate.DefaultCellStyle.ForeColor = Color.Black

                For i = 0 To UBound(arrValueNames)
                    strValueName = Nothing
                    arrValues = Nothing
                    strvalue = Nothing
                    intValue = Nothing

                    strValueName = arrValueNames(i)

                    Select Case arrValueTypes(i)
                        Case REG_SZ
                            objReg.GetStringValue(intRegistryHive, strKeyPath, strValueName, strvalue)
                            'If strValueName = "" Then
                            'strValueName = "(Default)"
                            'End If
                            DataGridViewValues.RowTemplate.DefaultCellStyle.ForeColor = Color.DarkRed
                            DataGridViewValues.Rows.Add(strValueName, "REG_SZ", strvalue)
                            DataGridViewValues.RowTemplate.DefaultCellStyle.ForeColor = Color.Black
                        Case REG_DWORD
                            objReg.GetDWORDValue(intRegistryHive, strKeyPath, strValueName, intValue)
                            Dim p As Long = intValue
                            Dim hex As String = Conversion.Hex(p)
                            DataGridViewValues.RowTemplate.DefaultCellStyle.ForeColor = Color.DarkBlue
                            DataGridViewValues.Rows.Add(strValueName, "REG_DWORD", hex & " (" & intValue & ")")
                            DataGridViewValues.RowTemplate.DefaultCellStyle.ForeColor = Color.Black
                        Case REG_QWORD
                            objReg.GetQWORDValue(intRegistryHive, strKeyPath, strValueName, intValue)
                            Dim p As Long = intValue
                            Dim hex As String = Conversion.Hex(p)
                            DataGridViewValues.RowTemplate.DefaultCellStyle.ForeColor = Color.DarkSlateBlue
                            DataGridViewValues.Rows.Add(strValueName, "REG_QWORD", hex & " (" & intValue & ")")
                            DataGridViewValues.RowTemplate.DefaultCellStyle.ForeColor = Color.Black
                        Case REG_MULTI_SZ
                            objReg.GetMultiStringValue(intRegistryHive, strKeyPath, strValueName, arrValues)
                            Dim S As String = Nothing
                            For Each strvalue In arrValues
                                S &= strvalue & " "
                            Next
                            DataGridViewValues.RowTemplate.DefaultCellStyle.ForeColor = Color.DarkViolet
                            DataGridViewValues.Rows.Add(strValueName, "REG_MULTI_SZ", S)
                            DataGridViewValues.RowTemplate.DefaultCellStyle.ForeColor = Color.Black
                        Case REG_EXPAND_SZ
                            objReg.GetExpandedStringValue(intRegistryHive, strKeyPath, strValueName, strvalue)
                            strvalue = strvalue.ToLower
                            strvalue = strvalue.Replace("c:\windows", "%systemroot%")
                            strvalue = strvalue.Replace("c:\program files (x86)", "%programfiles(x86)%")
                            strvalue = strvalue.Replace("c:\program files", "%programfiles%")
                            strvalue = strvalue.Replace("c:\programdata", "%programdata%")
                            DataGridViewValues.RowTemplate.DefaultCellStyle.ForeColor = Color.DarkOliveGreen
                            DataGridViewValues.Rows.Add(strValueName, "REG_EXPAND_SZ", strvalue)
                            DataGridViewValues.RowTemplate.DefaultCellStyle.ForeColor = Color.Black
                        Case REG_BINARY
                            objReg.GetBinaryValue(intRegistryHive, strKeyPath, strValueName, arrValues)
                            Dim S As String = Nothing
                            For Each strvalue In arrValues
                                Dim p As Integer = strvalue
                                Dim hex As String = Conversion.Hex(p)
                                S &= hex & " "
                            Next
                            DataGridViewValues.Rows.Add(strValueName, "REG_BINARY", S)
                    End Select
                Next
            End If

            DataGridViewValues.Sort(DataGridViewValues.Columns(0), System.ComponentModel.ListSortDirection.Ascending)

            Me.Cursor = Cursors.Default
        End If
    End Sub

    Private Sub TreeViewKeys_MouseDoubleClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles TreeViewKeys.MouseDoubleClick
        On Error Resume Next
        TreeviewKeysSelectedNode = TreeViewKeys.SelectedNode.FullPath
        ToolStripStatusLabel2.Text = TreeViewKeys.SelectedNode.FullPath
        RetrieveValues()
        TreeViewKeys.SelectedNode.Nodes.Clear()

        If RegistryBox1.Text <> "" Then

            Me.Cursor = Cursors.WaitCursor
            Dim strComputerName As String = txtpcname
            Dim strStringValue As String = ""
            Dim objManagementScope As ManagementScope = Nothing
            Dim objManagementClass As ManagementClass = Nothing
            Dim objManagementBaseObject As ManagementBaseObject = Nothing
            Dim strkey As String
            Dim myKey As String
            Dim myValue As String
            Dim myValue1 As String
            Dim myValue2 As String
            Dim aSubKeys() As String = Nothing
            Dim strkey2 As String = Nothing
            Dim aSubKeys2() As String = Nothing
            Dim i As Integer = Nothing

            If RegistryBox1.Text = "LocalMachine" Then
                Dim intRegistryHive As Microsoft.Win32.RegistryHive
                intRegistryHive = Microsoft.Win32.RegistryHive.LocalMachine
                Dim Strkeypath = TreeViewKeys.SelectedNode.FullPath

                Dim options As ConnectionOptions
                options = New ConnectionOptions()
                Dim computerconnect As String = "\\" & txtpcname & "\root\DEFAULT"
                options.Username = username
                options.Password = password
                options.Timeout = TimeSpan.FromSeconds(30)
                options.Authority = "NTLMDOMAIN:" & domain
                options.Authentication = AuthenticationLevel.PacketPrivacy
                objManagementScope = New ManagementScope(computerconnect, options)

                If objManagementScope.IsConnected = True Then
                Else
                    objManagementScope.Connect()
                End If

                objManagementClass = New ManagementClass("stdRegProv")
                objManagementClass.Scope = objManagementScope
                objManagementBaseObject = objManagementClass.GetMethodParameters("EnumKey")
                objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                objManagementBaseObject.SetPropertyValue("sSubKeyName", Strkeypath)
                aSubKeys = CType(objManagementClass.InvokeMethod("EnumKey", objManagementBaseObject, Nothing).Properties.Item("sNames").Value, String())

                For i = 0 To UBound(aSubKeys)
                    TreeViewKeys.SelectedNode.Nodes.Add(aSubKeys(i), aSubKeys(i), 0)
                Next

                objManagementScope = Nothing
                objManagementBaseObject.Dispose()
                objManagementClass.Dispose()
            End If

            If RegistryBox1.Text = "CurrentUser" Then
                Dim intRegistryHive As Microsoft.Win32.RegistryHive
                intRegistryHive = Microsoft.Win32.RegistryHive.Users
                Dim strKeyPath As String = SIDKEY & "\" & TreeViewKeys.SelectedNode.FullPath

                Dim options As ConnectionOptions
                options = New ConnectionOptions()
                Dim computerconnect As String = "\\" & txtpcname & "\root\DEFAULT"
                options.Username = username
                options.Password = password
                options.Timeout = TimeSpan.FromSeconds(30)
                options.Authority = "NTLMDOMAIN:" & domain
                options.Authentication = AuthenticationLevel.PacketPrivacy
                objManagementScope = New ManagementScope(computerconnect, options)

                If objManagementScope.IsConnected = True Then
                Else
                    objManagementScope.Connect()
                End If

                objManagementClass = New ManagementClass("stdRegProv")
                objManagementClass.Scope = objManagementScope
                objManagementBaseObject = objManagementClass.GetMethodParameters("EnumKey")
                objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath)
                aSubKeys2 = CType(objManagementClass.InvokeMethod("EnumKey", objManagementBaseObject, Nothing).Properties.Item("sNames").Value, String())

                For i = 0 To UBound(aSubKeys2)
                    TreeViewKeys.SelectedNode.Nodes.Add(aSubKeys2(i), aSubKeys2(i), 0)
                Next

                objManagementScope = Nothing
                objManagementBaseObject.Dispose()
                objManagementClass.Dispose()
            End If

            'TreeViewKeys.Sort()
            If TreeViewKeys.SelectedNode.IsExpanded = False Then
                TreeViewKeys.SelectedNode.Expand()
            End If

            Me.Cursor = Cursors.Default
        End If
    End Sub

    Private Sub RegistryBox1_SelectedIndexChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RegistryBox1.SelectedIndexChanged
        On Error Resume Next
        TreeviewKeysSelectedNode = Nothing
        TreeViewKeys.Nodes.Clear()
        DataGridViewValues.Rows.Clear()
        CurrentUserlabel.Text = Nothing
        ToolStripStatusLabel2.Text = ""

        If RegistryBox1.Text <> "" Then

            Me.Cursor = Cursors.WaitCursor
            Dim strComputerName As String = txtpcname
            Dim strStringValue As String = ""
            Dim objManagementScope As ManagementScope = Nothing
            Dim objManagementClass As ManagementClass = Nothing
            Dim objManagementBaseObject As ManagementBaseObject = Nothing
            Dim strkey As String
            Dim myKey As String
            Dim myValue As String
            Dim myValue1 As String
            Dim myValue2 As String
            Dim aSubKeys() As String
            Dim strkey2 As String
            Dim aSubKeys2() As String
            Dim i As Integer = Nothing

            If RegistryBox1.Text = "LocalMachine" Then
                Dim intRegistryHive As Microsoft.Win32.RegistryHive
                intRegistryHive = Microsoft.Win32.RegistryHive.LocalMachine
                Dim Strkeypath = ""

                Dim options As ConnectionOptions
                options = New ConnectionOptions()
                Dim computerconnect As String = "\\" & txtpcname & "\root\DEFAULT"
                options.Username = username
                options.Password = password
                options.Timeout = TimeSpan.FromSeconds(30)
                options.Authority = "NTLMDOMAIN:" & domain
                options.Authentication = AuthenticationLevel.PacketPrivacy
                objManagementScope = New ManagementScope(computerconnect, options)

                If objManagementScope.IsConnected = True Then
                Else
                    objManagementScope.Connect()
                End If

                objManagementClass = New ManagementClass("stdRegProv")
                objManagementClass.Scope = objManagementScope
                objManagementBaseObject = objManagementClass.GetMethodParameters("EnumKey")
                objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                objManagementBaseObject.SetPropertyValue("sSubKeyName", Strkeypath)
                aSubKeys = CType(objManagementClass.InvokeMethod("EnumKey", objManagementBaseObject, Nothing).Properties.Item("sNames").Value, String())

                For i = 0 To UBound(aSubKeys)
                    TreeViewKeys.Nodes.Add(aSubKeys(i), aSubKeys(i), 0)
                Next

                objManagementScope = Nothing
                objManagementBaseObject.Dispose()
                objManagementClass.Dispose()
            End If

            If RegistryBox1.Text = "CurrentUser" Then
                CurrentUserlabel.Text = "= " & LoggedOnUserNameOnly
                Dim intRegistryHive As Microsoft.Win32.RegistryHive
                intRegistryHive = Microsoft.Win32.RegistryHive.Users
                Dim strKeyPath As String = ""

                Dim options As ConnectionOptions
                options = New ConnectionOptions()
                Dim computerconnect As String = "\\" & txtpcname & "\root\DEFAULT"
                options.Username = username
                options.Password = password
                options.Timeout = TimeSpan.FromSeconds(30)
                options.Authority = "NTLMDOMAIN:" & domain
                options.Authentication = AuthenticationLevel.PacketPrivacy
                objManagementScope = New ManagementScope(computerconnect, options)

                If objManagementScope.IsConnected = True Then
                Else
                    objManagementScope.Connect()
                End If

                objManagementClass = New ManagementClass("stdRegProv")
                objManagementClass.Scope = objManagementScope
                objManagementBaseObject = objManagementClass.GetMethodParameters("EnumKey")
                objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                objManagementBaseObject.SetPropertyValue("sSubKeyName", SIDKEY)
                aSubKeys2 = CType(objManagementClass.InvokeMethod("EnumKey", objManagementBaseObject, Nothing).Properties.Item("sNames").Value, String())

                For i = 0 To UBound(aSubKeys2)
                    TreeViewKeys.Nodes.Add(aSubKeys2(i), aSubKeys2(i), 0)
                Next
            End If

            objManagementScope = Nothing
            objManagementBaseObject.Dispose()
            objManagementClass.Dispose()
        End If

        Me.Cursor = Cursors.Default
    End Sub

    Private Sub ClearRegistryLists_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClearRegistryLists.Click
        RegistryBox1.Text = Nothing
        TreeViewKeys.Nodes.Clear()
        TreeviewKeysSelectedNode = Nothing
        CurrentUserlabel.Text = Nothing
        DataGridViewValues.Rows.Clear()
        ToolStripStatusLabel2.Text = ""
    End Sub

    Private Sub ADD_Key_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Add_Key.Click
        On Error Resume Next

        If RegistryBox1.Text <> "" Then

            Dim message, title, defaultValue As String
            Dim InputValue As String = Nothing
            message = "Enter the new key name"
            title = "Create new key"
            defaultValue = ""   ' Set default value.
            InputValue = InputBox(message, title, defaultValue)
            If InputValue = "" Then Exit Sub

            Me.Cursor = Cursors.WaitCursor

            If RegistryBox1.Text = "LocalMachine" Then
                Dim intRegistryHive As Microsoft.Win32.RegistryHive
                intRegistryHive = Microsoft.Win32.RegistryHive.LocalMachine
                Dim objReg
                Dim objSWbemServices
                Dim objSWbemLocator
                Dim strKeyPath As String = Nothing
                objSWbemLocator = CreateObject("wbemScripting.SwbemLocator")
                objSWbemLocator.Security_.AuthenticationLevel = 6 'Packet Privacy.
                objSWbemServices = objSWbemLocator.ConnectServer(txtpcname, "root\default", domain & "\" & username, password)
                objReg = objSWbemServices.Get("StdRegProv")
                strKeyPath = TreeViewKeys.SelectedNode.FullPath & "\" & InputValue
                objReg.CreateKey(intRegistryHive, strKeyPath)
            End If

            If RegistryBox1.Text = "CurrentUser" Then
                Dim intRegistryHive As Microsoft.Win32.RegistryHive
                intRegistryHive = Microsoft.Win32.RegistryHive.Users
                Dim objReg
                Dim objSWbemServices
                Dim objSWbemLocator
                Dim strKeyPath As String = Nothing
                objSWbemLocator = CreateObject("wbemScripting.SwbemLocator")
                objSWbemLocator.Security_.AuthenticationLevel = 6 'Packet Privacy.
                objSWbemServices = objSWbemLocator.ConnectServer(txtpcname, "root\default", domain & "\" & username, password)
                objReg = objSWbemServices.Get("StdRegProv")
                strKeyPath = SIDKEY & "\" & TreeViewKeys.SelectedNode.FullPath & "\" & InputValue
                objReg.CreateKey(intRegistryHive, strKeyPath)
            End If

            TreeviewKeys_AddKey_Refresh()

            Me.Cursor = Cursors.Default
        End If

    End Sub

    Private Sub TreeviewKeys_AddKey_Refresh()
        On Error Resume Next
        TreeViewKeys.SelectedNode.Nodes.Clear()
        RetrieveValues()

        If RegistryBox1.Text <> "" Then

            Me.Cursor = Cursors.WaitCursor
            Dim strComputerName As String = txtpcname
            Dim strStringValue As String = ""
            Dim objManagementScope As ManagementScope = Nothing
            Dim objManagementClass As ManagementClass = Nothing
            Dim objManagementBaseObject As ManagementBaseObject = Nothing
            Dim strkey As String
            Dim myKey As String
            Dim myValue As String
            Dim myValue1 As String
            Dim myValue2 As String
            Dim aSubKeys() As String = Nothing
            Dim strkey2 As String = Nothing
            Dim aSubKeys2() As String = Nothing
            Dim i As Integer = Nothing

            If RegistryBox1.Text = "LocalMachine" Then
                Dim intRegistryHive As Microsoft.Win32.RegistryHive
                intRegistryHive = Microsoft.Win32.RegistryHive.LocalMachine
                Dim Strkeypath = TreeViewKeys.SelectedNode.FullPath

                Dim options As ConnectionOptions
                options = New ConnectionOptions()
                Dim computerconnect As String = "\\" & txtpcname & "\root\DEFAULT"
                options.Username = username
                options.Password = password
                options.Timeout = TimeSpan.FromSeconds(30)
                options.Authority = "NTLMDOMAIN:" & domain
                options.Authentication = AuthenticationLevel.PacketPrivacy
                objManagementScope = New ManagementScope(computerconnect, options)

                If objManagementScope.IsConnected = True Then
                Else
                    objManagementScope.Connect()
                End If

                objManagementClass = New ManagementClass("stdRegProv")
                objManagementClass.Scope = objManagementScope
                objManagementBaseObject = objManagementClass.GetMethodParameters("EnumKey")
                objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                objManagementBaseObject.SetPropertyValue("sSubKeyName", Strkeypath)
                aSubKeys = CType(objManagementClass.InvokeMethod("EnumKey", objManagementBaseObject, Nothing).Properties.Item("sNames").Value, String())

                For i = 0 To UBound(aSubKeys)
                    TreeViewKeys.SelectedNode.Nodes.Add(aSubKeys(i), aSubKeys(i), 0)
                Next

                objManagementScope = Nothing
                objManagementBaseObject.Dispose()
                objManagementClass.Dispose()
            End If

            If RegistryBox1.Text = "CurrentUser" Then
                Dim intRegistryHive As Microsoft.Win32.RegistryHive
                intRegistryHive = Microsoft.Win32.RegistryHive.Users
                Dim strKeyPath As String = SIDKEY & "\" & TreeViewKeys.SelectedNode.FullPath

                Dim options As ConnectionOptions
                options = New ConnectionOptions()
                Dim computerconnect As String = "\\" & txtpcname & "\root\DEFAULT"
                options.Username = username
                options.Password = password
                options.Timeout = TimeSpan.FromSeconds(30)
                options.Authority = "NTLMDOMAIN:" & domain
                options.Authentication = AuthenticationLevel.PacketPrivacy
                objManagementScope = New ManagementScope(computerconnect, options)

                If objManagementScope.IsConnected = True Then
                Else
                    objManagementScope.Connect()
                End If

                objManagementClass = New ManagementClass("stdRegProv")
                objManagementClass.Scope = objManagementScope
                objManagementBaseObject = objManagementClass.GetMethodParameters("EnumKey")
                objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath)
                aSubKeys2 = CType(objManagementClass.InvokeMethod("EnumKey", objManagementBaseObject, Nothing).Properties.Item("sNames").Value, String())

                For i = 0 To UBound(aSubKeys2)
                    TreeViewKeys.SelectedNode.Nodes.Add(aSubKeys2(i), aSubKeys2(i), 0)
                Next

                objManagementScope = Nothing
                objManagementBaseObject.Dispose()
                objManagementClass.Dispose()
            End If

            'TreeViewKeys.Sort()
            If TreeViewKeys.SelectedNode.IsExpanded = False Then
                TreeViewKeys.SelectedNode.Expand()
            End If

            Me.Cursor = Cursors.Default
        End If

    End Sub

    Private Sub TreeviewKeys_DeleteKey_Refresh()
        On Error Resume Next
        TreeViewKeys.SelectedNode.Parent.Nodes.Clear()
        RetrieveValues()

        If RegistryBox1.Text <> "" Then

            Me.Cursor = Cursors.WaitCursor
            Dim strComputerName As String = txtpcname
            Dim strStringValue As String = ""
            Dim objManagementScope As ManagementScope = Nothing
            Dim objManagementClass As ManagementClass = Nothing
            Dim objManagementBaseObject As ManagementBaseObject = Nothing
            Dim strkey As String
            Dim myKey As String
            Dim myValue As String
            Dim myValue1 As String
            Dim myValue2 As String
            Dim aSubKeys() As String = Nothing
            Dim strkey2 As String = Nothing
            Dim aSubKeys2() As String = Nothing
            Dim i As Integer = Nothing

            If RegistryBox1.Text = "LocalMachine" Then
                Dim intRegistryHive As Microsoft.Win32.RegistryHive
                intRegistryHive = Microsoft.Win32.RegistryHive.LocalMachine
                Dim Strkeypath = TreeViewKeys.SelectedNode.FullPath

                Dim options As ConnectionOptions
                options = New ConnectionOptions()
                Dim computerconnect As String = "\\" & txtpcname & "\root\DEFAULT"
                options.Username = username
                options.Password = password
                options.Timeout = TimeSpan.FromSeconds(30)
                options.Authority = "NTLMDOMAIN:" & domain
                options.Authentication = AuthenticationLevel.PacketPrivacy
                objManagementScope = New ManagementScope(computerconnect, options)

                If objManagementScope.IsConnected = True Then
                Else
                    objManagementScope.Connect()
                End If

                objManagementClass = New ManagementClass("stdRegProv")
                objManagementClass.Scope = objManagementScope
                objManagementBaseObject = objManagementClass.GetMethodParameters("EnumKey")
                objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                objManagementBaseObject.SetPropertyValue("sSubKeyName", Strkeypath)
                aSubKeys = CType(objManagementClass.InvokeMethod("EnumKey", objManagementBaseObject, Nothing).Properties.Item("sNames").Value, String())

                For i = 0 To UBound(aSubKeys)
                    TreeViewKeys.SelectedNode.Nodes.Add(aSubKeys(i), aSubKeys(i), 0)
                Next

                objManagementScope = Nothing
                objManagementBaseObject.Dispose()
                objManagementClass.Dispose()
            End If

            If RegistryBox1.Text = "CurrentUser" Then
                Dim intRegistryHive As Microsoft.Win32.RegistryHive
                intRegistryHive = Microsoft.Win32.RegistryHive.Users
                Dim strKeyPath As String = SIDKEY & "\" & TreeViewKeys.SelectedNode.FullPath

                Dim options As ConnectionOptions
                options = New ConnectionOptions()
                Dim computerconnect As String = "\\" & txtpcname & "\root\DEFAULT"
                options.Username = username
                options.Password = password
                options.Timeout = TimeSpan.FromSeconds(30)
                options.Authority = "NTLMDOMAIN:" & domain
                options.Authentication = AuthenticationLevel.PacketPrivacy
                objManagementScope = New ManagementScope(computerconnect, options)

                If objManagementScope.IsConnected = True Then
                Else
                    objManagementScope.Connect()
                End If

                objManagementClass = New ManagementClass("stdRegProv")
                objManagementClass.Scope = objManagementScope
                objManagementBaseObject = objManagementClass.GetMethodParameters("EnumKey")
                objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath)
                aSubKeys2 = CType(objManagementClass.InvokeMethod("EnumKey", objManagementBaseObject, Nothing).Properties.Item("sNames").Value, String())

                For i = 0 To UBound(aSubKeys2)
                    TreeViewKeys.SelectedNode.Nodes.Add(aSubKeys2(i), aSubKeys2(i), 0)
                Next

                objManagementScope = Nothing
                objManagementBaseObject.Dispose()
                objManagementClass.Dispose()
            End If

            'TreeViewKeys.Sort()
            If TreeViewKeys.SelectedNode.IsExpanded = False Then
                TreeViewKeys.SelectedNode.Expand()
            End If

            Me.Cursor = Cursors.Default
        End If

    End Sub

    Private Sub TreeViewkeys_NodeMouseClick(ByVal sender As Object, ByVal e As TreeNodeMouseClickEventArgs) Handles TreeViewKeys.NodeMouseClick
        If e.Button = MouseButtons.Right Then
            TreeViewKeys.SelectedNode = e.Node
            TreeviewKeysSelectedNode = TreeViewKeys.SelectedNode.FullPath
            ToolStripStatusLabel2.Text = TreeViewKeys.SelectedNode.FullPath
        End If
        If e.Button = MouseButtons.Left Then
            TreeViewKeys.SelectedNode = e.Node
            TreeviewKeysSelectedNode = TreeViewKeys.SelectedNode.FullPath
            ToolStripStatusLabel2.Text = TreeViewKeys.SelectedNode.FullPath
        End If
    End Sub

    Private Sub DeleteWholeKey_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Delete_Key.Click
        If RegistryBox1.Text <> "" Then

            Dim response As MsgBoxResult
            response = MsgBox("Are you really sure you want to delete this whole registry key branch ?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "This can be dangerous, do you know what your doing!")
            If response = MsgBoxResult.Yes Then
                Me.Cursor = Cursors.WaitCursor
                If RegistryBox1.Text = "LocalMachine" Then
                    Dim processID As UInteger = 0
                    Dim ExitCode = 1
                    Try
                        Dim connOptions As New Management.ConnectionOptions()
                        connOptions.Username = username
                        connOptions.Password = password
                        connOptions.Timeout = TimeSpan.FromSeconds(30)
                        connOptions.Authority = "NTLMDOMAIN:" & domain
                        connOptions.EnablePrivileges = True
                        connOptions.Authentication = AuthenticationLevel.PacketPrivacy
                        connOptions.Impersonation = ImpersonationLevel.Impersonate
                        connOptions.EnablePrivileges = True
                        Dim manScope As New Management.ManagementScope([String].Format("\\{0}\ROOT\CIMV2", txtpcname), connOptions)

                        Try
                            manScope.Connect()
                        Catch
                            MsgBox("Couldn't connect to remote PC.")
                            Exit Try
                        End Try
                        Dim objectGetOptions As New Management.ObjectGetOptions()
                        Dim managementPath As New Management.ManagementPath("Win32_Process")
                        Using processClass As New Management.ManagementClass(manScope, managementPath, objectGetOptions)
                            Using inParams As Management.ManagementBaseObject = processClass.GetMethodParameters("Create")
                                inParams("CommandLine") = "REG.EXE DELETE " & Chr(34) & "HKLM\" & TreeViewKeys.SelectedNode.FullPath & Chr(34) & " /f"
                                Using outParams As Management.ManagementBaseObject = processClass.InvokeMethod("Create", inParams, Nothing)
                                    If CUInt(outParams("returnValue")) <> 0 Then
                                        Me.Cursor = Cursors.Default
                                        MsgBox("Delete Failed...")
                                        Exit Sub
                                    Else
                                        'MsgBox("Install Started at : " & Now & " : with a process Id of : " & CUInt(outParams("processId")))
                                        processID = CUInt(outParams("processId"))
                                    End If
                                End Using
                            End Using
                        End Using
                    Catch
                    End Try
                End If

                If RegistryBox1.Text = "CurrentUser" Then
                    Dim processID As UInteger = 0
                    Dim ExitCode = 1
                    Try
                        Dim connOptions As New Management.ConnectionOptions()
                        connOptions.Username = username
                        connOptions.Password = password
                        connOptions.Timeout = TimeSpan.FromSeconds(30)
                        connOptions.Authority = "NTLMDOMAIN:" & domain
                        connOptions.EnablePrivileges = True
                        connOptions.Authentication = AuthenticationLevel.PacketPrivacy
                        connOptions.Impersonation = ImpersonationLevel.Impersonate
                        connOptions.EnablePrivileges = True
                        Dim manScope As New Management.ManagementScope([String].Format("\\{0}\ROOT\CIMV2", txtpcname), connOptions)

                        Try
                            manScope.Connect()
                        Catch
                            MsgBox("Couldn't connect to remote PC.")
                            Exit Try
                        End Try
                        Dim objectGetOptions As New Management.ObjectGetOptions()
                        Dim managementPath As New Management.ManagementPath("Win32_Process")
                        Using processClass As New Management.ManagementClass(manScope, managementPath, objectGetOptions)
                            Using inParams As Management.ManagementBaseObject = processClass.GetMethodParameters("Create")
                                inParams("CommandLine") = "REG.EXE DELETE " & Chr(34) & "HKU\" & SIDKEY & "\" & TreeViewKeys.SelectedNode.FullPath & Chr(34) & " /f"
                                Using outParams As Management.ManagementBaseObject = processClass.InvokeMethod("Create", inParams, Nothing)
                                    If CUInt(outParams("returnValue")) <> 0 Then
                                        Me.Cursor = Cursors.Default
                                        MsgBox("Delete Failed...")
                                        Exit Sub
                                    Else
                                        'MsgBox("Install Started at : " & Now & " : with a process Id of : " & CUInt(outParams("processId")))
                                        processID = CUInt(outParams("processId"))
                                    End If
                                End Using
                            End Using
                        End Using
                    Catch
                    End Try
                End If
                TreeviewKeys_DeleteKey_Refresh()
                Me.Cursor = Cursors.Default

            ElseIf response = MsgBoxResult.No Then
                Exit Sub
            End If
        End If

    End Sub

    Private Sub Rename_Key_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Rename_Key.Click
        If RegistryBox1.Text <> "" Then

            Dim response As MsgBoxResult
            response = MsgBox("Are you really sure you want to rename this registry key ?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "This can be dangerous and overwrite existing keys!")
            If response = MsgBoxResult.Yes Then
                Dim message, title, defaultValue As String
                Dim InputValue As String = Nothing
                message = "Enter the key name required"
                title = "Rename key"
                defaultValue = ""   ' Set default value.
                InputValue = InputBox(message, title, defaultValue)
                If InputValue = "" Then Exit Sub

                Me.Cursor = Cursors.WaitCursor

                Dim OldKey As String = TreeViewKeys.SelectedNode.FullPath
                Dim NewKey As String = TreeViewKeys.SelectedNode.Parent.FullPath & "\" & InputValue

                If RegistryBox1.Text = "LocalMachine" Then
                    Dim processID As UInteger = 0
                    Dim ExitCode = 1
                    Try
                        Dim connOptions As New Management.ConnectionOptions()
                        connOptions.Username = username
                        connOptions.Password = password
                        connOptions.Timeout = TimeSpan.FromSeconds(30)
                        connOptions.Authority = "NTLMDOMAIN:" & domain
                        connOptions.EnablePrivileges = True
                        connOptions.Authentication = AuthenticationLevel.PacketPrivacy
                        connOptions.Impersonation = ImpersonationLevel.Impersonate
                        connOptions.EnablePrivileges = True
                        Dim manScope As New Management.ManagementScope([String].Format("\\{0}\ROOT\CIMV2", txtpcname), connOptions)

                        Try
                            manScope.Connect()
                        Catch
                            MsgBox("Couldn't connect to remote PC.")
                            Exit Try
                        End Try
                        Dim objectGetOptions As New Management.ObjectGetOptions()
                        Dim managementPath As New Management.ManagementPath("Win32_Process")
                        Using processClass As New Management.ManagementClass(manScope, managementPath, objectGetOptions)
                            Using inParams As Management.ManagementBaseObject = processClass.GetMethodParameters("Create")
                                inParams("CommandLine") = "REG.EXE COPY " & Chr(34) & "HKLM\" & OldKey & Chr(34) & " " & Chr(34) & "HKLM\" & NewKey & Chr(34) & " /s /f"
                                Using outParams As Management.ManagementBaseObject = processClass.InvokeMethod("Create", inParams, Nothing)
                                    If CUInt(outParams("returnValue")) <> 0 Then
                                        Me.Cursor = Cursors.Default
                                        MsgBox("Copy HKLM Key Failed...")
                                        Exit Sub
                                    Else
                                        'MsgBox("Install Started at : " & Now & " : with a process Id of : " & CUInt(outParams("processId")))
                                        processID = CUInt(outParams("processId"))
                                    End If
                                End Using
                            End Using
                        End Using
                    Catch
                    End Try
                End If

                If RegistryBox1.Text = "CurrentUser" Then
                    Dim processID As UInteger = 0
                    Dim ExitCode = 1
                    Try
                        Dim connOptions As New Management.ConnectionOptions()
                        connOptions.Username = username
                        connOptions.Password = password
                        connOptions.Timeout = TimeSpan.FromSeconds(30)
                        connOptions.Authority = "NTLMDOMAIN:" & domain
                        connOptions.EnablePrivileges = True
                        connOptions.Authentication = AuthenticationLevel.PacketPrivacy
                        connOptions.Impersonation = ImpersonationLevel.Impersonate
                        connOptions.EnablePrivileges = True
                        Dim manScope As New Management.ManagementScope([String].Format("\\{0}\ROOT\CIMV2", txtpcname), connOptions)

                        Try
                            manScope.Connect()
                        Catch
                            MsgBox("Couldn't connect to remote PC.")
                            Exit Try
                        End Try
                        Dim objectGetOptions As New Management.ObjectGetOptions()
                        Dim managementPath As New Management.ManagementPath("Win32_Process")
                        Using processClass As New Management.ManagementClass(manScope, managementPath, objectGetOptions)
                            Using inParams As Management.ManagementBaseObject = processClass.GetMethodParameters("Create")
                                inParams("CommandLine") = "REG.EXE COPY " & Chr(34) & "HKU\" & SIDKEY & "\" & OldKey & Chr(34) & " " & Chr(34) & "HKU\" & SIDKEY & "\" & NewKey & Chr(34) & " /s /f"
                                Using outParams As Management.ManagementBaseObject = processClass.InvokeMethod("Create", inParams, Nothing)
                                    If CUInt(outParams("returnValue")) <> 0 Then
                                        Me.Cursor = Cursors.Default
                                        MsgBox("Copy HKU Key Failed...")
                                        Exit Sub
                                    Else
                                        'MsgBox("Install Started at : " & Now & " : with a process Id of : " & CUInt(outParams("processId")))
                                        processID = CUInt(outParams("processId"))
                                    End If
                                End Using
                            End Using
                        End Using
                    Catch
                    End Try
                End If

                Thread.Sleep(3000)

                If RegistryBox1.Text = "LocalMachine" Then
                    Dim processID As UInteger = 0
                    Dim ExitCode = 1
                    Try
                        Dim connOptions As New Management.ConnectionOptions()
                        connOptions.Username = username
                        connOptions.Password = password
                        connOptions.Timeout = TimeSpan.FromSeconds(30)
                        connOptions.Authority = "NTLMDOMAIN:" & domain
                        connOptions.EnablePrivileges = True
                        connOptions.Authentication = AuthenticationLevel.PacketPrivacy
                        connOptions.Impersonation = ImpersonationLevel.Impersonate
                        connOptions.EnablePrivileges = True
                        Dim manScope As New Management.ManagementScope([String].Format("\\{0}\ROOT\CIMV2", txtpcname), connOptions)

                        Try
                            manScope.Connect()
                        Catch
                            MsgBox("Couldn't connect to remote PC.")
                            Exit Try
                        End Try
                        Dim objectGetOptions As New Management.ObjectGetOptions()
                        Dim managementPath As New Management.ManagementPath("Win32_Process")
                        Using processClass As New Management.ManagementClass(manScope, managementPath, objectGetOptions)
                            Using inParams As Management.ManagementBaseObject = processClass.GetMethodParameters("Create")
                                inParams("CommandLine") = "REG.EXE DELETE " & Chr(34) & "HKLM\" & TreeViewKeys.SelectedNode.FullPath & Chr(34) & " /f"
                                Using outParams As Management.ManagementBaseObject = processClass.InvokeMethod("Create", inParams, Nothing)
                                    If CUInt(outParams("returnValue")) <> 0 Then
                                        Me.Cursor = Cursors.Default
                                        MsgBox("Delete Failed...")
                                        Exit Sub
                                    Else
                                        'MsgBox("Install Started at : " & Now & " : with a process Id of : " & CUInt(outParams("processId")))
                                        processID = CUInt(outParams("processId"))
                                    End If
                                End Using
                            End Using
                        End Using
                    Catch
                    End Try
                End If

                If RegistryBox1.Text = "CurrentUser" Then
                    Dim processID As UInteger = 0
                    Dim ExitCode = 1
                    Try
                        Dim connOptions As New Management.ConnectionOptions()
                        connOptions.Username = username
                        connOptions.Password = password
                        connOptions.Timeout = TimeSpan.FromSeconds(30)
                        connOptions.Authority = "NTLMDOMAIN:" & domain
                        connOptions.EnablePrivileges = True
                        connOptions.Authentication = AuthenticationLevel.PacketPrivacy
                        connOptions.Impersonation = ImpersonationLevel.Impersonate
                        connOptions.EnablePrivileges = True
                        Dim manScope As New Management.ManagementScope([String].Format("\\{0}\ROOT\CIMV2", txtpcname), connOptions)

                        Try
                            manScope.Connect()
                        Catch
                            MsgBox("Couldn't connect to remote PC.")
                            Exit Try
                        End Try
                        Dim objectGetOptions As New Management.ObjectGetOptions()
                        Dim managementPath As New Management.ManagementPath("Win32_Process")
                        Using processClass As New Management.ManagementClass(manScope, managementPath, objectGetOptions)
                            Using inParams As Management.ManagementBaseObject = processClass.GetMethodParameters("Create")
                                inParams("CommandLine") = "REG.EXE DELETE " & Chr(34) & "HKU\" & SIDKEY & "\" & TreeViewKeys.SelectedNode.FullPath & Chr(34) & " /f"
                                Using outParams As Management.ManagementBaseObject = processClass.InvokeMethod("Create", inParams, Nothing)
                                    If CUInt(outParams("returnValue")) <> 0 Then
                                        Me.Cursor = Cursors.Default
                                        MsgBox("Delete Failed...")
                                        Exit Sub
                                    Else
                                        'MsgBox("Install Started at : " & Now & " : with a process Id of : " & CUInt(outParams("processId")))
                                        processID = CUInt(outParams("processId"))
                                    End If
                                End Using
                            End Using
                        End Using
                    Catch
                    End Try
                End If

                TreeviewKeys_DeleteKey_Refresh()
                Me.Cursor = Cursors.Default

            ElseIf response = MsgBoxResult.No Then
                Exit Sub
            End If

        End If

    End Sub

    Private Sub Copy_Key_FullPath_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Copy_Key_FullPath.Click
        If RegistryBox1.Text = "" Then
            Exit Sub
        End If
        If RegistryBox1.Text = "LocalMachine" Then
            Try
                Clipboard.SetText(MachineName & "\HKLM\" & TreeviewKeysSelectedNode)
            Catch ex As Exception
            End Try
        End If
        If RegistryBox1.Text = "CurrentUser" Then
            Try
                Clipboard.SetText(MachineName & "\HKU\" & SIDKEY & "\" & TreeviewKeysSelectedNode)
            Catch ex As Exception
            End Try
        End If
    End Sub

    Private Sub CopyKeyName_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CopyKeyName.Click
        If RegistryBox1.Text = "" Then
            Exit Sub
        End If
        Try
            Clipboard.SetText(TreeViewKeys.SelectedNode.Name)
        Catch ex As Exception
        End Try
    End Sub

    Private Sub Export_Key_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Export_Key.Click
        If RegistryBox1.Text <> "" Then

            MapDrive(username, password, domain, txtpcname)
            Dim fullPath As String = "\\" & txtpcname & "\c$\Program Files\RDT"
            Directory.CreateDirectory(fullPath)

            Me.Cursor = Cursors.WaitCursor

            If RegistryBox1.Text = "LocalMachine" Then
                Dim processID As UInteger = 0
                Dim ExitCode = 1
                Try
                    Dim connOptions As New Management.ConnectionOptions()
                    connOptions.Username = username
                    connOptions.Password = password
                    connOptions.Timeout = TimeSpan.FromSeconds(30)
                    connOptions.Authority = "NTLMDOMAIN:" & domain
                    connOptions.EnablePrivileges = True
                    connOptions.Authentication = AuthenticationLevel.PacketPrivacy
                    connOptions.Impersonation = ImpersonationLevel.Impersonate
                    connOptions.EnablePrivileges = True
                    Dim manScope As New Management.ManagementScope([String].Format("\\{0}\ROOT\CIMV2", txtpcname), connOptions)

                    Try
                        manScope.Connect()
                    Catch
                        MsgBox("Couldn't connect to remote PC.")
                        Exit Try
                    End Try
                    Dim objectGetOptions As New Management.ObjectGetOptions()
                    Dim managementPath As New Management.ManagementPath("Win32_Process")
                    Using processClass As New Management.ManagementClass(manScope, managementPath, objectGetOptions)
                        Using inParams As Management.ManagementBaseObject = processClass.GetMethodParameters("Create")
                            inParams("CommandLine") = "REG.EXE EXPORT " & Chr(34) & "HKLM\" & TreeViewKeys.SelectedNode.FullPath & Chr(34) & " " & Chr(34) & "C:\Program Files\RDT\Export.reg" & Chr(34) & " /y"
                            Using outParams As Management.ManagementBaseObject = processClass.InvokeMethod("Create", inParams, Nothing)
                                If CUInt(outParams("returnValue")) <> 0 Then
                                    Me.Cursor = Cursors.Default
                                    MsgBox("Export Failed...")
                                    Exit Sub
                                Else
                                    'MsgBox("Install Started at : " & Now & " : with a process Id of : " & CUInt(outParams("processId")))
                                    processID = CUInt(outParams("processId"))
                                End If
                            End Using
                        End Using
                    End Using
                Catch
                End Try
            End If

            If RegistryBox1.Text = "CurrentUser" Then
                Dim processID As UInteger = 0
                Dim ExitCode = 1
                Try
                    Dim connOptions As New Management.ConnectionOptions()
                    connOptions.Username = username
                    connOptions.Password = password
                    connOptions.Timeout = TimeSpan.FromSeconds(30)
                    connOptions.Authority = "NTLMDOMAIN:" & domain
                    connOptions.EnablePrivileges = True
                    connOptions.Authentication = AuthenticationLevel.PacketPrivacy
                    connOptions.Impersonation = ImpersonationLevel.Impersonate
                    connOptions.EnablePrivileges = True
                    Dim manScope As New Management.ManagementScope([String].Format("\\{0}\ROOT\CIMV2", txtpcname), connOptions)

                    Try
                        manScope.Connect()
                    Catch
                        MsgBox("Couldn't connect to remote PC.")
                        Exit Try
                    End Try
                    Dim objectGetOptions As New Management.ObjectGetOptions()
                    Dim managementPath As New Management.ManagementPath("Win32_Process")
                    Using processClass As New Management.ManagementClass(manScope, managementPath, objectGetOptions)
                        Using inParams As Management.ManagementBaseObject = processClass.GetMethodParameters("Create")
                            MsgBox(SIDKEY)
                            MsgBox(TreeViewKeys.SelectedNode.FullPath)
                            inParams("CommandLine") = "REG.EXE EXPORT " & Chr(34) & "HKU\" & SIDKEY & "\" & TreeViewKeys.SelectedNode.FullPath & Chr(34) & " " & Chr(34) & "C:\Program Files\RDT\Export.reg" & Chr(34) & " /y"
                            Using outParams As Management.ManagementBaseObject = processClass.InvokeMethod("Create", inParams, Nothing)
                                If CUInt(outParams("returnValue")) <> 0 Then
                                    Me.Cursor = Cursors.Default
                                    MsgBox("Export Failed...")
                                    Exit Sub
                                Else
                                    'MsgBox("Install Started at : " & Now & " : with a process Id of : " & CUInt(outParams("processId")))
                                    processID = CUInt(outParams("processId"))
                                End If
                            End Using
                        End Using
                    End Using
                Catch
                End Try
            End If

            Thread.Sleep(3000)

            Try
                MapDrive(username, password, domain, txtpcname)
                Dim objShell = CreateObject("Wscript.Shell")
                Dim Exportreg As String = "Notepad.exe \\" & txtpcname & "\c$\Program Files\RDT\Export.reg"
                objShell.run(Exportreg)
            Catch ex As Exception
            End Try

            Me.Cursor = Cursors.Default

        End If
    End Sub

    Public Function MapDrive(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String) As Boolean
        Dim nr As NETRESOURCE
        Dim strUsername As String
        Dim strPassword As String
        strUsername = domain & "\" & username
        strPassword = password

        Me.Cursor = Cursors.WaitCursor

        Try
            Dim oNet = CreateObject("WScript.Network")
            Try
                oNet.RemoveNetworkDrive("\\" & txtpcname & "\ipc$", True, False)
                oNet.RemoveNetworkDrive("\\" & txtpcname & "\admin$", True, False)
            Catch
            End Try
            nr = New NETRESOURCE
            nr.lpRemoteName = "\\" & txtpcname & "\Admin$"
            nr.lpLocalName = Nothing
            nr.dwType = RESOURCETYPE_DISK

            Dim result As Integer
            result = WNetAddConnection2(nr, strPassword, strUsername, 0)

            If result = 0 Then
                Me.Cursor = Cursors.Default
                Return True
            Else
                Me.Cursor = Cursors.Default
                Return False
            End If
        Catch ex As Exception
        End Try

        Me.Cursor = Cursors.Default

    End Function

    Private Sub AddStringValue1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddStringValue1.Click
        If RegistryBox1.Text <> "" Then

            AddSTRINGdialog.AddSTRINGName.Text = ""
            AddSTRINGdialog.AddSTRINGdata.Text = ""
            AddSTRINGdialog.ShowDialog()
            If AddSTRINGdialog.DialogResult = System.Windows.Forms.DialogResult.Cancel Then
                Exit Sub
            End If
            If AddSTRINGdialog.DialogResult = System.Windows.Forms.DialogResult.OK Then

                Dim InputValue1 As String = AddSTRINGdialog.AddSTRINGName.Text
                Dim InputValue2 As String = AddSTRINGdialog.AddSTRINGdata.Text
                If InputValue2 = "" Then Exit Sub

                Me.Cursor = Cursors.WaitCursor

                If RegistryBox1.Text = "LocalMachine" Then
                    Dim intRegistryHive As Microsoft.Win32.RegistryHive
                    intRegistryHive = Microsoft.Win32.RegistryHive.LocalMachine
                    Dim objReg
                    Dim objSWbemServices
                    Dim objSWbemLocator
                    Dim strKeyPath As String = Nothing
                    objSWbemLocator = CreateObject("wbemScripting.SwbemLocator")
                    objSWbemLocator.Security_.AuthenticationLevel = 6 'Packet Privacy.
                    objSWbemServices = objSWbemLocator.ConnectServer(txtpcname, "root\default", domain & "\" & username, password)
                    objReg = objSWbemServices.Get("StdRegProv")
                    strKeyPath = TreeViewKeys.SelectedNode.FullPath
                    objReg.SetStringValue(intRegistryHive, strKeyPath, InputValue1, InputValue2)
                End If

                If RegistryBox1.Text = "CurrentUser" Then
                    Dim intRegistryHive As Microsoft.Win32.RegistryHive
                    intRegistryHive = Microsoft.Win32.RegistryHive.Users
                    Dim objReg
                    Dim objSWbemServices
                    Dim objSWbemLocator
                    Dim strKeyPath As String = Nothing
                    objSWbemLocator = CreateObject("wbemScripting.SwbemLocator")
                    objSWbemLocator.Security_.AuthenticationLevel = 6 'Packet Privacy.
                    objSWbemServices = objSWbemLocator.ConnectServer(txtpcname, "root\default", domain & "\" & username, password)
                    objReg = objSWbemServices.Get("StdRegProv")
                    strKeyPath = SIDKEY & "\" & TreeViewKeys.SelectedNode.FullPath
                    objReg.SetStringValue(intRegistryHive, strKeyPath, InputValue1, InputValue2)
                End If

                TreeviewKeys_AddKey_Refresh()
                Me.Cursor = Cursors.Default
            End If
        End If
    End Sub

    Private Sub AddBinaryValue1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddBinaryValue1.Click
        If RegistryBox1.Text <> "" Then

            Dim message, title, defaultValue As String
            Dim InputValue1 As String = Nothing
            message = "Enter the new binary name"
            title = "New Binary"
            defaultValue = ""   ' Set default value.
            InputValue1 = InputBox(message, title, defaultValue)
            If InputValue1 = "" Then Exit Sub

            Dim InputValue2 As String = Nothing
            Dim strvalue
            message = "Enter the new binary value"
            title = "New Binary"
            defaultValue = ""   ' Set default value.
            InputValue2 = InputBox(message, title, defaultValue)
            If InputValue2 = "" Then Exit Sub
            Dim hexarray = Split(InputValue2, " ")
            Dim list As New List(Of Byte)
            For Each strvalue In hexarray
                Dim dec As Byte = (CInt("&H" & strvalue))
                list.Add(dec)
            Next
            Dim BinaryData As Byte() = list.ToArray()

            Me.Cursor = Cursors.WaitCursor

            If RegistryBox1.Text = "LocalMachine" Then
                Dim intRegistryHive As Microsoft.Win32.RegistryHive
                intRegistryHive = Microsoft.Win32.RegistryHive.LocalMachine
                Dim objReg
                Dim objSWbemServices
                Dim objSWbemLocator
                Dim strKeyPath As String = Nothing
                objSWbemLocator = CreateObject("wbemScripting.SwbemLocator")
                objSWbemLocator.Security_.AuthenticationLevel = 6 'Packet Privacy.
                objSWbemServices = objSWbemLocator.ConnectServer(txtpcname, "root\default", domain & "\" & username, password)
                objReg = objSWbemServices.Get("StdRegProv")
                strKeyPath = TreeViewKeys.SelectedNode.FullPath
                objReg.SetBinaryValue(intRegistryHive, strKeyPath, InputValue1, BinaryData)
            End If

            If RegistryBox1.Text = "CurrentUser" Then
                Dim intRegistryHive As Microsoft.Win32.RegistryHive
                intRegistryHive = Microsoft.Win32.RegistryHive.Users
                Dim objReg
                Dim objSWbemServices
                Dim objSWbemLocator
                Dim strKeyPath As String = Nothing
                objSWbemLocator = CreateObject("wbemScripting.SwbemLocator")
                objSWbemLocator.Security_.AuthenticationLevel = 6 'Packet Privacy.
                objSWbemServices = objSWbemLocator.ConnectServer(txtpcname, "root\default", domain & "\" & username, password)
                objReg = objSWbemServices.Get("StdRegProv")
                strKeyPath = SIDKEY & "\" & TreeViewKeys.SelectedNode.FullPath
                objReg.SetBinaryValue(intRegistryHive, strKeyPath, InputValue1, BinaryData)
            End If

            TreeviewKeys_AddKey_Refresh()

            Me.Cursor = Cursors.Default
        End If
    End Sub

    Private Sub AddDwordValue1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddDwordValue1.Click
        If RegistryBox1.Text <> "" Then

            AddDWORDdialog.AddDWORDName.Text = ""
            AddDWORDdialog.AddDWORDdata.Text = ""
            AddDWORDdialog.ShowDialog()
            If AddDWORDdialog.DialogResult = System.Windows.Forms.DialogResult.Cancel Then
                Exit Sub
            End If
            If AddDWORDdialog.DialogResult = System.Windows.Forms.DialogResult.OK Then

                Dim InputValue1 As String = AddDWORDdialog.AddDWORDName.Text
                Dim InputValue2 As String = AddDWORDdialog.AddDWORDdata.Text
                If InputValue1 = "" Then Exit Sub
                If InputValue2 = "" Then Exit Sub
                Dim InputValue3 As Long = (CLng("&H" & InputValue2))
                Dim vOut As String = InputValue3.ToString

                Try
                    Dim dec As Integer = Convert.ToInt32(vOut)

                    Me.Cursor = Cursors.WaitCursor

                    If RegistryBox1.Text = "LocalMachine" Then
                        Dim intRegistryHive As Microsoft.Win32.RegistryHive
                        intRegistryHive = Microsoft.Win32.RegistryHive.LocalMachine
                        Dim objReg
                        Dim objSWbemServices
                        Dim objSWbemLocator
                        Dim strKeyPath As String = Nothing
                        objSWbemLocator = CreateObject("wbemScripting.SwbemLocator")
                        objSWbemLocator.Security_.AuthenticationLevel = 6 'Packet Privacy.
                        objSWbemServices = objSWbemLocator.ConnectServer(txtpcname, "root\default", domain & "\" & username, password)
                        objReg = objSWbemServices.Get("StdRegProv")
                        strKeyPath = TreeViewKeys.SelectedNode.FullPath
                        objReg.SetDWORDValue(intRegistryHive, strKeyPath, InputValue1, dec)
                    End If

                    If RegistryBox1.Text = "CurrentUser" Then
                        Dim intRegistryHive As Microsoft.Win32.RegistryHive
                        intRegistryHive = Microsoft.Win32.RegistryHive.Users
                        Dim objReg
                        Dim objSWbemServices
                        Dim objSWbemLocator
                        Dim strKeyPath As String = Nothing
                        objSWbemLocator = CreateObject("wbemScripting.SwbemLocator")
                        objSWbemLocator.Security_.AuthenticationLevel = 6 'Packet Privacy.
                        objSWbemServices = objSWbemLocator.ConnectServer(txtpcname, "root\default", domain & "\" & username, password)
                        objReg = objSWbemServices.Get("StdRegProv")
                        strKeyPath = SIDKEY & "\" & TreeViewKeys.SelectedNode.FullPath
                        objReg.SetDWORDValue(intRegistryHive, strKeyPath, InputValue1, dec)
                    End If

                    TreeviewKeys_AddKey_Refresh()

                    Me.Cursor = Cursors.Default
                Catch ex As Exception
                    MsgBox(ex.ToString)
                    Exit Sub
                End Try
            End If
        End If
    End Sub

    Private Sub AddQwordValue1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddQwordValue1.Click

        If RegistryBox1.Text <> "" Then

            AddQWORDdialog.AddQWORDName.Text = ""
            AddQWORDdialog.AddQWORDdata.Text = ""
            AddQWORDdialog.ShowDialog()
            If AddQWORDdialog.DialogResult = System.Windows.Forms.DialogResult.Cancel Then
                Exit Sub
            End If
            If AddQWORDdialog.DialogResult = System.Windows.Forms.DialogResult.OK Then

                Dim InputValue1 As String = AddQWORDdialog.AddQWORDName.Text
                Dim InputValue2 As String = AddQWORDdialog.AddQWORDdata.Text
                If InputValue1 = "" Then Exit Sub
                If InputValue2 = "" Then Exit Sub
                Dim InputValue3 As Long = (CLng("&H" & InputValue2))
                Dim vOut As String = InputValue3.ToString
                'MsgBox(vOut)
                Dim dec As Long = Convert.ToInt64(vOut)
                'MsgBox(dec.ToString)

                Me.Cursor = Cursors.WaitCursor

                If RegistryBox1.Text = "LocalMachine" Then
                    Dim processID As UInteger = 0
                    Dim ExitCode = 1
                    Try
                        Dim connOptions As New Management.ConnectionOptions()
                        connOptions.Username = username
                        connOptions.Password = password
                        connOptions.Timeout = TimeSpan.FromSeconds(30)
                        connOptions.Authority = "NTLMDOMAIN:" & domain
                        connOptions.EnablePrivileges = True
                        connOptions.Authentication = AuthenticationLevel.PacketPrivacy
                        connOptions.Impersonation = ImpersonationLevel.Impersonate
                        connOptions.EnablePrivileges = True
                        Dim manScope As New Management.ManagementScope([String].Format("\\{0}\ROOT\CIMV2", txtpcname), connOptions)

                        Try
                            manScope.Connect()
                        Catch
                            MsgBox("Couldn't connect to remote PC.")
                            Exit Try
                        End Try
                        Dim objectGetOptions As New Management.ObjectGetOptions()
                        Dim managementPath As New Management.ManagementPath("Win32_Process")
                        Using processClass As New Management.ManagementClass(manScope, managementPath, objectGetOptions)
                            Using inParams As Management.ManagementBaseObject = processClass.GetMethodParameters("Create")
                                inParams("CommandLine") = "REG.EXE ADD " & Chr(34) & "HKLM\" & TreeViewKeys.SelectedNode.FullPath & Chr(34) & " /v " & InputValue1 & " /t REG_QWORD /d " & dec & " /f"
                                Using outParams As Management.ManagementBaseObject = processClass.InvokeMethod("Create", inParams, Nothing)
                                    If CUInt(outParams("returnValue")) <> 0 Then
                                        Me.Cursor = Cursors.Default
                                        MsgBox("Export Failed...")
                                        Exit Sub
                                    Else
                                        'MsgBox("Install Started at : " & Now & " : with a process Id of : " & CUInt(outParams("processId")))
                                        processID = CUInt(outParams("processId"))
                                    End If
                                End Using
                            End Using
                        End Using
                    Catch
                    End Try
                End If

                If RegistryBox1.Text = "CurrentUser" Then
                    Dim processID As UInteger = 0
                    Dim ExitCode = 1
                    Try
                        Dim connOptions As New Management.ConnectionOptions()
                        connOptions.Username = username
                        connOptions.Password = password
                        connOptions.Timeout = TimeSpan.FromSeconds(30)
                        connOptions.Authority = "NTLMDOMAIN:" & domain
                        connOptions.EnablePrivileges = True
                        connOptions.Authentication = AuthenticationLevel.PacketPrivacy
                        connOptions.Impersonation = ImpersonationLevel.Impersonate
                        connOptions.EnablePrivileges = True
                        Dim manScope As New Management.ManagementScope([String].Format("\\{0}\ROOT\CIMV2", txtpcname), connOptions)

                        Try
                            manScope.Connect()
                        Catch
                            MsgBox("Couldn't connect to remote PC.")
                            Exit Try
                        End Try
                        Dim objectGetOptions As New Management.ObjectGetOptions()
                        Dim managementPath As New Management.ManagementPath("Win32_Process")
                        Using processClass As New Management.ManagementClass(manScope, managementPath, objectGetOptions)
                            Using inParams As Management.ManagementBaseObject = processClass.GetMethodParameters("Create")
                                inParams("CommandLine") = "REG.EXE ADD " & Chr(34) & "HKU\" & SIDKEY & "\" & TreeViewKeys.SelectedNode.FullPath & Chr(34) & " /v " & InputValue1 & " /t REG_QWORD /d " & dec & " /f"
                                Using outParams As Management.ManagementBaseObject = processClass.InvokeMethod("Create", inParams, Nothing)
                                    If CUInt(outParams("returnValue")) <> 0 Then
                                        Me.Cursor = Cursors.Default
                                        MsgBox("Export Failed...")
                                        Exit Sub
                                    Else
                                        'MsgBox("Install Started at : " & Now & " : with a process Id of : " & CUInt(outParams("processId")))
                                        processID = CUInt(outParams("processId"))
                                    End If
                                End Using
                            End Using
                        End Using
                    Catch
                    End Try
                End If

                Thread.Sleep(3000)
                Me.Cursor = Cursors.Default
                TreeviewKeys_AddKey_Refresh()
            End If
        End If
    End Sub

    Private Sub AddExpandableStringValue1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddExpandableStringValue1.Click
        If RegistryBox1.Text <> "" Then

            AddExpandedStringdialog.AddExpandedStringName.Text = ""
            AddExpandedStringdialog.AddExpandedStringdata.Text = ""
            AddExpandedStringdialog.ShowDialog()
            If AddExpandedStringdialog.DialogResult = System.Windows.Forms.DialogResult.Cancel Then
                Exit Sub
            End If
            If AddExpandedStringdialog.DialogResult = System.Windows.Forms.DialogResult.OK Then

                Dim InputValue1 As String = AddExpandedStringdialog.AddExpandedStringName.Text
                Dim InputValue2 As String = AddExpandedStringdialog.AddExpandedStringdata.Text
                If InputValue1 = "" Then Exit Sub
                If InputValue2 = "" Then Exit Sub

                Me.Cursor = Cursors.WaitCursor

                If RegistryBox1.Text = "LocalMachine" Then
                    Dim intRegistryHive As Microsoft.Win32.RegistryHive
                    intRegistryHive = Microsoft.Win32.RegistryHive.LocalMachine
                    Dim objReg
                    Dim objSWbemServices
                    Dim objSWbemLocator
                    Dim strKeyPath As String = Nothing
                    objSWbemLocator = CreateObject("wbemScripting.SwbemLocator")
                    objSWbemLocator.Security_.AuthenticationLevel = 6 'Packet Privacy.
                    objSWbemServices = objSWbemLocator.ConnectServer(txtpcname, "root\default", domain & "\" & username, password)
                    objReg = objSWbemServices.Get("StdRegProv")
                    strKeyPath = TreeViewKeys.SelectedNode.FullPath
                    objReg.SetExpandedStringValue(intRegistryHive, strKeyPath, InputValue1, InputValue2)
                End If

                If RegistryBox1.Text = "CurrentUser" Then
                    Dim intRegistryHive As Microsoft.Win32.RegistryHive
                    intRegistryHive = Microsoft.Win32.RegistryHive.Users
                    Dim objReg
                    Dim objSWbemServices
                    Dim objSWbemLocator
                    Dim strKeyPath As String = Nothing
                    objSWbemLocator = CreateObject("wbemScripting.SwbemLocator")
                    objSWbemLocator.Security_.AuthenticationLevel = 6 'Packet Privacy.
                    objSWbemServices = objSWbemLocator.ConnectServer(txtpcname, "root\default", domain & "\" & username, password)
                    objReg = objSWbemServices.Get("StdRegProv")
                    strKeyPath = SIDKEY & "\" & TreeViewKeys.SelectedNode.FullPath
                    objReg.SetExpandedStringValue(intRegistryHive, strKeyPath, InputValue1, InputValue2)
                End If
                TreeviewKeys_AddKey_Refresh()
                Me.Cursor = Cursors.Default
            End If
        End If
    End Sub

    Private Sub AddMultiStringValue1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddMultiStringValue1.Click
        If RegistryBox1.Text <> "" Then

            MultiStringDialog.MultiStringListBox.Text = ""
            MultiStringDialog.MultiStringValueName.Text = ""
            MultiStringDialog.ShowDialog()
            If MultiStringDialog.DialogResult = System.Windows.Forms.DialogResult.Cancel Then
                Exit Sub
            End If
            If MultiStringDialog.DialogResult = System.Windows.Forms.DialogResult.OK Then

                Dim arrLines() As String = Split(MultiStringDialog.MultiStringListBox.Text, vbCrLf)
                Dim InputValue1 As String = MultiStringDialog.MultiStringValueName.Text
                If InputValue1 = "" Then Exit Sub
                If arrLines(0) = "" Then
                    Exit Sub
                Else

                    Me.Cursor = Cursors.WaitCursor

                    Dim StringData As String = Nothing
                    Dim strLine As String = Nothing
                    For Each strLine In arrLines
                        StringData = StringData + (strLine & "\0")
                    Next

                    If RegistryBox1.Text = "LocalMachine" Then
                        Dim processID As UInteger = 0
                        Dim ExitCode = 1
                        Try
                            Dim connOptions As New Management.ConnectionOptions()
                            connOptions.Username = username
                            connOptions.Password = password
                            connOptions.Timeout = TimeSpan.FromSeconds(30)
                            connOptions.Authority = "NTLMDOMAIN:" & domain
                            connOptions.EnablePrivileges = True
                            connOptions.Authentication = AuthenticationLevel.PacketPrivacy
                            connOptions.Impersonation = ImpersonationLevel.Impersonate
                            connOptions.EnablePrivileges = True
                            Dim manScope As New Management.ManagementScope([String].Format("\\{0}\ROOT\CIMV2", txtpcname), connOptions)

                            Try
                                manScope.Connect()
                            Catch
                                MsgBox("Couldn't connect to remote PC.")
                                Exit Try
                            End Try
                            Dim objectGetOptions As New Management.ObjectGetOptions()
                            Dim managementPath As New Management.ManagementPath("Win32_Process")
                            Using processClass As New Management.ManagementClass(manScope, managementPath, objectGetOptions)
                                Using inParams As Management.ManagementBaseObject = processClass.GetMethodParameters("Create")
                                    inParams("CommandLine") = "REG.EXE ADD " & Chr(34) & "HKLM\" & TreeViewKeys.SelectedNode.FullPath & Chr(34) & " /v " & InputValue1 & " /t REG_MULTI_SZ /d " & StringData & " /f"
                                    Using outParams As Management.ManagementBaseObject = processClass.InvokeMethod("Create", inParams, Nothing)
                                        If CUInt(outParams("returnValue")) <> 0 Then
                                            Me.Cursor = Cursors.Default
                                            MsgBox("Export Failed...")
                                            Exit Sub
                                        Else
                                            'MsgBox("Install Started at : " & Now & " : with a process Id of : " & CUInt(outParams("processId")))
                                            processID = CUInt(outParams("processId"))
                                        End If
                                    End Using
                                End Using
                            End Using
                        Catch
                        End Try
                    End If

                    If RegistryBox1.Text = "CurrentUser" Then
                        Dim processID As UInteger = 0
                        Dim ExitCode = 1
                        Try
                            Dim connOptions As New Management.ConnectionOptions()
                            connOptions.Username = username
                            connOptions.Password = password
                            connOptions.Timeout = TimeSpan.FromSeconds(30)
                            connOptions.Authority = "NTLMDOMAIN:" & domain
                            connOptions.EnablePrivileges = True
                            connOptions.Authentication = AuthenticationLevel.PacketPrivacy
                            connOptions.Impersonation = ImpersonationLevel.Impersonate
                            connOptions.EnablePrivileges = True
                            Dim manScope As New Management.ManagementScope([String].Format("\\{0}\ROOT\CIMV2", txtpcname), connOptions)

                            Try
                                manScope.Connect()
                            Catch
                                MsgBox("Couldn't connect to remote PC.")
                                Exit Try
                            End Try
                            Dim objectGetOptions As New Management.ObjectGetOptions()
                            Dim managementPath As New Management.ManagementPath("Win32_Process")
                            Using processClass As New Management.ManagementClass(manScope, managementPath, objectGetOptions)
                                Using inParams As Management.ManagementBaseObject = processClass.GetMethodParameters("Create")
                                    inParams("CommandLine") = "REG.EXE ADD " & Chr(34) & "HKU\" & SIDKEY & "\" & TreeViewKeys.SelectedNode.FullPath & Chr(34) & " /v " & InputValue1 & " /t REG_MULTI_SZ /d " & StringData & " /f"
                                    Using outParams As Management.ManagementBaseObject = processClass.InvokeMethod("Create", inParams, Nothing)
                                        If CUInt(outParams("returnValue")) <> 0 Then
                                            Me.Cursor = Cursors.Default
                                            MsgBox("Export Failed...")
                                            Exit Sub
                                        Else
                                            'MsgBox("Install Started at : " & Now & " : with a process Id of : " & CUInt(outParams("processId")))
                                            processID = CUInt(outParams("processId"))
                                        End If
                                    End Using
                                End Using
                            End Using
                        Catch
                        End Try
                    End If

                    Thread.Sleep(3000)
                    TreeviewKeys_AddKey_Refresh()
                    Me.Cursor = Cursors.Default
                End If
            End If
        End If

    End Sub

    Private Sub DeleteValue_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeleteValue.Click
        If RegistryBox1.Text <> "" Then

            If DataGridViewValues.CurrentRow.Cells.Item(0).Value <> "" Then
                Dim InputValue1 As String = DataGridViewValues.CurrentRow.Cells.Item(0).Value

                Dim response As MsgBoxResult
                response = MsgBox("Are you really sure you want to delete the value : " & InputValue1 & " ?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "This can be dangerous, do you know what your doing!")
                If response = MsgBoxResult.Yes Then
                    Me.Cursor = Cursors.WaitCursor
                    If RegistryBox1.Text = "LocalMachine" Then
                        Dim intRegistryHive As Microsoft.Win32.RegistryHive
                        intRegistryHive = Microsoft.Win32.RegistryHive.LocalMachine
                        Dim objReg
                        Dim objSWbemServices
                        Dim objSWbemLocator
                        Dim strKeyPath As String = Nothing
                        objSWbemLocator = CreateObject("wbemScripting.SwbemLocator")
                        objSWbemLocator.Security_.AuthenticationLevel = 6 'Packet Privacy.
                        objSWbemServices = objSWbemLocator.ConnectServer(txtpcname, "root\default", domain & "\" & username, password)
                        objReg = objSWbemServices.Get("StdRegProv")
                        strKeyPath = TreeViewKeys.SelectedNode.FullPath
                        objReg.DeleteValue(intRegistryHive, strKeyPath, InputValue1)
                    End If

                    If RegistryBox1.Text = "CurrentUser" Then
                        Dim intRegistryHive As Microsoft.Win32.RegistryHive
                        intRegistryHive = Microsoft.Win32.RegistryHive.Users
                        Dim objReg
                        Dim objSWbemServices
                        Dim objSWbemLocator
                        Dim strKeyPath As String = Nothing
                        objSWbemLocator = CreateObject("wbemScripting.SwbemLocator")
                        objSWbemLocator.Security_.AuthenticationLevel = 6 'Packet Privacy.
                        objSWbemServices = objSWbemLocator.ConnectServer(txtpcname, "root\default", domain & "\" & username, password)
                        objReg = objSWbemServices.Get("StdRegProv")
                        strKeyPath = SIDKEY & "\" & TreeViewKeys.SelectedNode.FullPath
                        objReg.DeleteValue(intRegistryHive, strKeyPath, InputValue1)
                    End If
                    TreeviewKeys_AddKey_Refresh()
                    Me.Cursor = Cursors.Default
                ElseIf response = MsgBoxResult.No Then
                    Exit Sub
                End If
            End If
        End If
    End Sub

    Private Sub Refreshed_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Refreshed.Click
        TreeviewKeys_AddKey_Refresh()
    End Sub

    Private Sub DataGridViewValues_CellMouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles DataGridViewValues.CellMouseDown
        If e.Button = System.Windows.Forms.MouseButtons.Right AndAlso e.RowIndex >= 0 Then
            DataGridViewValues.Rows(e.RowIndex).Selected = True
            DataGridViewValues.SelectedRows.Item(0).Cells(0).Selected = True
        End If
    End Sub
End Class
