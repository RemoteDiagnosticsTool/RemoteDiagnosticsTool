<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Serial
    Inherits MetroFramework.Forms.MetroForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Serial))
        Me.MaskedTextBox1 = New System.Windows.Forms.MaskedTextBox()
        Me.MaskedTextBox2 = New System.Windows.Forms.MaskedTextBox()
        Me.MaskedTextBox3 = New System.Windows.Forms.MaskedTextBox()
        Me.MaskedTextBox4 = New System.Windows.Forms.MaskedTextBox()
        Me.MaskedTextBox5 = New System.Windows.Forms.MaskedTextBox()
        Me.MaskedTextBox6 = New System.Windows.Forms.MaskedTextBox()
        Me.Evaluate = New MetroFramework.Controls.MetroTile()
        Me.SerialButton = New MetroFramework.Controls.MetroTile()
        Me.MetroLabel1 = New MetroFramework.Controls.MetroLabel()
        Me.MetroLabel2 = New MetroFramework.Controls.MetroLabel()
        Me.HelpButton1 = New MetroFramework.Controls.MetroTile()
        Me.SuspendLayout()
        '
        'MaskedTextBox1
        '
        Me.MaskedTextBox1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.MaskedTextBox1.Location = New System.Drawing.Point(93, 35)
        Me.MaskedTextBox1.Mask = "00000"
        Me.MaskedTextBox1.Name = "MaskedTextBox1"
        Me.MaskedTextBox1.Size = New System.Drawing.Size(42, 21)
        Me.MaskedTextBox1.TabIndex = 5
        Me.MaskedTextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.MaskedTextBox1.ValidatingType = GetType(Integer)
        '
        'MaskedTextBox2
        '
        Me.MaskedTextBox2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.MaskedTextBox2.Location = New System.Drawing.Point(141, 35)
        Me.MaskedTextBox2.Mask = "00000"
        Me.MaskedTextBox2.Name = "MaskedTextBox2"
        Me.MaskedTextBox2.Size = New System.Drawing.Size(42, 21)
        Me.MaskedTextBox2.TabIndex = 6
        Me.MaskedTextBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.MaskedTextBox2.ValidatingType = GetType(Integer)
        '
        'MaskedTextBox3
        '
        Me.MaskedTextBox3.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.MaskedTextBox3.Location = New System.Drawing.Point(189, 35)
        Me.MaskedTextBox3.Mask = "00000"
        Me.MaskedTextBox3.Name = "MaskedTextBox3"
        Me.MaskedTextBox3.Size = New System.Drawing.Size(42, 21)
        Me.MaskedTextBox3.TabIndex = 7
        Me.MaskedTextBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.MaskedTextBox3.ValidatingType = GetType(Integer)
        '
        'MaskedTextBox4
        '
        Me.MaskedTextBox4.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.MaskedTextBox4.Location = New System.Drawing.Point(237, 35)
        Me.MaskedTextBox4.Mask = "00000"
        Me.MaskedTextBox4.Name = "MaskedTextBox4"
        Me.MaskedTextBox4.Size = New System.Drawing.Size(42, 21)
        Me.MaskedTextBox4.TabIndex = 8
        Me.MaskedTextBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.MaskedTextBox4.ValidatingType = GetType(Integer)
        '
        'MaskedTextBox5
        '
        Me.MaskedTextBox5.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.MaskedTextBox5.Location = New System.Drawing.Point(285, 35)
        Me.MaskedTextBox5.Mask = "00000"
        Me.MaskedTextBox5.Name = "MaskedTextBox5"
        Me.MaskedTextBox5.Size = New System.Drawing.Size(42, 21)
        Me.MaskedTextBox5.TabIndex = 9
        Me.MaskedTextBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.MaskedTextBox5.ValidatingType = GetType(Integer)
        '
        'MaskedTextBox6
        '
        Me.MaskedTextBox6.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.MaskedTextBox6.Location = New System.Drawing.Point(333, 35)
        Me.MaskedTextBox6.Mask = "00000"
        Me.MaskedTextBox6.Name = "MaskedTextBox6"
        Me.MaskedTextBox6.Size = New System.Drawing.Size(42, 21)
        Me.MaskedTextBox6.TabIndex = 10
        Me.MaskedTextBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.MaskedTextBox6.ValidatingType = GetType(Integer)
        '
        'Evaluate
        '
        Me.Evaluate.ActiveControl = Nothing
        Me.Evaluate.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Evaluate.Location = New System.Drawing.Point(123, 117)
        Me.Evaluate.Name = "Evaluate"
        Me.Evaluate.Size = New System.Drawing.Size(227, 31)
        Me.Evaluate.TabIndex = 12
        Me.Evaluate.Text = "Evaluate Application"
        Me.Evaluate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Evaluate.UseCustomBackColor = True
        Me.Evaluate.UseSelectable = True
        '
        'SerialButton
        '
        Me.SerialButton.ActiveControl = Nothing
        Me.SerialButton.BackColor = System.Drawing.Color.Green
        Me.SerialButton.Location = New System.Drawing.Point(123, 61)
        Me.SerialButton.Name = "SerialButton"
        Me.SerialButton.Size = New System.Drawing.Size(227, 31)
        Me.SerialButton.TabIndex = 13
        Me.SerialButton.Text = "Apply Serial Number"
        Me.SerialButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.SerialButton.UseSelectable = True
        '
        'MetroLabel1
        '
        Me.MetroLabel1.AutoSize = True
        Me.MetroLabel1.FontWeight = MetroFramework.MetroLabelWeight.Bold
        Me.MetroLabel1.Location = New System.Drawing.Point(162, 13)
        Me.MetroLabel1.Name = "MetroLabel1"
        Me.MetroLabel1.Size = New System.Drawing.Size(144, 19)
        Me.MetroLabel1.TabIndex = 14
        Me.MetroLabel1.Text = "Enter Serial Number"
        Me.MetroLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MetroLabel1.UseCustomForeColor = True
        '
        'MetroLabel2
        '
        Me.MetroLabel2.AutoSize = True
        Me.MetroLabel2.Location = New System.Drawing.Point(219, 95)
        Me.MetroLabel2.Name = "MetroLabel2"
        Me.MetroLabel2.Size = New System.Drawing.Size(28, 19)
        Me.MetroLabel2.TabIndex = 15
        Me.MetroLabel2.Text = "OR"
        '
        'HelpButton1
        '
        Me.HelpButton1.ActiveControl = Nothing
        Me.HelpButton1.Location = New System.Drawing.Point(2, 9)
        Me.HelpButton1.Name = "HelpButton1"
        Me.HelpButton1.Size = New System.Drawing.Size(24, 23)
        Me.HelpButton1.TabIndex = 0
        Me.HelpButton1.Text = "?"
        Me.HelpButton1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.HelpButton1.UseSelectable = True
        '
        'Serial
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoValidate = System.Windows.Forms.AutoValidate.EnableAllowFocusChange
        Me.BorderStyle = MetroFramework.Forms.MetroFormBorderStyle.FixedSingle
        Me.ClientSize = New System.Drawing.Size(475, 160)
        Me.Controls.Add(Me.HelpButton1)
        Me.Controls.Add(Me.MetroLabel2)
        Me.Controls.Add(Me.MetroLabel1)
        Me.Controls.Add(Me.SerialButton)
        Me.Controls.Add(Me.Evaluate)
        Me.Controls.Add(Me.MaskedTextBox6)
        Me.Controls.Add(Me.MaskedTextBox5)
        Me.Controls.Add(Me.MaskedTextBox4)
        Me.Controls.Add(Me.MaskedTextBox3)
        Me.Controls.Add(Me.MaskedTextBox2)
        Me.Controls.Add(Me.MaskedTextBox1)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Movable = False
        Me.Name = "Serial"
        Me.Resizable = False
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MaskedTextBox1 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents MaskedTextBox2 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents MaskedTextBox3 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents MaskedTextBox4 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents MaskedTextBox5 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents MaskedTextBox6 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents Evaluate As MetroFramework.Controls.MetroTile
    Friend WithEvents SerialButton As MetroFramework.Controls.MetroTile
    Friend WithEvents MetroLabel1 As MetroFramework.Controls.MetroLabel
    Friend WithEvents MetroLabel2 As MetroFramework.Controls.MetroLabel
    Friend WithEvents HelpButton1 As MetroFramework.Controls.MetroTile

End Class
