<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits MetroFramework.Forms.MetroForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.password = New System.Windows.Forms.MaskedTextBox()
        Me.username = New System.Windows.Forms.TextBox()
        Me.Domain = New System.Windows.Forms.TextBox()
        Me.Button1 = New MetroFramework.Controls.MetroTile()
        Me.MetroLabel1 = New MetroFramework.Controls.MetroLabel()
        Me.MetroLabel2 = New MetroFramework.Controls.MetroLabel()
        Me.MetroLabel3 = New MetroFramework.Controls.MetroLabel()
        Me.Useloggedonuser = New MetroFramework.Controls.MetroCheckBox()
        Me.MetroLabel4 = New MetroFramework.Controls.MetroLabel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'password
        '
        Me.password.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.password.Location = New System.Drawing.Point(141, 162)
        Me.password.Name = "password"
        Me.password.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.password.Size = New System.Drawing.Size(323, 30)
        Me.password.TabIndex = 1
        '
        'username
        '
        Me.username.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.username.Location = New System.Drawing.Point(141, 127)
        Me.username.Name = "username"
        Me.username.Size = New System.Drawing.Size(323, 30)
        Me.username.TabIndex = 0
        '
        'Domain
        '
        Me.Domain.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Domain.Location = New System.Drawing.Point(141, 196)
        Me.Domain.Name = "Domain"
        Me.Domain.Size = New System.Drawing.Size(323, 30)
        Me.Domain.TabIndex = 3
        '
        'Button1
        '
        Me.Button1.ActiveControl = Nothing
        Me.Button1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button1.Location = New System.Drawing.Point(188, 241)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(138, 46)
        Me.Button1.TabIndex = 11
        Me.Button1.Text = "Enter Application"
        Me.Button1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Button1.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Bold
        Me.Button1.UseSelectable = True
        '
        'MetroLabel1
        '
        Me.MetroLabel1.AutoSize = True
        Me.MetroLabel1.Location = New System.Drawing.Point(43, 127)
        Me.MetroLabel1.Name = "MetroLabel1"
        Me.MetroLabel1.Size = New System.Drawing.Size(91, 19)
        Me.MetroLabel1.TabIndex = 12
        Me.MetroLabel1.Text = "USERNAME >"
        '
        'MetroLabel2
        '
        Me.MetroLabel2.AutoSize = True
        Me.MetroLabel2.Location = New System.Drawing.Point(43, 162)
        Me.MetroLabel2.Name = "MetroLabel2"
        Me.MetroLabel2.Size = New System.Drawing.Size(92, 19)
        Me.MetroLabel2.TabIndex = 13
        Me.MetroLabel2.Text = "PASSWORD >"
        '
        'MetroLabel3
        '
        Me.MetroLabel3.AutoSize = True
        Me.MetroLabel3.Location = New System.Drawing.Point(58, 196)
        Me.MetroLabel3.Name = "MetroLabel3"
        Me.MetroLabel3.Size = New System.Drawing.Size(76, 19)
        Me.MetroLabel3.TabIndex = 14
        Me.MetroLabel3.Text = "DOMAIN >"
        '
        'Useloggedonuser
        '
        Me.Useloggedonuser.FontSize = MetroFramework.MetroCheckBoxSize.Medium
        Me.Useloggedonuser.Location = New System.Drawing.Point(141, 87)
        Me.Useloggedonuser.Name = "Useloggedonuser"
        Me.Useloggedonuser.Size = New System.Drawing.Size(323, 24)
        Me.Useloggedonuser.TabIndex = 15
        Me.Useloggedonuser.Text = "Use logged on user account credentials"
        Me.Useloggedonuser.UseSelectable = True
        '
        'MetroLabel4
        '
        Me.MetroLabel4.FontSize = MetroFramework.MetroLabelSize.Tall
        Me.MetroLabel4.FontWeight = MetroFramework.MetroLabelWeight.Bold
        Me.MetroLabel4.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.MetroLabel4.Location = New System.Drawing.Point(28, 25)
        Me.MetroLabel4.Name = "MetroLabel4"
        Me.MetroLabel4.Size = New System.Drawing.Size(462, 49)
        Me.MetroLabel4.TabIndex = 16
        Me.MetroLabel4.Text = "Enter your desktop administrator account details or use the tick box to use your " &
    "current logged on user credentials"
        Me.MetroLabel4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MetroLabel4.UseCustomForeColor = True
        Me.MetroLabel4.WrapToLine = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.InitialImage = CType(resources.GetObject("PictureBox1.InitialImage"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(5, 8)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(22, 26)
        Me.PictureBox1.TabIndex = 17
        Me.PictureBox1.TabStop = False
        '
        'Form1
        '
        Me.AcceptButton = Me.Button1
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoValidate = System.Windows.Forms.AutoValidate.EnableAllowFocusChange
        Me.BorderStyle = MetroFramework.Forms.MetroFormBorderStyle.FixedSingle
        Me.ClientSize = New System.Drawing.Size(513, 312)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.MetroLabel4)
        Me.Controls.Add(Me.Useloggedonuser)
        Me.Controls.Add(Me.MetroLabel3)
        Me.Controls.Add(Me.MetroLabel2)
        Me.Controls.Add(Me.MetroLabel1)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Domain)
        Me.Controls.Add(Me.username)
        Me.Controls.Add(Me.password)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Movable = False
        Me.Name = "Form1"
        Me.Resizable = False
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
        Me.TopMost = True
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents password As System.Windows.Forms.MaskedTextBox
    Friend WithEvents username As System.Windows.Forms.TextBox
    Friend WithEvents Domain As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As MetroFramework.Controls.MetroTile
    Friend WithEvents MetroLabel1 As MetroFramework.Controls.MetroLabel
    Friend WithEvents MetroLabel2 As MetroFramework.Controls.MetroLabel
    Friend WithEvents MetroLabel3 As MetroFramework.Controls.MetroLabel
    Friend WithEvents Useloggedonuser As MetroFramework.Controls.MetroCheckBox
    Friend WithEvents MetroLabel4 As MetroFramework.Controls.MetroLabel
    Friend WithEvents PictureBox1 As PictureBox
End Class
