Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Management
Imports System.Runtime.InteropServices
Imports System.Diagnostics.Process
Imports System.IO
Imports System.Net

Public Class Form3

    Private Sub APPV_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Public Overloads Shared Function GETAPPV(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String, ByVal strValueName As String)

        Dim strStringValue As String = ""
        Dim strSubKeyName As String
        Dim objManagementScope As ManagementScope
        Dim objManagementClass As ManagementClass
        Dim objManagementBaseObject As ManagementBaseObject
        Dim intRegistryHive As Microsoft.Win32.RegistryHive

        intRegistryHive = Microsoft.Win32.RegistryHive.LocalMachine
        strSubKeyName = "SOFTWARE\Microsoft\SoftGrid\4.5\Client\Configuration"

        Dim options As ConnectionOptions
        options = New ConnectionOptions()
        Dim computerconnect As String = "\\" & txtpcname & "\root\DEFAULT"

        options.Username = txtusername
        options.Password = txtpassword
        options.Authority = "ntlmdomain:" & txtdomain

        objManagementScope = New ManagementScope(computerconnect, options)

        If objManagementScope.IsConnected = True Then
        Else
            Try
                objManagementScope.Connect()
            Catch
            End Try
            If objManagementScope.IsConnected = False Then
                MsgBox("Could not connect to PC name specified! Please check you inputed your username, password and domain correctly!")
                Return 1
                Exit Function
            End If
        End If

        objManagementClass = New ManagementClass("StdRegProv")

        With objManagementClass
            .Scope = objManagementScope
            objManagementBaseObject = .GetMethodParameters("GetStringValue")

            With objManagementBaseObject
                .SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                .SetPropertyValue("sSubKeyName", strSubKeyName)
                .SetPropertyValue("sValueName", strValueName)
            End With

            Dim OutParams As ManagementBaseObject = .InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
            strStringValue = CType(OutParams("sValue"), String)
            If strStringValue = Nothing Then strStringValue = ""
        End With

        objManagementScope = Nothing
        Return strStringValue
    End Function

    Public Overloads Shared Function GETAPPVDRIVE(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String, ByVal strValueName As String)

        Dim strStringValue As String = ""
        Dim strSubKeyName As String
        Dim objManagementScope As ManagementScope
        Dim objManagementClass As ManagementClass
        Dim objManagementBaseObject As ManagementBaseObject
        Dim intRegistryHive As Microsoft.Win32.RegistryHive

        intRegistryHive = Microsoft.Win32.RegistryHive.LocalMachine
        strSubKeyName = "SOFTWARE\Microsoft\SoftGrid\4.5\Client\APPFS"

        Dim options As ConnectionOptions
        options = New ConnectionOptions()
        Dim computerconnect As String = "\\" & txtpcname & "\root\DEFAULT"

        options.Username = txtusername
        options.Password = txtpassword
        options.Authority = "ntlmdomain:" & txtdomain

        objManagementScope = New ManagementScope(computerconnect, options)

        If objManagementScope.IsConnected = True Then
        Else
            Try
                objManagementScope.Connect()
            Catch
            End Try
            If objManagementScope.IsConnected = False Then
                MsgBox("Could not connect to PC name specified! Please check you inputed your username, password and domain correctly!")
                Return 1
                Exit Function
            End If
        End If

        objManagementClass = New ManagementClass("StdRegProv")

        With objManagementClass
            .Scope = objManagementScope
            objManagementBaseObject = .GetMethodParameters("GetStringValue")

            With objManagementBaseObject
                .SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
                .SetPropertyValue("sSubKeyName", strSubKeyName)
                .SetPropertyValue("sValueName", strValueName)
            End With

            Dim OutParams As ManagementBaseObject = .InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
            strStringValue = CType(OutParams("sValue"), String)
            If strStringValue = Nothing Then strStringValue = ""
        End With

        objManagementScope = Nothing
        Return strStringValue
    End Function

    Private Sub GETAPPVSERVERS(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)
        Dim strComputerName As String = txtpcname
        Dim strStringValue As String = ""
        Dim strKeyPath As String = "SOFTWARE\Microsoft\SoftGrid\4.5\Client\DC Servers\"
        Dim objManagementScope As ManagementScope
        Dim objManagementClass As ManagementClass
        Dim objManagementBaseObject As ManagementBaseObject
        Dim strkey As String
        Dim myKey As String
        Dim myValue As String
        Dim aSubKeys() As String
        Dim intRegistryHive As Microsoft.Win32.RegistryHive
        intRegistryHive = Microsoft.Win32.RegistryHive.LocalMachine

        Dim options As ConnectionOptions
        options = New ConnectionOptions()
        Dim computerconnect As String = "\\" & txtpcname & "\root\DEFAULT"

        options.Username = txtusername
        options.Password = txtpassword
        options.Authority = "ntlmdomain:" & txtdomain

        objManagementScope = New ManagementScope(computerconnect, options)

        If objManagementScope.IsConnected = True Then
        Else
            Try
                objManagementScope.Connect()
            Catch
            End Try
            If objManagementScope.IsConnected = False Then
                MsgBox("Could not connect to PC name specified! Please check you inputed your username, password and domain correctly!")
                Exit Sub
            End If
        End If

        objManagementClass = New ManagementClass("stdRegProv")
        objManagementClass.Scope = objManagementScope
        objManagementBaseObject = objManagementClass.GetMethodParameters("EnumKey")
        objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
        objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath)
        aSubKeys = CType(objManagementClass.InvokeMethod("EnumKey", objManagementBaseObject, Nothing).Properties.Item("sNames").Value, String())

        For Each strkey In aSubKeys
            myKey = strkey
            objManagementBaseObject = objManagementClass.GetMethodParameters("GetStringValue")
            objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
            objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath & strkey)
            objManagementBaseObject.SetPropertyValue("sValueName", "Host")
            objManagementBaseObject = objManagementClass.InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
            myValue = objManagementBaseObject("sValue")

            If Not myValue = "" Then
                DataGridView3.Rows.Add(strkey, myValue)
            End If
        Next
        Return
    End Sub
    Private Sub GETAPPVPACKAGES(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)
        Dim strComputerName As String = txtpcname
        Dim strStringValue As String = ""
        Dim strKeyPath As String = "SOFTWARE\Microsoft\SoftGrid\4.5\Client\Packages\"
        Dim objManagementScope As ManagementScope
        Dim objManagementClass As ManagementClass
        Dim objManagementBaseObject As ManagementBaseObject
        Dim strkey As String
        Dim myKey As String
        Dim myValue As String
        Dim aSubKeys() As String
        Dim intRegistryHive As Microsoft.Win32.RegistryHive
        intRegistryHive = Microsoft.Win32.RegistryHive.LocalMachine

        Dim options As ConnectionOptions
        options = New ConnectionOptions()
        Dim computerconnect As String = "\\" & txtpcname & "\root\DEFAULT"

        options.Username = txtusername
        options.Password = txtpassword
        options.Authority = "ntlmdomain:" & txtdomain

        objManagementScope = New ManagementScope(computerconnect, options)

        If objManagementScope.IsConnected = True Then
        Else
            Try
                objManagementScope.Connect()
            Catch
            End Try
            If objManagementScope.IsConnected = False Then
                MsgBox("Could not connect to PC name specified! Please check you inputed your username, password and domain correctly!")
                Exit Sub
            End If
        End If

        objManagementClass = New ManagementClass("stdRegProv")
        objManagementClass.Scope = objManagementScope
        objManagementBaseObject = objManagementClass.GetMethodParameters("EnumKey")
        objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
        objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath)
        aSubKeys = CType(objManagementClass.InvokeMethod("EnumKey", objManagementBaseObject, Nothing).Properties.Item("sNames").Value, String())

        For Each strkey In aSubKeys
            myKey = strkey
            objManagementBaseObject = objManagementClass.GetMethodParameters("GetStringValue")
            objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
            objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath & strkey)
            objManagementBaseObject.SetPropertyValue("sValueName", "OriginalURL")
            objManagementBaseObject = objManagementClass.InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
            myValue = objManagementBaseObject("sValue")

            If Not myValue = "" Then
                DataGridView4.Rows.Add(strkey, myValue)
            End If
        Next
        Return
    End Sub

    Private Sub GETAPPVAPPS(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)
        Dim strComputerName As String = txtpcname
        Dim strStringValue As String = ""
        Dim strKeyPath As String = "SOFTWARE\Microsoft\SoftGrid\4.5\Client\Applications\"
        Dim objManagementScope As ManagementScope
        Dim objManagementClass As ManagementClass
        Dim objManagementBaseObject As ManagementBaseObject
        Dim strkey As String
        Dim myKey As String
        Dim myValue As String
        Dim aSubKeys() As String
        Dim intRegistryHive As Microsoft.Win32.RegistryHive
        intRegistryHive = Microsoft.Win32.RegistryHive.LocalMachine

        Dim options As ConnectionOptions
        options = New ConnectionOptions()
        Dim computerconnect As String = "\\" & txtpcname & "\root\DEFAULT"

        options.Username = txtusername
        options.Password = txtpassword
        options.Authority = "ntlmdomain:" & txtdomain

        objManagementScope = New ManagementScope(computerconnect, options)

        If objManagementScope.IsConnected = True Then
        Else
            Try
                objManagementScope.Connect()
            Catch
            End Try
            If objManagementScope.IsConnected = False Then
                MsgBox("Could not connect to PC name specified! Please check you inputed your username, password and domain correctly!")
                Exit Sub
            End If
        End If

        objManagementClass = New ManagementClass("stdRegProv")
        objManagementClass.Scope = objManagementScope
        objManagementBaseObject = objManagementClass.GetMethodParameters("EnumKey")
        objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
        objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath)
        aSubKeys = CType(objManagementClass.InvokeMethod("EnumKey", objManagementBaseObject, Nothing).Properties.Item("sNames").Value, String())

        For Each strkey In aSubKeys
            myKey = strkey
            objManagementBaseObject = objManagementClass.GetMethodParameters("GetStringValue")
            objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
            objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPath & strkey)
            objManagementBaseObject.SetPropertyValue("sValueName", "OriginalDescriptionURL")
            objManagementBaseObject = objManagementClass.InvokeMethod("GetStringValue", objManagementBaseObject, Nothing)
            myValue = objManagementBaseObject("sValue")

            If Not myValue = "" Then
                DataGridView5.Rows.Add(strkey, myValue)
            End If
        Next
        Return
    End Sub

    Private Sub DataGridView5_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs)
        Dim x As String
        x = DataGridView5.CurrentCell.Value
        RemoteCommand.Text = x
    End Sub

    Private Sub EXECUTECOMMAND(ByVal txtusername As String, ByVal txtpassword As String, ByVal txtdomain As String, ByVal txtpcname As String)
        Dim wmi_out As ManagementBaseObject
        Dim objManagementScope As ManagementScope
        Dim objManagementClass As ManagementClass
        Dim objManagementBaseObject As ManagementBaseObject
        Dim retValue As Integer
        Dim Command As String = RemoteCommand.Text
        Try
            If RemoteCommand.Text = "" Then
                Exit Sub
            End If
            Dim options As ConnectionOptions
            options = New ConnectionOptions()
            Dim computerconnect As String = "\\" & txtpcname & "\root\cimv2:Win32_Process"

            options.Username = txtusername
            options.Password = txtpassword
            options.Authority = "ntlmdomain:" & txtdomain

            objManagementScope = New ManagementScope(computerconnect, options)

            If objManagementScope.IsConnected = True Then
            Else
                Try
                    objManagementScope.Connect()
                Catch
                End Try
                If objManagementScope.IsConnected = False Then
                    MsgBox("Could not connect to PC name specified! Please check you inputed your username, password and domain correctly!")
                    Exit Sub
                End If
            End If

            objManagementClass = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
            objManagementClass.Scope = objManagementScope

            objManagementBaseObject = objManagementClass.GetMethodParameters("Create")
            objManagementBaseObject.SetPropertyValue("CommandLine", Command)
            wmi_out = objManagementClass.InvokeMethod("Create", objManagementBaseObject, Nothing)

            'wmi = New ManagementClass("\\" & txtpcname & "\root\cimv2:Win32_Process")
            'wmi_in = wmi.GetMethodParameters("Create")
            'wmi_in("CommandLine") = "cmd /c md c:\temp\temptd"
            'wmi_out = wmi.InvokeMethod("Create", wmi_in, Nothing)

            retValue = Convert.ToInt32(wmi_out("returnValue"))
            Select Case retValue
                Case 0
                    ' success!
                Case 2
                    Throw New ApplicationException("Access denied")
                Case 3
                    Throw New ApplicationException("Insufficient privilege")
                Case 8
                    Throw New ApplicationException("Unknown failure")
                Case 9
                    Throw New ApplicationException("Path not found")
                Case 21
                    Throw New ApplicationException("Invalid parameter")
                Case Else
                    Throw New ApplicationException("Unknown return code " & retValue)
            End Select
        Catch ex As Exception
            MsgBox(txtpcname & ": Can't create the process. " & ex.Message)
        End Try
    End Sub

    Private Sub ExecuteRemoteCommand_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If txtpcname = "" Then
            Exit Sub
        End If
        EXECUTECOMMAND(username, password, domain, txtpcname)
    End Sub

    Private Sub Form_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Me.Hide() 'or form.ShowDialog() for Modal forms
        Form2.Show() 'or form.ShowDialog() for Modal forms
    End Sub

    Private Sub DetectAPPV_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DetectAPPV.Click
        If txtpcname = "" Then
            Exit Sub
        End If
        Dim strValueName As String = Nothing
        Dim TextOutput As String = Nothing
        Dim TextOut As String = Nothing
        Dim strRead1 As String = Nothing
        Dim strRead2 As String = Nothing
        Dim strRead3 As String = Nothing
        Dim strRead4 As String = Nothing

        strValueName = "Version"
        strRead1 = GETAPPV(username, password, domain, txtpcname, strValueName)
        If strRead1 = "1" Then Exit Sub
        strValueName = "GlobalDataDirectorye"
        strRead2 = GETAPPV(username, password, domain, txtpcname, strValueName)
        strValueName = "UserDataDirectory"
        strRead3 = GETAPPV(username, password, domain, txtpcname, strValueName)
        strValueName = "CurrentDriveLetter"
        strRead4 = GETAPPVDRIVE(username, password, domain, txtpcname, strValueName)
        DataGridView2.Rows.Add(strRead1, strRead2, strRead3, strRead4)

        GETAPPVSERVERS(username, password, domain, txtpcname)
        GETAPPVPACKAGES(username, password, domain, txtpcname)
        GETAPPVAPPS(username, password, domain, txtpcname)
    End Sub
End Class