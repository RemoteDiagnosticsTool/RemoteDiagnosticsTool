Module GlobalVariables
    Dim Host As String
    Public username As String
    Public password As String
    Public domain As String
    Public txtpcname As String
    Public MachineName As String
    Public DetectedAPPVVersion As String
    Public IP4Address As String = String.Empty
    Public TotalPhysicalMemory As Long
    Public myFileVersionInfo As FileVersionInfo
    Public TEMPDIR As String = Environment.GetEnvironmentVariable("TEMP")
    Public EvaluateFlag As String = "False"
    Public LoggedOnUserNameFULL As String = Nothing
    Public LoggedOnUserNameOnly As String = Nothing
    Public SIDKEY As String = Nothing
    Public TreeviewKeysSelectedNode As String = Nothing
    Public Waitforcopy As Boolean = True
    Public WaitforInstall As Boolean = True
    Public WaitforRemove As Boolean = True
    Public WaitforInstallMSI As Boolean = True
    Public WaitforRemoveMSI As Boolean = True
    Public WaitforInstallAny As Boolean = True
    Public InstallResult As Integer = 1
    Public RemoveResult As Integer = 1
    Public NodenameSelected As String = ""
    Public ADDomainName As String = ""

End Module
