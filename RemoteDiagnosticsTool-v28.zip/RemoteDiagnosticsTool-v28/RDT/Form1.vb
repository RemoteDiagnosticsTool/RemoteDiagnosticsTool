Imports System.ComponentModel
Imports System.DirectoryServices

Public Class Form1
    Inherits MetroFramework.Forms.MetroForm

    Dim txtusername As String
    Dim txtpassword As String
    Dim txtdomain As String

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Useloggedonuser.Checked = False
        username.Focus()
        Activate()
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Dim response As MsgBoxResult
        response = MsgBox("Do you want to close this application down?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "Confirm")
        If response = MsgBoxResult.Yes Then
            Try
                'Dim sResult As String
                Dim objShell = CreateObject("Wscript.Shell")
                Try
                    'sResult = objShell.run("cmd /c net use * /d /y", 0, True)
                Catch ex As Exception
                End Try
            Catch
            End Try
            Dim pProcess() As Process = System.Diagnostics.Process.GetProcessesByName("RDT.exe")
            For Each p As Process In pProcess
                p.Kill()
            Next
            Me.Dispose()
        ElseIf response = MsgBoxResult.No Then
            e.Cancel = True
            Exit Sub
        End If
    End Sub

    Private Sub username_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles username.TextChanged
    End Sub

    Private Sub password_MaskInputRejected(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MaskInputRejectedEventArgs) Handles password.MaskInputRejected
    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click, MyBase.Enter, Button1.Enter
        If Useloggedonuser.Checked = False Then
            If username.Text = "" Then
                MsgBox("Your ""Username"" must be set properly and cannot be blank. Please input your account details correctly!")
                Exit Sub
            End If
            If password.Text = "" Then
                MsgBox("Your ""Password"" must be set properly and cannot be blank. Please input your account details correctly!")
                Exit Sub
            End If
            If Domain.Text = "" Then
                MsgBox("Your ""Domain"" must be set properly and cannot be blank. Please input your account details correctly!")
                Exit Sub
            End If
            txtusername = username.Text.ToLower
            txtpassword = password.Text
            txtdomain = Domain.Text.ToLower
        Else
            txtusername = Environment.GetEnvironmentVariable("USERNAME").ToLower
            txtdomain = Environment.GetEnvironmentVariable("USERDOMAIN").ToLower

            Passwordbox.ShowDialog()
            txtpassword = GlobalVariables.password

        End If


        Dim dirEntry As DirectoryEntry = New DirectoryEntry()
        Dim UExists As String
        Dim GroupsArray As New Collection
        Dim t As Long = 0
        Dim accessgroup As String
        Dim Groupaccessgranted As String = "No"
        Dim outputstringarray As Array
        Me.Cursor = Cursors.WaitCursor

        If txtdomain = "greenlnk" Or txtdomain = "greenlnk.net" Then
            UExists = UserExists()
            If UExists = "False" Then
                Me.Cursor = Cursors.Default
                Exit Sub
            Else
                GroupsArray = GetGroups()
                'MsgBox(GroupsArray.Count)

                For t = 1 To GroupsArray.Count
                    accessgroup = GroupsArray(t).ToString
                    'MsgBox(accessgroup)
                    outputstringarray = accessgroup.Split(",")
                    'MsgBox(outputstringarray(0))
                    accessgroup = outputstringarray(0).replace("CN=", "")
                    'MsgBox(accessgroup)

                    If accessgroup = "DLG.G.DesktopAdminTool" Then
                        Groupaccessgranted = "Yes"
                    End If
                Next
                If Groupaccessgranted = "No" Then
                    MsgBox("Access Denied : You need to be a member of the group DLG.G.DesktopAdminTool to use this Admin tool!")
                    Me.Cursor = Cursors.Default
                    Exit Sub
                End If
            End If
        End If

        Dim form5 As New Form5()
        form5.PassParam(txtusername, txtpassword, txtdomain)
        Me.Cursor = Cursors.Default
        Try
            form5.Show() 'or form.ShowDialog() for Modal forms
        Catch ex As InvalidOperationException
            form5.Show()
        End Try
        Me.Hide() 'or form.ShowDialog() for Modal forms

    End Sub

    ''' Method used to create an entry to the AD using a secure connection. 
    ''' <returns>DirectoryEntry</returns> 
    Public Shared Function GetDirectoryEntryGREENLNK(ByVal txtdomain As String, ByVal txtusername As String, ByVal txtpassword As String) As DirectoryEntry
        Dim dirEntry As New DirectoryEntry("LDAP://greenlnk.net/DC=greenlnk,DC=net")
        dirEntry.Username = txtdomain & "\" & txtusername
        dirEntry.Password = txtpassword
        dirEntry.AuthenticationType = AuthenticationTypes.Secure
        Return dirEntry
    End Function

    Private Function GetGroups() As Collection
        Dim Groups As New Collection
        Dim dirEntry As DirectoryEntry = GetDirectoryEntryGREENLNK(txtdomain, txtusername, txtpassword)
        Dim dirSearcher As New DirectorySearcher(dirEntry)
        ' dirSearcher.Filter = String.Format("(sAMAccountName={0}))", txtusername)
        dirSearcher.Filter = ("(&(objectClass=user)(samaccountname=" & txtusername & "))")
        dirSearcher.PropertiesToLoad.Add("memberOf")
        Dim dirSearchResults As SearchResult = dirSearcher.FindOne()

        Try
            Dim propCount As Long = 0

            propCount = dirSearchResults.Properties("memberOf").Count
            'MsgBox(propCount)

            For i As Integer = 0 To propCount - 1
                If Not Groups.Contains(dirSearchResults.Properties("memberOf")(i).ToString) Then
                    Groups.Add(dirSearchResults.Properties("memberOf")(i).ToString)
                    'MsgBox(dirSearchResults.Properties("memberOf")(i).ToString)
                End If
            Next

        Catch ex As Exception
            If ex.GetType Is GetType(System.NullReferenceException) Then
                MessageBox.Show("Selected user isn't a member of any groups " &
                                "at this time.", "No groups listed",
                                MessageBoxButtons.OK, MessageBoxIcon.Error)
                'they are still a good user just does not
                'have a "memberOf" attribute so it errors out.
                'code to do something else here if you want
            Else
                MessageBox.Show(ex.Message.ToString, "Search Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        End Try

        Return Groups
    End Function

    Public Function UserExists() As Boolean
        Try
            Dim de As DirectoryEntry = GetDirectoryEntryGREENLNK(txtdomain, txtusername, txtpassword)
            Dim deSearch As DirectorySearcher = New DirectorySearcher()
            deSearch.SearchRoot = de
            deSearch.Filter = "(&(objectClass=user) (cn=" & txtusername & "))"
            Dim results As SearchResultCollection = deSearch.FindAll()
            If results.Count = 0 Then
                Return False
            Else
                Return True
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Function

End Class
