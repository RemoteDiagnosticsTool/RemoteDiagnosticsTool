﻿Imports System
Imports Microsoft.Win32
Imports Microsoft.VisualBasic
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Management
Imports System.Runtime.InteropServices
Imports System.IO
Imports System.Net
Imports System.Text.RegularExpressions
Imports System.DirectoryServices
Imports System.Threading
Imports System.Text
Imports System.Security.AccessControl
Imports System.Security.Principal

Public Class StartupItems
    Inherits MetroFramework.Forms.MetroForm

    Private Sub StartupItems_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Text = "Startup Items on : " & MachineName
        On Error Resume Next
        Me.Cursor = Cursors.WaitCursor

        Dim strKeyPath As String = "SOFTWARE\Microsoft\Windows\CurrentVersion\Run"
        Dim strKeyPath2 As String = "SOFTWARE\WOW6432node\Microsoft\Windows\CurrentVersion\Run"
        Dim strKeyPathShell1 As String = "Software\Classes\Drive\ShellEx\ContextMenuHandlers"
        Dim strKeyPathShell2 As String = "Software\Wow6432Node\Classes\Drive\ShellEx\ContextMenuHandlers"
        Dim strKeyPathShell3 As String = "Software\Classes\Directory\ShellEx\ContextMenuHandlers"
        Dim strKeyPathShell4 As String = "Software\Wow6432Node\Classes\Directory\ShellEx\ContextMenuHandlers"
        Dim strKeyPathShell5 As String = "Software\Classes\Directory\Shellex\CopyHookHandlers"
        Dim strKeyPathShell6 As String = "Software\Wow6432Node\Classes\Directory\Shellex\CopyHookHandlers"
        Dim strKeyPathShell7 As String = "Software\Classes\Folder\ShellEx\ContextMenuHandlers"
        Dim strKeyPathShell8 As String = "Software\Wow6432Node\Classes\Folder\ShellEx\ContextMenuHandlers"
        Dim strKeyPathShell9 As String = "Software\Microsoft\Windows\CurrentVersion\Explorer\Browser Helper Objects"
        Dim strKeyPathShell10 As String = "Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\Browser Helper Objects"
        Dim strKeyPathShell11 As String = "Software\Microsoft\Internet Explorer\Extensions"
        Dim strKeyPathShell12 As String = "Software\Wow6432Node\Microsoft\Internet Explorer\Extensions"
        Dim strKeyPathShell13 As String = "System\CurrentControlSet\Services\WinSock2\Parameters\Protocol_Catalog9\Catalog_Entries"
        Dim strKeyPathShell14 As String = "System\CurrentControlSet\Services\WinSock2\Parameters\Protocol_Catalog9\Catalog_Entries64"
        Dim strKeyPathShell15 As String = "System\CurrentControlSet\Services\WinSock2\Parameters\NameSpace_Catalog5\Catalog_Entries"
        Dim strKeyPathShell16 As String = "System\CurrentControlSet\Services\WinSock2\Parameters\NameSpace_Catalog5\Catalog_Entries64"
        Dim strKeyPathShell17 As String = "SYSTEM\CurrentControlSet\Control\Print\Monitors"

        Const REG_SZ = 1
        Const REG_EXPAND_SZ = 2
        Const REG_BINARY = 3
        Const REG_DWORD = 4
        Const REG_MULTI_SZ = 7
        Const REG_QWORD = 11

        DataGridViewRun32.Rows.Clear()
        DataGridViewRun64.Rows.Clear()
        DataGridViewRunUser.Rows.Clear()
        DataGridViewShellEX1.Rows.Clear()
        DataGridViewShellEX2.Rows.Clear()
        DataGridViewShellEX3.Rows.Clear()
        DataGridViewShellEX4.Rows.Clear()
        DataGridViewIE1.Rows.Clear()
        DataGridViewIE2.Rows.Clear()
        DataGridViewIE3.Rows.Clear()
        DataGridViewIE4.Rows.Clear()
        DataGridViewNW1.Rows.Clear()
        DataGridViewNW2.Rows.Clear()
        DataGridViewNW3.Rows.Clear()
        DataGridViewNW4.Rows.Clear()
        DataGridViewPM.Rows.Clear()

        DataGridViewRun32.ColumnHeadersDefaultCellStyle.BackColor = Color.Cornsilk
        DataGridViewRun64.ColumnHeadersDefaultCellStyle.BackColor = Color.Cornsilk
        DataGridViewRunUser.ColumnHeadersDefaultCellStyle.BackColor = Color.Cornsilk
        DataGridViewShellEX1.ColumnHeadersDefaultCellStyle.BackColor = Color.Cornsilk
        DataGridViewShellEX2.ColumnHeadersDefaultCellStyle.BackColor = Color.Cornsilk
        DataGridViewShellEX3.ColumnHeadersDefaultCellStyle.BackColor = Color.Cornsilk
        DataGridViewShellEX4.ColumnHeadersDefaultCellStyle.BackColor = Color.Cornsilk
        DataGridViewIE1.ColumnHeadersDefaultCellStyle.BackColor = Color.Cornsilk
        DataGridViewIE2.ColumnHeadersDefaultCellStyle.BackColor = Color.Cornsilk
        DataGridViewIE3.ColumnHeadersDefaultCellStyle.BackColor = Color.Cornsilk
        DataGridViewIE4.ColumnHeadersDefaultCellStyle.BackColor = Color.Cornsilk
        DataGridViewNW1.ColumnHeadersDefaultCellStyle.BackColor = Color.Cornsilk
        DataGridViewNW2.ColumnHeadersDefaultCellStyle.BackColor = Color.Cornsilk
        DataGridViewNW3.ColumnHeadersDefaultCellStyle.BackColor = Color.Cornsilk
        DataGridViewNW4.ColumnHeadersDefaultCellStyle.BackColor = Color.Cornsilk
        DataGridViewPM.ColumnHeadersDefaultCellStyle.BackColor = Color.Cornsilk

        Dim intRegistryHive As Microsoft.Win32.RegistryHive
        intRegistryHive = Microsoft.Win32.RegistryHive.LocalMachine
        Dim strarray
        Dim objReg
        Dim objSWbemServices
        Dim objSWbemLocator
        Dim arrValueNames = Nothing
        Dim arrValueTypes = Nothing
        Dim strText = Nothing
        Dim i As Integer = 0
        Dim strValueName = Nothing
        Dim arrValues = Nothing
        Dim strvalue As String = Nothing
        Dim intValue As String = Nothing

        objSWbemLocator = CreateObject("wbemScripting.SwbemLocator")
        objSWbemLocator.Security_.AuthenticationLevel = 6 'Packet Privacy.
        objSWbemServices = objSWbemLocator.ConnectServer(txtpcname, "root\default", domain & "\" & username, password)
        objReg = objSWbemServices.Get("StdRegProv")
        objReg.EnumValues(intRegistryHive, strKeyPath, arrValueNames, arrValueTypes)
        For i = 0 To UBound(arrValueNames)
            strValueName = Nothing
            arrValues = Nothing
            strvalue = Nothing
            intValue = Nothing

            strValueName = arrValueNames(i)

            Select Case arrValueTypes(i)
                Case REG_SZ
                    objReg.GetStringValue(intRegistryHive, strKeyPath, strValueName, strvalue)
                    If strvalue <> "" Then
                        DataGridViewRun32.Rows.Add(strValueName, strvalue)
                    End If
            End Select
        Next

        arrValueNames = Nothing
        arrValueTypes = Nothing
        objReg.EnumValues(intRegistryHive, strKeyPath2, arrValueNames, arrValueTypes)
        For i = 0 To UBound(arrValueNames)
            strValueName = Nothing
            arrValues = Nothing
            strvalue = Nothing
            intValue = Nothing

            strValueName = arrValueNames(i)

            Select Case arrValueTypes(i)
                Case REG_SZ
                    objReg.GetStringValue(intRegistryHive, strKeyPath2, strValueName, strvalue)
                    If strvalue <> "" Then
                        DataGridViewRun64.Rows.Add(strValueName, strvalue)
                    End If
            End Select
        Next

        intRegistryHive = Microsoft.Win32.RegistryHive.Users
        Dim strKeyPath3 As String = SIDKEY & "\" & strKeyPath
        objReg.EnumValues(intRegistryHive, strKeyPath3, arrValueNames, arrValueTypes)
        For i = 0 To UBound(arrValueNames)
            strValueName = Nothing
            arrValues = Nothing
            strvalue = Nothing
            intValue = Nothing

            strValueName = arrValueNames(i)

            Select Case arrValueTypes(i)
                Case REG_SZ
                    objReg.GetStringValue(intRegistryHive, strKeyPath3, strValueName, strvalue)
                    If strvalue <> "" Then
                        DataGridViewRunUser.Rows.Add(strValueName, strvalue)
                    End If
            End Select
        Next

        Dim strComputerName As String = txtpcname
        Dim strStringValue As String = ""
        Dim objManagementScope As ManagementScope = Nothing
        Dim objManagementClass As ManagementClass = Nothing
        Dim objManagementBaseObject As ManagementBaseObject = Nothing
        Dim strkey As String
        Dim myKey As String
        Dim myValue As String
        Dim myValue1 As String
        Dim myValue2 As String
        Dim aSubKeys() As String = Nothing
        Dim strkey2 As String = Nothing
        Dim aSubKeys2() As String = Nothing
        Array.Clear(aSubKeys, 0, aSubKeys.Length)
        intRegistryHive = Microsoft.Win32.RegistryHive.LocalMachine
        Dim options As ConnectionOptions
        options = New ConnectionOptions()
        Dim computerconnect As String = "\\" & txtpcname & "\root\DEFAULT"
        options.Username = username
        options.Password = password
        options.Timeout = TimeSpan.FromSeconds(30)
        options.Authority = "NTLMDOMAIN:" & domain
        options.Authentication = AuthenticationLevel.PacketPrivacy
        objManagementScope = New ManagementScope(computerconnect, options)

        If objManagementScope.IsConnected = True Then
        Else
            objManagementScope.Connect()
        End If

        objManagementClass = New ManagementClass("stdRegProv")
        objManagementClass.Scope = objManagementScope
        objManagementBaseObject = objManagementClass.GetMethodParameters("EnumKey")
        objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
        objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPathShell1)
        aSubKeys = CType(objManagementClass.InvokeMethod("EnumKey", objManagementBaseObject, Nothing).Properties.Item("sNames").Value, String())
        For i = 0 To UBound(aSubKeys)
            Dim szValue As String = ""
            strKeyPath = strKeyPathShell1 & "\" & aSubKeys(i)
            objReg.GetStringValue(intRegistryHive, strKeyPath, "", szValue)
            If szValue <> "" Then
                Dim szValue2 As String = ""
                strKeyPath = "SOFTWARE\Classes\CLSID\" & szValue & "\InprocServer32"
                objReg.GetStringValue(intRegistryHive, strKeyPath, "", szValue2)
                If aSubKeys(i) <> "Sharing" And aSubKeys(i) <> "EnhancedStorageShell" Then
                    If szValue2 <> "" Then
                        DataGridViewShellEX1.Rows.Add(aSubKeys(i), szValue2)
                    End If
                End If
                strKeyPath = "SOFTWARE\Wow6432Node\Classes\CLSID\" & szValue & "\InprocServer32"
                objReg.GetStringValue(intRegistryHive, strKeyPath, "", szValue2)
                If aSubKeys(i) <> "Sharing" And aSubKeys(i) <> "EnhancedStorageShell" Then
                    If szValue2 <> "" Then
                        DataGridViewShellEX1.Rows.Add(aSubKeys(i), szValue2)
                    End If
                End If
            End If
        Next

        Array.Clear(aSubKeys, 0, aSubKeys.Length)
        objManagementClass = New ManagementClass("stdRegProv")
        objManagementClass.Scope = objManagementScope
        objManagementBaseObject = objManagementClass.GetMethodParameters("EnumKey")
        objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
        objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPathShell2)
        aSubKeys = CType(objManagementClass.InvokeMethod("EnumKey", objManagementBaseObject, Nothing).Properties.Item("sNames").Value, String())
        For i = 0 To UBound(aSubKeys)
            Dim szValue As String = ""
            strKeyPath = strKeyPathShell2 & "\" & aSubKeys(i)
            objReg.GetStringValue(intRegistryHive, strKeyPath, "", szValue)
            If szValue <> "" Then
                Dim szValue2 As String = ""
                strKeyPath = "SOFTWARE\Classes\CLSID\" & szValue & "\InprocServer32"
                objReg.GetStringValue(intRegistryHive, strKeyPath, "", szValue2)
                If aSubKeys(i) <> "Sharing" And aSubKeys(i) <> "EnhancedStorageShell" Then
                    If szValue2 <> "" Then
                        DataGridViewShellEX1.Rows.Add(aSubKeys(i), szValue2)
                    End If
                End If
                strKeyPath = "SOFTWARE\Wow6432Node\Classes\CLSID\" & szValue & "\InprocServer32"
                objReg.GetStringValue(intRegistryHive, strKeyPath, "", szValue2)
                If aSubKeys(i) <> "Sharing" And aSubKeys(i) <> "EnhancedStorageShell" Then
                    If szValue2 <> "" Then
                        DataGridViewShellEX1.Rows.Add(aSubKeys(i), szValue2)
                    End If
                End If
            End If
        Next

        Array.Clear(aSubKeys, 0, aSubKeys.Length)
        objManagementClass = New ManagementClass("stdRegProv")
        objManagementClass.Scope = objManagementScope
        objManagementBaseObject = objManagementClass.GetMethodParameters("EnumKey")
        objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
        objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPathShell3)
        aSubKeys = CType(objManagementClass.InvokeMethod("EnumKey", objManagementBaseObject, Nothing).Properties.Item("sNames").Value, String())
        For i = 0 To UBound(aSubKeys)
            Dim szValue As String = ""
            strKeyPath = strKeyPathShell3 & "\" & aSubKeys(i)
            objReg.GetStringValue(intRegistryHive, strKeyPath, "", szValue)
            If szValue <> "" Then
                Dim szValue2 As String = ""
                strKeyPath = "SOFTWARE\Classes\CLSID\" & szValue & "\InprocServer32"
                objReg.GetStringValue(intRegistryHive, strKeyPath, "", szValue2)
                If aSubKeys(i) <> "Sharing" And aSubKeys(i) <> "EncryptionMenu" And aSubKeys(i) <> "Offline Files" Then
                    If szValue2 <> "" Then
                        DataGridViewShellEX2.Rows.Add(aSubKeys(i), szValue2)
                    End If
                End If
                strKeyPath = "SOFTWARE\Wow6432Node\Classes\CLSID\" & szValue & "\InprocServer32"
                objReg.GetStringValue(intRegistryHive, strKeyPath, "", szValue2)
                If aSubKeys(i) <> "Sharing" And aSubKeys(i) <> "EncryptionMenu" And aSubKeys(i) <> "Offline Files" Then
                    If szValue2 <> "" Then
                        DataGridViewShellEX2.Rows.Add(aSubKeys(i), szValue2)
                    End If
                End If
            End If
        Next

        Array.Clear(aSubKeys, 0, aSubKeys.Length)
        objManagementClass = New ManagementClass("stdRegProv")
        objManagementClass.Scope = objManagementScope
        objManagementBaseObject = objManagementClass.GetMethodParameters("EnumKey")
        objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
        objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPathShell4)
        aSubKeys = CType(objManagementClass.InvokeMethod("EnumKey", objManagementBaseObject, Nothing).Properties.Item("sNames").Value, String())
        For i = 0 To UBound(aSubKeys)
            Dim szValue As String = ""
            strKeyPath = strKeyPathShell4 & "\" & aSubKeys(i)
            objReg.GetStringValue(intRegistryHive, strKeyPath, "", szValue)
            If szValue <> "" Then
                Dim szValue2 As String = ""
                strKeyPath = "SOFTWARE\Classes\CLSID\" & szValue & "\InprocServer32"
                objReg.GetStringValue(intRegistryHive, strKeyPath, "", szValue2)
                If aSubKeys(i) <> "Sharing" And aSubKeys(i) <> "EncryptionMenu" And aSubKeys(i) <> "Offline Files" Then
                    If szValue2 <> "" Then
                        DataGridViewShellEX2.Rows.Add(aSubKeys(i), szValue2)
                    End If
                End If
                strKeyPath = "SOFTWARE\Wow6432Node\Classes\CLSID\" & szValue & "\InprocServer32"
                objReg.GetStringValue(intRegistryHive, strKeyPath, "", szValue2)
                If aSubKeys(i) <> "Sharing" And aSubKeys(i) <> "EncryptionMenu" And aSubKeys(i) <> "Offline Files" Then
                    If szValue2 <> "" Then
                        DataGridViewShellEX2.Rows.Add(aSubKeys(i), szValue2)
                    End If
                End If
            End If
        Next

        Array.Clear(aSubKeys, 0, aSubKeys.Length)
        objManagementClass = New ManagementClass("stdRegProv")
        objManagementClass.Scope = objManagementScope
        objManagementBaseObject = objManagementClass.GetMethodParameters("EnumKey")
        objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
        objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPathShell5)
        aSubKeys = CType(objManagementClass.InvokeMethod("EnumKey", objManagementBaseObject, Nothing).Properties.Item("sNames").Value, String())
        For i = 0 To UBound(aSubKeys)
            Dim szValue As String = ""
            strKeyPath = strKeyPathShell5 & "\" & aSubKeys(i)
            objReg.GetStringValue(intRegistryHive, strKeyPath, "", szValue)
            If szValue <> "" Then
                Dim szValue2 As String = ""
                strKeyPath = "SOFTWARE\Classes\CLSID\" & szValue & "\InprocServer32"
                objReg.GetStringValue(intRegistryHive, strKeyPath, "", szValue2)
                If aSubKeys(i) <> "Sharing" And aSubKeys(i) <> "FileSystem" Then
                    If szValue2 <> "" Then
                        DataGridViewShellEX3.Rows.Add(aSubKeys(i), szValue2)
                    End If
                End If
                strKeyPath = "SOFTWARE\Wow6432Node\Classes\CLSID\" & szValue & "\InprocServer32"
                objReg.GetStringValue(intRegistryHive, strKeyPath, "", szValue2)
                If aSubKeys(i) <> "Sharing" And aSubKeys(i) <> "FileSystem" Then
                    If szValue2 <> "" Then
                        DataGridViewShellEX3.Rows.Add(aSubKeys(i), szValue2)
                    End If
                End If
            End If
        Next

        Array.Clear(aSubKeys, 0, aSubKeys.Length)
        objManagementClass = New ManagementClass("stdRegProv")
        objManagementClass.Scope = objManagementScope
        objManagementBaseObject = objManagementClass.GetMethodParameters("EnumKey")
        objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
        objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPathShell6)
        aSubKeys = CType(objManagementClass.InvokeMethod("EnumKey", objManagementBaseObject, Nothing).Properties.Item("sNames").Value, String())
        For i = 0 To UBound(aSubKeys)
            Dim szValue As String = ""
            strKeyPath = strKeyPathShell6 & "\" & aSubKeys(i)
            objReg.GetStringValue(intRegistryHive, strKeyPath, "", szValue)
            If szValue <> "" Then
                Dim szValue2 As String = ""
                strKeyPath = "SOFTWARE\Classes\CLSID\" & szValue & "\InprocServer32"
                objReg.GetStringValue(intRegistryHive, strKeyPath, "", szValue2)
                If aSubKeys(i) <> "Sharing" And aSubKeys(i) <> "FileSystem" Then
                    If szValue2 <> "" Then
                        DataGridViewShellEX3.Rows.Add(aSubKeys(i), szValue2)
                    End If
                End If
                strKeyPath = "SOFTWARE\Wow6432Node\Classes\CLSID\" & szValue & "\InprocServer32"
                objReg.GetStringValue(intRegistryHive, strKeyPath, "", szValue2)
                If aSubKeys(i) <> "Sharing" And aSubKeys(i) <> "FileSystem" Then
                    If szValue2 <> "" Then
                        DataGridViewShellEX3.Rows.Add(aSubKeys(i), szValue2)
                    End If
                End If
            End If
        Next

        Array.Clear(aSubKeys, 0, aSubKeys.Length)
        objManagementClass = New ManagementClass("stdRegProv")
        objManagementClass.Scope = objManagementScope
        objManagementBaseObject = objManagementClass.GetMethodParameters("EnumKey")
        objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
        objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPathShell7)
        aSubKeys = CType(objManagementClass.InvokeMethod("EnumKey", objManagementBaseObject, Nothing).Properties.Item("sNames").Value, String())
        For i = 0 To UBound(aSubKeys)
            Dim szValue As String = ""
            strKeyPath = strKeyPathShell7 & "\" & aSubKeys(i)
            objReg.GetStringValue(intRegistryHive, strKeyPath, "", szValue)
            If szValue <> "" Then
                Dim szValue2 As String = ""
                strKeyPath = "SOFTWARE\Classes\CLSID\" & szValue & "\InprocServer32"
                objReg.GetStringValue(intRegistryHive, strKeyPath, "", szValue2)
                If aSubKeys(i) <> "Sharing" And aSubKeys(i) <> "BriefcaseMenu" And aSubKeys(i) <> "Library Location" And aSubKeys(i) <> "Offline Files" Then
                    If szValue2 <> "" Then
                        DataGridViewShellEX4.Rows.Add(aSubKeys(i), szValue2)
                    End If
                End If
                strKeyPath = "SOFTWARE\Wow6432Node\Classes\CLSID\" & szValue & "\InprocServer32"
                objReg.GetStringValue(intRegistryHive, strKeyPath, "", szValue2)
                If aSubKeys(i) <> "Sharing" And aSubKeys(i) <> "BriefcaseMenu" And aSubKeys(i) <> "Library Location" And aSubKeys(i) <> "Offline Files" Then
                    If szValue2 <> "" Then
                        DataGridViewShellEX4.Rows.Add(aSubKeys(i), szValue2)
                    End If
                End If
            End If
        Next

        Array.Clear(aSubKeys, 0, aSubKeys.Length)
        objManagementClass = New ManagementClass("stdRegProv")
        objManagementClass.Scope = objManagementScope
        objManagementBaseObject = objManagementClass.GetMethodParameters("EnumKey")
        objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
        objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPathShell8)
        aSubKeys = CType(objManagementClass.InvokeMethod("EnumKey", objManagementBaseObject, Nothing).Properties.Item("sNames").Value, String())
        For i = 0 To UBound(aSubKeys)
            Dim szValue As String = ""
            strKeyPath = strKeyPathShell8 & "\" & aSubKeys(i)
            objReg.GetStringValue(intRegistryHive, strKeyPath, "", szValue)
            If szValue <> "" Then
                Dim szValue2 As String = ""
                strKeyPath = "SOFTWARE\Classes\CLSID\" & szValue & "\InprocServer32"
                objReg.GetStringValue(intRegistryHive, strKeyPath, "", szValue2)
                If aSubKeys(i) <> "Sharing" And aSubKeys(i) <> "BriefcaseMenu" And aSubKeys(i) <> "Library Location" And aSubKeys(i) <> "Offline Files" Then
                    If szValue2 <> "" Then
                        DataGridViewShellEX4.Rows.Add(aSubKeys(i), szValue2)
                    End If
                End If
                strKeyPath = "SOFTWARE\Wow6432Node\Classes\CLSID\" & szValue & "\InProcServer32"
                objReg.GetStringValue(intRegistryHive, strKeyPath, "", szValue2)
                If aSubKeys(i) <> "Sharing" And aSubKeys(i) <> "BriefcaseMenu" And aSubKeys(i) <> "Library Location" And aSubKeys(i) <> "Offline Files" Then
                    If szValue2 <> "" Then
                        DataGridViewShellEX4.Rows.Add(aSubKeys(i), szValue2)
                    End If
                End If
            End If
        Next

        Array.Clear(aSubKeys, 0, aSubKeys.Length)
        objManagementClass = New ManagementClass("stdRegProv")
        objManagementClass.Scope = objManagementScope
        objManagementBaseObject = objManagementClass.GetMethodParameters("EnumKey")
        objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
        objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPathShell9)
        aSubKeys = CType(objManagementClass.InvokeMethod("EnumKey", objManagementBaseObject, Nothing).Properties.Item("sNames").Value, String())
        For i = 0 To UBound(aSubKeys)
            Dim szValue1 As String = ""
            Dim szValue2 As String = ""
            Dim szValue3 As String = ""
            Dim szValue4 As String = ""

            strKeyPath = "SOFTWARE\Classes\CLSID\" & aSubKeys(i)
            objReg.GetStringValue(intRegistryHive, strKeyPath, "", szValue1)

            'strKeyPath = "SOFTWARE\Wow6432Node\Classes\CLSID\" & aSubKeys(i)
            'objReg.GetStringValue(intRegistryHive, strKeyPath, "", szValue2)

            strKeyPath = "SOFTWARE\Classes\CLSID\" & aSubKeys(i) & "\InprocServer32"
            objReg.GetStringValue(intRegistryHive, strKeyPath, "", szValue3)
            If szValue3 <> "" Then
                DataGridViewIE1.Rows.Add(szValue1, szValue3)
            End If

            'strKeyPath = "SOFTWARE\Wow6432Node\Classes\CLSID\" & aSubKeys(i) & "\InProcServer32"
            'objReg.GetStringValue(intRegistryHive, strKeyPath, "", szValue4)
            'If szValue4 <> "" Then
            'DataGridViewIE1.Rows.Add(szValue2, szValue4)
            'End If
        Next

        Array.Clear(aSubKeys, 0, aSubKeys.Length)
        objManagementClass = New ManagementClass("stdRegProv")
        objManagementClass.Scope = objManagementScope
        objManagementBaseObject = objManagementClass.GetMethodParameters("EnumKey")
        objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
        objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPathShell10)
        aSubKeys = CType(objManagementClass.InvokeMethod("EnumKey", objManagementBaseObject, Nothing).Properties.Item("sNames").Value, String())
        For i = 0 To UBound(aSubKeys)
            Dim szValue1 As String = ""
            Dim szValue2 As String = ""
            Dim szValue3 As String = ""
            Dim szValue4 As String = ""

            'strKeyPath = "SOFTWARE\Classes\CLSID\" & aSubKeys(i)
            'objReg.GetStringValue(intRegistryHive, strKeyPath, "", szValue1)

            strKeyPath = "SOFTWARE\Wow6432Node\Classes\CLSID\" & aSubKeys(i)
            objReg.GetStringValue(intRegistryHive, strKeyPath, "", szValue2)

            'strKeyPath = "SOFTWARE\Classes\CLSID\" & aSubKeys(i) & "\InprocServer32"
            'objReg.GetStringValue(intRegistryHive, strKeyPath, "", szValue3)
            'If szValue3 <> "" Then
            'DataGridViewIE2.Rows.Add(szValue1, szValue3)
            'End If

            strKeyPath = "SOFTWARE\Wow6432Node\Classes\CLSID\" & aSubKeys(i) & "\InProcServer32"
            objReg.GetStringValue(intRegistryHive, strKeyPath, "", szValue4)
            If szValue4 <> "" Then
                DataGridViewIE2.Rows.Add(szValue2, szValue4)
            End If
        Next

        Array.Clear(aSubKeys, 0, aSubKeys.Length)
        objManagementClass = New ManagementClass("stdRegProv")
        objManagementClass.Scope = objManagementScope
        objManagementBaseObject = objManagementClass.GetMethodParameters("EnumKey")
        objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
        objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPathShell11)
        aSubKeys = CType(objManagementClass.InvokeMethod("EnumKey", objManagementBaseObject, Nothing).Properties.Item("sNames").Value, String())
        For i = 0 To UBound(aSubKeys)
            Dim szValue1 As String = ""
            Dim szValue2 As String = ""
            Dim szValue3 As String = ""
            Dim szValue4 As String = ""

            strKeyPath = "SOFTWARE\Classes\CLSID\" & aSubKeys(i)
            objReg.GetStringValue(intRegistryHive, strKeyPath, "", szValue1)

            'strKeyPath = "SOFTWARE\Wow6432Node\Classes\CLSID\" & aSubKeys(i)
            'objReg.GetStringValue(intRegistryHive, strKeyPath, "", szValue2)

            strKeyPath = "SOFTWARE\Classes\CLSID\" & aSubKeys(i) & "\InprocServer32"
            objReg.GetStringValue(intRegistryHive, strKeyPath, "", szValue3)
            If szValue3 <> "" Then
                DataGridViewIE3.Rows.Add(szValue1, szValue3)
            End If

            'strKeyPath = "SOFTWARE\Wow6432Node\Classes\CLSID\" & aSubKeys(i) & "\InProcServer32"
            'objReg.GetStringValue(intRegistryHive, strKeyPath, "", szValue4)
            'If szValue4 <> "" Then
            'DataGridViewIE3.Rows.Add(szValue2, szValue4)
            'End If
        Next

        Array.Clear(aSubKeys, 0, aSubKeys.Length)
        objManagementClass = New ManagementClass("stdRegProv")
        objManagementClass.Scope = objManagementScope
        objManagementBaseObject = objManagementClass.GetMethodParameters("EnumKey")
        objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
        objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPathShell12)
        aSubKeys = CType(objManagementClass.InvokeMethod("EnumKey", objManagementBaseObject, Nothing).Properties.Item("sNames").Value, String())
        For i = 0 To UBound(aSubKeys)
            Dim szValue1 As String = ""
            Dim szValue2 As String = ""
            Dim szValue3 As String = ""
            Dim szValue4 As String = ""

            'strKeyPath = "SOFTWARE\Classes\CLSID\" & aSubKeys(i)
            'objReg.GetStringValue(intRegistryHive, strKeyPath, "", szValue1)

            strKeyPath = "SOFTWARE\Wow6432Node\Classes\CLSID\" & aSubKeys(i)
            objReg.GetStringValue(intRegistryHive, strKeyPath, "", szValue2)

            'strKeyPath = "SOFTWARE\Classes\CLSID\" & aSubKeys(i) & "\InprocServer32"
            'objReg.GetStringValue(intRegistryHive, strKeyPath, "", szValue3)
            'If szValue3 <> "" Then
            'DataGridViewIE4.Rows.Add(szValue1, szValue3)
            'End If

            strKeyPath = "SOFTWARE\Wow6432Node\Classes\CLSID\" & aSubKeys(i) & "\InProcServer32"
            objReg.GetStringValue(intRegistryHive, strKeyPath, "", szValue4)
            If szValue4 <> "" Then
                DataGridViewIE4.Rows.Add(szValue2, szValue4)
            End If
        Next

        Array.Clear(aSubKeys, 0, aSubKeys.Length)
        objManagementClass = New ManagementClass("stdRegProv")
        objManagementClass.Scope = objManagementScope
        objManagementBaseObject = objManagementClass.GetMethodParameters("EnumKey")
        objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
        objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPathShell13)
        aSubKeys = CType(objManagementClass.InvokeMethod("EnumKey", objManagementBaseObject, Nothing).Properties.Item("sNames").Value, String())
        For i = 0 To UBound(aSubKeys)
            Dim szValue As String = Nothing
            strKeyPath = ""
            strKeyPath = strKeyPathShell13 & "\" & aSubKeys(i)
            objReg.GetStringValue(intRegistryHive, strKeyPath, "ProtocolName", szValue)
            If szValue <> Nothing Then
                Dim chars As Char() = Nothing
                Array.Clear(chars, 0, chars.Length)
                chars = szValue.ToCharArray()
                If chars(0) <> "@" Then
                    objReg.GetBinaryValue(intRegistryHive, strKeyPath, "PackedCatalogItem", arrValues)
                    Dim S As String = Nothing
                    For Each strvalue In arrValues
                        Dim p As Integer = (strvalue)
                        Dim hex As String = Conversion.Hex(p)
                        S &= hex & " "
                    Next
                    Dim hexsplit = Split(S, " 0 ")
                    hexsplit(0) = Replace(hexsplit(0), " ", "")
                    hexsplit(0) = DecodeHex(hexsplit(0))
                    DataGridViewNW1.Rows.Add(szValue, hexsplit(0))
                End If
            End If
        Next

        Array.Clear(aSubKeys, 0, aSubKeys.Length)
        objManagementClass = New ManagementClass("stdRegProv")
        objManagementClass.Scope = objManagementScope
        objManagementBaseObject = objManagementClass.GetMethodParameters("EnumKey")
        objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
        objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPathShell15)
        aSubKeys = CType(objManagementClass.InvokeMethod("EnumKey", objManagementBaseObject, Nothing).Properties.Item("sNames").Value, String())
        For i = 0 To UBound(aSubKeys)
            Dim szValue3 As String = Nothing
            strKeyPath = ""
            strKeyPath = strKeyPathShell15 & "\" & aSubKeys(i)
            objReg.GetStringValue(intRegistryHive, strKeyPath, "DisplayString", szValue3)
            If szValue3 <> Nothing Then
                Dim chars As Char() = Nothing
                Array.Clear(chars, 0, chars.Length)
                chars = szValue3.ToCharArray()
                If chars(0) <> "@" Then
                    Dim szValue7 As String = ""
                    objReg.GetStringValue(intRegistryHive, strKeyPath, "LibraryPath", szValue7)
                    DataGridViewNW3.Rows.Add(szValue3, szValue7)
                End If
            End If
        Next

        Array.Clear(aSubKeys, 0, aSubKeys.Length)
        objManagementClass = New ManagementClass("stdRegProv")
        objManagementClass.Scope = objManagementScope
        objManagementBaseObject = objManagementClass.GetMethodParameters("EnumKey")
        objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
        objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPathShell14)
        aSubKeys = CType(objManagementClass.InvokeMethod("EnumKey", objManagementBaseObject, Nothing).Properties.Item("sNames").Value, String())
        For i = 0 To UBound(aSubKeys)
            Dim szValue2 As String = ""
            strKeyPath = ""
            strKeyPath = strKeyPathShell14 & "\" & aSubKeys(i)
            objReg.GetStringValue(intRegistryHive, strKeyPath, "ProtocolName", szValue2)
            If szValue2 <> "" Then
                Dim chars As Char() = Nothing
                Array.Clear(chars, 0, chars.Length)
                chars = szValue2.ToCharArray()
                If chars(0) <> "@" Then
                    objReg.GetBinaryValue(intRegistryHive, strKeyPath, "PackedCatalogItem", arrValues)
                    Dim S As String = Nothing
                    For Each strvalue In arrValues
                        Dim p As Integer = (strvalue)
                        Dim hex As String = Conversion.Hex(p)
                        S &= hex & " "
                    Next
                    Dim hexsplit = Split(S, " 0 ")
                    hexsplit(0) = Replace(hexsplit(0), " ", "")
                    hexsplit(0) = DecodeHex(hexsplit(0))
                    DataGridViewNW2.Rows.Add(szValue2, hexsplit(0))
                End If
            End If
        Next

        Array.Clear(aSubKeys, 0, aSubKeys.Length)
        objManagementClass = New ManagementClass("stdRegProv")
        objManagementClass.Scope = objManagementScope
        objManagementBaseObject = objManagementClass.GetMethodParameters("EnumKey")
        objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
        objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPathShell16)
        aSubKeys = CType(objManagementClass.InvokeMethod("EnumKey", objManagementBaseObject, Nothing).Properties.Item("sNames").Value, String())
        For i = 0 To UBound(aSubKeys)
            Dim szValue4 As String = ""
            strKeyPath = ""
            strKeyPath = strKeyPathShell16 & "\" & aSubKeys(i)
            objReg.GetStringValue(intRegistryHive, strKeyPath, "DisplayString", szValue4)
            If szValue4 <> "" Then
                Dim chars As Char() = Nothing
                Array.Clear(chars, 0, chars.Length)
                chars = szValue4.ToCharArray()
                If chars(0) <> "@" Then
                    Dim szValue8 As String = ""
                    objReg.GetStringValue(intRegistryHive, strKeyPath, "LibraryPath", szValue8)
                    DataGridViewNW4.Rows.Add(szValue4, szValue8)
                End If
            End If
        Next

        Array.Clear(aSubKeys, 0, aSubKeys.Length)
        objManagementClass = New ManagementClass("stdRegProv")
        objManagementClass.Scope = objManagementScope
        objManagementBaseObject = objManagementClass.GetMethodParameters("EnumKey")
        objManagementBaseObject.SetPropertyValue("hDefKey", CType("&H" & Hex(intRegistryHive), Long))
        objManagementBaseObject.SetPropertyValue("sSubKeyName", strKeyPathShell17)
        aSubKeys = CType(objManagementClass.InvokeMethod("EnumKey", objManagementBaseObject, Nothing).Properties.Item("sNames").Value, String())
        For i = 0 To UBound(aSubKeys)
            Dim szValue4 As String = ""
            strKeyPath = ""
            strKeyPath = strKeyPathShell17 & "\" & aSubKeys(i)
            objReg.GetStringValue(intRegistryHive, strKeyPath, "Driver", szValue4)
            If aSubKeys(i) <> "Local Port" And aSubKeys(i) <> "Microsoft Shared Fax Monitor" And aSubKeys(i) <> "Standard TCP/IP Port" And aSubKeys(i) <> "USB Monitor" And aSubKeys(i) <> "WSD Port" Then
                If szValue4 <> "" Then
                    DataGridViewPM.Rows.Add(aSubKeys(i), szValue4)
                End If
            End If
        Next

        DataGridViewRun32.Sort(DataGridViewRun32.Columns(0), System.ComponentModel.ListSortDirection.Ascending)
        DataGridViewRun64.Sort(DataGridViewRun64.Columns(0), System.ComponentModel.ListSortDirection.Ascending)
        DataGridViewRunUser.Sort(DataGridViewRunUser.Columns(0), System.ComponentModel.ListSortDirection.Ascending)
        DataGridViewShellEX1.Sort(DataGridViewShellEX1.Columns(0), System.ComponentModel.ListSortDirection.Ascending)
        DataGridViewShellEX2.Sort(DataGridViewShellEX2.Columns(0), System.ComponentModel.ListSortDirection.Ascending)
        DataGridViewShellEX3.Sort(DataGridViewShellEX3.Columns(0), System.ComponentModel.ListSortDirection.Ascending)
        DataGridViewShellEX4.Sort(DataGridViewShellEX4.Columns(0), System.ComponentModel.ListSortDirection.Ascending)
        DataGridViewIE1.Sort(DataGridViewIE1.Columns(0), System.ComponentModel.ListSortDirection.Ascending)
        DataGridViewIE2.Sort(DataGridViewIE2.Columns(0), System.ComponentModel.ListSortDirection.Ascending)
        DataGridViewIE3.Sort(DataGridViewIE3.Columns(0), System.ComponentModel.ListSortDirection.Ascending)
        DataGridViewIE4.Sort(DataGridViewIE4.Columns(0), System.ComponentModel.ListSortDirection.Ascending)
        DataGridViewNW1.Sort(DataGridViewNW1.Columns(0), System.ComponentModel.ListSortDirection.Ascending)
        DataGridViewNW2.Sort(DataGridViewNW2.Columns(0), System.ComponentModel.ListSortDirection.Ascending)
        DataGridViewNW3.Sort(DataGridViewNW3.Columns(0), System.ComponentModel.ListSortDirection.Ascending)
        DataGridViewNW4.Sort(DataGridViewNW4.Columns(0), System.ComponentModel.ListSortDirection.Ascending)
        DataGridViewPM.Sort(DataGridViewPM.Columns(0), System.ComponentModel.ListSortDirection.Ascending)

        Me.Cursor = Cursors.Default

    End Sub
    Private Function DecodeHex(ByVal HexString As String) As String
        Dim thisChar As String
        Dim ascii As Integer
        Dim ret As String = Nothing
        'Keep going until we exhaust all the source string
        Do While Len(HexString) > 0
            'Get the next two-digit hex number
            thisChar = HexString.Substring(0, 2)
            'Remove this hex number from the source string
            HexString = HexString.Substring(2)
            'Get the value in decimal of this hex number
            ascii = CInt(Val("&H" & thisChar))
            'Convert it to a character
            ret &= Chr(ascii)
        Loop
        'All done
        Return ret
    End Function

    Private Sub StartupItems_FormClosed(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles MyBase.FormClosed
        Form5.Focus()
    End Sub
End Class